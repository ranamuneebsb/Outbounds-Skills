"""
Per-run cost logging for the name-normalizer skill.

Same format as the company-scoring log so a single tail-and-grep workflow can
review both. One JSON line per run, appended to ~/.olympolabs/normalize-costs.log.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


DEFAULT_LOG_PATH = Path.home() / ".olympolabs" / "normalize-costs.log"


def append_run(record: Dict[str, Any], log_path: Path = DEFAULT_LOG_PATH) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(record)
    payload.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
    line = json.dumps(payload, ensure_ascii=False)
    with open(log_path, "a", encoding="utf-8") as fh:
        fh.write(line + "\n")
    os.chmod(log_path, 0o644)
