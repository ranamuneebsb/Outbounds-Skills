#!/usr/bin/env python3
"""
Name-normalizer orchestrator.

Reads a Google Sheet of leads, finds the first-name + company columns,
batches rows to an LLM that strips legal suffixes / titles / ALL-CAPS junk
and writes the cleaned values back IN PLACE.

Design:
- Batch size: 25 rows per LLM call. Cuts per-row token overhead ~10x vs
  one-call-per-row while keeping JSON output small enough that Flash-Lite
  is reliable.
- Concurrency: ThreadPoolExecutor with 16 workers by default. Each worker
  gets its own OpenRouterClient (no shared rate-limiter state).
- Writes are batched back to Sheets every --write-batch-size rows (default
  100).
- Preview mode (--preview N): print N rows side-by-side, DON'T write to the
  sheet. The SKILL.md uses this for user sign-off before committing the
  full run.
- Resume safety: the operation is idempotent (already-clean inputs come back
  unchanged), so a re-run after a crash just re-processes everything. Cost
  is low enough ($0.10-0.20 per 10k rows on Flash-Lite) that we don't add
  resume detection complexity.

Cost ballpark (Gemini 2.0 Flash-Lite, $0.075/$0.30 per M tokens):
  - ~80 input + 80 output tokens per row, ~25 rows per batch
  - One batch: ~2k in, ~2k out -> ~$0.00075
  - 1,000 rows: ~$0.03
  - 10,000 rows: ~$0.30
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Locate the shared foundations (openrouter-api, google-sheets-api).
_SKILLS_ROOT_CANDIDATES = [
    Path(__file__).resolve().parent.parent.parent,
    Path.home() / "Desktop" / "OlympoLabs-Skills",
]
_SKILLS_ROOT = next(
    (p for p in _SKILLS_ROOT_CANDIDATES if (p / "openrouter-api" / "client.py").exists()),
    None,
)
if _SKILLS_ROOT is None:
    sys.stderr.write(
        "ERROR: cannot locate the openrouter-api / google-sheets-api foundations.\n"
        "Tried:\n" + "".join(f"  - {p}\n" for p in _SKILLS_ROOT_CANDIDATES)
    )
    sys.exit(2)

sys.path.insert(0, str(Path(__file__).resolve().parent))  # for sibling modules

import importlib.util


def _load_module(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_name} from {file_path}")
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(Path(file_path).parent))
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


_or_client_mod = _load_module("or_client", _SKILLS_ROOT / "openrouter-api" / "client.py")
_or_pricing_mod = _load_module("or_pricing", _SKILLS_ROOT / "openrouter-api" / "pricing.py")
_gs_client_mod = _load_module("gs_client", _SKILLS_ROOT / "google-sheets-api" / "client.py")

OpenRouterClient = _or_client_mod.OpenRouterClient
OpenRouterError = _or_client_mod.OpenRouterError
or_estimate_cost = _or_pricing_mod.estimate_cost

SheetsClient = _gs_client_mod.SheetsClient
extract_sheet_id = _gs_client_mod.extract_sheet_id
col_index_to_letter = _gs_client_mod.col_index_to_letter

from column_detect import detect_columns  # noqa: E402
from cost_log import append_run            # noqa: E402
from prompts import SYSTEM_PROMPT, build_user_message  # noqa: E402


# ---- Constants ----

DEFAULT_MODEL = "google/gemini-2.5-flash"
DEFAULT_BATCH_SIZE = 25
DEFAULT_CONCURRENCY = 16
DEFAULT_WRITE_BATCH_SIZE = 100


# ---- Helpers ----


def is_blank(cell: Any) -> bool:
    return cell is None or (isinstance(cell, str) and not cell.strip())


def extract_first_name_from_full(full: str) -> str:
    """Split a full-name string on whitespace, return the first token.

    Used when the sheet has only a `name` column (no dedicated first_name).
    The LLM will still clean titles + caps from this token; we just give it a
    shorter starting point.
    """
    if not full:
        return ""
    s = str(full).strip()
    if not s:
        return ""
    # Quoted-nickname pattern: prefer the nickname if present.
    m = re.search(r'"([^"]+)"', s)
    if m:
        return m.group(1).strip()
    return s.split()[0]


# ---- Per-batch LLM call ----


class BatchNormalizer:
    """Runs one batch of rows through the LLM and returns a list of dicts.

    Maintains per-thread totals so the orchestrator can aggregate cost across
    workers at the end.
    """

    def __init__(self, model: str, or_client: OpenRouterClient):
        self._model = model
        self._or = or_client
        self.totals = {
            "calls": 0,
            "rows": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "cost_usd": 0.0,
            "errors": 0,
        }

    def normalize_batch(
        self,
        batch: List[Dict[str, Any]],
        *,
        max_retries: int = 2,
    ) -> List[Dict[str, str]]:
        """Send one batch to the LLM and return cleaned results.

        Each input row is {"idx": int, "first_name": str, "company": str}.
        Returns the same list with first_name and company normalized. On a
        hard parse failure after retries, returns the originals unchanged
        and increments the error counter (better to write the raw value back
        than to write nothing - but in practice we just skip the write so
        the cell keeps its current value).
        """
        attempts = 0
        last_err: Optional[Exception] = None
        while attempts <= max_retries:
            attempts += 1
            try:
                resp = self._or.chat(
                    model=self._model,
                    messages=[
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": build_user_message(batch)},
                    ],
                    json_mode=True,
                    temperature=0.0,
                    max_tokens=4000,
                )
                parsed = self._or.parse_json_content(resp)
                usage = self._or.usage_tokens(resp)
                cost = or_estimate_cost(
                    self._model,
                    input_tokens=usage["input"],
                    output_tokens=usage["output"],
                    cached_input_tokens=usage.get("cached_input", 0),
                )
                self.totals["calls"] += 1
                self.totals["rows"] += len(batch)
                self.totals["input_tokens"] += usage["input"]
                self.totals["output_tokens"] += usage["output"]
                self.totals["cost_usd"] += cost

                results_raw = parsed.get("results")
                if not isinstance(results_raw, list):
                    raise OpenRouterError(
                        f"Response missing 'results' array: {parsed!r}"
                    )

                # Build idx -> {first_name, company}; tolerate missing or extra entries.
                by_idx: Dict[int, Dict[str, str]] = {}
                for entry in results_raw:
                    if not isinstance(entry, dict):
                        continue
                    try:
                        idx_val = int(entry["idx"])
                    except (KeyError, TypeError, ValueError):
                        continue
                    fn_val = entry.get("first_name", "")
                    co_val = entry.get("company", "")
                    by_idx[idx_val] = {
                        "first_name": str(fn_val or ""),
                        "company": str(co_val or ""),
                    }

                # Fill in any missing idx slots from the original batch (no-op).
                out: List[Dict[str, str]] = []
                for row in batch:
                    idx = int(row["idx"])
                    if idx in by_idx:
                        out.append({
                            "idx": idx,
                            "first_name": by_idx[idx]["first_name"],
                            "company": by_idx[idx]["company"],
                        })
                    else:
                        # Model dropped this row. Fall back to passthrough so the
                        # caller can still decide what to do with it (we mark
                        # passthrough by sentinel for visibility).
                        out.append({
                            "idx": idx,
                            "first_name": row.get("first_name", ""),
                            "company": row.get("company", ""),
                            "__passthrough": True,
                        })
                return out
            except (OpenRouterError, json.JSONDecodeError, KeyError) as exc:
                last_err = exc
                continue
        # Out of retries; pass through and record error
        self.totals["errors"] += 1
        return [
            {
                "idx": int(r["idx"]),
                "first_name": r.get("first_name", ""),
                "company": r.get("company", ""),
                "__passthrough": True,
                "__error": str(last_err)[:200] if last_err else "unknown",
            }
            for r in batch
        ]


# ---- Argparse + main ----


def main() -> int:
    parser = argparse.ArgumentParser(description="Normalize first names + company names in a Google Sheet or CSV file.")
    # Input source: either --sheet-url OR --csv-path (one required)
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--sheet-url", help="Google Sheets URL or ID")
    src.add_argument("--csv-path", help="Path to a CSV file. Read + write back via the file system (no Sheets API needed).")
    parser.add_argument("--csv-out", help=(
        "Output path for CSV mode. Default: writes to <input>_normalized.csv "
        "as a sibling file (preserves the original). Pass --csv-out same to "
        "overwrite the input file in place (matching the Sheets behavior)."
    ))
    parser.add_argument("--worksheet", help="Worksheet/tab title; defaults to the first tab (Sheets mode only)")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--first-name-col", type=int, help="Override 1-based first-name column (0 = none)")
    parser.add_argument("--full-name-col", type=int, help="Override 1-based full-name column (0 = none)")
    parser.add_argument("--company-col", type=int, help="Override 1-based company column (0 = none)")
    parser.add_argument("--max-rows", type=int, help="Cap number of rows processed (for testing)")
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE)
    parser.add_argument("--concurrency", type=int, default=DEFAULT_CONCURRENCY)
    parser.add_argument("--write-batch-size", type=int, default=DEFAULT_WRITE_BATCH_SIZE)
    parser.add_argument(
        "--preview",
        type=int,
        metavar="N",
        help=(
            "Preview mode: normalize the first N rows, print a side-by-side "
            "comparison to stdout, DO NOT write anything to the sheet or CSV. "
            "Used for ICP-style sign-off before the full run."
        ),
    )
    parser.add_argument("--dry-run", action="store_true", help="Print plan, don't call APIs or write back")
    args = parser.parse_args()

    csv_mode = bool(args.csv_path)
    if csv_mode and args.worksheet:
        sys.stderr.write("WARNING: --worksheet is ignored in CSV mode.\n")

    # --preview N implies --max-rows N
    if args.preview:
        if args.preview < 1:
            sys.stderr.write("ERROR: --preview N must be >= 1.\n")
            return 2
        args.max_rows = args.preview

    # ---- Resolve input source: Sheets or CSV ----
    # We end up with `headers` (list[str]) + `data_rows` (list[list[str]]) in either mode.
    # `ctx` carries mode-specific I/O state for the write-back step.
    sheet_id: Optional[str] = None
    worksheet_title: Optional[str] = None
    sheets: Optional[Any] = None
    csv_raw_rows: Optional[List[List[str]]] = None  # full file including header, kept in memory for rewriting

    if csv_mode:
        import csv as _csv
        csv_in = Path(args.csv_path).expanduser().resolve()
        if not csv_in.exists():
            sys.stderr.write(f"ERROR: --csv-path not found: {csv_in}\n")
            return 3
        print(f"CSV: {csv_in}")
        with csv_in.open(newline="", encoding="utf-8") as f:
            csv_raw_rows = [list(r) for r in _csv.reader(f)]
        if not csv_raw_rows:
            sys.stderr.write("ERROR: CSV is empty\n")
            return 3
        rows = csv_raw_rows
    else:
        sheet_id = extract_sheet_id(args.sheet_url)
        print(f"Sheet: {sheet_id}")
        sheets = SheetsClient()
        worksheets = sheets.list_worksheets(sheet_id)
        if not worksheets:
            sys.stderr.write("ERROR: spreadsheet has no worksheets\n")
            return 3
        if args.worksheet:
            ws = next((w for w in worksheets if w["title"] == args.worksheet), None)
            if not ws:
                sys.stderr.write(
                    f"ERROR: worksheet {args.worksheet!r} not found. Available: "
                    + ", ".join(w["title"] for w in worksheets) + "\n"
                )
                return 3
        else:
            ws = worksheets[0]
        worksheet_title = ws["title"]
        print(f"Worksheet: {worksheet_title!r} ({ws['rowCount']} rows x {ws['columnCount']} cols)")
        rows = sheets.read_full_sheet(sheet_id, worksheet_title)

    if not rows:
        sys.stderr.write("ERROR: input is empty\n")
        return 3
    headers = rows[0]
    data_rows = rows[1:]
    print(f"Headers ({len(headers)}): {[str(h) for h in headers]}")
    print(f"Data rows: {len(data_rows)}")

    # ---- Detect / confirm columns ----
    detected = detect_columns(headers)
    if args.first_name_col is not None:
        detected["first_name"] = args.first_name_col or None
    if args.full_name_col is not None:
        detected["full_name"] = args.full_name_col or None
    if args.company_col is not None:
        detected["company"] = args.company_col or None

    print(f"Detected columns: {detected}")

    if not detected.get("first_name") and not detected.get("full_name"):
        sys.stderr.write(
            "ERROR: could not detect a first-name or full-name column. "
            "Pass --first-name-col N or --full-name-col N.\n"
        )
        return 4
    if not detected.get("company"):
        sys.stderr.write(
            "ERROR: could not detect a company column. Pass --company-col N.\n"
        )
        return 4

    # Pick the active name-source column. If both exist, prefer first_name.
    if detected.get("first_name"):
        name_col_idx = detected["first_name"]
        name_source = "first_name"
    else:
        name_col_idx = detected["full_name"]
        name_source = "full_name"
    company_col_idx = detected["company"]
    print(f"Using {name_source!r} from column {name_col_idx} and 'company' from column {company_col_idx}.")

    # ---- Build the pending list ----
    pending: List[Dict[str, Any]] = []
    for i, row in enumerate(data_rows):
        sheet_row_idx = i + 2  # row 1 is the header
        raw_name = row[name_col_idx - 1] if name_col_idx - 1 < len(row) else ""
        raw_company = row[company_col_idx - 1] if company_col_idx - 1 < len(row) else ""

        if is_blank(raw_name) and is_blank(raw_company):
            continue  # nothing to normalize

        first_name_input = ""
        if name_source == "first_name":
            first_name_input = str(raw_name or "").strip()
        else:
            first_name_input = extract_first_name_from_full(str(raw_name or ""))

        pending.append({
            "sheet_row_idx": sheet_row_idx,
            "first_name_input": first_name_input,
            "company_input": str(raw_company or "").strip(),
            # Track raw originals for the preview side-by-side
            "raw_name_cell": str(raw_name or ""),
            "raw_company_cell": str(raw_company or ""),
        })

        if args.max_rows and len(pending) >= args.max_rows:
            break

    print(f"Rows queued for normalization: {len(pending)}")
    if not pending:
        print("Nothing to do.")
        return 0

    if args.dry_run:
        print("\n=== DRY RUN ===")
        for p in pending[:5]:
            print(f"  row {p['sheet_row_idx']}: name={p['first_name_input']!r} company={p['company_input']!r}")
        if len(pending) > 5:
            print(f"  ... and {len(pending) - 5} more")
        return 0

    # ---- Chunk into batches ----
    batches: List[List[Dict[str, Any]]] = []
    bs = max(1, int(args.batch_size))
    for start in range(0, len(pending), bs):
        chunk = pending[start:start + bs]
        # Build the JSON payload for the LLM (idx is the position within the batch).
        payload = [
            {
                "idx": j,
                "first_name": item["first_name_input"],
                "company": item["company_input"],
            }
            for j, item in enumerate(chunk)
        ]
        batches.append(payload)
    print(f"Sending {len(batches)} batches of up to {bs} rows each, concurrency={args.concurrency}.")

    # ---- Run batches concurrently ----
    thread_local = threading.local()
    normalizers_list: List[BatchNormalizer] = []
    normalizers_lock = threading.Lock()

    def get_normalizer() -> BatchNormalizer:
        if not hasattr(thread_local, "normalizer"):
            bn = BatchNormalizer(model=args.model, or_client=OpenRouterClient())
            with normalizers_lock:
                normalizers_list.append(bn)
            thread_local.normalizer = bn
        return thread_local.normalizer

    started_at = time.time()
    # Map batch_index -> list of result dicts (same length, idx-aligned)
    results_by_batch: Dict[int, List[Dict[str, Any]]] = {}
    results_lock = threading.Lock()

    def process_batch(batch_idx: int, batch: List[Dict[str, Any]]):
        bn = get_normalizer()
        out = bn.normalize_batch(batch)
        with results_lock:
            results_by_batch[batch_idx] = out
        return batch_idx

    with ThreadPoolExecutor(max_workers=max(1, args.concurrency)) as ex:
        futures = [ex.submit(process_batch, bi, b) for bi, b in enumerate(batches)]
        done = 0
        for fut in as_completed(futures):
            fut.result()
            done += 1
            if done % 5 == 0 or done == len(batches):
                print(f"  ... {done}/{len(batches)} batches done")

    elapsed_llm = time.time() - started_at

    # ---- Reassemble results in row order ----
    normalized: List[Dict[str, Any]] = []  # parallel to `pending`
    for bi, payload in enumerate(batches):
        batch_results = results_by_batch.get(bi, [])
        result_by_idx = {int(r["idx"]): r for r in batch_results if "idx" in r}
        for j, _payload_row in enumerate(payload):
            r = result_by_idx.get(j, {})
            pending_row = pending[bi * bs + j]
            normalized.append({
                "sheet_row_idx": pending_row["sheet_row_idx"],
                "name_source": name_source,
                "raw_name_cell": pending_row["raw_name_cell"],
                "raw_company_cell": pending_row["raw_company_cell"],
                "first_name_input": pending_row["first_name_input"],
                "company_input": pending_row["company_input"],
                "first_name_clean": str(r.get("first_name", "")),
                "company_clean": str(r.get("company", "")),
                "passthrough": bool(r.get("__passthrough", False)),
                "error": r.get("__error"),
            })

    # ---- Preview path: print side-by-side, exit before any writes ----
    if args.preview:
        print(f"\n=== PREVIEW: first {len(normalized)} rows (no writes performed) ===\n")
        # Compute column widths from data, capped so wide rows don't blow up the terminal
        rows_to_show = normalized
        col_widths = {
            "row": max(3, max(len(str(r["sheet_row_idx"])) for r in rows_to_show)),
            "name_in": min(30, max(len("name (raw)"), max(len(r["raw_name_cell"][:60]) for r in rows_to_show))),
            "name_out": min(20, max(len("name (clean)"), max(len(r["first_name_clean"]) for r in rows_to_show))),
            "co_in": min(40, max(len("company (raw)"), max(len(r["raw_company_cell"][:60]) for r in rows_to_show))),
            "co_out": min(40, max(len("company (clean)"), max(len(r["company_clean"]) for r in rows_to_show))),
        }
        header = (
            f"{'row':<{col_widths['row']}}  "
            f"{'name (raw)':<{col_widths['name_in']}}  ->  "
            f"{'name (clean)':<{col_widths['name_out']}}    |    "
            f"{'company (raw)':<{col_widths['co_in']}}  ->  "
            f"{'company (clean)':<{col_widths['co_out']}}"
        )
        print(header)
        print("-" * len(header))
        for r in rows_to_show:
            print(
                f"{str(r['sheet_row_idx']):<{col_widths['row']}}  "
                f"{r['raw_name_cell'][:col_widths['name_in']]:<{col_widths['name_in']}}  ->  "
                f"{r['first_name_clean'][:col_widths['name_out']]:<{col_widths['name_out']}}    |    "
                f"{r['raw_company_cell'][:col_widths['co_in']]:<{col_widths['co_in']}}  ->  "
                f"{r['company_clean'][:col_widths['co_out']]:<{col_widths['co_out']}}"
            )

        # Print cost rollup for the preview
        totals = _aggregate_totals(normalizers_list)
        print(f"\nPreview: {len(rows_to_show)} rows in {elapsed_llm:.1f}s. "
              f"LLM cost: ${totals['cost_usd']:.4f} "
              f"(in={totals['input_tokens']} out={totals['output_tokens']} "
              f"calls={totals['calls']} errors={totals['errors']}).")
        return 0

    # ---- Write back ----
    # We update two cells per affected row: name column + company column.
    # In Sheets mode we call batch_write to the Sheets API.
    # In CSV mode we mutate the in-memory rows and write the whole file back once.
    write_started = time.time()
    written = 0
    skipped = 0

    if csv_mode:
        # Resolve output path
        csv_in = Path(args.csv_path).expanduser().resolve()
        if args.csv_out is None:
            csv_out = csv_in.with_name(csv_in.stem + "_normalized" + csv_in.suffix)
        elif args.csv_out.lower() == "same":
            csv_out = csv_in
        else:
            csv_out = Path(args.csv_out).expanduser().resolve()

        print(f"\nWriting normalized CSV to {csv_out} (overwriting columns {name_col_idx} and {company_col_idx})...")
        # csv_raw_rows is the full file kept in memory. Mutate name/company cells in-place,
        # then write the whole file.
        # IMPORTANT: sheet_row_idx is 1-based across header+data. Row 1 = header, so
        # data row i corresponds to csv_raw_rows index (sheet_row_idx - 1).
        for r in normalized:
            if r["passthrough"]:
                skipped += 1
                continue
            file_row_idx = r["sheet_row_idx"] - 1  # convert 1-based to 0-based
            # Make sure the row is long enough (some CSV rows may be ragged)
            while len(csv_raw_rows[file_row_idx]) <= max(name_col_idx, company_col_idx) - 1:
                csv_raw_rows[file_row_idx].append("")
            csv_raw_rows[file_row_idx][name_col_idx - 1] = r["first_name_clean"]
            csv_raw_rows[file_row_idx][company_col_idx - 1] = r["company_clean"]
            written += 1

        import csv as _csv
        csv_out.parent.mkdir(parents=True, exist_ok=True)
        with csv_out.open("w", newline="", encoding="utf-8") as f:
            w = _csv.writer(f)
            w.writerows(csv_raw_rows)
        print(f"  -> wrote {csv_out}")
        elapsed_write = time.time() - write_started
    else:
        name_col_letter = col_index_to_letter(name_col_idx)
        company_col_letter = col_index_to_letter(company_col_idx)
        pending_writes: List[Dict[str, Any]] = []

        def flush_writes() -> None:
            nonlocal pending_writes
            if not pending_writes:
                return
            to_flush = pending_writes
            pending_writes = []
            sheets.batch_write(sheet_id, to_flush)

        print(f"\nWriting normalized values back to columns {name_col_letter} and {company_col_letter}...")
        for r in normalized:
            if r["passthrough"]:
                skipped += 1
                continue
            sheet_row_idx = r["sheet_row_idx"]
            # Two separate single-cell writes per row (different non-contiguous columns).
            pending_writes.append({
                "range": f"{worksheet_title}!{name_col_letter}{sheet_row_idx}",
                "values": [[r["first_name_clean"]]],
            })
            pending_writes.append({
                "range": f"{worksheet_title}!{company_col_letter}{sheet_row_idx}",
                "values": [[r["company_clean"]]],
            })
            written += 1
            if len(pending_writes) >= args.write_batch_size * 2:
                flush_writes()
                print(f"  ... {written}/{len(normalized)} rows written")

        flush_writes()
        elapsed_write = time.time() - write_started

    # ---- Cost summary ----
    totals = _aggregate_totals(normalizers_list)
    print(f"\nNormalized {written} rows in {elapsed_llm:.1f}s LLM + {elapsed_write:.1f}s write.")
    print(f"Skipped (passthrough/error): {skipped}")
    print(f"\nCost summary:")
    print(f"  Model: {args.model}")
    print(f"  Calls: {totals['calls']}  Rows: {totals['rows']}  Errors: {totals['errors']}")
    print(f"  Tokens: in={totals['input_tokens']} out={totals['output_tokens']}")
    print(f"  TOTAL: ${totals['cost_usd']:.4f}")

    # ---- Log run ----
    append_run({
        "mode": "csv" if csv_mode else "sheets",
        "sheet_id": sheet_id,
        "sheet_url": args.sheet_url,
        "csv_path": args.csv_path,
        "worksheet": worksheet_title,
        "model": args.model,
        "rows_normalized": written,
        "rows_skipped": skipped,
        "name_source": name_source,
        "llm_calls": totals["calls"],
        "input_tokens": totals["input_tokens"],
        "output_tokens": totals["output_tokens"],
        "errors": totals["errors"],
        "total_cost_usd": round(totals["cost_usd"], 6),
        "elapsed_llm_seconds": round(elapsed_llm, 2),
        "elapsed_write_seconds": round(elapsed_write, 2),
    })
    return 0


def _aggregate_totals(normalizers: List[BatchNormalizer]) -> Dict[str, Any]:
    """Sum per-worker totals across all BatchNormalizers used in this run."""
    rollup = {
        "calls": 0,
        "rows": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "cost_usd": 0.0,
        "errors": 0,
    }
    for n in normalizers:
        for k in ("calls", "rows", "input_tokens", "output_tokens", "errors"):
            rollup[k] += n.totals.get(k, 0)
        rollup["cost_usd"] += n.totals.get("cost_usd", 0.0)
    return rollup


if __name__ == "__main__":
    sys.exit(main())
