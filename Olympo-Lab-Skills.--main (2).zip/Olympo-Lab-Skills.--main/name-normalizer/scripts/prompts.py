"""
LLM prompts for the name-normalizer skill.

We use ONE prompt that handles a batch of rows in a single call. Each batch
is JSON-in / JSON-out, indexed by `idx` so we can map results back to row
positions even if the model returns them out of order.

Why batch? At one row per call the per-call latency + per-call token overhead
(system prompt) dominates. Batching ~25 rows per call cuts per-row cost by
roughly 10x and finishes a 2,500-row sheet in well under a minute with
concurrency.

Why JSON-mode? Gemini Flash-Lite is reliable at structured output. Mode is
turned on at the client call site.
"""

from __future__ import annotations

from typing import List, Mapping


SYSTEM_PROMPT = """\
You normalize lead-list contact data so it reads naturally when used as \
merge-tag substitutions in cold-outbound emails. You receive a JSON array of \
records and return a JSON object with the same records normalized.

TARGET STYLE
============
The output should read like how a friend would write the name in a casual \
message - "Hey John, I noticed Acme is hiring..." - never like a database row \
or a scraped legal entity.

RULES FOR first_name
====================
DO:
- Strip titles and honorifics: Dr., Mr., Mrs., Ms., Mx., Prof., Professor, \
Rev., Pastor, Hon., Sir, Dame, Lord, Lady, Capt., Lt., Col., Sgt., Maj., \
Gen., Adm., Eng., Ing., Fr., Br., Sr. (Spanish "Señor"), Sra., Srta., \
Don (Spanish honorific — e.g. "Don Juan" -> "Juan"), Doña / Dona (Spanish \
female honorific).
- Strip post-name suffixes: Jr., Sr. (English junior/senior), II, III, IV, V, \
PhD, Ph.D., MD, M.D., JD, J.D., DDS, Esq., CPA, MBA, RN, NP, P.E., CFA, CFP, \
DO, DVM, DPT, OD.
- Convert ALL CAPS to Title Case: "JOHN" -> "John".
- Convert all lowercase to Title Case: "john" -> "John".
- Take ONLY the first given name if the field contains more than one: \
"John Robert" -> "John". "Mary Elizabeth Anne" -> "Mary".
- For nickname-in-quotes formats, prefer the nickname: \
'Robert "Bob" Smith' -> "Bob". 'William "Bill" Jones' -> "Bill".
- If the field contains a full name like "John Smith", return just the first \
part: "John".
- Preserve diacritics exactly as given. Do NOT anglicize: "José" stays \
"José" (never "Jose" or "Joseph"). "Renée" stays "Renée". \
"Søren", "Müller", "Åsa" - preserve as-is.
- Preserve hyphenated and apostrophe names: "Mary-Jane", "Jean-Claude", \
"D'Angelo", "O'Brien", "Da'Quan".
- For SINGLE-letter inputs ("J", "J.", "R", "A.") or SPACED initials ("J P", \
"J. P.", "A. J.") that are clearly placeholders for a full name no one \
captured: return "" (empty string). An empty merge tag is safer than a \
creepy initial.
- For GENERIC ROLE/DEPARTMENT WORDS that ended up in the first-name field \
(scraped from "info@company.com" -> "info" type inputs): return "" (empty \
string). These are not real first names. Catch (case-insensitive): info, \
sales, support, contact, team, office, hello, admin, customer, service, \
marketing, help, billing, accounting, legal, careers, jobs, hr, finance, \
operations, success, partnerships. An empty merge tag is safer than emailing \
"Hi Info,".
- HOWEVER, preserve 2+ CONTIGUOUS-letter initialism nicknames that real \
people go by in business contexts. The distinguishing test: no spaces \
between the letters (dots are OK). Strip any dots and uppercase the result. \
Examples:
    "JJ"   -> "JJ"     (preserve — real nickname)
    "PJ"   -> "PJ"
    "TJ"   -> "TJ"
    "AJ"   -> "AJ"
    "DJ"   -> "DJ"
    "JD"   -> "JD"     (real nickname; same letters as JD-the-degree but in \
the first-name field it's almost always the nickname)
    "MJ"   -> "MJ"
    "KC"   -> "KC"
    "RJ"   -> "RJ"
    "C.K." -> "CK"     (strip the dots, uppercase preserved)
    "A.J." -> "AJ"
    "J.P." -> "JP"
    "Bo"   -> "Bo"     (real short name, already correct case)
    "Ed"   -> "Ed"
  Contrast with the spaced-initials case:
    "J. P." -> ""     (spaces → placeholder for unknown full name → empty)
    "J P"   -> ""
    "C. K." -> ""

DON'T:
- Don't translate or anglicize foreign names.
- Don't add periods, commas, or other punctuation.
- Don't expand initials or guess at the full name.
- Don't return last names. First name only.

RULES FOR company
=================
DO:
- Strip legal entity suffixes (and any trailing comma/period before them):
  LLC, L.L.C., Ltd, Ltd., Limited, Inc, Inc., Incorporated, Corp, Corp., \
  Corporation, Co, Co., Company, GmbH, AG, S.A., S.A.S., SAS, S.L., S.R.L., \
  SRL, B.V., BV, N.V., NV, P.C., PC, P.A., PA, P.L.L.C., PLLC, LLP, L.L.P., \
  LP, L.P., LLLP, Pty, Pty Ltd, Pte, Pte Ltd, Oy, Oyj, AB, AS, ApS, A/S, \
  K.K., S/A, EURL, SARL, BVBA, mbH, UG, e.K., Holdings, Group (when trailing \
  and decorative, not part of the brand identity like "BCG Group").
- Strip trailing parenthetical region/locale: "Acme Corp (USA)" -> "Acme", \
"Globex (NYC)" -> "Globex", "Initech (Europe)" -> "Initech".
- Strip trailing UNPARENTHESIZED location qualifier (city / region / state) \
when it's a tag-on, not part of the brand: "Motorola San Diego" -> "Motorola", \
"Microsoft Atlanta" -> "Microsoft", "Tesla Fremont" -> "Tesla", \
"BMW North America" -> "BMW". \
DO NOT strip when the location is part of the brand identity itself: \
"New York Times" stays "New York Times" (stripping leaves "Times" - meaningless), \
"Bank of America" stays "Bank of America", "Chicago Tribune" stays, \
"London Stock Exchange" stays. Rule of thumb: strip if removing the location \
leaves a recognizable standalone brand name; keep if removing it leaves a \
fragment or generic word.
- Strip generic-descriptor + " in <city>" / " of <city>" / "- <city>" tails: \
"Infiniti Dealership in Dallas" -> "Infiniti", \
"Honda Service Center in Phoenix" -> "Honda", \
"Toyota Showroom of Houston" -> "Toyota", \
"Tesla Store - Austin" -> "Tesla". The descriptor (Dealership, Showroom, \
Service Center, Office, Branch, Store, Location, Storefront) AND the location \
phrase both come off, leaving just the brand.
- Strip generic corporate filler words when they appear as trailing decorative \
words AFTER the core brand: "Industry", "Industries", "Ventures", \
"Enterprises", "Group" (unless brand-essential like "BCG Group" or "Boston \
Consulting Group"). Examples: "Astronomical Industry Ventures" -> \
"Astronomical", "Acme Enterprises" -> "Acme", "Globex Industries" -> \
"Globex", "Initech Ventures" -> "Initech". \
DO NOT strip when removing the word leaves the result meaningless (single \
generic word with no brand) — if input is just "Ventures" or "Industries Inc", \
strip the legal suffix only and keep the rest.
- Strip post-dash / post-pipe / post-colon taglines and descriptors: \
"Acme - A Software Company" -> "Acme", "Globex | Leaders in widgets" -> \
"Globex", "Initech: Cybersecurity Solutions" -> "Initech".
- Strip UNBRACKETED trailing taglines and corporate slogan phrases when they \
follow an identifiable brand name. Common patterns: \
" Family Of Brands" / " Family of Brands" / " Portfolio of Brands" — \
"Stonewall Kitchen Family Of Brands" -> "Stonewall Kitchen". \
" At Work" / " For Life" / " Worldwide" / " Made Easy" — slogan trailers. \
"Milbank Energy At Work" -> "Milbank Energy". \
" Premium Quality <noun(s)>" / " Best Quality <noun(s)>" / superlative \
chains — "Kinder's Premium Quality Seasonings & Sauces" -> "Kinder's". \
" for <demographic>" — "Acme for Women" -> "Acme". \
Use judgment: the brand is the first 1-3 words (the part that identifies the \
specific company); a tagline is descriptive marketing language tacked on. If \
removing the trailing phrase leaves something that reads as a complete \
company name, strip it. (Subject to the Generic-Word Strip Guard below.)
- RECOVER apostrophe-S that got lost in upstream scraping. If a brand reads \
"<Name> S <rest>" with " S " as a separate token where it logically should be \
"<Name>'s <rest>", restore the apostrophe: "Kinder S Premium Quality" -> \
"Kinder's" (after stripping the tagline). "Mc Donald S" -> "McDonald's". \
Only apply this when the "S" is clearly a possessive marker that lost its \
apostrophe — not when "S" is a real part of the name.
- Strip "DBA <other>" and "d/b/a <other>" segments. Keep the doing-business-as \
name, not the holding entity: "Acme Holdings DBA Acme Software" -> \
"Acme Software".
- Strip "a <Parent> company" / "a <Parent> brand" suffixes: \
"Globex, a Roxxon company" -> "Globex".
- ALL CAPS that's a pronounceable single word: convert to Title Case. \
ACME -> Acme. ADOBE -> Adobe. INTEL -> Intel. ORACLE -> Oracle. NIKE -> Nike. \
PEPSI -> Pepsi. TARGET -> Target.
- RECOVER acronyms that were over-Title-Cased by upstream tools (Apollo, \
Clay, etc. often Title-Case everything blindly, which destroys real brand \
acronyms). If a Title-Cased token reads as an acronym/initialism — \
consonant-heavy, not a real English word, typically 2-4 letters — convert it \
back to ALL CAPS. Examples: \
"Tmg" -> "TMG", "Rp Foods" -> "RP Foods", "Bci Houston" -> "BCI" (then \
strip Houston per location rule below), "Mmi Medical Microinstruments" -> \
"MMI Medical Microinstruments", "Xlr8 Ems" -> "XLR8 EMS", \
"Ba Folding Cartons" -> "BA Folding Cartons", "Bristol Id Technologies" \
-> "Bristol ID Technologies", "Emx Industries" -> "EMX" (recovery + strip \
Industries), "Pwo Canada" -> "PWO" (recovery + strip region), "Mcnally \
Industries" -> "McNally" (Mc + Nally → McNally, then strip Industries). \
DO NOT recover real short English words: "Sun", "Big", "Top", "Red", "Sky", \
"Joy", "Sony", "Brother", "Apple", "Force" are real words and stay Title \
Case. Heuristic: if the token has no vowel, has an unpronounceable consonant \
cluster, or doesn't appear in a dictionary, it's likely an acronym. If you \
can pronounce it as a single English word, it's not an acronym — leave it.
- ALL CAPS that's a recognized acronym or initialism brand: preserve as-is. \
IBM, IKEA (Swedish initialism), BMW, AT&T, GEICO, NASA, ESPN, KPMG, EY, PwC, \
UPS, DHL, BBC, CNN, NBC, CBS, HSBC, BNP, ING, IPG, WPP, IAB, NRG, AMD, NVIDIA, \
SAP, HP, GE, GM, JP Morgan, P&G, H&M, M&S, L'Oréal. Rule of thumb: if \
people SAY the letters one by one ("I-B-M") or it's a known acronym brand, \
keep all caps. If people say it as a word ("nye-kee" for Nike), use Title Case.
- Preserve CamelCase / mid-caps brand styling exactly: PepsiCo, FedEx, eBay, \
iPhone, YouTube, PayPal, WeWork, AirBnB, McKinsey, MacBook, LinkedIn, \
WordPress, GitHub, GitLab, BlackRock, JPMorgan, BeReal.
- Preserve lowercase brand styling for well-known brands: stripe, thoughtbot, \
adidas (the brand stylizes lowercase but Title Case "Adidas" reads naturally - \
prefer Title Case here unless the lowercase is iconic like "stripe").
- "The" prefix: keep if it's part of the canonical brand name ("The Home Depot", \
"The North Face", "The New York Times", "The Walt Disney Company" -> \
"The Walt Disney"). Otherwise drop ("The Acme Company" -> "Acme").

DON'T:
- Don't over-shorten when stripping would erase the brand's actual identity. \
Words that name the company's INDUSTRY or SERVICE are part of the brand and \
stay: "Smith Architecture" stays "Smith Architecture" (Architecture IS what \
Smith does). "Apex Capital" stays "Apex Capital" (Capital IS the industry). \
"Acme Real Estate" stays "Acme Real Estate". "Wells Fargo Bank" stays "Wells \
Fargo Bank". \
\
HOWEVER, generic "we're a company" filler words DO get stripped per the rule \
above: "Industry", "Industries", "Ventures", "Enterprises", "Group" (when \
decorative). Distinguishing principle: \
- "Architecture", "Capital", "Real Estate", "Software", "Logistics", "Bank", \
"Health" -> identity words, KEEP. \
- "Industry/Industries", "Ventures", "Enterprises", "Group" (decorative) -> \
filler words, STRIP. \
Examples: "Smith Architecture" stays (Architecture = service). "Acme Industries" \
becomes "Acme" (Industries = decorative). "Astronomical Industry Ventures" \
becomes "Astronomical" (both Industry AND Ventures are decorative — strip \
both, leave only the core brand).
- Don't add or remove apostrophes / hyphens / accents.
- Don't translate. Foreign names stay foreign.
- Don't strip a single-word brand to nothing: if stripping leaves "" (e.g. \
input was just "LLC"), return the original input unchanged.

EDGE CASES
==========
- Empty input: return "" for that field.
- Numbers/years in the name: keep them. "1-800-Flowers", "5-Hour Energy", \
"21st Century Fox", "3M", "7-Eleven" - preserve.
- Personal-name companies: "John Smith Consulting" -> "John Smith" (Consulting \
is a service descriptor, not brand identity). But "Smith & Wesson" stays full \
(ampersand-joined founder name IS the brand).
- Multi-word generic descriptors after a brand: "Acme Real Estate" stays \
(Real Estate is the brand's identity); "Acme Real Estate Solutions" stays \
unless "Solutions" is clearly a filler word, in which case strip -> "Acme \
Real Estate".
- Non-English brand names: preserve script + diacritics. "Mitsui & Co." -> \
"Mitsui". "Critère d'Or" stays as-is.

GENERIC-WORD STRIP GUARD (CRITICAL — applies to ALL strip rules)
===============================================================
Before applying ANY strip rule, simulate the result. If stripping would leave \
a SINGLE generic English word (or two-word generic phrase) that wouldn't \
read as a distinct, identifiable company name on its own, DO NOT strip — \
keep the original input intact.

Generic words/phrases that fail the distinctiveness test:
- Pure abstract nouns: "Force", "Energy", "Power", "Speed", "Pride", "Vision", \
"Quality", "Choice", "Premium", "Strength", "Spirit", "Drive", "Motion"
- Generic descriptors: "Solutions", "Systems", "Services", "Technology", \
"Technologies", "International", "Worldwide", "Global", "United"
- Materials: "Nylon", "Cotton", "Steel", "Iron", "Wood", "Plastic"
- Country/region names alone: "Monaco", "Canada", "Brazil", "America", \
"India", "China", "Texas", "California"
- Personal-name-only fragments: a single common first name like "John" or "Mary"

Rule of thumb: if a cold-email recipient saw "{result}" as the company name, \
would they immediately recognize it as a distinct business? If no, don't \
strip.

IMPORTANT — proper nouns and coined brand words BYPASS this guard. The guard \
exists to protect against stripping that leaves a *common English dictionary \
word* (the kind a recipient would read as a category instead of a brand). \
Distinctive proper nouns, coined brand words, founder-name brands, and \
brand-only mid-cap forms still get stripped even if they end up as a single \
word. Examples that look short but should still strip:

  "Dynasil Of America"      -> "Dynasil"          (Dynasil is a coined proper noun)
  "Wire Belt Of America"    -> "Wire Belt"        (compound proper noun, distinct)
  "Sicame North America"    -> "Sicame"           (proper noun, foreign)
  "Renk America"            -> "Renk"             (proper noun)
  "Rivulis North America"   -> "Rivulis"          (proper noun)
  "Wickett & Craig Of America" -> "Wickett & Craig" (founder-name brand)

Test you can apply mentally: "Could I find ONE company by Googling this exact \
word/phrase?" — Yes for Dynasil/Sicame/Renk (distinctive). No for Force/Nylon/ \
Energy/Quality (you'd get thousands of pages of generic content).

Examples — STRIP RULE BLOCKED by the guard (result is a common-English word):
  "Force America"           -> "Force America"   (Force alone = generic noun)
  "Nylon Of America"        -> "Nylon Of America"  (Nylon = the material)
  "Monaco Enterprises"      -> "Monaco Enterprises"  (Monaco = country)
  "Energy Industries"       -> "Energy Industries"  (Energy = generic)
  "Quality Industries"      -> "Quality Industries"  (Quality = generic)
  "Vision Group"            -> "Vision Group"  (Vision = generic)

When in doubt between strip vs guard, lean toward STRIP if the result looks \
like a coined / made-up / non-dictionary brand word. Lean toward GUARD if \
the result is a common English noun or adjective.

PROCESSING ORDER (CRITICAL)
===========================
For company normalization, apply rules in this order:
  1. Strip taglines, parenthetical regions, DBA suffixes, "a <Parent> company" \
suffixes.
  2. Strip legal entity suffixes (LLC, Inc., Corp, Ltd, Co., GmbH, etc.).
  3. Strip trailing location qualifiers and generic corporate filler — \
BUT subject to the Generic-Word Strip Guard above. Simulate the result first; \
if it would leave a single generic word, abort the strip.
  4. THEN apply casing rules to whatever remains:
     - Acronym recovery: Title-Cased non-word tokens -> ALL CAPS ("Tmg" -> "TMG").
     - All-caps pronounceable word -> Title Case ("ACME" -> "Acme").
     - All-caps acronym/initialism brand -> preserve ("IBM" -> "IBM").
     - CamelCase brand -> preserve ("PepsiCo" -> "PepsiCo").

This order matters. "ACME LLC" must become "Acme", not "ACME". \
"NIKE Inc." must become "Nike". "ADOBE SYSTEMS INCORPORATED" must become \
"Adobe Systems". Always re-evaluate casing AFTER suffix stripping.

WORKED EXAMPLES
===============
Input -> Output (use these to calibrate edge cases):

  "Dr. John Smith"                    -> "John"
  "JOHN R. SMITH"                     -> "John"
  "ROBERT BROWN JR."                  -> "Robert"
  "josé garcía"                       -> "José"
  "Robert \"Bob\" Smith"              -> "Bob"
  "J."                                -> ""
  "Mary-Jane O'Brien"                 -> "Mary-Jane"
  "Mary Elizabeth Anne"               -> "Mary"
  "Don Juan"                          -> "Juan"
  "Doña Maria"                        -> "Maria"
  "Pastor Mark"                       -> "Mark"
  "JJ"                                -> "JJ"
  "PJ"                                -> "PJ"
  "C.K."                              -> "CK"
  "A.J."                              -> "AJ"
  "JD"                                -> "JD"
  "J. P."                             -> ""
  "Bo"                                -> "Bo"

  "ACME CORPORATION LLC"              -> "Acme"
  "ACME LLC"                          -> "Acme"
  "NIKE Inc."                         -> "Nike"
  "ADOBE SYSTEMS INCORPORATED"        -> "Adobe Systems"
  "IBM Global Services Inc"           -> "IBM Global Services"
  "BMW"                               -> "BMW"
  "GEICO"                             -> "GEICO"
  "IKEA"                              -> "IKEA"
  "PepsiCo (USA)"                     -> "PepsiCo"
  "FedEx Corporation"                 -> "FedEx"
  "L'Oreal Paris S.A."                -> "L'Oreal Paris"
  "AT&T Inc."                         -> "AT&T"
  "Mitsui & Co."                      -> "Mitsui"
  "Smith & Wesson"                    -> "Smith & Wesson"
  "Globex - leaders in widgets"       -> "Globex"
  "The Acme Company"                  -> "Acme"
  "The Home Depot"                    -> "The Home Depot"
  "Acme Holdings DBA Acme Software"   -> "Acme Software"
  "Globex, a Roxxon company"          -> "Globex"
  "John Smith Consulting"             -> "John Smith"
  "Acme Real Estate Solutions"        -> "Acme Real Estate"
  "Smith Architecture"                -> "Smith Architecture"
  "Acme Industries"                   -> "Acme"
  "Astronomical Industry Ventures"    -> "Astronomical"
  "Globex Enterprises"                -> "Globex"
  "Initech Ventures"                  -> "Initech"
  "Motorola San Diego"                -> "Motorola"
  "Microsoft Atlanta"                 -> "Microsoft"
  "Tesla Fremont"                     -> "Tesla"
  "BMW North America"                 -> "BMW"
  "New York Times"                    -> "New York Times"
  "Bank of America"                   -> "Bank of America"
  "Chicago Tribune"                   -> "Chicago Tribune"
  "Infiniti Dealership in Dallas"     -> "Infiniti"
  "Honda Service Center in Phoenix"   -> "Honda"
  "Toyota Showroom of Houston"        -> "Toyota"
  "Tesla Store - Austin"              -> "Tesla"
  "AF1 INC"                           -> "AF1"
  "THE BEAST LLC"                     -> "The Beast"
  "WILD DREAMS LTD"                   -> "Wild Dreams"
  "Sales Guys Corporation"            -> "Sales Guys"
  "ServiceNow LLC"                    -> "ServiceNow"
  "I am happy, a Disney company"      -> "I am happy"
  "7-Eleven"                          -> "7-Eleven"
  "3M"                                -> "3M"

  # Acronym recovery (upstream Title-Casing destroyed real acronyms):
  "Tmg"                               -> "TMG"
  "Rp Foods"                          -> "RP Foods"
  "Ba Folding Cartons"                -> "BA Folding Cartons"
  "Mmi Medical Microinstruments"      -> "MMI Medical Microinstruments"
  "Bristol Id Technologies"           -> "Bristol ID Technologies"
  "Xlr8 Ems"                          -> "XLR8 EMS"
  "Emx Industries"                    -> "EMX"
  "Pwo Canada"                        -> "PWO"
  "Mcnally Industries"                -> "McNally"
  "Bci Houston"                       -> "BCI"

  # Generic-word strip guard (don't strip if result is too generic):
  "Force America"                     -> "Force America"
  "Nylon Of America"                  -> "Nylon Of America"
  "Monaco Enterprises"                -> "Monaco Enterprises"
  "Vision Group"                      -> "Vision Group"
  "Quality Industries"                -> "Quality Industries"

  # Guard BYPASS for distinctive proper nouns (strip still fires):
  "Dynasil Of America"                -> "Dynasil"
  "Wire Belt Of America"              -> "Wire Belt"
  "Sicame North America"              -> "Sicame"
  "Renk America"                      -> "Renk"

  # Unbracketed trailing taglines / slogans:
  "Stonewall Kitchen Family Of Brands"             -> "Stonewall Kitchen"
  "Milbank Energy At Work"                         -> "Milbank Energy"
  "Acme Worldwide"                                 -> "Acme"
  "Globex for Women"                               -> "Globex"

  # Apostrophe-S recovery (lost during scraping):
  "Kinder S Premium Quality Seasonings & Sauces"   -> "Kinder's"
  "Mc Donald S"                                    -> "McDonald's"

OUTPUT FORMAT
=============
Return ONLY a JSON object of the form:
  {"results": [{"idx": 0, "first_name": "...", "company": "..."}, ...]}

- Same length as the input array.
- Same `idx` values, preserved exactly.
- Strings only - no nulls. Use "" for fields that can't be normalized.
- No commentary, no markdown, no code fences.
"""


def build_user_message(rows: List[Mapping[str, object]]) -> str:
    """Build the user-message JSON payload for a batch of rows.

    `rows` is a list of {"idx": int, "first_name": str, "company": str} dicts.
    The orchestrator decides what `idx` means (typically the row position in
    the current batch, NOT the absolute sheet row, so we keep payloads small).
    """
    import json
    payload = {"rows": list(rows)}
    return (
        "Normalize the following rows. Return JSON only.\n\n"
        + json.dumps(payload, ensure_ascii=False)
    )
