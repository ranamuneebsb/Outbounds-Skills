"""
Column detection for the name-normalizer skill.

Looks at the header row and identifies which columns are:
  - first_name : the contact's first name (or a full-name column we'll split)
  - company    : the human-readable company / account name

Returns 1-based column indices so the orchestrator can map directly to A1
notation via col_index_to_letter(). Returns None when nothing matched - the
SKILL.md asks the user to confirm or override in that case.

The two columns are mandatory inputs (we won't normalize a column that
isn't there). full_name vs first_name is distinguished so the orchestrator
knows whether to extract the first token before normalizing.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Sequence


def _normalize(s: Any) -> str:
    """Lowercase + strip non-alphanumeric for header matching."""
    if s is None:
        return ""
    text = str(s).lower()
    text = re.sub(r"[^a-z0-9]", "", text)
    return text


# Headers that contain JUST a first name (or "given name").
# Matched before full-name patterns so a sheet with both gets first_name.
FIRST_NAME_PATTERNS: List[str] = [
    r"^(first|given|forename|fore)(name)?$",
    r"^fname$",
    r"^(contact|lead|rep|prospect|customer|user|owner|primary|decisionmaker)(first|given)(name)?$",
    r"^(firstnameofcontact|contactsfirstname)$",
]

# Headers that contain a full name (we'll split on whitespace and take the
# first token if no dedicated first_name column exists).
FULL_NAME_PATTERNS: List[str] = [
    r"^(full|contact|lead|rep|prospect|customer|owner|primary)?name$",
    r"^(fullname|contactname|leadname|repname|prospectname|ownername)$",
    r"^(decisionmakername|personname|peoplename)$",
]

# Company / account name patterns.
COMPANY_PATTERNS: List[str] = [
    r"^(company|account|organization|organisation|business|firm|employer|brand)(name)?$",
    r"^(companyname|accountname|orgname|businessname|firmname)$",
    r"^(legalname|tradename|tradingname|displayname|dbaname)$",
]


def _first_match(headers: Sequence[Any], patterns: Sequence[str]) -> Optional[int]:
    """Return the 1-based index of the first header matching any pattern."""
    normalized = [_normalize(h) for h in headers]
    for pattern in patterns:
        regex = re.compile(pattern)
        for idx, h in enumerate(normalized, start=1):
            if h and regex.fullmatch(h):
                return idx
    return None


def detect_columns(headers: Sequence[Any]) -> Dict[str, Optional[int]]:
    """Detect first_name (or full_name) and company columns.

    Resolution order for the name column:
      1. A dedicated first-name column wins if present.
      2. Otherwise, a full-name column is used and the orchestrator splits it.

    Returns:
        {
            "first_name": 3,   # 1-based col index, or None
            "full_name":  None,
            "company":    1,
        }

    `first_name` and `full_name` are mutually informative - the orchestrator
    should prefer first_name when it's set. They are returned separately so
    the SKILL.md can be transparent about which column it's using.
    """
    first_name = _first_match(headers, FIRST_NAME_PATTERNS)
    full_name = _first_match(headers, FULL_NAME_PATTERNS)
    company = _first_match(headers, COMPANY_PATTERNS)

    # Edge case: if first_name and full_name both matched the same column
    # (a sheet with just one "Name" column), prefer the full_name reading
    # so the orchestrator knows to split.
    if first_name and full_name and first_name == full_name:
        first_name = None

    return {
        "first_name": first_name,
        "full_name": full_name,
        "company": company,
    }
