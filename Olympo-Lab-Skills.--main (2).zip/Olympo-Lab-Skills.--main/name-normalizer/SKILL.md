---
name: name-normalizer
description: Normalize first-name and company-name columns in a Google Sheet or local CSV so they read naturally as cold-email merge tags. Strips legal suffixes (LLC, Inc, Corp, Ltd, GmbH), titles (Dr., Mr., PhD), trailing location qualifiers (Motorola San Diego → Motorola), generic corporate filler (Industries, Ventures, Enterprises), parent-company clauses ("X, a Disney company" → X), and unbracketed taglines ("Family Of Brands", "At Work"). Title-Cases ALL-CAPS junk while preserving real acronym brands (IBM, IKEA, BMW). RECOVERS acronyms that upstream tools (Apollo, Clay) over-Title-Cased (Tmg → TMG, Bci → BCI). Preserves diacritics. Overwrites originals in place. Trigger when user wants to "clean up names", "normalize a lead list", "strip LLC from company names", "remove titles", "fix ALL CAPS", "fix wrong-case acronyms", "prep a list for merge tags", or after company-scoring + filtering, before copywriter. Powered by Gemini 2.5 Flash at ~$0.15 per 1,000 rows. Uses ~/.olympolabs/openrouter.json for the LLM key.
---

# Name Normalizer

Clean up the `{{first_name}}` and `{{company}}` merge tags in a lead list so cold emails read like a human wrote them. Wraps two foundations:

- `openrouter-api/` (LLM call to Gemini 2.5 Flash)
- `google-sheets-api/` (ADC auth, read + write back to the sheet in batches)

## What this skill does and doesn't do

**Does:**

- Reads a Google Sheet of leads
- Auto-detects the `first_name` (or `full_name`) and `company` columns
- For each row, sends the raw values to an LLM that applies a strict normalization ruleset:
  - **First names:** strip titles (Dr., Mr., Prof., Esq., PhD), take the first given name only, ALL CAPS → Title Case, preserve diacritics + hyphens + apostrophes, never anglicize
  - **Company names:** strip legal entity suffixes (LLC, Inc., Corp, Ltd, GmbH, S.A., Pty, etc.), strip parenthetical regions, strip post-dash taglines, ALL CAPS → Title Case UNLESS the value is a real acronym/initialism brand (IBM, IKEA, BMW, GEICO, KPMG, NASA), preserve CamelCase brands (PepsiCo, FedEx, eBay)
- Writes the cleaned values back **in place** (overwrites the original cells)
- Batches 25 rows per LLM call + 16 concurrent workers — finishes a 5k-row sheet in ~1-2 minutes
- Logs per-run cost to `~/.olympolabs/normalize-costs.log`

**Does NOT:**

- Add or remove rows
- Touch any column other than the two it's normalizing
- Score leads — that's `company-scoring`
- Generate emails — that's `copywriter`
- Push anywhere — this is a pure Sheets-in / Sheets-out cleanup step

## When to use this skill

Most common moment: **after company-scoring**, after filtering to `ICP Verdict == Qualified`, but **before copywriter generates scripts**. The cleaned merge tags then flow through Copywriter → Spintax → Campaign Manager into PlusVibe.

Also useful any time you get a raw lead list (Clay, Apollo, LinkedIn export) where the company column is full of "ACME CORPORATION LLC" and the first-name column is full of "Dr. JOHN" or "John Robert".

## One-time setup

Same setup as `company-scoring`. If you've already done that, you're done.

### 1. gcloud ADC for Sheets write access

```bash
gcloud auth application-default login \
  --scopes=openid,email,https://www.googleapis.com/auth/spreadsheets
gcloud auth application-default set-quota-project <your-project-id>
```

### 2. OpenRouter API key

```bash
mkdir -p ~/.olympolabs && cat > ~/.olympolabs/openrouter.json <<'EOF'
{"api_key": "sk-or-..."}
EOF
chmod 600 ~/.olympolabs/openrouter.json
```

## Workflow

### Step 1 - Resolve the input source

The user provides ONE of:
- A Google Sheets URL or ID — `--sheet-url <url>`
- A local CSV file path — `--csv-path <path>`

If the conversation doesn't already contain one, ask:

> Which file should I normalize? Paste the Google Sheets URL or the CSV file path.

CSV mode notes:
- Default output path: `<input>_normalized.csv` as a sibling file (preserves the original — safer because CSV has no undo).
- Pass `--csv-out same` to overwrite the input file in place (matches Sheets behavior).
- Pass `--csv-out <path>` to write to a specific output path.
- CSV mode requires no Google credentials; the LLM call still needs `~/.olympolabs/openrouter.json`.

### Step 2 - Confirm column detection (dry-run)

Always run a dry-run first to see what the skill picked up:

```bash
# Sheets:
python3 ~/.claude/skills/name-normalizer/scripts/normalize_sheet.py \
  --sheet-url "<url>" \
  --dry-run \
  --max-rows 3

# CSV:
python3 ~/.claude/skills/name-normalizer/scripts/normalize_sheet.py \
  --csv-path "<path>" \
  --dry-run \
  --max-rows 3
```

The output prints the detected columns and the first 3 rows that would be processed. Show this to the user and confirm:

> I detected: first-name in column N, company in column M. Look right, or do you want to override?

If they want to override, re-run with explicit flags:
- `--first-name-col N` — 1-based column index
- `--full-name-col N` — when the sheet has only a combined "Name" column (the skill will split on whitespace and take the first token before sending to the LLM)
- `--company-col N`

### Step 3 - Preview the first 20 rows

This is the equivalent of the company-scoring calibration pilot. The skill normalizes the first 20 rows BUT DOES NOT WRITE — it prints a side-by-side comparison so the user can sanity-check the rules before committing the full run.

```bash
python3 ~/.claude/skills/name-normalizer/scripts/normalize_sheet.py \
  --sheet-url "<url>" \
  --preview 20 \
  --concurrency 8
```

Output is a table like:

```
row  name (raw)            ->  name (clean)         |    company (raw)                  ->  company (clean)
---  ----------------      --  -----------------    -    -------------------------------     ----------------
2    Dr. JOHN SMITH        ->  John                 |    ACME CORPORATION LLC              ->  Acme
3    Mary-Jane O'Brien     ->  Mary-Jane            |    PepsiCo (USA)                     ->  PepsiCo
4    josé garcía           ->  José                 |    IBM Global Services Inc           ->  IBM Global Services
5    Robert "Bob" Smith    ->  Bob                  |    The Acme Company                  ->  Acme
6    J.                    ->                       |    Globex - leaders in widgets       ->  Globex
```

Present this to the user verbatim and ask:

> Preview complete. Does the normalization look right?
>
> - **"Looks good, continue"** → I'll run the full sheet and overwrite the originals.
> - **"Row X should be Y because..."** → tell me which rows are wrong and the rule that should change. I'll adjust the prompt and re-run the preview.
>
> What's your call?

**Iterate the preview loop until the user signs off.** If the user surfaces a systematic issue (e.g. "GEICO is getting Title-Cased — it should stay all-caps"), edit `~/.claude/skills/name-normalizer/scripts/prompts.py` to refine the rule, then re-run `--preview 20`.

### Step 4 - Run the full sheet

Once the user signs off on the preview:

```bash
python3 ~/.claude/skills/name-normalizer/scripts/normalize_sheet.py \
  --sheet-url "<url>" \
  --concurrency 16
```

This:
- Re-processes every row (including the preview's 20 — they were never written)
- Batches 25 rows per LLM call
- 16 concurrent workers
- Batch-writes back to the sheet every 100 rows
- **Overwrites the originals in place** — the raw values are not preserved

Cost ballpark: ~$0.03 per 1,000 rows. A 5k-row sheet runs in 1-2 minutes for $0.15-0.20.

### Step 5 - Confirm + report

Print a short summary to the user:

```
Normalized 4,847 rows in 73s LLM + 9s write.
Skipped (passthrough/error): 3
Cost: $0.18
Sheet: https://docs.google.com/spreadsheets/d/<ID>/edit
```

Note any errors (rows the LLM couldn't parse). Errored rows are LEFT UNTOUCHED — their original values stay in the sheet, so nothing is silently destroyed.

## Edge cases to expect during the preview

These are the cases users most often surface in the sign-off loop. If they come up, the right move is usually a prompt tweak (`scripts/prompts.py`) rather than a code change.

| Input | Expected output | Why |
|---|---|---|
| `Dr. JOHN R. SMITH` | `John` | Strip title, take first given name only |
| `Mary-Jane O'Brien` | `Mary-Jane` | Preserve hyphenation |
| `Robert "Bob" Smith` | `Bob` | Prefer the nickname |
| `José` | `José` | Preserve diacritic |
| `J. P.` (no full first name) | `` (empty) | Better blank than creepy initial |
| `ACME CORPORATION LLC` | `Acme` | Strip legal suffix, Title-Case |
| `IBM Global Services Inc` | `IBM Global Services` | Preserve acronym brand, strip legal suffix |
| `PepsiCo (USA)` | `PepsiCo` | Preserve CamelCase, strip parenthetical |
| `IKEA` | `IKEA` | Real Swedish initialism, preserve |
| `GEICO` | `GEICO` | Recognized acronym brand, preserve |
| `Globex — leaders in widgets` | `Globex` | Strip post-dash tagline |
| `Acme Holdings DBA Acme Software` | `Acme Software` | Keep DBA name, drop holding entity |
| `Smith Architecture` | `Smith Architecture` | "Architecture" is the brand identity (service), keep |
| `John Smith Consulting` | `John Smith` | "Consulting" is a service descriptor, strip |
| `Acme Industries` | `Acme` | "Industries" is decorative filler (not industry-naming), strip |
| `Astronomical Industry Ventures` | `Astronomical` | Both "Industry" and "Ventures" are decorative — strip both |
| `Globex Enterprises` | `Globex` | "Enterprises" is decorative filler, strip |
| `Motorola San Diego` | `Motorola` | Trailing city/location qualifier, strip |
| `Tesla Fremont` | `Tesla` | Same — location tag-on, not brand identity |
| `BMW North America` | `BMW` | Regional qualifier, strip |
| `New York Times` | `New York Times` | Location IS the brand identity (stripping leaves "Times") — keep |
| `Bank of America` | `Bank of America` | Same — "of America" is part of the brand — keep |
| `Infiniti Dealership in Dallas` | `Infiniti` | Generic descriptor + " in <city>" tail, strip both |
| `Honda Service Center in Phoenix` | `Honda` | Same pattern |
| `Tesla Store - Austin` | `Tesla` | Descriptor + "- <city>" variant, strip both |
| `I am happy, a Disney company` | `I am happy` | Parent-company suffix clause, strip |
| `7-Eleven` | `7-Eleven` | Numbers/punctuation in name preserved |

If the user reports a mismatch, ask them to specify the rule (e.g. "PepsiCo should stay PepsiCo, not Pepsi"), then update `scripts/prompts.py` accordingly.

## Default flags

```
--model              google/gemini-2.5-flash
--batch-size         25                            # rows per LLM call
--concurrency        16                            # parallel workers
--write-batch-size   100                           # rows per Sheets write
```

For preview, lower concurrency (`--concurrency 8`) keeps the side-by-side output readable while the API calls fly.

## When NOT to use this skill

- The sheet's `first_name` and `company` columns already look clean (no titles, no LLC suffixes, no ALL CAPS) — no point spending the API call.
- You need the original values preserved for audit purposes — this skill overwrites in place. Make a backup tab first if that matters.
- The column you want to clean isn't first-name or company (e.g. you want to normalize a `title` or `industry` column). This skill is purpose-built for the two merge tags that go into cold emails.

## Failure modes

- **"could not detect a first-name or full-name column"** → re-run with `--first-name-col N` or `--full-name-col N`.
- **"could not detect a company column"** → re-run with `--company-col N`.
- **All rows showing as `passthrough`** → the LLM is returning malformed JSON. Check `~/.olympolabs/openrouter.json` has a valid key. If it's a model issue, try `--model openai/gpt-4o-mini`.
- **A specific row's normalization is wrong but the rest are fine** → re-run a targeted preview using `--max-rows N` and surface the issue, then adjust the prompt.
