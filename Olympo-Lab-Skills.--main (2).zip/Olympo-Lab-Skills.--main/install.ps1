# OlympoLabs Skills - one-command install (Windows / PowerShell)
#
# Run this after cloning the repo. Re-runnable safely (idempotent).
# Installs all .skill files at the repo root into %USERPROFILE%\.claude\skills\
# and prints next steps for credentials + gcloud + the Copywriter knowledge-base doc.
#
# Usage (in PowerShell):
#   .\install.ps1
#
# If you get "running scripts is disabled on this system", run this ONCE in an
# elevated PowerShell, then re-run install.ps1 normally:
#   Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

$ErrorActionPreference = "Stop"

$RepoDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillsDir = Join-Path $env:USERPROFILE ".claude\skills"
$OlympoDir = Join-Path $env:USERPROFILE ".olympolabs"

function Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Blue }
function Ok($msg)   { Write-Host "    [OK] $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "    [!]  $msg" -ForegroundColor Yellow }
function Err($msg)  { Write-Host "    [X]  $msg" -ForegroundColor Red }

# ----------------------------------------------------------------------------
Step "Verifying prerequisites"

# Detect Python (try `python`, then `py`)
$pythonCmd = $null
foreach ($candidate in @("python", "py")) {
    $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
    if ($cmd) {
        $version = & $candidate --version 2>&1
        if ($version -match "Python (\d+)\.(\d+)") {
            $major = [int]$matches[1]; $minor = [int]$matches[2]
            if ($major -ge 3 -and $minor -ge 10) {
                $pythonCmd = $candidate
                Ok "Python found: $version (using '$candidate')"
                break
            }
        }
    }
}
if (-not $pythonCmd) {
    Err "Python 3.10+ not found. Install from https://www.python.org/downloads/ (check 'Add to PATH' during install)."
    exit 1
}

# pip
$pipCmd = $null
foreach ($candidate in @("pip", "pip3")) {
    if (Get-Command $candidate -ErrorAction SilentlyContinue) {
        $pipCmd = $candidate; break
    }
}
if (-not $pipCmd) {
    # Fall back to invoking pip via python -m
    $pipCmd = "$pythonCmd -m pip"
    Warn "pip not on PATH; will invoke via '$pythonCmd -m pip'"
} else {
    Ok "pip found: $pipCmd"
}

# gcloud (optional but recommended)
if (Get-Command gcloud -ErrorAction SilentlyContinue) {
    Ok "gcloud is installed"
} else {
    Warn "gcloud CLI not found - required for the company-scoring skill (Google Sheets write access)."
    Warn "Install from https://cloud.google.com/sdk/docs/install#windows OR via winget: winget install Google.CloudSDK"
    Warn "You can finish the install now and add gcloud later."
}

# Python dependencies
Write-Host ""
Write-Host "    Checking Python dependencies..."
$pythonDeps = @(
    @{ Import = "requests";                            Package = "requests" }
    @{ Import = "google.oauth2.service_account";       Package = "google-auth" }
    @{ Import = "googleapiclient.discovery";           Package = "google-api-python-client" }
    @{ Import = "trafilatura";                         Package = "trafilatura" }
    @{ Import = "google_auth_oauthlib.flow";           Package = "google-auth-oauthlib" }
)
$missing = @()
foreach ($dep in $pythonDeps) {
    & $pythonCmd -c "import $($dep.Import)" 2>$null
    if ($LASTEXITCODE -ne 0) {
        $missing += $dep.Package
    }
}
if ($missing.Count -gt 0) {
    Warn "Missing Python packages: $($missing -join ', ')"
    Write-Host "    Installing them now (pip install --user)..."
    & $pythonCmd -m pip install --user --quiet @missing
    if ($LASTEXITCODE -ne 0) {
        Err "pip install failed - run manually and re-run this script."
        exit 1
    }
    Ok "Python deps installed"
} else {
    Ok "All Python deps present"
}

# ----------------------------------------------------------------------------
Step "Creating directories"

if (-not (Test-Path $SkillsDir)) { New-Item -ItemType Directory -Force -Path $SkillsDir | Out-Null }
Ok $SkillsDir

if (-not (Test-Path $OlympoDir)) { New-Item -ItemType Directory -Force -Path $OlympoDir | Out-Null }
$icpProfiles = Join-Path $OlympoDir "icp-profiles"
if (-not (Test-Path $icpProfiles)) { New-Item -ItemType Directory -Force -Path $icpProfiles | Out-Null }
Ok $OlympoDir

# ----------------------------------------------------------------------------
Step "Vendoring foundations into self-contained skills (rebuilding .skill bundles)"

# For each skill that has scripts/lib/.foundations, refresh the vendored copies
# of the listed foundation packages from the repo root, then rebuild that
# skill's .skill bundle. Idempotent.
$markers = Get-ChildItem -Path $RepoDir -Recurse -Filter ".foundations" -ErrorAction SilentlyContinue |
           Where-Object { $_.FullName -match "scripts\\lib\\\.foundations$" }

if ($markers) {
    foreach ($marker in $markers) {
        $skillDir  = (Resolve-Path (Join-Path $marker.Directory.FullName "..\..")).Path.TrimEnd('\')
        $skillName = Split-Path $skillDir -Leaf
        $libDir    = Join-Path $skillDir "scripts\lib"

        foreach ($pkg in Get-Content $marker.FullName) {
            $pkg = $pkg.Trim()
            if (-not $pkg) { continue }
            $srcPkg = Join-Path $RepoDir $pkg
            if (Test-Path $srcPkg) {
                $dstPkg = Join-Path $libDir $pkg
                if (Test-Path $dstPkg) { Remove-Item -Recurse -Force $dstPkg }
                Copy-Item -Recurse $srcPkg $dstPkg
                # Strip __pycache__ and ping.py
                Get-ChildItem -Recurse -Force -Path $dstPkg -Filter "__pycache__" -ErrorAction SilentlyContinue |
                    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
                $ping = Join-Path $dstPkg "ping.py"
                if (Test-Path $ping) { Remove-Item -Force $ping }
                Ok "vendored $pkg -> $skillName\scripts\lib\"
            } else {
                Warn "foundation package '$pkg' not found at repo root (needed by $skillName)"
            }
        }

        # Rebuild the .skill bundle
        $bundle = Join-Path $RepoDir "$skillName.skill"
        if (Test-Path $bundle) { Remove-Item -Force $bundle }
        # PowerShell's Compress-Archive doesn't support exclude patterns directly; first prune caches
        Get-ChildItem -Recurse -Force -Path $skillDir -Filter "__pycache__" -ErrorAction SilentlyContinue |
            Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Compress-Archive -Path $skillDir -DestinationPath $bundle -Force
        # Compress-Archive produces .zip — rename happens via DestinationPath already being .skill
        Ok "rebuilt $skillName.skill (self-contained)"
    }
} else {
    Warn "No vendoring markers found - skipping rebuild; install will use existing .skill files."
}

# ----------------------------------------------------------------------------
Step "Installing skills"

$skillFiles = Get-ChildItem -Path $RepoDir -Filter "*.skill" -File
if ($skillFiles.Count -eq 0) {
    Err "No .skill files found at the repo root. Did you clone the right repo?"
    exit 1
}

foreach ($skillFile in $skillFiles) {
    $skillName = [System.IO.Path]::GetFileNameWithoutExtension($skillFile.Name)
    $target    = Join-Path $SkillsDir $skillName
    if (Test-Path $target) { Remove-Item -Recurse -Force $target }
    # Expand-Archive needs the source to have a .zip-compatible extension; .skill IS zip.
    # Copy to a temp .zip first, then expand.
    $tmpZip = Join-Path $env:TEMP "$skillName.zip"
    Copy-Item -Force $skillFile.FullName $tmpZip
    Expand-Archive -Path $tmpZip -DestinationPath $SkillsDir -Force
    Remove-Item -Force $tmpZip
    Ok "Installed: $skillName"
}

# ----------------------------------------------------------------------------
Step "Next steps (one-time, ~5 minutes)"

$nextSteps = @"

The skills are installed. Three things still need to happen:

1. Set up your API keys

   Each teammate uses their OWN OpenRouter and ZenRows keys.
   PlusVibe is one team-shared key - ask team lead.

   # OpenRouter: get a key from https://openrouter.ai/keys
   '{"api_key": "sk-or-v1-..."}' | Out-File -Encoding ascii "$OlympoDir\openrouter.json"

   # ZenRows: get a key from https://app.zenrows.com/users/api-keys
   '{"api_key": "your-zenrows-key"}' | Out-File -Encoding ascii "$OlympoDir\zenrows.json"

   # PlusVibe: ask team lead for the team's shared key
   '{"api_key": "the-team-plusvibe-key"}' | Out-File -Encoding ascii "$OlympoDir\plusvibe.json"

2. Set up gcloud Application Default Credentials  (required for the
   company-scoring skill - it needs WRITE access to your Google Sheets)

   If gcloud isn't installed:
     winget install Google.CloudSDK
     (then close + reopen PowerShell so PATH refreshes)

   Then run (this opens your browser):
     gcloud auth login
     gcloud auth application-default login `
       --client-id-file="$RepoDir\shared-config\gcloud-oauth-client.json" `
       --scopes=openid,email,https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/spreadsheets
     gcloud auth application-default set-quota-project olympolabs-copywriter

   See docs\setup-gcloud-adc.md for screenshots and troubleshooting.

3. Copywriter knowledge-base doc  (only needed if you'll use the copywriter
   skill)

   The copywriter reads from a markdown file of OlympoLabs's winning cold
   email scripts. Ask team lead for the Google Doc URL, then:

     File -> Download -> Markdown (.md)
     Move-Item "$env:USERPROFILE\Downloads\<file>.md" "$OlympoDir\copywriter-kb.md"

   Add this to your PowerShell profile so the skill can find it:
     Add-Content -Path `$PROFILE -Value '`$env:COPYWRITER_KB_FILE = "`$env:USERPROFILE\.olympolabs\copywriter-kb.md"'
     . `$PROFILE

Finally: restart Claude Code. The skills will auto-load.

Read docs\ for per-skill setup details, common workflows, and troubleshooting.

"@

Write-Host $nextSteps
