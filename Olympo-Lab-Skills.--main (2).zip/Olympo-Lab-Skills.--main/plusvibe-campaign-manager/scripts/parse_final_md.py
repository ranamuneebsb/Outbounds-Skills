#!/usr/bin/env python3
"""
Parse a Spintax `final.md` (or `draft.md`) into structured email pairs.

The Copywriter writes a per-pair section like:

    ## 1. Framework: #4 - Pain-point question + solution + interest CTA + P.S. proof

    **Email 1**

    {{first_name}},

    How many acquisitions has {{company_name}} walked away from...

    {{sender_signature}}

    **Email 2 (follow-up)**

    {{first_name}},

    Different question - when a deal collapses...

    {{sender_signature}}

    ---

This script extracts each pair into:

    {
        "index": 1,
        "framework": "#4 - Pain-point question + solution + interest CTA + P.S. proof",
        "email_1": "<body text>",
        "email_2": "<body text>",
    }

It also strips:
- The top-level "# Copywriter batch for ..." title
- The "## Frameworks used" summary section
- "Frameworks skipped: ..." notes
- "Single-asset note:" or other prose between the header and the first pair
- "Saved to:" / "Saved (audit):" / "Saved + opened:" trailing pointers

Usage:
    python3 parse_final_md.py /path/to/final.md
    python3 parse_final_md.py /path/to/final.md --json    # machine-readable

If --json is omitted, prints a human-readable summary.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional


# Lenient header regex: matches both Copywriter formats produced over time —
#   "## 1. Framework: #4 - description"   (older, colon after Framework)
#   "## 1. Framework #4 - description"    (newer, no colon, hash before number)
# Failing to match either drops every pair silently and the launcher exits 3.
PAIR_HEADER_RE = re.compile(r"^##\s+(\d+)\.\s*Framework[\s:#]+(.+?)\s*$", re.MULTILINE)

# Lines that mark email-1 vs email-2 within a pair
EMAIL_1_MARKER = "**Email 1**"
EMAIL_2_MARKER = "**Email 2 (follow-up)**"


def parse(content: str) -> List[Dict[str, str]]:
    """Parse final.md content into a list of pair dicts.

    Returns at least an empty list if no pairs were found (helpful for the
    caller to surface a "no scripts in this file" error rather than failing
    further downstream).
    """
    # Find every `## N. Framework: ...` header position
    headers = list(PAIR_HEADER_RE.finditer(content))
    if not headers:
        return []

    pairs: List[Dict[str, str]] = []
    for i, m in enumerate(headers):
        section_start = m.end()
        section_end = headers[i + 1].start() if i + 1 < len(headers) else len(content)
        section = content[section_start:section_end]

        email_1 = _extract_email(section, EMAIL_1_MARKER, EMAIL_2_MARKER)
        email_2 = _extract_email(section, EMAIL_2_MARKER, None)

        if email_1 is None and email_2 is None:
            # A header with no email blocks - skip rather than emit junk
            continue

        pairs.append(
            {
                "index": int(m.group(1)),
                "framework": m.group(2).strip(),
                "email_1": (email_1 or "").strip(),
                "email_2": (email_2 or "").strip(),
            }
        )

    return pairs


def _extract_email(section: str, start_marker: str, end_marker: Optional[str]) -> Optional[str]:
    """Pull the body that follows a marker, stopping at the next marker or `---`."""
    start_idx = section.find(start_marker)
    if start_idx == -1:
        return None
    body_start = start_idx + len(start_marker)

    # Find where this email block ends
    candidates: List[int] = []
    if end_marker:
        em = section.find(end_marker, body_start)
        if em != -1:
            candidates.append(em)

    # Horizontal rule between pairs also terminates the email
    for hr_match in re.finditer(r"^\s*---\s*$", section[body_start:], re.MULTILINE):
        candidates.append(body_start + hr_match.start())
        break

    body_end = min(candidates) if candidates else len(section)
    return section[body_start:body_end]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, help="Path to a Spintax final.md or Copywriter draft.md")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of human summary")
    args = parser.parse_args()

    if not args.path.exists():
        sys.stderr.write(f"ERROR: file not found: {args.path}\n")
        return 2

    content = args.path.read_text(encoding="utf-8")
    pairs = parse(content)

    if not pairs:
        sys.stderr.write(
            f"ERROR: no email pairs found in {args.path}.\n"
            "The file should contain `## N. Framework: ...` headers with\n"
            "`**Email 1**` and `**Email 2 (follow-up)**` blocks underneath.\n"
        )
        return 3

    if args.json:
        json.dump({"source": str(args.path), "pairs": pairs}, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
        return 0

    print(f"Source: {args.path}")
    print(f"Pairs found: {len(pairs)}")
    print()
    for p in pairs:
        e1_lines = len([ln for ln in p["email_1"].splitlines() if ln.strip()])
        e2_lines = len([ln for ln in p["email_2"].splitlines() if ln.strip()])
        print(f"  #{p['index']:>2}  {p['framework']!r:<70}  E1={e1_lines}L  E2={e2_lines}L")
    return 0


if __name__ == "__main__":
    sys.exit(main())
