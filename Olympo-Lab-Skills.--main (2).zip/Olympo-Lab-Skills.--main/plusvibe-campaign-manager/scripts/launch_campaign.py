#!/usr/bin/env python3
"""
Launch a PlusVibe campaign from a Spintax `final.md` (or a Copywriter
`draft.md`).

This script is the workhorse of the plusvibe-campaign-manager skill. The skill
collects inputs from the user (workspace, campaign name, schedule, subjects,
email accounts), drops them into JSON files in /tmp, then invokes this script
with the file paths. The script does the actual API work and prints a clean
summary.

What it does in order:

  1. Parse the final.md into N pairs (each pair = Email 1 + Email 2 follow-up).
  2. Validate that the user-provided subjects match the pair count.
  3. Convert each email body from plain text / markdown to PlusVibe HTML.
  4. Build PlusVibe `sequences`: step 1 with N variations (one per pair),
     step 2 with N matching variations (subject="" so PlusVibe replies in
     thread).
  5. Call create_and_configure_campaign to: (a) create the campaign shell,
     (b) push the full config (schedules, sequences, email_accounts).
  6. Optionally activate the campaign.
  7. Print campaign_id, campaign URL, and what got configured.

Variation pairing: variation A in step 1 is paired with variation A in step 2.
PlusVibe's round-robin variation selection should keep the lead's first-email
angle aligned with their follow-up angle. (If PlusVibe doesn't actually
preserve this pairing in practice, revisit by using N sub-campaigns instead.)
"""

from __future__ import annotations

import argparse
import json
import string
import sys
from pathlib import Path
from typing import Any, Dict, List

# Make the plusvibe-api foundation importable.
#
# Resolution order:
#   1. OLYMPOLABS_SKILLS_HOME env var (if set), points at the source folder.
#   2. Path relative to this script (works when running from the source folder
#      at ~/Desktop/OlympoLabs-Skills/plusvibe-campaign-manager/scripts/).
#   3. The canonical user-source location ~/Desktop/OlympoLabs-Skills/plusvibe-api
#      (works when the skill is installed at ~/.claude/skills/ and the source
#      still lives in its original location).
import os  # noqa: E402

_skills_home = os.environ.get("OLYMPOLABS_SKILLS_HOME")
_candidate_paths = []
if _skills_home:
    _candidate_paths.append(Path(_skills_home) / "plusvibe-api")
_candidate_paths.append(Path(__file__).resolve().parent.parent.parent / "plusvibe-api")
_candidate_paths.append(Path.home() / "Desktop" / "OlympoLabs-Skills" / "plusvibe-api")

PLUSVIBE_API_PATH = next((p for p in _candidate_paths if (p / "client.py").exists()), None)
if PLUSVIBE_API_PATH is None:
    sys.stderr.write(
        "ERROR: cannot locate the plusvibe-api foundation. Tried:\n"
        + "".join(f"  - {p}\n" for p in _candidate_paths)
        + "Set OLYMPOLABS_SKILLS_HOME to the parent folder of plusvibe-api,\n"
        "or keep the source at ~/Desktop/OlympoLabs-Skills/plusvibe-api/.\n"
    )
    sys.exit(2)
sys.path.insert(0, str(PLUSVIBE_API_PATH))

# Also make sibling scripts (parse_final_md) importable
sys.path.insert(0, str(Path(__file__).resolve().parent))

from client import PlusVibeClient  # type: ignore  # noqa: E402
from exceptions import PlusVibeError  # type: ignore  # noqa: E402
from formatters import body_to_plusvibe_html  # type: ignore  # noqa: E402
from parse_final_md import parse  # type: ignore  # noqa: E402


def _load_json(path: Path) -> Any:
    if not path.exists():
        sys.stderr.write(f"ERROR: file not found: {path}\n")
        sys.exit(2)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        sys.stderr.write(f"ERROR: invalid JSON in {path}: {exc}\n")
        sys.exit(2)


def count_spintax_blocks(pairs: List[Dict[str, str]]) -> int:
    """Count `{{random|...}}` blocks across every email body in the batch.

    A real Spintax `final.md` will have MANY of these (the user's house style
    is heavy spintax - target several per email). A raw Copywriter `draft.md`
    will have zero. This is the cheapest reliable signal of "did the user
    actually run this through Spintax."

    We only count `{{random|` (with the literal `random` keyword) because
    PlusVibe needs that prefix to recognize a spin - `{{first_name}}` and
    other merge tags are NOT spintax even though they share the brace shape.
    """
    total = 0
    for pair in pairs:
        for body in (pair.get("email_1", ""), pair.get("email_2", "")):
            total += body.count("{{random|")
    return total


def _variation_letter(idx: int) -> str:
    """0->A, 1->B, ..., 25->Z, 26->AA, 27->AB, ..."""
    if idx < 26:
        return string.ascii_uppercase[idx]
    # PlusVibe seems to use single-letter variations in practice; this is a
    # safety valve for >26-pair edge cases (shouldn't happen since the user
    # trims to 4-8 keepers before this step).
    first = string.ascii_uppercase[(idx // 26) - 1]
    second = string.ascii_uppercase[idx % 26]
    return first + second


def build_sequences(
    pairs: List[Dict[str, str]],
    subjects: List[str],
    follow_up_wait_days: int,
) -> List[Dict[str, Any]]:
    """Turn parsed pairs + subjects into PlusVibe's `sequences` shape.

    Args:
        pairs: Output of parse_final_md.parse() - list of
            {index, framework, email_1, email_2} dicts.
        subjects: One subject per pair, in pair order. Step-2 (follow-up)
            subjects are always empty so PlusVibe replies in thread.
        follow_up_wait_days: Days to wait after step 1 before sending step 2.

    Returns:
        A two-step sequence ([step 1, step 2]) where each step has one
        variation per pair, A through Z.
    """
    if len(subjects) != len(pairs):
        raise ValueError(
            f"Got {len(subjects)} subjects for {len(pairs)} pairs - they must match."
        )

    step_1_variations: List[Dict[str, Any]] = []
    step_2_variations: List[Dict[str, Any]] = []

    for i, (pair, subject) in enumerate(zip(pairs, subjects)):
        letter = _variation_letter(i)
        # Step 1: full subject + body
        step_1_variations.append(
            {
                "variation": letter,
                "subject": subject,
                "name": f"Pair {pair['index']} - {pair['framework']}",
                "body": body_to_plusvibe_html(pair["email_1"]),
            }
        )
        # Step 2: empty subject (reply-in-thread) + follow-up body
        step_2_variations.append(
            {
                "variation": letter,
                "subject": "",
                "name": f"Pair {pair['index']} follow-up",
                "body": body_to_plusvibe_html(pair["email_2"]),
            }
        )

    return [
        # step 1 wait_time must be >= 1 per PlusVibe's validator. The real
        # "delay before the first send" lives at the campaign level via
        # `first_wait_time` (minutes), not here.
        {"step": 1, "wait_time": 1, "variations": step_1_variations},
        {"step": 2, "wait_time": follow_up_wait_days, "variations": step_2_variations},
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--final-md", type=Path, required=True, help="Path to final.md (or draft.md)")
    parser.add_argument("--workspace-id", required=True, help="PlusVibe workspace ID")
    parser.add_argument("--campaign-name", required=True, help="Display name for the new campaign")
    parser.add_argument(
        "--subjects-file",
        type=Path,
        required=True,
        help="Path to JSON file containing a list of subject lines, one per pair (in pair order)",
    )
    parser.add_argument(
        "--schedule-file",
        type=Path,
        required=True,
        help="Path to JSON file containing the PlusVibe schedules object",
    )
    parser.add_argument(
        "--email-accounts-file",
        type=Path,
        help="Optional path to JSON file with a list of email_account_ids. "
        "If omitted, uses ALL active accounts in the workspace.",
    )
    parser.add_argument(
        "--follow-up-wait-days",
        type=int,
        default=3,
        help="Days to wait after step 1 before sending step 2 (default: 3)",
    )
    parser.add_argument(
        "--first-wait-time-minutes",
        type=int,
        default=60,
        help="Minutes to wait before sending the very first email (default: 60)",
    )
    parser.add_argument("--activate", action="store_true", help="Activate the campaign after configuring it")
    parser.add_argument("--dry-run", action="store_true", help="Print what would happen without calling PlusVibe")
    parser.add_argument(
        "--skip-spintax-check",
        action="store_true",
        help=(
            "Skip the safety check that refuses non-spintaxed input. ONLY use this "
            "if you deliberately want to upload copy without spintax variations "
            "(rare - e.g. you're testing the pipeline, or you have a special "
            "one-off send where every lead must see identical bytes). Normal "
            "production use should always run final.md through Spintax first."
        ),
    )
    parser.add_argument(
        "--skip-spam-audit",
        action="store_true",
        help=(
            "Skip the spam-word audit that refuses uploads when any term from "
            "plusvibe-spintax/references/spam-words.md appears in the body. ONLY "
            "use this if the user has explicitly told you to bypass the audit "
            "(extremely rare - the audit exists because a production campaign "
            "almost shipped with 39 spam-word hits when the audit was an LLM "
            "self-assessment). Bypassing risks deliverability and reputation."
        ),
    )
    args = parser.parse_args()

    # 1. Parse final.md
    if not args.final_md.exists():
        sys.stderr.write(f"ERROR: final.md not found: {args.final_md}\n")
        return 2
    pairs = parse(args.final_md.read_text(encoding="utf-8"))
    if not pairs:
        sys.stderr.write(f"ERROR: no email pairs parsed from {args.final_md}\n")
        return 3
    print(f"Parsed {len(pairs)} pair(s) from {args.final_md}")

    # Spintax-presence guard. PlusVibe's whole inbox-uniqueness story depends
    # on `{{random|...}}` blocks in the body. A file with zero spin blocks is
    # almost certainly a draft.md (Copywriter output) that the user passed by
    # mistake instead of a Spintax final.md. Refuse by default and explain
    # how to recover; allow --skip-spintax-check for legitimate edge cases.
    spin_count = count_spintax_blocks(pairs)
    if spin_count == 0 and not args.skip_spintax_check:
        sys.stderr.write(
            f"ERROR: {args.final_md} contains zero `{{{{random|...}}}}` spin blocks.\n"
            "This looks like a Copywriter draft.md that hasn't been run through\n"
            "the plusvibe-spintax skill yet. Uploading non-spintaxed copy means\n"
            "every lead sees the same bytes - which kills the whole point of\n"
            "variations and risks deliverability.\n"
            "\n"
            "To fix: run Spintax on this batch first (it will produce a\n"
            "final.md sibling file), then point this script at final.md\n"
            "instead.\n"
            "\n"
            "If you genuinely want to upload without spintax (rare - testing\n"
            "the pipeline, or a one-off send where identical bytes are fine),\n"
            "re-run with --skip-spintax-check.\n"
        )
        return 9
    if spin_count == 0:
        print("Spintax check skipped via --skip-spintax-check (0 spin blocks present).")
    else:
        per_email = spin_count / (len(pairs) * 2) if pairs else 0
        print(f"Spintax check OK: {spin_count} spin block(s) across {len(pairs)} pair(s) (~{per_email:.1f}/email).")

    # Spam-word audit gate. Deterministic, non-bypassable-by-default check
    # against the full 387-term reference. Past failure: a production campaign
    # almost shipped with 39 spam-word hits because the audit was an LLM
    # self-assessment using a hand-picked subset (~25 terms). The script
    # removes that failure mode entirely. See plusvibe-spintax/scripts/
    # audit_spam_words.py for the implementation.
    audit_script = Path.home() / "Desktop/OlympoLabs-Skills/plusvibe-spintax/scripts/audit_spam_words.py"
    if not args.skip_spam_audit:
        if not audit_script.exists():
            sys.stderr.write(
                f"ERROR: spam-audit script not found at {audit_script}\n"
                "Cannot proceed without the audit. Either install the script or\n"
                "re-run with --skip-spam-audit (only do this with the user's explicit\n"
                "go-ahead - bypassing the audit risks shipping spam-flagged copy).\n"
            )
            return 10
        import subprocess
        result = subprocess.run(
            ["python3", str(audit_script), str(args.final_md), "--quiet"],
            capture_output=True, text=True,
        )
        # Print the audit's stdout so the operator sees the result line.
        if result.stdout.strip():
            print(f"Spam audit: {result.stdout.strip()}")
        if result.returncode != 0:
            sys.stderr.write(
                "\nERROR: spam-word audit FAILED. Re-run the audit standalone to\n"
                "see exact line numbers and matched terms:\n"
                f"  python3 {audit_script} {args.final_md}\n"
                "\nFix the offending lines in final.md, then re-run this launcher.\n"
                "Do NOT pass --skip-spam-audit unless the user has explicitly told\n"
                "you to bypass the audit.\n"
            )
            return 11
    else:
        print("Spam audit: SKIPPED via --skip-spam-audit (use only with user approval).")

    # 2. Load supporting inputs
    subjects = _load_json(args.subjects_file)
    if not isinstance(subjects, list):
        sys.stderr.write(f"ERROR: {args.subjects_file} must contain a JSON list of subjects.\n")
        return 2
    schedules = _load_json(args.schedule_file)
    if not isinstance(schedules, dict):
        sys.stderr.write(f"ERROR: {args.schedule_file} must contain a JSON object.\n")
        return 2

    # 3. Build sequences
    try:
        sequences = build_sequences(pairs, subjects, follow_up_wait_days=args.follow_up_wait_days)
    except ValueError as exc:
        sys.stderr.write(f"ERROR: {exc}\n")
        return 4

    # 4. Resolve email accounts (explicit list, or fetch all from workspace)
    client = PlusVibeClient()
    if args.email_accounts_file:
        email_accounts = _load_json(args.email_accounts_file)
        if not isinstance(email_accounts, list):
            sys.stderr.write(f"ERROR: {args.email_accounts_file} must contain a JSON list of account IDs.\n")
            return 2
        print(f"Using {len(email_accounts)} email accounts from {args.email_accounts_file}")
    else:
        print("No email_accounts_file supplied; fetching all ACTIVE accounts in the workspace...")
        accounts_resp = client.list_email_accounts(workspace_id=args.workspace_id)
        all_accounts = (accounts_resp.get("accounts", []) if isinstance(accounts_resp, dict) else accounts_resp) or []
        email_accounts = [
            a["id"] for a in all_accounts if a.get("status") == "ACTIVE"
        ]
        print(f"Found {len(email_accounts)} ACTIVE accounts.")

    if not email_accounts:
        sys.stderr.write(
            "ERROR: no email accounts to attach. Either pass --email-accounts-file "
            "or make sure the workspace has at least one ACTIVE account.\n"
        )
        return 5

    # 5. Dry-run or real call
    if args.dry_run:
        print("\n=== DRY RUN ===")
        print(f"Would create campaign: {args.campaign_name}")
        print(f"Workspace: {args.workspace_id}")
        print(f"Sequences: 2 steps, {len(sequences[0]['variations'])} variations each")
        print(f"Email accounts: {len(email_accounts)}")
        print(f"Schedule: {json.dumps(schedules, indent=2)}")
        print(f"First wait time: {args.first_wait_time_minutes} minutes")
        print(f"Activate after: {args.activate}")
        return 0

    # 6. Create + configure
    try:
        result = client.create_and_configure_campaign(
            name=args.campaign_name,
            workspace_id=args.workspace_id,
            email_accounts=email_accounts,
            schedules=schedules,
            sequences=sequences,
            first_wait_time=args.first_wait_time_minutes,
            extra={
                "stop_on_lead_replied": "yes",
                "is_emailopened_tracking": "yes",
                "var_sel_type": "R_ROBIN",
                "exclude_ooo": "yes",
                "is_pause_on_bouncerate": "yes",
                "bounce_rate_limit": 5,
            },
        )
    except PlusVibeError as exc:
        sys.stderr.write(f"ERROR creating campaign: {exc}\n")
        return 6

    # The update response usually echoes the campaign id; otherwise look it up
    campaign_id = (
        result.get("campaign_id")
        or result.get("id")
        or (result.get("data", {}) or {}).get("campaign_id")
    )

    print()
    print("===== Campaign created and configured =====")
    print(f"  campaign_id:   {campaign_id}")
    print(f"  workspace_id:  {args.workspace_id}")
    print(f"  name:          {args.campaign_name}")
    print(f"  steps:         2")
    print(f"  variations:    {len(sequences[0]['variations'])} per step")
    print(f"  accounts:      {len(email_accounts)}")
    print(f"  status:        DRAFT (not yet sending)")
    if campaign_id:
        print(f"  url:           https://app.plusvibe.ai/v2/campaign/{campaign_id}")
    print()

    # 7. Optional activation
    if args.activate:
        if not campaign_id:
            sys.stderr.write(
                "ERROR: --activate was requested but the create response did "
                "not include a campaign_id. Activate manually in the PlusVibe UI.\n"
            )
            return 7
        print("Activating campaign...")
        try:
            client.activate_campaign(campaign_id, workspace_id=args.workspace_id)
        except PlusVibeError as exc:
            sys.stderr.write(f"ERROR activating campaign: {exc}\n")
            return 8
        print(f"  status:        ACTIVE (sending will begin per the schedule)")

    return 0


if __name__ == "__main__":
    sys.exit(main())
