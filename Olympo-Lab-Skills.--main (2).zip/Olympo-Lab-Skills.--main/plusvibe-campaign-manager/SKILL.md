---
name: plusvibe-campaign-manager
description: Upload a finished OlympoLabs campaign (a Spintax `final.md`) to PlusVibe via API - create the campaign, configure schedule and sequences with all variations, attach email accounts, and optionally activate. Use this skill whenever the user wants to launch a campaign in PlusVibe, push a finished draft to PlusVibe, "upload to PlusVibe", "create the campaign", "launch this in PlusVibe", "ship this campaign", or any time they've finished the spam-check and are ready to send. Reads the final.md emitted by the plusvibe-spintax skill, parses email pairs, converts bodies to PlusVibe HTML, configures variations for built-in A/B testing, and writes back the campaign id and URL. Leaves the campaign in DRAFT by default - asks before activating so a misconfig doesn't send 50k emails.
---

# PlusVibe Campaign Manager

Take a Spintax `final.md` and turn it into a configured, ready-to-send PlusVibe campaign. This is the last step of the cold-email pipeline before sending:

```
Copywriter → draft.md → (user trims) → Spintax → final.md → (user spam-checks)
                                                                ↓
                                                  [this skill]
                                                                ↓
                                                  PlusVibe campaign (DRAFT)
                                                                ↓
                                                        (user activates)
```

The user just finished spam-checking `final.md`. This skill picks it up from there.

## What this skill does and doesn't do

**Does:**

- Interviews the user for the campaign inputs (workspace, name, subjects, schedule, accounts)
- Parses email pairs from a Spintax `final.md`
- Converts each email body from plain text to PlusVibe HTML
- Creates the campaign via PlusVibe's two-step API flow (`POST /campaign/add/campaign` + `POST /campaign/update`)
- Uploads every pair as a paired variation (step 1 variation A is paired with step 2 variation A, etc.) so PlusVibe's built-in A/B testing keeps the matched value angles aligned per lead
- Attaches email accounts (default: all `ACTIVE` accounts in the workspace; or a user-specified subset)
- Returns the campaign id + URL for the user to inspect in the PlusVibe UI
- Asks before activating - default is DRAFT so a misconfig doesn't blast 50k emails

**Does NOT:**

- Generate scripts or add spintax - those are the Copywriter and Spintax skills
- Upload leads - skipped in v1; user adds leads via PlusVibe UI or a future skill
- Pause/restart existing campaigns - this is a launch tool, not a campaign manager (yet)
- Choose subjects for the user - subjects are user-provided per the source-of-truth rule
- Pick a schedule for the user - same reason; schedule is user-provided

## One-time setup

Already done if the user followed the PlusVibe-API setup:

```bash
# API key in ~/.olympolabs/plusvibe.json (mode 600)
cat ~/.olympolabs/plusvibe.json
# Optional: default workspace_id in the same file under "default_workspace_id"
```

If the file or key is missing, the underlying `plusvibe-api` foundation surfaces a clear error pointing the user at https://app.plusvibe.ai/v2/settings/api-access/. Don't try to recover by faking an upload.

## Workflow

### Step 1 - Find the `final.md`

The skill works from a Spintax `final.md`. Most of the time the user has just finished spam-checking the file and the path is fresh in the conversation; if not, ask:

> Which `final.md` should I push to PlusVibe? Either paste the path or drop me a campaign folder name (under `~/Desktop/OlympoLabs-Skills/copywriter-workspace/runs/`).

Resolve the path. If only a folder was given, append `/final.md`. If the file doesn't exist, surface that and stop - don't fall back to `draft.md` or `spintaxed.md` silently because the user might have specifically intended the spam-cleaned version.

### Step 2 - Run the interview

Ask for **all six inputs in one consolidated message**, the same shape Copywriter uses. Pre-fill anything you can infer (campaign name from the folder, default workspace from credentials, etc.). Don't ask for things the conversation already supplied.

> Before I push to PlusVibe, I need:
>
> 1. **Workspace** - which client account? (Available: list from the workspaces call; e.g. OLYMPO LABS, GLOBALTIZE, KATMAI, ...) Or paste a workspace_id.
> 2. **Campaign name** - what should it be called in PlusVibe? (Default suggestion: derived from the folder name + today's date.)
> 3. **Subject lines** - one per pair, in pair order. Or one default for all variations. Subjects can include `{{first_name}}` etc. (Email 2 is always a reply-in-thread, so no subject needed for follow-ups.)
> 4. **Schedule** - timezone, days of week, hours, daily limit, daily limit for new leads, start date. Or say "default" and I'll use: M-F, 9am-6pm in the workspace's local TZ, 100/day, 50 new leads/day, start tomorrow.
> 5. **Email accounts** - say "all" to attach every ACTIVE inbox in the workspace, or paste a list of account IDs / tags to filter.
> 6. **First wait time + follow-up gap** - minutes before the first send (default 60), days between step 1 and step 2 (default 3).

If the user is sparse, ASK for clarification before generating. Do not autopilot subjects or schedule - those are decisions belonging to the user (same principle as the Copywriter skill).

### Step 3 - Validate before sending the API call

Before running `launch_campaign.py`, sanity-check:

1. **The input file has spintax in it.** The launcher will refuse (exit 9) if the file contains zero `{{random|...}}` blocks - that's almost always a sign that the user passed a Copywriter `draft.md` by mistake instead of a Spintax `final.md`. If you see the guard fire, STOP and ask the user to run Spintax first, don't reach for `--skip-spintax-check` to bypass it. Production campaigns without spintax kill inbox-level uniqueness, which is the whole point of variations.
2. **Subject count matches pair count.** If the user gave 3 subjects but final.md has 5 pairs, ask which subject applies to which pair OR have them supply more. If they say "use one subject for all 5", duplicate it.
3. **Schedule fields look complete.** `start_date` is `YYYY-MM-DD`, `timing.from` and `timing.to` are `HH:MM`, `days` is a `{1..7: bool}` map (Mon=1), `timezone` is an IANA string (e.g. `America/New_York`, NOT `EST`).
4. **Workspace ID matches a real workspace** - if the user said a name, call `list_workspaces()` and confirm the lookup. If multiple workspaces match by substring, ask which.

Don't run the launcher until all four pass.

### Step 4 - Drop the inputs into /tmp and run the launcher

Write three JSON files to `/tmp/` for the launcher to read:

```bash
# /tmp/pv-subjects.json  - list of strings, one per pair
# /tmp/pv-schedule.json  - the schedules object
# /tmp/pv-accounts.json  - list of account_id strings (only if user specified a subset)
```

Then invoke the launcher:

```bash
python3 ~/Desktop/OlympoLabs-Skills/plusvibe-campaign-manager/scripts/launch_campaign.py \
  --final-md "<path-to-final.md>" \
  --workspace-id "<resolved-workspace-id>" \
  --campaign-name "<resolved-name>" \
  --subjects-file /tmp/pv-subjects.json \
  --schedule-file /tmp/pv-schedule.json \
  [--email-accounts-file /tmp/pv-accounts.json] \
  --first-wait-time-minutes 60 \
  --follow-up-wait-days 3
```

(Omit `--email-accounts-file` to attach every ACTIVE account in the workspace.)

If the launcher exits non-zero, surface the stderr verbatim to the user. **Do not retry blindly.** Most likely culprits:

- Subject count mismatch (re-run the interview for subjects)
- Bad workspace_id (re-lookup)
- API auth error (point at `~/.olympolabs/plusvibe.json` and the regenerate URL)

### Step 5 - Show the result and ask about activation

The launcher prints a summary like:

```
===== Campaign created and configured =====
  campaign_id:   <id>
  workspace_id:  <id>
  name:          <name>
  steps:         2
  variations:    5 per step
  accounts:      2027
  status:        DRAFT (not yet sending)
  url:           https://app.plusvibe.ai/v2/campaign/<id>
```

Print this in chat verbatim, then ask the user:

> Campaign is configured but paused. Do you want me to activate it now, or do you want to inspect it in PlusVibe first and activate manually?

If they say yes, re-run the launcher with `--activate` against the SAME inputs (the launcher is idempotent on activation but the easier path is to call `client.activate_campaign(campaign_id, workspace_id=...)` directly via a one-liner python invocation). If they say no, do nothing - the campaign sits in DRAFT, the user activates from the PlusVibe UI when ready.

## Output conventions

The skill is mostly a wrapper around the launcher script - it doesn't produce its own files. The only artifact is the campaign in PlusVibe. The chat output should be tight:

- A confirmation block (the launcher's summary)
- The "Activate now?" question
- Whatever the user's response triggers

No invented success messages, no estimated send dates, no inferred reply-rate projections.

## Decision rules

### Subjects

- One subject per pair is the canonical case. The user provides them in pair order, and the launcher zips them into the step-1 variations.
- "One subject for all pairs" is fine - duplicate it across the variations.
- Step 2 subjects are ALWAYS empty (reply-in-thread). Don't ask the user about follow-up subjects.
- Personalization tokens (`{{first_name}}`, `{{company_name}}`) are allowed in subjects. So are spintax blocks (`{{random|a|b}}`) - PlusVibe expands them at send time.
- If the user wants A/B subject testing inside a single variation, they can include `{{random|subject A|subject B}}` directly. The skill doesn't second-guess this.

### Schedule defaults (only when the user explicitly says "default")

```json
{
  "daily_limit": 100,
  "daily_limit_new_lead": 50,
  "start_date": "<tomorrow in YYYY-MM-DD>",
  "end_date": "",
  "days": {"1": true, "2": true, "3": true, "4": true, "5": true},
  "timezone": "<workspace's TZ, or America/New_York if unknown>",
  "timing": {"from": "09:00", "to": "18:00"}
}
```

Do not invent a schedule if the user didn't say "default" - ask them.

### Email accounts

- Default: all `ACTIVE` accounts in the workspace. The launcher does this when `--email-accounts-file` is omitted.
- The OLYMPO LABS workspace alone has 2,000+ accounts attached to existing campaigns. Sending across all of them is usually what you want for high-volume agency operations, but ALWAYS confirm with the user before pushing.
- For client workspaces (KATMAI, GLOBALTIZE, etc.), expect smaller fleets (10-50 accounts). Same default applies.

### Variation labeling

Variations are labeled A, B, C... in pair order. Step 1 variation A pairs with step 2 variation A. PlusVibe's `R_ROBIN` (round-robin) variation selection should pair them at send time, but this hasn't been empirically verified - if a future test shows the pairing breaks, revisit by uploading each pair as a separate sub-campaign instead.

## Mandatory final-pass audit

Before declaring the campaign created, verify:

1. **Spam-word audit passes (HARD GATE)**. Run the audit script against the file you're about to upload:

   ```bash
   python3 ~/Desktop/OlympoLabs-Skills/plusvibe-spintax/scripts/audit_spam_words.py <path-to-final.md>
   ```

   Must exit `0` before any API call to PlusVibe. If exit `1`, fix the offending lines in `final.md` (the script prints exact line numbers and matched terms) and re-run until exit 0. The launcher script also runs this automatically and refuses to upload on any hit; don't pass `--skip-spam-audit` to bypass it unless the user has explicitly told you to (and even then, surface what you're skipping).

   When updating an *existing* campaign via the API directly (not the launcher), audit BOTH the source file AND the rendered bodies after fetching them back from PlusVibe — the round-trip can introduce silent body discrepancies. The "PATCH returned success" message is not proof the new bodies landed; re-fetch and re-audit.

   **Why this is mechanical, not eyeballed:** a production campaign once almost shipped with 39 spam-word hits because the audit was a hand-picked subset of the 387-term reference. The script removes that failure mode. Past prose-driven audit instructions were insufficient. See `plusvibe-spintax/SKILL.md` "Mandatory final-pass audit" for the full backstory.

2. **Subject count == pair count** in the launcher invocation.
3. **All approved tokens only** - if a subject contains `{{some_made_up_token}}`, flag it and ask the user before launching.
4. **Schedule timezone is IANA** - "EST", "PST", "CET" will be silently treated as `UTC` by PlusVibe and the campaign sends at wrong times. Reject those, require IANA strings.
5. **Status is DRAFT** in the launcher output (status: DRAFT confirms the activate flag was NOT set on the create step).
6. **Campaign URL works** - the launcher prints a `https://app.plusvibe.ai/v2/campaign/<id>` link. The user should be able to open it and see the configured campaign.
7. **The activate question was actually asked.** Don't activate silently.
8. **The launcher reported a non-zero spintax-block count** in its early output (`Spintax check OK: N spin block(s) ...`). If you see `Spintax check skipped`, the upload happened with non-spintaxed copy and the user almost certainly wants to know - surface that prominently rather than burying it.
9. **The launcher reported `Spam audit: CLEAN`** in its early output. If you see `Spam audit: FAIL`, the upload was refused and you need to fix the file before retrying.

If any check fails, surface the issue and don't proceed. The cost of asking is 30 seconds. The cost of launching wrong is a misfired campaign across thousands of leads.
