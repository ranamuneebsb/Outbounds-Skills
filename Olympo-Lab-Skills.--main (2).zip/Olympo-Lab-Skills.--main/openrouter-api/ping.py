#!/usr/bin/env python3
"""
Sanity-check the OpenRouter API key + a chosen model.

Calls `chat/completions` with a tiny prompt against the model passed on the
CLI (default: google/gemini-2.0-flash-lite, the cheapest viable model). Prints
the model's reply, token usage, and the estimated cost of the call.

Usage:
    python3 ping.py                                   # uses default cheap model
    python3 ping.py anthropic/claude-haiku-4.5        # different model
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from openrouter_auth import DEFAULT_CONFIG_PATH, MissingCredentials, load_credentials  # noqa: E402
from client import OpenRouterAuthError, OpenRouterClient, OpenRouterError  # noqa: E402
from pricing import estimate_cost, lookup  # noqa: E402


DEFAULT_MODEL = "google/gemini-2.0-flash-lite-001"


def main() -> int:
    model = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_MODEL

    try:
        creds = load_credentials()
    except MissingCredentials as exc:
        sys.stderr.write(f"{exc}\n")
        return 2

    print(f"Credentials source: {DEFAULT_CONFIG_PATH}")
    print(f"API key (first 12): {creds.api_key[:12]}...")
    print(f"Testing model: {model}")
    price = lookup(model)
    if price.name == "unknown":
        print("(no local pricing data for this model; cost will report $0)")
    else:
        print(f"Pricing: ${price.input_per_m}/M in, ${price.output_per_m}/M out")
    print()

    client = OpenRouterClient(credentials=creds)
    try:
        response = client.chat(
            model=model,
            messages=[
                {"role": "system", "content": "You are a terse model. Answer in one short sentence."},
                {"role": "user", "content": "What is 2+2? Reply just the number."},
            ],
            max_tokens=50,
        )
    except OpenRouterAuthError as exc:
        sys.stderr.write(f"AUTH FAILED: {exc}\n")
        return 3
    except OpenRouterError as exc:
        sys.stderr.write(f"API ERROR: {exc}\n")
        return 4

    print("OK - OpenRouter call succeeded.")
    content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
    print(f"Model said: {content!r}")
    usage = client.usage_tokens(response)
    cost = estimate_cost(model, usage["input"], usage["output"], usage["cached_input"])
    print()
    print("Token usage:")
    print(json.dumps(usage, indent=2))
    print(f"Estimated cost: ${cost:.6f}")
    print(f"Served by: {response.get('model', '?')}")
    print(f"Request id: {response.get('id', '?')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
