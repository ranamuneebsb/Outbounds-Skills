# Personalization profile

Save reusable personalization directives at `~/.olympolabs/personalization-prompts/<slug>.md`
in this format. Reference at run time with `--profile <slug>`.

## Directive
Notice that <company> is expanding into <new market or product line>.

## Fallback
B2B SaaS founders

---

Notes:
- The body under `## Directive` and `## Fallback` is taken verbatim — preserve
  the exact wording, punctuation, and length you want.
- Anything before the first `##` header (a title, comments, etc.) is ignored
  by the parser. Use it for human-readable notes.
- Both sections are required. Loader errors if either is missing or empty.

Examples to crib from:

### Literal phrase (no variation, every row gets the same string)

```markdown
## Directive
Commercial loans in Florida

## Fallback
Commercial loans nationwide
```

### Sentence template (LLM substitutes the company name + a real fact)

```markdown
## Directive
Noticed that Sony is expanding into electronics.

## Fallback
B2B founders growing fast
```

### Topic / role descriptor

```markdown
## Directive
CTOs in manufacturing companies

## Fallback
operations leaders in industry
```
