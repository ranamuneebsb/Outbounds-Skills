#!/usr/bin/env python3
"""
Personalization orchestrator.

Reads a Google Sheet or local CSV (one row per company) that has a 'Scrape Content'
column produced by the company-scoring skill, and generates a per-row personalization
snippet in the user's chosen style. Each row's snippet is either:

  - A real, company-specific snippet following the user's DIRECTIVE, or
  - The user-provided FALLBACK string verbatim, when the LLM judges that
    forcing the directive on this row would produce something generic or
    inauthentic (or when the Scrape Content cell is empty).

Output is written to a new column "Personalization" at the right edge of the
sheet (or to a sidecar <name>.personalized.csv in CSV mode).

Design mirrors the name-normalizer skill:
- Batched LLM calls (20 rows/call), 16 concurrent workers
- Write back live to Sheets, write CSV sidecar at the end
- Preview mode (--preview N) for the tweak loop: scores N rows, prints
  side-by-side, doesn't write
- Resume mode: rows that already have a non-empty Personalization value are
  skipped unless --force-rerun is passed

The DIRECTIVE + FALLBACK can be supplied two ways:
  1. Inline via --directive and --fallback CLI flags
  2. Via --profile <slug> which reads ~/.olympolabs/personalization-prompts/<slug>.md
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Locate the shared foundations (openrouter-api, google-sheets-api).
_SKILLS_ROOT_CANDIDATES = [
    Path(__file__).resolve().parent.parent.parent,
    Path.home() / "Desktop" / "OlympoLabs-Skills",
]
_SKILLS_ROOT = next(
    (p for p in _SKILLS_ROOT_CANDIDATES if (p / "openrouter-api" / "client.py").exists()),
    None,
)
if _SKILLS_ROOT is None:
    sys.stderr.write(
        "ERROR: cannot locate the openrouter-api / google-sheets-api foundations.\n"
        "Tried:\n" + "".join(f"  - {p}\n" for p in _SKILLS_ROOT_CANDIDATES)
    )
    sys.exit(2)

sys.path.insert(0, str(Path(__file__).resolve().parent))

import importlib.util


def _load_module(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_name} from {file_path}")
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(Path(file_path).parent))
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


_or_client_mod = _load_module("or_client", _SKILLS_ROOT / "openrouter-api" / "client.py")
_or_pricing_mod = _load_module("or_pricing", _SKILLS_ROOT / "openrouter-api" / "pricing.py")

OpenRouterClient = _or_client_mod.OpenRouterClient
OpenRouterError = _or_client_mod.OpenRouterError
or_estimate_cost = _or_pricing_mod.estimate_cost

from column_detect import (  # noqa: E402
    detect_input_columns,
    detect_output_column,
    PERSONALIZATION_HEADER,
)
from prompts import SYSTEM_PROMPT, build_user_message, truncate_scrape  # noqa: E402


# ---- Company-key normalization (used for de-duplication) ----

def normalize_company_key(domain: str, company_name: str) -> str:
    """Return a stable key that groups rows belonging to the same company.

    Prefers the domain when present (normalized: lowercase, stripped protocol /
    www / trailing slash). Falls back to a normalized company name when the
    domain column is blank. Returns "" when neither is usable — caller treats
    "" as "don't dedupe this row".
    """
    d = (domain or "").strip().lower()
    d = re.sub(r"^https?://", "", d)
    d = re.sub(r"^www\.", "", d)
    d = d.rstrip("/")
    # Some scraped lists have a trailing path; keep only the bare host
    d = d.split("/")[0]
    if d:
        return f"d:{d}"
    c = re.sub(r"[^a-z0-9]", "", (company_name or "").lower())
    if c:
        return f"c:{c}"
    return ""


# ---- Constants ----

DEFAULT_MODEL = "anthropic/claude-sonnet-4.6"
DEFAULT_BATCH_SIZE = 20
DEFAULT_CONCURRENCY = 8
DEFAULT_WRITE_BATCH_SIZE = 100
DEFAULT_PREVIEW = 20

PROFILE_DIR = Path.home() / ".olympolabs" / "personalization-prompts"


# ---- Profile loader ----

def load_profile(slug: str) -> Tuple[str, str]:
    """Load DIRECTIVE + FALLBACK from a saved profile file.

    File format (markdown, human-editable):

        # any preamble/title here is ignored

        ## Directive
        <one or more lines of directive text>

        ## Fallback
        <one or more lines of fallback text>
    """
    path = PROFILE_DIR / f"{slug}.md"
    if not path.exists():
        raise FileNotFoundError(f"profile not found: {path}")
    text = path.read_text(encoding="utf-8")
    sections: Dict[str, List[str]] = {}
    current_header: Optional[str] = None
    for line in text.splitlines():
        m = re.match(r"^##\s+(\S.*?)\s*$", line)
        if m:
            current_header = m.group(1).strip().lower()
            sections.setdefault(current_header, [])
            continue
        if current_header is not None:
            sections[current_header].append(line)
    directive = "\n".join(sections.get("directive", [])).strip()
    fallback = "\n".join(sections.get("fallback", [])).strip()
    if not directive:
        raise ValueError(f"profile {path} missing '## Directive' section")
    if not fallback:
        raise ValueError(f"profile {path} missing '## Fallback' section")
    return directive, fallback


# ---- Batch normalizer ----

class BatchPersonalizer:
    """Runs one batch of rows through the LLM and returns a list of dicts.

    Maintains per-thread totals so the orchestrator can aggregate cost across
    workers at the end.
    """

    def __init__(self, model: str, or_client: OpenRouterClient, directive: str, fallback: str):
        self._model = model
        self._or = or_client
        self._directive = directive
        self._fallback = fallback
        self.totals = {
            "calls": 0, "rows": 0, "input_tokens": 0,
            "output_tokens": 0, "cost_usd": 0.0, "errors": 0,
        }

    def personalize_batch(self, batch: List[Dict[str, Any]], *, max_retries: int = 2) -> List[Dict[str, Any]]:
        """Send one batch of rows through the LLM, return idx-aligned results.

        Each result is {"idx": int, "personalization": str | None}.
        On parse failure after retries, every row in the batch falls back to None.
        """
        attempts = 0
        last_err: Optional[Exception] = None
        while attempts <= max_retries:
            attempts += 1
            try:
                resp = self._or.chat(
                    model=self._model,
                    messages=[
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": build_user_message(self._directive, self._fallback, batch)},
                    ],
                    json_mode=True,
                    temperature=0.2,  # slight variation so identical-shape rows don't collide
                    max_tokens=4000,
                )
                parsed = self._or.parse_json_content(resp)
                usage = self._or.usage_tokens(resp)
                cost = or_estimate_cost(
                    self._model,
                    input_tokens=usage["input"],
                    output_tokens=usage["output"],
                    cached_input_tokens=usage.get("cached_input", 0),
                )
                self.totals["calls"] += 1
                self.totals["rows"] += len(batch)
                self.totals["input_tokens"] += usage["input"]
                self.totals["output_tokens"] += usage["output"]
                self.totals["cost_usd"] += cost

                results_raw = parsed.get("results")
                if not isinstance(results_raw, list):
                    raise OpenRouterError(f"Response missing 'results' array: {parsed!r}")

                by_idx: Dict[int, Optional[str]] = {}
                for entry in results_raw:
                    if not isinstance(entry, dict):
                        continue
                    try:
                        idx_val = int(entry["idx"])
                    except (KeyError, TypeError, ValueError):
                        continue
                    p_val = entry.get("personalization")
                    if isinstance(p_val, str):
                        p_val = p_val.strip()
                        if not p_val:
                            p_val = None
                    elif p_val is not None:
                        p_val = str(p_val).strip() or None
                    by_idx[idx_val] = p_val

                out: List[Dict[str, Any]] = []
                for row in batch:
                    idx = int(row["idx"])
                    out.append({"idx": idx, "personalization": by_idx.get(idx)})
                return out
            except (OpenRouterError, json.JSONDecodeError, KeyError) as exc:
                last_err = exc
                continue

        # Exhausted retries — treat every row as null so orchestrator substitutes fallback
        self.totals["errors"] += 1
        return [
            {"idx": int(r["idx"]), "personalization": None, "__error": str(last_err)[:200] if last_err else "unknown"}
            for r in batch
        ]


# ---- Argparse + main ----

def main() -> int:
    parser = argparse.ArgumentParser(description="Generate per-company personalization snippets from Scrape Content.")

    # Input source
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--sheet-url", help="Google Sheets URL or ID")
    src.add_argument("--csv-path", help="Path to a CSV file (the .personalized.csv sidecar with Scrape Content)")
    parser.add_argument("--csv-out", help=(
        "Output path for CSV mode. Default writes to <input>_personalized.csv as a sibling. "
        "Pass --csv-out same to overwrite the input file in place."
    ))
    parser.add_argument("--worksheet", help="Worksheet/tab title (Sheets mode only; defaults to first tab)")

    # Personalization directive + fallback
    parser.add_argument("--directive", help=(
        "What kind of personalization to generate. Could be a literal phrase ('Real Estate'), "
        "a sentence template/example ('Noticed that Sony is expanding into electronics'), "
        "or a topic ('CTOs in manufacturing companies')."
    ))
    parser.add_argument("--fallback", help=(
        "String to substitute for rows where the directive can't be applied authentically "
        "(empty Scrape Content, or LLM judges the result too generic). e.g. 'B2B SaaS founders'."
    ))
    parser.add_argument("--profile", help=(
        "Alternative to --directive/--fallback: read both from "
        "~/.olympolabs/personalization-prompts/<slug>.md. The file must contain "
        "'## Directive' and '## Fallback' sections."
    ))

    # Run shaping
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--company-col", type=int, help="Override 1-based company-name column")
    parser.add_argument("--scrape-col", type=int, help="Override 1-based Scrape Content column")
    parser.add_argument("--max-rows", type=int, help="Cap rows processed (testing)")
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE)
    parser.add_argument("--concurrency", type=int, default=DEFAULT_CONCURRENCY)
    parser.add_argument("--write-batch-size", type=int, default=DEFAULT_WRITE_BATCH_SIZE)
    parser.add_argument(
        "--preview", type=int, metavar="N", nargs="?", const=DEFAULT_PREVIEW,
        help=(
            "Preview mode: generate personalizations for the first N rows (default 20), "
            "print side-by-side to stdout, DO NOT write back. Use this for the tweak loop."
        ),
    )
    parser.add_argument("--force-rerun", action="store_true", help=(
        "Re-generate personalizations even for rows that already have a value. "
        "Default skips already-personalized rows (resume mode)."
    ))
    parser.add_argument("--no-dedupe", action="store_true", help=(
        "Disable company-level deduplication. By default the script groups rows "
        "by domain (or normalized company name if domain is blank), calls the "
        "LLM once per unique company, and propagates the result to every "
        "contact at that company. Pass --no-dedupe to call the LLM separately "
        "for every row (rare — only useful if you specifically want per-contact "
        "variation despite identical scrape content)."
    ))
    parser.add_argument("--dry-run", action="store_true", help="Print plan, don't call APIs or write back")
    args = parser.parse_args()

    csv_mode = bool(args.csv_path)

    # Resolve directive + fallback
    if args.profile:
        if args.directive or args.fallback:
            sys.stderr.write("ERROR: --profile is mutually exclusive with --directive/--fallback\n")
            return 2
        try:
            directive, fallback = load_profile(args.profile)
        except (FileNotFoundError, ValueError) as exc:
            sys.stderr.write(f"ERROR: {exc}\n")
            return 3
    else:
        if not args.directive or not args.fallback:
            sys.stderr.write(
                "ERROR: must pass --directive AND --fallback (or --profile <slug>)\n"
                "  --directive 'What kind of personalization to generate'\n"
                "  --fallback  'String to use when directive can't be applied'\n"
            )
            return 2
        directive, fallback = args.directive, args.fallback

    print(f"Directive: {directive!r}")
    print(f"Fallback:  {fallback!r}")

    if args.preview:
        args.max_rows = args.preview

    # ---- Resolve input source: Sheet or CSV ----
    sheet_id: Optional[str] = None
    worksheet_title: Optional[str] = None
    sheets: Optional[Any] = None
    csv_raw_rows: Optional[List[List[str]]] = None
    col_index_to_letter = None

    if csv_mode:
        import csv as _csv
        csv_in = Path(args.csv_path).expanduser().resolve()
        if not csv_in.exists():
            sys.stderr.write(f"ERROR: --csv-path not found: {csv_in}\n")
            return 3
        print(f"CSV: {csv_in}")
        with csv_in.open(newline="", encoding="utf-8") as f:
            csv_raw_rows = [list(r) for r in _csv.reader(f)]
        if not csv_raw_rows:
            sys.stderr.write("ERROR: CSV is empty\n")
            return 3
        rows = csv_raw_rows
    else:
        # Lazy-load the Sheets client only in Sheets mode
        _gs_client_mod = _load_module("gs_client", _SKILLS_ROOT / "google-sheets-api" / "client.py")
        SheetsClient = _gs_client_mod.SheetsClient
        extract_sheet_id = _gs_client_mod.extract_sheet_id
        col_index_to_letter = _gs_client_mod.col_index_to_letter
        sheet_id = extract_sheet_id(args.sheet_url)
        print(f"Sheet: {sheet_id}")
        sheets = SheetsClient()
        worksheets = sheets.list_worksheets(sheet_id)
        if not worksheets:
            sys.stderr.write("ERROR: spreadsheet has no worksheets\n")
            return 3
        if args.worksheet:
            ws = next((w for w in worksheets if w["title"] == args.worksheet), None)
            if not ws:
                sys.stderr.write(
                    f"ERROR: worksheet {args.worksheet!r} not found. Available: "
                    + ", ".join(w["title"] for w in worksheets) + "\n"
                )
                return 3
        else:
            ws = worksheets[0]
        worksheet_title = ws["title"]
        print(f"Worksheet: {worksheet_title!r} ({ws['rowCount']} rows x {ws['columnCount']} cols)")
        rows = sheets.read_full_sheet(sheet_id, worksheet_title)

    if not rows:
        sys.stderr.write("ERROR: input is empty\n")
        return 3
    headers = rows[0]
    data_rows = rows[1:]
    print(f"Headers ({len(headers)}): {[str(h) for h in headers]}")
    print(f"Data rows: {len(data_rows)}")

    # ---- Detect / confirm columns ----
    detected = detect_input_columns(headers)
    if args.company_col is not None:
        detected["company"] = args.company_col or None
    if args.scrape_col is not None:
        detected["scrape"] = args.scrape_col or None
    print(f"Detected input columns: {detected}")

    if not detected.get("company"):
        sys.stderr.write("ERROR: could not detect a company-name column. Pass --company-col N.\n")
        return 4
    if not detected.get("scrape"):
        sys.stderr.write(
            "ERROR: could not detect a 'Scrape Content' column. This skill consumes the column "
            "produced by the company-scoring skill — run that first, then this. "
            "Or pass --scrape-col N to point at a different text column.\n"
        )
        return 4

    company_col_idx = detected["company"]
    scrape_col_idx = detected["scrape"]
    domain_col_idx = detected.get("domain")  # optional — improves dedupe accuracy when present

    # Detect existing Personalization column for resume mode + writeback
    existing_p_col = detect_output_column(headers)
    if existing_p_col is None:
        # We'll need to add the column. For sheets, this happens via append-columns at write time.
        # For preview mode in CSV, we just don't write.
        new_personalization_col = len(headers) + 1  # 1-based; would land at right edge
    else:
        new_personalization_col = existing_p_col

    print(f"Using company column {company_col_idx}, scrape column {scrape_col_idx}, "
          + (f"domain column {domain_col_idx}, " if domain_col_idx else "no domain column, ")
          + f"personalization column {new_personalization_col} "
          + f"({'existing' if existing_p_col else 'will be appended'}).")

    # ---- Build pending list ----
    # Each pending entry gets a `company_key` derived from domain (preferred)
    # or normalized company name. Rows that share a key share an LLM call.
    pending: List[Dict[str, Any]] = []
    unique_keys_seen: int = 0  # counts the number of distinct keys at --max-rows enforcement time
    seen_keys: set = set()
    for i, row in enumerate(data_rows):
        sheet_row_idx = i + 2  # row 1 is header
        raw_company = row[company_col_idx - 1] if company_col_idx - 1 < len(row) else ""
        raw_scrape = row[scrape_col_idx - 1] if scrape_col_idx - 1 < len(row) else ""
        raw_domain = ""
        if domain_col_idx and domain_col_idx - 1 < len(row):
            raw_domain = str(row[domain_col_idx - 1] or "").strip()
        existing_p = ""
        if existing_p_col is not None and existing_p_col - 1 < len(row):
            existing_p = str(row[existing_p_col - 1] or "").strip()

        company_name = str(raw_company or "").strip()
        scrape_excerpt = truncate_scrape(str(raw_scrape or "").strip())

        # Skip in resume mode if already personalized (unless --force-rerun)
        if existing_p and not args.force_rerun:
            continue
        # Skip rows with no company at all (no point personalizing nothing)
        if not company_name:
            continue

        # Compute the dedupe key. With --no-dedupe, each row gets a unique key
        # (its sheet row index) so the grouping degenerates to one group per row.
        if args.no_dedupe:
            company_key = f"row_{sheet_row_idx}"
        else:
            company_key = normalize_company_key(raw_domain, company_name)
            # Fall back to a row-unique key if neither domain nor name produced one
            if not company_key:
                company_key = f"row_{sheet_row_idx}"

        pending.append({
            "sheet_row_idx": sheet_row_idx,
            "company_name": company_name,
            "scrape_excerpt": scrape_excerpt,
            "raw_company": company_name,
            "company_key": company_key,
        })

        # --max-rows now counts UNIQUE companies, not raw rows. This matches user
        # intuition for --preview 20 (means "20 companies' worth", not "first 20
        # CSV rows which might all be at the same company").
        if company_key not in seen_keys:
            seen_keys.add(company_key)
            unique_keys_seen += 1
        if args.max_rows and unique_keys_seen >= args.max_rows:
            break

    # ---- Group pending rows by company_key (one LLM call per unique company) ----
    # `groups` preserves first-seen order so output is deterministic.
    groups: Dict[str, List[int]] = {}  # company_key -> list of indices into `pending`
    for i, p in enumerate(pending):
        groups.setdefault(p["company_key"], []).append(i)
    # `representatives` is one entry per group (the first pending row in each group).
    representatives: List[Dict[str, Any]] = [pending[idxs[0]] for idxs in groups.values()]

    n_total_rows = len(pending)
    n_unique = len(representatives)
    n_dupes = n_total_rows - n_unique
    if n_dupes > 0:
        savings_pct = n_dupes * 100 // n_total_rows
        print(f"Rows queued for personalization: {n_total_rows}  "
              f"→ {n_unique} unique companies "
              f"({n_dupes} duplicate contact rows will share results, ~{savings_pct}% LLM savings)")
    else:
        print(f"Rows queued for personalization: {n_total_rows}  "
              f"→ {n_unique} unique companies (no duplicates)")

    if not pending:
        print("Nothing to do.")
        return 0

    if args.dry_run:
        print("\n=== DRY RUN ===")
        for rep in representatives[:5]:
            excerpt = (rep["scrape_excerpt"][:120] + "...") if len(rep["scrape_excerpt"]) > 120 else rep["scrape_excerpt"]
            n_rows_in_group = len(groups[rep["company_key"]])
            print(f"  {rep['company_name']!r} ({n_rows_in_group} contact row(s)): scrape_excerpt={excerpt!r}")
        if len(representatives) > 5:
            print(f"  ... and {len(representatives) - 5} more unique companies")
        return 0

    # ---- Chunk REPRESENTATIVES into batches (one LLM call per unique company) ----
    batches: List[List[Dict[str, Any]]] = []
    bs = max(1, int(args.batch_size))
    for start in range(0, len(representatives), bs):
        chunk = representatives[start:start + bs]
        payload = [
            {
                "idx": j,
                "company_name": item["company_name"],
                "scrape_excerpt": item["scrape_excerpt"],
            }
            for j, item in enumerate(chunk)
        ]
        batches.append(payload)
    print(f"Sending {len(batches)} batches of up to {bs} rows each, concurrency={args.concurrency}.")

    # ---- Run batches concurrently ----
    thread_local = threading.local()
    personalizers_list: List[BatchPersonalizer] = []
    personalizers_lock = threading.Lock()

    def get_personalizer() -> BatchPersonalizer:
        if not hasattr(thread_local, "personalizer"):
            bp = BatchPersonalizer(model=args.model, or_client=OpenRouterClient(),
                                   directive=directive, fallback=fallback)
            with personalizers_lock:
                personalizers_list.append(bp)
            thread_local.personalizer = bp
        return thread_local.personalizer

    started_at = time.time()
    results_by_batch: Dict[int, List[Dict[str, Any]]] = {}
    results_lock = threading.Lock()

    def process_batch(batch_idx: int, batch: List[Dict[str, Any]]):
        bp = get_personalizer()
        out = bp.personalize_batch(batch)
        with results_lock:
            results_by_batch[batch_idx] = out
        return batch_idx

    with ThreadPoolExecutor(max_workers=max(1, args.concurrency)) as ex:
        futures = [ex.submit(process_batch, bi, b) for bi, b in enumerate(batches)]
        done = 0
        for fut in as_completed(futures):
            fut.result()
            done += 1
            if done % 5 == 0 or done == len(batches):
                print(f"  ... {done}/{len(batches)} batches done")

    elapsed_llm = time.time() - started_at

    # ---- Map each unique company's LLM result back to its company_key ----
    result_by_key: Dict[str, Optional[str]] = {}
    for bi, payload in enumerate(batches):
        batch_results = results_by_batch.get(bi, [])
        result_by_idx = {int(r["idx"]): r for r in batch_results if "idx" in r}
        for j in range(len(payload)):
            r = result_by_idx.get(j, {})
            rep = representatives[bi * bs + j]
            result_by_key[rep["company_key"]] = r.get("personalization")

    # ---- Expand back to one personalization per pending row (propagate within groups) ----
    personalized: List[Dict[str, Any]] = []
    fallback_count = 0
    direct_count = 0
    for pending_row in pending:
        llm_value = result_by_key.get(pending_row["company_key"])
        if llm_value is None or not llm_value:
            final_value = fallback
            fallback_used = True
            fallback_count += 1
        else:
            final_value = llm_value
            fallback_used = False
            direct_count += 1
        personalized.append({
            "sheet_row_idx": pending_row["sheet_row_idx"],
            "company_name": pending_row["company_name"],
            "scrape_excerpt": pending_row["scrape_excerpt"],
            "personalization": final_value,
            "fallback_used": fallback_used,
        })

    # ---- Preview path ----
    if args.preview:
        print(f"\n=== PREVIEW: first {len(personalized)} rows (no writes performed) ===\n")
        company_w = max(20, max(len(r["company_name"][:30]) for r in personalized))
        for r in personalized:
            tag = "  [fallback]" if r["fallback_used"] else ""
            print(f"  row {r['sheet_row_idx']:>4}  {r['company_name'][:30]:<{company_w}}  ->  "
                  f"{r['personalization']}{tag}")
        totals = _aggregate_totals(personalizers_list)
        print(f"\nPreview: {len(personalized)} rows in {elapsed_llm:.1f}s. "
              f"LLM cost: ${totals['cost_usd']:.4f} "
              f"(direct={direct_count}, fallback={fallback_count}, "
              f"calls={totals['calls']}, errors={totals['errors']}).")
        return 0

    # ---- Write back ----
    write_started = time.time()
    written = 0

    if csv_mode:
        csv_in = Path(args.csv_path).expanduser().resolve()
        if args.csv_out is None:
            csv_out = csv_in.with_name(csv_in.stem + "_personalized" + csv_in.suffix)
        elif args.csv_out.lower() == "same":
            csv_out = csv_in
        else:
            csv_out = Path(args.csv_out).expanduser().resolve()

        # If we're appending a new column, extend the header and every row.
        if existing_p_col is None:
            csv_raw_rows[0] = list(csv_raw_rows[0]) + [PERSONALIZATION_HEADER]
            for i in range(1, len(csv_raw_rows)):
                csv_raw_rows[i] = list(csv_raw_rows[i]) + [""]

        for r in personalized:
            file_row_idx = r["sheet_row_idx"] - 1
            target_col_idx = new_personalization_col - 1
            while len(csv_raw_rows[file_row_idx]) <= target_col_idx:
                csv_raw_rows[file_row_idx].append("")
            csv_raw_rows[file_row_idx][target_col_idx] = r["personalization"]
            written += 1

        import csv as _csv
        csv_out.parent.mkdir(parents=True, exist_ok=True)
        with csv_out.open("w", newline="", encoding="utf-8") as f:
            w = _csv.writer(f)
            w.writerows(csv_raw_rows)
        print(f"\nWrote {written} personalizations to {csv_out}")
        elapsed_write = time.time() - write_started
    else:
        # Sheets mode: append the column if needed, then live-write
        if existing_p_col is None:
            start_col = sheets.append_columns(sheet_id, worksheet_title, [PERSONALIZATION_HEADER])
            new_personalization_col = start_col
            print(f"Appended '{PERSONALIZATION_HEADER}' column at index {new_personalization_col}")
        col_letter = col_index_to_letter(new_personalization_col)

        pending_writes: List[Dict[str, Any]] = []
        for r in personalized:
            sheet_row = r["sheet_row_idx"]
            pending_writes.append({
                "range": f"{worksheet_title}!{col_letter}{sheet_row}",
                "values": [[r["personalization"]]],
            })
            written += 1
            if len(pending_writes) >= args.write_batch_size:
                sheets.batch_write(sheet_id, pending_writes)
                pending_writes = []
                print(f"  ... {written}/{len(personalized)} rows written")
        if pending_writes:
            sheets.batch_write(sheet_id, pending_writes)
        elapsed_write = time.time() - write_started

    # ---- Cost summary ----
    totals = _aggregate_totals(personalizers_list)
    print(f"\nPersonalized {written} rows in {elapsed_llm:.1f}s LLM + {elapsed_write:.1f}s write.")
    print(f"  Direct snippets: {direct_count}  ({direct_count*100//max(1,written)}%)")
    print(f"  Fallbacks used:  {fallback_count}  ({fallback_count*100//max(1,written)}%)")
    print(f"\nCost summary:")
    print(f"  Model: {args.model}")
    print(f"  Calls: {totals['calls']}  Rows: {totals['rows']}  Errors: {totals['errors']}")
    print(f"  Tokens: in={totals['input_tokens']} out={totals['output_tokens']}")
    print(f"  TOTAL: ${totals['cost_usd']:.4f}")
    return 0


def _aggregate_totals(personalizers: List[BatchPersonalizer]) -> Dict[str, Any]:
    rollup = {"calls": 0, "rows": 0, "input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0, "errors": 0}
    for p in personalizers:
        for k in ("calls", "rows", "input_tokens", "output_tokens", "errors"):
            rollup[k] += p.totals.get(k, 0)
        rollup["cost_usd"] += p.totals.get("cost_usd", 0.0)
    return rollup


if __name__ == "__main__":
    sys.exit(main())
