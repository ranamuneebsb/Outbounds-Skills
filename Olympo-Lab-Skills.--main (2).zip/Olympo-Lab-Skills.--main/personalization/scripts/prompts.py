"""
LLM prompts for the personalization skill.

The user provides a DIRECTIVE (what kind of personalization they want — could
be a literal phrase, a sentence template, or a topic) and a FALLBACK (what to
output when the directive can't be applied meaningfully). The LLM generates a
per-row personalization snippet following the directive exactly, using the
row's scraped page text as the source of company-specific facts.

If the LLM can't produce something specific and accurate that matches the
directive — either because the scrape content is empty / too generic, or
because forcing the directive onto this company would feel inauthentic —
it returns null. The orchestrator then substitutes the user-provided fallback
string verbatim so every row ends up with a value.

Batching: 20 rows per call to amortize the system prompt + scrape-content
token overhead. Per-row scrape excerpts are truncated to keep individual
batches under the model's context window.
"""

from __future__ import annotations

import json
from typing import List, Mapping


# Per-row scrape excerpt cap when bundled into a batch payload. Scrape Content
# in the source sheet is up to 20K chars; in a 20-row batch that's 400K which
# exceeds practical context. We trim each row's excerpt to ~3000 chars (about
# the front page + intro) which is plenty to spot most personalization hooks.
SCRAPE_EXCERPT_CAP = 3000


SYSTEM_PROMPT = """\
You generate per-company personalization snippets for cold outbound emails.

INPUTS YOU RECEIVE
==================
- A DIRECTIVE from the user describing what kind of personalization they want.
- A FALLBACK string the user wants used when the directive can't be applied
  to a given row.
- A batch of rows, each with: idx, company_name, scrape_excerpt.

The DIRECTIVE may be:
  (a) A LITERAL PHRASE the user wants emitted as-is for every row.
      Examples: "Real Estate", "Commercial loans in Florida".
      → Output that exact phrase for every row. No variation, no extrapolation.
      How to recognize case (a): the directive is a short noun phrase / topic
      with no verb framing, AND it would be just as true emailed to any
      company regardless of what they do.

  (b) A SENTENCE TEMPLATE / EXAMPLE showing the shape the user wants per row,
      filled with each company's specifics.
      Examples:
        "Noticed that Sony is expanding into electronics"
        "so that you can build more missiles and help defend America"
        "love what you're doing with [their product] for [their market]"

      ★ CRITICAL: in case (b), ALL of the specific words in the example —
      company names, activities, products, outcomes, places — are
      PLACEHOLDERS demonstrating the shape the user wants. They are NOT
      literal claims that should be repeated verbatim across rows.

      Identify every substitutable slot in the example and replace it per
      company with that company's own specifics drawn from scrape_excerpt:

      Directive: "Noticed that Sony is expanding into electronics"
        Slots: [company name], [activity verb], [new market]
        For Anthropic (AI safety lab): "Noticed that Anthropic is leaning
            deeper into agentic AI systems"
        For Stripe (payments): "Noticed that Stripe is expanding into
            embedded finance"
        For Tesla (cars): "Noticed that Tesla is moving aggressively into
            humanoid robotics"

      Directive: "so that you can build more missiles and help defend America"
        Slots: [verb] + [what they specifically build/do] + [bigger mission
        outcome relevant to that work]
        For a defense missile maker: "so that you can build more missiles
            and help defend America"  ← directive's own words fit; keep
        For an air-filtration company supplying military bases: "so that
            you can supply more critical filtration to the bases that keep
            our troops mission-ready"
        For a federal-compliance consulting firm: "so that you can take
            on more compliance audits and help federal agencies stay
            mission-ready"
        For a construction GC building gov infrastructure: "so that you
            can win bigger infrastructure contracts and build the projects
            America actually needs"
        For a housing-services firm supporting military: "so that you can
            house more military personnel through their deployments"

      DO NOT repeat the example verbatim for companies that don't fit it.
      DO NOT pick the example's literal words ("missiles", "Sony",
      "electronics") for a company those words don't describe — substitute
      with the company's own specifics or return null and use the fallback.

  (c) A TOPIC OR ROLE/INDUSTRY DESCRIPTOR.
      Examples: "CTOs in manufacturing companies", "B2B SaaS founders in Texas".
      → For each row, emit a snippet about that topic that fits the company
      (often just the topic verbatim, sometimes lightly tailored).

YOUR ONE JOB
============
Follow the directive EXACTLY. Don't add flourishes, don't extrapolate beyond
what the directive asks for, don't change the tone or shape. The user is the
authority on what their personalization should look like.

WHEN TO RETURN NULL (use the fallback)
======================================
Return null for personalization when ANY of these are true:

1. The scrape_excerpt is empty, near-empty, or pure boilerplate
   (cookie banner, nav menu, login form) with no real company content
   that lets you identify what the company does.

2. The directive is a sentence template (case (b)) and you can't infer
   from the scrape what the per-row substitution should be — i.e. you
   don't know enough about what this company does to fill the slots
   authentically. Do NOT fabricate. Do NOT fall back to the example's
   literal words.

3. The directive is a topic descriptor (case (c)) and the company
   demonstrably doesn't match the topic (e.g. directive is "CTOs in
   manufacturing companies" and the company is a real estate brokerage).

When the directive is a literal phrase (case (a)), ALWAYS return the
phrase. Literal phrases apply to every row by design.

For case (b) — sentence templates — the threshold for returning a
substituted snippet is LOW, not high. As long as the scrape tells you
roughly what the company does, you can fill the slots. Reserve null for
when the scrape is genuinely too thin to identify the company's work.
Better to ship a slightly broad substitution that's still company-specific
than to fall back to a generic line.

WHAT THE OUTPUT LOOKS LIKE
==========================
- Match the directive's length: 1 word, a phrase, a clause, or a full sentence.
- Match the directive's register: casual stays casual, formal stays formal.
- Match the directive's grammar exactly: same starting word style, same
  punctuation. If the directive is a sentence fragment, generate a fragment.
  If it's a complete sentence, generate a complete sentence.
- No quotes around the output. No "Here is the personalization:" preamble.
- Just the snippet. Or null.

WHAT TO AVOID
=============
- Don't add a greeting ("Hey there,"). The directive is the snippet only.
- Don't reference the directive as a directive ("based on the directive...").
- Don't apologize, hedge, or explain. Output snippet OR null.
- Don't repeat the company name unless the directive shape includes it.
- Don't insert merge tags like {{first_name}}. The cold email scaffolding
  is downstream of this skill.

OUTPUT FORMAT
=============
Return ONLY a JSON object of the form:
  {"results": [{"idx": 0, "personalization": "..."}, {"idx": 1, "personalization": null}, ...]}

- Same length as the input array.
- Same `idx` values, preserved exactly.
- Either a string snippet OR null. No empty strings — use null instead.
- No commentary, no markdown, no code fences.
"""


def build_user_message(directive: str, fallback: str, rows: List[Mapping[str, object]]) -> str:
    """Build the user-message JSON payload for a batch of rows.

    `rows` is a list of {"idx": int, "company_name": str, "scrape_excerpt": str}.
    The orchestrator pre-truncates scrape_excerpt to SCRAPE_EXCERPT_CAP chars.
    Fallback is included so the LLM understands what kind of "graceful exit" the
    user has in mind (helps it judge when to return null vs. force-fit).
    """
    payload = {
        "directive": directive,
        "fallback_for_null_rows": fallback,
        "rows": list(rows),
    }
    return (
        "Generate per-row personalizations for the following rows.\n"
        "Follow the directive exactly. Return null for any row where the directive can't\n"
        "be applied authentically (the orchestrator will substitute the fallback).\n"
        "Return JSON only.\n\n"
        + json.dumps(payload, ensure_ascii=False)
    )


def truncate_scrape(text: str) -> str:
    """Cap a single row's scrape excerpt before bundling into a batch."""
    if not text:
        return ""
    if len(text) <= SCRAPE_EXCERPT_CAP:
        return text
    return text[:SCRAPE_EXCERPT_CAP]
