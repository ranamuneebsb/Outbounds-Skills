"""
Column detection for the personalization skill.

Required columns:
  - company   : the company name (used as context in the LLM prompt)
  - scrape    : the "Scrape Content" column produced by the company-scoring skill

Optional (used as context if present, not required):
  - domain    : website domain
  - description : original description column (falls through to LLM context)

The personalization OUTPUT column is "Personalization" — written to the right
edge of the sheet/CSV if not already present.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Sequence


# Reuse the same input-detection patterns as company-scoring + name-normalizer
# so this skill drops cleanly onto sheets the other two have touched.

COMPANY_NAME_PATTERNS: List[str] = [
    r"^(company|account|organization|business|firm|brand)(name)?$",
    r"^(name|legalname|tradename|displayname)$",
]

DOMAIN_PATTERNS: List[str] = [
    r"^(company|primary|business)?(domain|website|url|site)$",
    r"^(companywebsite|companydomain|companysite|websiteurl|domainurl)$",
    r"^(homepageurl|homepage|webaddress|webpageurl)$",
]

DESCRIPTION_PATTERNS: List[str] = [
    r"^(company|business)?description$",
    r"^(snippet|summary|overview|about|profile|tagline|bio|blurb)$",
    r"^(short|long|company)description$",
    r"^(industrydescription|companyabout|aboutus|sitedescription)$",
]

# Scrape Content is the exact column name written by the company-scoring skill.
# It's case-sensitive there; we accept a couple of common variants here just in
# case a user has hand-renamed it.
SCRAPE_CONTENT_PATTERNS: List[str] = [
    r"^scrapecontent$",
    r"^scrape$",
    r"^scrapedcontent$",
    r"^scrapedtext$",
    r"^pagecontent$",
    r"^pagetext$",
]

# Output column the personalization skill writes
PERSONALIZATION_HEADER = "Personalization"


def _normalize(s: Any) -> str:
    if s is None:
        return ""
    text = str(s).lower()
    text = re.sub(r"[^a-z0-9]", "", text)
    return text


def _first_match(headers: Sequence[Any], patterns: Sequence[str]) -> Optional[int]:
    normalized = [_normalize(h) for h in headers]
    for pattern in patterns:
        regex = re.compile(pattern)
        for idx, h in enumerate(normalized, start=1):
            if h and regex.fullmatch(h):
                return idx
    return None


def detect_input_columns(headers: Sequence[Any]) -> Dict[str, Optional[int]]:
    """Detect company, scrape-content, domain, description columns.

    Returns a dict with 1-based column indices (or None when not found).
    'company' and 'scrape' are required; 'domain' and 'description' are optional context.
    """
    return {
        "company":     _first_match(headers, COMPANY_NAME_PATTERNS),
        "scrape":      _first_match(headers, SCRAPE_CONTENT_PATTERNS),
        "domain":      _first_match(headers, DOMAIN_PATTERNS),
        "description": _first_match(headers, DESCRIPTION_PATTERNS),
    }


def detect_output_column(headers: Sequence[Any]) -> Optional[int]:
    """Return the 1-based index of the 'Personalization' column, or None."""
    for idx, h in enumerate(headers, start=1):
        if (str(h) if h is not None else "").strip() == PERSONALIZATION_HEADER:
            return idx
    return None
