---
name: personalization
description: Generate per-row cold-email personalization snippets from the Scrape Content column written by company-scoring. Every run needs TWO user inputs — a DIRECTIVE (literal phrase, sentence template, or topic) and a FALLBACK string used when the directive can't be applied authentically. ALWAYS ASK THE USER FOR THE FALLBACK BEFORE RUNNING — never invent one, never guess from context, even if the directive seems clear. Writes a new "Personalization" column at the right edge. Trigger when the user wants to personalize a scored lead list, add a custom hook column, generate cold-email first lines, "add a personalization to this CSV", "give each row a custom opener", "personalize this list with X", "icebreakers for these companies", or "I want each row to have a [phrase/sentence] based on what we scraped". Iterative preview-and-tweak workflow (--preview 20 default), then full run. Supports Google Sheets and local CSV. Powered by Claude Sonnet 4.6 at ~$3 per 1,000 rows. Uses ~/.olympolabs/openrouter.json for the LLM key.
---

# Personalization

Generate per-company personalization snippets for cold outbound emails, reading the `Scrape Content` column that the **company-scoring** skill writes (trafilatura-extracted page text). Output goes to a new `Personalization` column the user can use as a merge tag (e.g. `{{personalization}}` in PlusVibe).

## ⚠️ Non-negotiable rule: ALWAYS ask the user for the fallback

Every run needs TWO user inputs: a DIRECTIVE and a FALLBACK. The directive may already be in the user's message that triggered the skill. **The fallback almost never is.**

**Never invent the fallback yourself.** Never pick a "sensible default" based on the directive. Never proceed without asking. Even if the directive is very clear, even if the user seems impatient, even if a fallback is obvious to you — STOP and ask the user before running.

The fallback is the user's safety net for rows where the directive can't be applied authentically. It's a tone/voice/positioning decision only the user can make for their campaign. Picking it for them silently means the user finds out about an unwanted fallback line in their list AFTER the run.

The right pattern, every single time:

1. User says something like: "personalize this CSV with [directive]"
2. You: "Got the directive. What should the fallback line be? It's used for rows where the directive can't be applied authentically (empty scrape or no specific signal). Example for the directive above: '[short example]'."
3. Wait for the user's fallback. Only then run.

If the user has explicitly given both in their initial message, or pointed at a saved `--profile <slug>`, fine — skip the ask. Otherwise: ask.

## When to use this skill

Most common moment: **after company-scoring + filtering to `ICP Verdict == Qualified`**, before generating cold-email copy with the copywriter skill. The personalization column becomes a per-lead merge variable that gives each email a custom opening line / phrase / topic anchor.

Also useful any time the user wants a custom hook column built on top of scraped page content — they always provide the style they want and the fallback for rows where it can't be done.

## What it does and doesn't do

**Does:**

- Reads the `Scrape Content` column for each row
- For each row, asks an LLM to generate a snippet in the user's directed style
- Falls back to the user-provided string when the LLM can't produce something authentic and specific
- Writes the result to a new `Personalization` column (or reuses the existing one for resume runs)
- Supports a preview-and-tweak loop: `--preview 20` runs the first 20 rows without writing

**Does NOT:**

- Re-scrape websites — uses whatever `Scrape Content` is already in the sheet/CSV. Re-run company-scoring first if the scrapes are stale or missing.
- Decide the directive or fallback for the user — those come from the user every run.
- Filter the list. The user filters by `ICP Verdict` before invoking this.
- Generate the cold email body. That's the copywriter skill. This produces ONE column the email body is templated against.

## The two inputs the user always provides

Every run needs both:

1. **DIRECTIVE** — what kind of snippet to generate. Could be any of:
   - **Literal phrase**: `"Real Estate"` → every row gets exactly "Real Estate" (no per-row variation).
   - **Sentence template / example**: `"Noticed that Sony is expanding into electronics"` → for each row, generate a sentence in that same shape, substituting the actual company name + a real fact from their scrape content.
   - **Topic / role descriptor**: `"CTOs in manufacturing companies"`, `"Commercial loans in Florida"` → emit a snippet about that topic per row.

2. **FALLBACK** — a string used verbatim when the directive can't be applied to a given row. Two cases trigger fallback:
   - The row's `Scrape Content` is empty (scrape failed during scoring, or it was scored from the description column).
   - The LLM judges that forcing the directive on this row would produce something inauthentic, generic, or factually wrong. The LLM is explicitly instructed to RETURN NULL rather than fabricate — null then becomes the fallback string in the orchestrator.

   Example fallback for the "Sony expanding" directive: `"B2B SaaS founders"` — so rows that don't have any expansion signal get a clean, generic line instead of a forced bad one.

## Workflow

### Step 1 — Resolve the source

Same pattern as company-scoring and name-normalizer. Ask the user:

> Which file should I personalize? Paste the Google Sheets URL or the CSV file path.

The CSV is typically the `<name>.scored.csv` sidecar from company-scoring (it already has the Scrape Content column).

### Step 2 — Capture the DIRECTIVE and FALLBACK from the user

This step is split into two checks. The DIRECTIVE may have been in the user's triggering message. The FALLBACK almost never is. **You must verify both before moving on.**

**Check 1: do you have an explicit directive?** If the user's message contained a phrase / sentence / topic they want as personalization, yes. Otherwise ask:

> What kind of personalization do you want? Could be a literal phrase, a sentence template showing the shape (e.g. "Noticed that X is expanding into Y"), or a topic descriptor.

**Check 2: do you have an explicit fallback?** Look back at the user's messages. Did they actually say "fallback should be ___"? If NO — even if the directive is crystal clear, even if a fallback seems obvious — STOP and ask:

> Got the directive. What should the fallback line be? It's used for rows where the directive can't be applied authentically (empty scrape, or no specific signal in the content). The orchestrator substitutes it verbatim for those rows.
>
> Example for your directive — `[propose ONE example fallback in the same tone, so the user has a reference. They can use it, edit it, or replace it.]`

**Do not assume.** Do not pick a "sensible default" silently. Do not run with a fallback you made up. The user must say their fallback in words you can quote.

(If the user has pointed at a saved profile via `--profile <slug>`, the profile file contains both — no ask needed.)

If the user wants to save the pair for reuse, write it to `~/.olympolabs/personalization-prompts/<slug>.md` in this format:

```markdown
# <profile name>

## Directive
<directive text>

## Fallback
<fallback text>
```

Then re-run with `--profile <slug>` instead of `--directive/--fallback`.

### Step 3 — Preview the first 20 rows (no writes)

```bash
# CSV:
python3 ~/.claude/skills/personalization/scripts/personalize.py \
  --csv-path "<path>" \
  --directive "<the user's directive>" \
  --fallback "<the user's fallback>" \
  --preview 20

# Sheets:
python3 ~/.claude/skills/personalization/scripts/personalize.py \
  --sheet-url "<url>" \
  --directive "..." --fallback "..." \
  --preview 20
```

Output is a row-by-row side-by-side: `row N  Company Name  ->  generated snippet [fallback]` (the `[fallback]` tag appears when the substitution fired).

Show this to the user and ask:

> Preview complete. Does this match what you wanted?
>
> - **"Looks good, run the full list"** → I'll drop the `--preview` flag and re-run.
> - **"Change the directive to..."** → I'll re-run preview with the new directive on the same first 20 rows.
> - **"Change the fallback to..."** → same, with a new fallback string.

Loop until the user signs off.

### Step 4 — Full run

Drop `--preview` and re-run with the approved directive + fallback:

```bash
python3 ~/.claude/skills/personalization/scripts/personalize.py \
  --csv-path "<path>" --directive "..." --fallback "..."
# or --sheet-url "..."
```

The script:
- Skips rows that already have a non-empty `Personalization` value (resume mode). Use `--force-rerun` to overwrite.
- Writes the new `Personalization` column at the right edge if it doesn't already exist.
- For CSV: writes the result to `<name>_personalized.csv` next to the input. Pass `--csv-out same` to overwrite in place, or `--csv-out <path>` for a specific output.
- Prints `Direct snippets: N  Fallbacks used: M` at the end so the user sees what fraction of the list got real personalization vs. fallback.

### Step 5 — Confirm + report

Print a one-line summary the user can act on:
- The output file path (CSV) or sheet URL
- Direct-vs-fallback ratio (if fallback ratio is high, the scrapes may be thin or the directive may be too specific to fit most rows)

## Decision rules

### Default model

`anthropic/claude-sonnet-4.6` — Sonnet is the model for this skill specifically. Personalization is the most judgment-heavy step in the pipeline (deciding whether a directive can be applied authentically, finding the right hook in scrape content, matching the exact register of the user's directive), so the smarter model earns its keep here even though it's ~10x the per-row cost of Flash. ~$3 per 1,000 rows. Override per-run with `--model` if you want to A/B against Flash or a cheaper model.

### Output column — canonical header

Always `Personalization`. Reuse if already present, append at the right edge if not.

### Resume mode is default

The skill skips rows where `Personalization` is non-empty. Pass `--force-rerun` to overwrite. Warn the user before re-running large lists (burns API spend).

### Company-level deduplication is default

Cold-email lists usually have multiple contacts at the same company (CEO + CTO + Head of Sales at Acme = 3 rows, same company). The personalization depends only on the company's scrape, NOT the contact, so calling the LLM 3 times produces 3 identical (or worse, randomly-different) results.

By default the skill groups rows by **domain** (preferred — `Website` column) or **normalized company name** (fallback when domain is blank), calls the LLM ONCE per unique company, and propagates the result to all contacts at that company. Typical savings: 10-30% LLM cost on real lists.

Side effects to mention to the user:
- The "Direct vs Fallback" ratio is now per-company, not per-contact. If a company's scrape is thin, all its contacts get the same fallback — consistently. Pre-dedupe runs sometimes had per-contact stochasticity that inflated the apparent direct rate; post-dedupe ratios are more honest.
- All contacts at the same company end up with the literally-identical Personalization string. This is correct — but worth flagging to the user since their previous mental model may have been "one personalization per row".

Pass `--no-dedupe` only if the user explicitly wants per-contact variation despite identical scrape content (rare).

### Per-row scrape excerpt cap

Each row's `Scrape Content` value is truncated to 3,000 chars before being bundled into the LLM batch. The full 20K cell value is preserved in the sheet; the trim only affects what the LLM sees per batch (keeps context windows manageable).

### Batching

20 rows per LLM call, 8 concurrent workers by default. Tuneable via `--batch-size` and `--concurrency`. Sheet writes flush every 100 rows.

### Temperature

`0.2` — slight variation so structurally-similar rows don't generate identical-looking snippets, low enough that the directive is still followed tightly.

## Mandatory final-pass audit

After the run completes, before declaring done:

1. **Output column was written.** Sheet: spot-check the last row by reading it back. CSV: confirm the sidecar exists and has the `Personalization` column.
2. **Direct/fallback ratio is sensible.** If `fallbacks_used / total > 50%`, surface that — either the directive is too narrow for the list, or many rows have thin/empty scrape content. The user may want to re-run company-scoring in force-scrape mode to refresh, or broaden the directive.
3. **No invented columns.** The only new column is `Personalization`.
4. **Resume mode worked if applicable.** If the user passed a sheet that already had partial personalizations, verify the run skipped them (look at "Rows queued for personalization").

## Troubleshooting

- **"could not detect a Scrape Content column"** — the input file hasn't been through the company-scoring skill yet, OR the column was renamed. Either run company-scoring first, or pass `--scrape-col N` to point at a different text column to use as the source.
- **Fallback ratio is very high (>70%)** — the directive is probably too specific for the list (e.g. you asked for "expanding into Asia" but most companies show no expansion signal). Try a broader directive, or run company-scoring in `--scrape-only` mode to get richer scrape content for description-mode rows.
- **OpenRouter 404 on the default model** — model name may have moved. Try the next Sonnet version (`anthropic/claude-sonnet-4.7` etc.) or fall back to `google/gemini-2.5-flash` (10x cheaper, less judgment headroom on borderline rows).
