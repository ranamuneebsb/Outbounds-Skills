---
name: company-scoring
description: Score a Google Sheet or local CSV of companies 1-10 for ICP fit using OpenRouter LLMs (cheap model on description column, ZenRows scrape + smarter model when not, smart-model escalation on 5-7 borderline scores). Writes 5 columns back — ICP Score, ICP Verdict, Scoring Source, ICP Reasoning, and Scrape Content (trafilatura page text persisted for scraped rows so downstream personalization can build first-line hooks without re-scraping). Use whenever the user wants to qualify a list against an ICP — "score this list", "qualify these leads", "rate these companies", "filter for X in this sheet", "score the Clay/Apollo list against the ICP", or anything like "I got X companies from Clay/Apollo/LinkedIn, tell me which match some ICP" even without saying "scoring". 7+ Qualified, under 7 Disqualified. Handles arbitrarily large CSVs via streaming SQLite, resumes mid-list, batches writes, logs cost, journals learnings. Sheets auth via gcloud ADC; keys at ~/.olympolabs/openrouter.json and ~/.olympolabs/zenrows.json.
---

# Company Scoring

Score a list of companies on a 1-10 ICP-fit scale and write the results back to the source (a Google Sheet, or a sidecar CSV). Designed for OlympoLabs's monthly volume (~500k-700k companies/month across all clients). Wraps three foundations:

- `openrouter-api/` (LLM calls, with model selection for cost-vs-quality tradeoff)
- `zenrows-api/` (scraping + trafilatura text extraction for companies without descriptions)
- `google-sheets-api/` (ADC auth, read + write back to the sheet in batches)

> ⚠️ **The scripts in this skill are prebuilt, complete, and self-contained. NEVER write, rewrite, or recreate them.** The foundation packages above ship VENDORED inside `scripts/lib/`, so the skill runs on any machine with zero setup time - there is no "build the scripts" step. If anything fails to run, it is an install/credentials problem, not a missing-code problem: run **`python3 scripts/doctor.py`** and fix exactly what it reports. Do not author Python to work around it.

## Engine (how it runs)

The orchestrator (`scripts/score_sheet.py`) is a thin shell around a proven scoring engine plus a **durable SQLite work queue** (`scripts/jobstore.py`) and a **source abstraction** (`scripts/sources.py`):

- **Two inputs, one engine.** A Google Sheet (`--sheet-url`) or a local CSV (`--csv-path`). Everything downstream is identical.
- **Bounded memory.** Rows are ingested once into an on-disk SQLite job DB under `~/.olympolabs/scoring-jobs/<job_id>.db`, then scored in small claimed batches. Peak memory is bounded by the batch size, NOT the list size - so a multi-GB / hundreds-of-thousands-of-rows CSV (e.g. the Globaltize list) runs without crashing the laptop.
- **Bulletproof resume.** "Done" lives in the DB, so a crashed or Ctrl-C'd run resumes exactly where it left off: just re-run the same command. The same job id is derived from the source identity, so it finds the same DB.
- **CSV is streamed end-to-end.** The original file is never loaded whole and never modified; results go to a new `<name>.scored.csv` written in a final streaming pass.
- **Self-improving.** Every run appends a structured entry to `references/run-journal.md`; the `/improve` ritual (bottom of this doc) folds those learnings back into the skill.

## What this skill does and doesn't do

**Does:**

- Reads a Google Sheet of companies (one row per company)
- Auto-detects which columns are `domain`, `description`, `company name`, `industry`
- For each row: scores via description if usable; falls through to ZenRows scrape if not; escalates to a smarter model on borderline 5-7 scores
- Writes five new columns back: `ICP Score`, `ICP Verdict`, `Scoring Source`, `ICP Reasoning`, `Scrape Content` (the trafilatura page text for scraped rows; empty for description-mode rows)
- Skips already-scored rows by default (resume mode) - safe to re-run on a crashed batch
- Batch-writes results every 25 rows so progress is durable
- Logs per-run cost (LLM tokens + ZenRows calls) to `~/.olympolabs/scoring-costs.log`

**Does NOT:**

- Choose the ICP for the user - the ICP comes from a profile file (`~/.olympolabs/icp-profiles/<slug>.md`) or inline text
- Add or remove rows from the sheet
- Filter the sheet itself - the user filters by `ICP Verdict == Qualified` after scoring
- Push qualified companies to PlusVibe - that's the future List Builder + plusvibe-campaign-manager pipeline
- Send any email - this is upstream of outreach

## One-time setup

Three things, each one-time. The skill fails fast with the exact remediation if any are missing - or run `python3 scripts/doctor.py` to check all of them at once.

### 1. gcloud ADC for Sheets write access

```bash
brew install --cask google-cloud-sdk          # if not already installed
# After install, restart your shell, then:
gcloud init                                   # pick your existing GCP project
gcloud services enable sheets.googleapis.com  # enable Sheets API on the project
gcloud auth application-default login \
  --scopes=openid,email,https://www.googleapis.com/auth/spreadsheets
gcloud auth application-default set-quota-project <your-project-id>
```

The skill authenticates AS the user. Any sheet the user owns or has edit access to is writable.

### 2. OpenRouter API key

```bash
mkdir -p ~/.olympolabs && cat > ~/.olympolabs/openrouter.json <<'EOF'
{"api_key": "sk-or-..."}
EOF
chmod 600 ~/.olympolabs/openrouter.json
```

Get a key at https://openrouter.ai/keys.

### 3. ZenRows API key

```bash
cat > ~/.olympolabs/zenrows.json <<'EOF'
{"api_key": "..."}
EOF
chmod 600 ~/.olympolabs/zenrows.json
```

Get a key from the ZenRows dashboard.

## Workflow

### Step 0 - Preflight (first run on a machine, or any failure)

Before the first run on a new machine - and any time a command errors out - run the doctor instead of debugging by hand:

```bash
python3 ~/.claude/skills/company-scoring/scripts/doctor.py
```

It checks the vendored foundations, Python deps, credentials, and gcloud ADC, and prints the exact fix for anything missing. (The gcloud check only matters for `--sheet-url`; CSV scoring works without it.)

### Step 1 - Resolve the source

The skill scores from **either** a Google Sheet **or** a local CSV. Figure out which the user has:

**Google Sheet** - they give a URL or ID:
- `https://docs.google.com/spreadsheets/d/1abc.../edit`
- `1abc...` (bare ID)
- Used with `--sheet-url "<url>"`. Results are written back into four columns on the sheet.

**Local CSV** - they give a file path (this is the right choice for big lists; Sheets caps out around a few hundred thousand cells, and CLI users often have multi-GB exports):
- e.g. `~/lists/globaltize-ecom.csv`
- Used with `--csv-path "<path>"`. Results are written to a **new sidecar** `<name>.scored.csv` next to the original; the original is never touched. Override the output with `--csv-output`.
- Arbitrarily large files are fine - the CSV is streamed and memory stays flat.

If it's ambiguous, ask:

> Which list should I score, and is it a Google Sheet or a CSV file? Paste the Sheets URL, or the path to the CSV.

**Everything past this point is identical for both sources** - just substitute `--csv-path "<path>"` wherever the commands below show `--sheet-url "<url>"`.

### Step 2 - Resolve the ICP

The ICP comes from one of two sources. Ask in one consolidated message:

> Which ICP should I score against?
> 1. A saved profile (I'll list available files in `~/.olympolabs/icp-profiles/`)
> 2. Pasted inline (paste the ICP definition right here)

To list saved profiles:

```bash
ls -1 ~/.olympolabs/icp-profiles/ 2>/dev/null
```

If a profile is chosen, the path is `~/.olympolabs/icp-profiles/<slug>.md`. If inline, capture the text as `--icp-text`. See `references/icp-profile-template.md` for what a good ICP looks like.

If the inline ICP is shorter than ~30 words OR is vague ("growth-stage SaaS"), push back before generating:

> That ICP is vague. The model is going to score consistently only when the definition lists concrete industry signals, size band, geography, and negative signals (look-alike industries that don't qualify). Want to flesh it out before I run, or save it to a profile file?

### Step 3 - Confirm column detection

After resolving the sheet + ICP, do a dry-run to surface what the skill auto-detected:

```bash
python3 ~/.claude/skills/company-scoring/scripts/score_sheet.py \
  --sheet-url "<url>" \
  --icp-file "<path>" \
  --dry-run \
  --max-rows 5
```

The dry-run output will print:

```
Headers (N): ['Company', 'Domain', 'Description', ...]
Detected columns: {'domain': 2, 'description': 3, 'company': 1, 'industry': None}
Rows queued for scoring: N
```

Show this to the user and ask:

> I auto-detected: domain in column N, description in column M, company name in column K. Look right, or do you want to override?

If they want to override, re-run with explicit flags:
- `--domain-col N` - 1-based column index
- `--description-col 0` - to indicate there's no description column
- `--company-col 0` - to indicate there's no company name column

### Step 4 - Ask the user which mode for the full-sheet run

Once the sheet and ICP are confirmed, ask the user which scoring mode they
want for the FULL run. Two options - present both clearly, let them pick:

> Two modes for the full-sheet run:
>
> **(a) Conventional / hybrid (cheaper, faster):** uses the description column
> when it's clear enough, only falls through to ZenRows scrape when the LLM
> says the description isn't sufficient. ~$0.0003 per row. Good when the
> sheet's description column is reasonably accurate.
>
> **(b) Force-scrape (more expensive, more accurate):** ignores the
> description column entirely and scrapes every row. Use when you don't
> trust the descriptions (often stale, marketing copy, or missing the
> business detail you actually care about). ~$0.003 per row.
>
> Which mode for the full run? (a / b)

Remember the answer - it determines the final-run command in Step 7.

### Step 5 - Calibration pilot: score the first 20 rows in scrape-mode

**Always scrape, regardless of the mode the user picked in Step 4.** The pilot
exists to test the ICP, not the data source. Scraping gives the LLM the most
reliable input, so any disagreement the user has with the pilot scores is
genuinely about the ICP definition (which we can fix) rather than data noise.

Run:

```bash
python3 ~/.claude/skills/company-scoring/scripts/score_sheet.py \
  --sheet-url "<url>" \
  --icp-file ~/.olympolabs/icp-profiles/<slug>.md \
  --pilot 20 \
  --no-escalation \
  --concurrency 30
```

`--pilot 20` is a friendly shortcut for `--max-rows 20 --scrape-only
--force-rescore`. The `--force-rescore` part is critical: re-pilots after an
ICP edit MUST hit the same 20 rows so the user can compare before/after on
identical companies. Cost: ~$0.06-0.10 per pilot. Time: ~15-30 seconds.

### Step 6 - Show the pilot output and wait for sign-off (loop)

Read the first 20 scored rows back from the sheet and present them cleanly
to the user. For each row include: company name, score, verdict, and the
one-line reasoning. Sort by score descending so the qualified-looking ones
are on top.

Then ask:

> Pilot complete. Does this scoring look right?
>
> - **"Looks good, continue"** -> I'll run the full sheet in <mode chosen in
>   Step 4>.
> - **"This is wrong because..."** -> tell me which rows are misclassified,
>   what the right verdict should be, and any ICP rules I'm missing. I'll
>   edit the ICP file and re-pilot on the same 20 rows.
>
> Either way, what's your call?

If the user signs off -> proceed to Step 7.

If the user has feedback, **interpret it and edit the ICP file directly.**
Don't ask the user to edit the file themselves. The pattern:

1. Read the user's specific complaints. Examples of feedback you might get:
   - "X should be Disqualified - it's actually a [different category]"
   - "Y should be Qualified - they really do [ICP-relevant activity]"
   - "The ICP shouldn't reject companies with [signal Z], because [reason]"
   - "Add [new positive signal] to the ICP"
2. Open the ICP file (`~/.olympolabs/icp-profiles/<slug>.md`) with the Edit
   tool.
3. Make targeted edits: add specific disqualifier patterns to the negative
   signals list, add positive signals, refine edge cases, etc. Keep the
   file's existing structure - just adjust the rules.
4. Tell the user briefly what you changed (1-2 lines).
5. Re-run the same `--pilot 20` command. Same rows, refreshed ICP.
6. Re-present the new pilot output and loop back to the "does this look
   right?" question.

Loop until the user signs off. Most ICPs converge in 1-3 iterations.

### Step 7 - Confirm models and the full run

Now that calibration is approved, restate what's about to happen on the full
sheet:

> Calibration approved. About to score <ROW_COUNT> remaining rows in
> <SHEET_TITLE> against the (now-refined) ICP "<icp_name>" in
> <mode chosen in Step 4>.
>
> Models:
>   - Description-mode: <model> (cheap)
>   - Scrape-mode: <model> (mid-tier)
>   - Escalation: <model> (off by default, on with --escalate-borderline)
>
> Estimated cost: <rough estimate>. Resume mode is ON; the 20 pilot rows
> already scored will be skipped (unless they're 6-7, in which case the
> targeted re-score in Step 9 will pick them up). Proceed?

Cost estimation:
- ~$0.0003 per row in conventional/hybrid mode
- ~$0.003 per row in force-scrape mode

If the user wants to override models, pass `--description-model`,
`--scrape-model`, or `--escalation-model`.

### Step 8 - Run the full sheet

```bash
# Conventional / hybrid (Step 4 option a):
python3 ~/.claude/skills/company-scoring/scripts/score_sheet.py \
  --sheet-url "<url>" \
  --icp-file ~/.olympolabs/icp-profiles/<slug>.md \
  --no-escalation \
  --concurrency 30

# Force-scrape (Step 4 option b):
python3 ~/.claude/skills/company-scoring/scripts/score_sheet.py \
  --sheet-url "<url>" \
  --icp-file ~/.olympolabs/icp-profiles/<slug>.md \
  --scrape-only \
  --no-escalation \
  --concurrency 30

# Same thing on a local CSV (any size) - swap --sheet-url for --csv-path.
# Results land in <name>.scored.csv next to the original:
python3 ~/.claude/skills/company-scoring/scripts/score_sheet.py \
  --csv-path "~/lists/globaltize-ecom.csv" \
  --icp-file ~/.olympolabs/icp-profiles/<slug>.md \
  --scrape-only \
  --no-escalation \
  --concurrency 30
```

The orchestrator prints progress at each write-batch boundary and a final cost
summary. If the run fails partway through (crash, Ctrl-C, network), **just
re-run with the same arguments** - the SQLite job store means it resumes exactly
where it left off (already-scored rows are skipped; in-flight rows are
re-queued). This holds for both sheets and CSVs, and for lists of any size.

CSV-only escape hatches: `--no-export` scores into the job store without writing
the sidecar (export later); `--export-only` (re)writes the sidecar from the job
store without re-scoring.

### Step 9 - Targeted 6-7 cleanup (ONLY when full run was hybrid mode)

The 6-7 rescue catches a systematic overshoot pattern: Flash-Lite on
descriptions tends to be too generous in the 6-7 band, marking borderline
specialty/adjacent firms as Qualified when a real scrape would correctly
disqualify them. The rescue is the cheap insurance against that bias.

**Skip this step entirely when the full run used force-scrape mode.** In
force-scrape mode, every row was already scraped + scored by DeepSeek on
scraped content. The 6-7 bias doesn't exist there - the borderline scores
are honest borderline cases, not Flash-Lite overshoot. Re-running the same
model on the same scraped content adds no new signal, just costs more.

**Run only after a hybrid (default) run:**

```bash
python3 ~/.claude/skills/company-scoring/scripts/score_sheet.py \
  --sheet-url "<url>" \
  --icp-file ~/.olympolabs/icp-profiles/<slug>.md \
  --rescore-score-range 6 7 \
  --scrape-only \
  --no-escalation \
  --concurrency 30
```

Costs are small (~$0.50-1 typical) and resolution rate is high (60-70%
of 6-7 rows flip to clearer verdicts) when applicable.

### Step 10 - Surface the final result

When all runs complete, print the cumulative cost from the session and the
location of the results:
- **Sheet:** the sheet URL. The user filters by `ICP Verdict == "Qualified"` in
  the Sheets UI to get the outreach shortlist.
- **CSV:** the sidecar path (`<name>.scored.csv`). The user filters that file by
  the `ICP Verdict` column. Don't filter it for them.

### Step 11 - Capture learnings (automatic)

Every run appends a structured entry to `references/run-journal.md` on its own -
you don't do anything here. It records the source, ICP, row/error counts,
scrape-fail and premium-proxy rates, scoring-source breakdown, cost, models, and
a sample of errors. This is the raw material for `/improve` below. Just confirm
the run printed `Run journal updated: ...`.

## The `/improve` ritual (closing the feedback loop)

When the user says "improve the scoring skill", "review the runs", or after a
batch of runs, do this - it turns accumulated run history into concrete skill
upgrades:

1. **Read the evidence.** `references/run-journal.md` (recent entries first) and
   the last ~20 lines of `~/.olympolabs/scoring-costs.log`.
2. **Look for patterns**, e.g.:
   - A creeping **error rate** or **ZenRows premium rate** on a vertical →
     the scrape ladder or concurrency may need tuning, or a site family blocks.
   - Recurring **error messages** → a systematic failure (bad domains column,
     an auth/quota issue, a site type trafilatura can't parse).
   - A model **overshooting a score band** on an ICP (the known Flash-Lite 6-7
     bias) → adjust defaults or recommend `--scrape-only` for that vertical.
   - Cost drifting above the ~$0.0003/row (hybrid) or ~$0.003/row (scrape)
     expectations → flag it.
3. **Propose concrete edits** for the user to approve - and only then apply:
   - Refine an ICP profile or `references/icp-profile-template.md`.
   - Adjust model defaults or the scrape-ladder waits in the scripts.
   - Add a troubleshooting note to this SKILL.md.
4. **Never auto-edit the skill without sign-off**, and never hand-edit past
   journal entries - they're an append-only audit trail.

## Decision rules

### Default models

- Description mode: `google/gemini-2.5-flash-lite`
- Scrape mode: `deepseek/deepseek-chat-v3.1`
- Escalation: `anthropic/claude-sonnet-4.5`

These are tuned for OlympoLabs's volume (cost-sensitive but quality matters on the ambiguous middle). Override per run if needed.

### Output columns - canonical headers

Always write exactly these five headers, in this order, at the right edge of the worksheet (or reuse if already present):

1. `ICP Score` - integer 1-10, or blank on error
2. `ICP Verdict` - `Qualified` (score >= 7), `Disqualified` (< 7), or `Error`
3. `Scoring Source` - `description`, `scrape`, `scrape_empty`, or `failed`
4. `ICP Reasoning` - one-line why (max ~200 chars)
5. `Scrape Content` - trafilatura-extracted page text from ZenRows, capped at 20,000 chars. Populated only for rows scored via scrape mode; empty for rows scored from the description column (no scrape happened). Downstream skills (personalization, copywriter) read this to build cold-email hooks without re-scraping.

Never rename these columns. The plusvibe-campaign-manager and future List Builder + personalization skills will read these exact names.

**Schema migration note:** existing job-store DBs from before the Scrape Content column was added are migrated automatically on the next run (ALTER TABLE ADD COLUMN). Sheets/CSVs that already have the four-column header from a prior run will get the fifth column appended at the right edge on the next write.

### Resume mode is default

The skill skips rows where `ICP Score` is non-empty. To force re-scoring (e.g. you changed the ICP and want fresh scores), pass `--force-rescore`. This burns API spend; warn the user before re-scoring large lists.

### Escalation is default

When scrape-mode returns a score in `[5, 7]` AND confidence is "low" or "medium", the orchestrator re-runs that row against the escalation model. This catches the genuinely ambiguous middle. Pass `--no-escalation` to disable (cheaper but blunter).

### ZenRows premium fallback is default

Basic ZenRows scrape ($0.002) fails on JS-heavy sites and on Cloudflare-protected sites. On any failed or empty-result scrape, the orchestrator retries with `js_render=true` + `premium_proxy=true` ($0.005). Pass `--no-zenrows-premium-retry` to disable.

## Mandatory final-pass audit

After the run completes, before declaring done:

1. **Cost log was written.** Verify `~/.olympolabs/scoring-costs.log` has a fresh JSONL line with the run timestamp and totals. If not, the cost data is lost - surface that.
2. **Writes succeeded.** Sheet: spot-check the last row by reading it back; confirm `ICP Score`, `ICP Verdict`, `Scoring Source`, `ICP Reasoning` are populated (and `Scrape Content` is populated for scrape-mode rows / empty for description-mode rows). CSV: confirm the run printed `Sidecar written: <path>` and the file exists with the five columns appended (a `tail` is enough; don't load the whole file).
3. **Error count is sensible.** If `rows_errored / rows_scored > 0.05` (more than 5% errored), surface this in the summary - the ICP may be malformed, the sheet may have garbage rows, or ZenRows may be rate-limited. Don't quietly succeed.
4. **No invented columns.** The output columns are exactly the five canonical names. If the orchestrator wrote anything else, that's a bug - flag it.
5. **Resume mode worked if applicable.** If the user passed a sheet that already had partial scores, verify the run skipped them (look at the printed "Rows queued for scoring" number).
