"""
Column detection for varying sheet schemas.

OlympoLabs gets company lists from Clay, Apollo, LinkedIn Sales Navigator,
Lemlist, raw CSV exports, and more. Each provider uses different header names
for the same conceptual columns. This module scans the header row and
proposes which columns are which. The SKILL.md then asks the user to confirm.

Convention used throughout:
  - "domain"      => the company's website domain or full URL
  - "description" => any text describing the company (industry, snippet, etc.)
  - "company"     => the human-readable company name

For each conceptual column we return the best matching header index (1-based,
so it maps cleanly to A1 column letters via col_index_to_letter()) or None
if nothing matched.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Sequence


# Patterns are matched against header text after lowercasing + stripping
# non-alphanumeric characters. Order matters: earlier patterns win on ties.
DOMAIN_PATTERNS: List[str] = [
    r"^(company|primary|business)?(domain|website|url|site)$",
    r"^(companywebsite|companydomain|companysite|websiteurl|domainurl)$",
    r"^(homepageurl|homepage|webaddress|webpageurl)$",
]

DESCRIPTION_PATTERNS: List[str] = [
    r"^(company|business)?description$",
    r"^(snippet|summary|overview|about|profile|tagline|bio|blurb)$",
    r"^(short|long|company)description$",
    r"^(industrydescription|companyabout|aboutus|sitedescription)$",
]

COMPANY_NAME_PATTERNS: List[str] = [
    r"^(company|account|organization|business|firm|brand)(name)?$",
    r"^(name|legalname|tradename|displayname)$",
]

# Industry / vertical column - useful supplemental context if present
INDUSTRY_PATTERNS: List[str] = [
    r"^industry$",
    r"^vertical$",
    r"^sector$",
    r"^(primaryindustry|companyindustry|businesstype)$",
]


def _normalize(s: Any) -> str:
    if s is None:
        return ""
    text = str(s).lower()
    text = re.sub(r"[^a-z0-9]", "", text)
    return text


def _first_match(headers: Sequence[Any], patterns: Sequence[str]) -> Optional[int]:
    """Return the 1-based column index of the first header matching any pattern."""
    normalized = [_normalize(h) for h in headers]
    for pattern in patterns:
        regex = re.compile(pattern)
        for idx, h in enumerate(normalized, start=1):
            if h and regex.fullmatch(h):
                return idx
    return None


def detect_columns(headers: Sequence[Any]) -> Dict[str, Optional[int]]:
    """Detect domain, description, company-name, and industry columns.

    Returns a dict like:
        {
            "domain":      3,   # 1-based column index, or None
            "description": 5,
            "company":     1,
            "industry":    None,
        }
    """
    return {
        "domain": _first_match(headers, DOMAIN_PATTERNS),
        "description": _first_match(headers, DESCRIPTION_PATTERNS),
        "company": _first_match(headers, COMPANY_NAME_PATTERNS),
        "industry": _first_match(headers, INDUSTRY_PATTERNS),
    }


def detect_output_columns(headers: Sequence[Any]) -> Dict[str, Optional[int]]:
    """Detect the five output columns this skill writes.

    If they already exist from a prior run, the orchestrator uses those
    positions instead of appending new columns. Header text must match
    exactly (case-sensitive) what the skill writes:
        "ICP Score", "ICP Verdict", "Scoring Source", "ICP Reasoning",
        "Scrape Content"
    """
    target = {"ICP Score", "ICP Verdict", "Scoring Source", "ICP Reasoning", "Scrape Content"}
    result: Dict[str, Optional[int]] = {name: None for name in target}
    for idx, h in enumerate(headers, start=1):
        s = (str(h) if h is not None else "").strip()
        if s in result:
            result[s] = idx
    return result
