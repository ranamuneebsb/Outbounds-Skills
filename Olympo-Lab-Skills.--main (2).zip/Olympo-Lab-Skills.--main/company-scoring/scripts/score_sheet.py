#!/usr/bin/env python3
"""
Company-scoring orchestrator.

Reads companies from a Google Sheet OR a local CSV, scores each one 1-10 for ICP
fit using OpenRouter LLMs (and ZenRows web scraping when there's no usable
description), writes scores + verdict + source + reasoning back, logs cost, and
appends a run-journal entry for the feedback loop.

Two input sources (see sources.py), one engine:
  - --sheet-url : Google Sheet; results written back into four columns.
  - --csv-path  : local CSV; results written to a NEW sidecar <name>.scored.csv.
                  Read + written as a STREAM so multi-GB files don't blow memory.

Durable engine (see jobstore.py): rows are ingested once into an on-disk SQLite
work queue, then scored in small claimed batches. Peak memory is bounded by the
claim batch size, NOT the list size - this is what lets hundreds-of-thousands-of-
rows lists run without crashing the laptop. The queue also makes resume
bulletproof: a crashed/Ctrl-C'd run picks up exactly where it left off.

Two-pass model strategy:
  1. Description mode (cheap model): score from sheet description if present.
     If the LLM signals `needs_scrape: true`, fall through to scrape mode.
  2. Scrape mode (mid-tier model): ZenRows scrape + trafilatura extraction +
     LLM score.
  3. Escalation (smart model): if scrape-mode result lands in the 5-7 score
     band with low/medium confidence, re-ask Sonnet with the same scraped
     text to break the tie.

Resume mode (default): rows that already have an "ICP Score" value are
skipped, so a crashed mid-run can pick up where it left off without burning
duplicate API spend. Pass --force-rescore to override.

Incremental writes: results are batch-written to the sheet every
`--write-batch-size` rows. A crash loses at most one batch worth of work.
"""

from __future__ import annotations

import argparse
import json
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests  # for requests.exceptions.RequestException in error filters

# Make the three foundation packages importable. The skill ships with its own
# VENDORED copies under scripts/lib/, so it runs standalone on any machine with
# zero setup time - this is the normal, instant path. The repo locations are
# kept only as dev fallbacks for working directly in the source tree.
#
# IMPORTANT: if none of these resolve, that is an INSTALL problem, not a
# missing-code problem. The foundations are bundled; do NOT recreate them by
# hand. Run `python3 scripts/doctor.py` for the exact remediation.
_SKILLS_ROOT_CANDIDATES = [
    Path(__file__).resolve().parent / "lib",                       # vendored (preferred, instant)
    Path(__file__).resolve().parent.parent.parent,                 # source tree
    Path.home() / "Desktop" / "OlympoLabs-Skills",                 # dev checkout
]
_SKILLS_ROOT = next((p for p in _SKILLS_ROOT_CANDIDATES if (p / "openrouter-api" / "client.py").exists()), None)
if _SKILLS_ROOT is None:
    _doctor = Path(__file__).resolve().parent / "doctor.py"
    sys.stderr.write(
        "ERROR: cannot find the openrouter-api / zenrows-api / google-sheets-api foundations.\n"
        "These ship VENDORED with the skill under scripts/lib/ - if they are missing,\n"
        "the install is incomplete. Do NOT rewrite the foundation packages by hand.\n"
        f"Run:  python3 {_doctor}\n"
        "Tried:\n"
        + "".join(f"  - {p}\n" for p in _SKILLS_ROOT_CANDIDATES)
    )
    sys.exit(2)

sys.path.insert(0, str(Path(__file__).resolve().parent))  # for sibling modules

# Foundation imports via importlib to avoid name collisions: openrouter-api,
# zenrows-api, and the script's own scripts/ folder all contain a `client.py`
# and `auth.py`. Pulling them in with importlib keeps them in separate module
# namespaces (or_client, zr_client, etc) so sys.modules doesn't shadow.
import importlib.util


def _load_module(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_name} from {file_path}")
    mod = importlib.util.module_from_spec(spec)
    # Make sibling-relative imports (e.g. `from auth import ...` inside
    # client.py) resolve by putting the module's directory on sys.path BEFORE
    # loading.
    sys.path.insert(0, str(Path(file_path).parent))
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


_or_client_mod = _load_module("or_client", _SKILLS_ROOT / "openrouter-api" / "client.py")
_or_pricing_mod = _load_module("or_pricing", _SKILLS_ROOT / "openrouter-api" / "pricing.py")
_zr_client_mod = _load_module("zr_client", _SKILLS_ROOT / "zenrows-api" / "client.py")
_zr_extract_mod = _load_module("zr_extract", _SKILLS_ROOT / "zenrows-api" / "extract.py")
_gs_client_mod = _load_module("gs_client", _SKILLS_ROOT / "google-sheets-api" / "client.py")

OpenRouterClient = _or_client_mod.OpenRouterClient
OpenRouterError = _or_client_mod.OpenRouterError
or_estimate_cost = _or_pricing_mod.estimate_cost

ZenRowsClient = _zr_client_mod.ZenRowsClient
ZenRowsError = _zr_client_mod.ZenRowsError
ZenRowsScrapeError = _zr_client_mod.ZenRowsScrapeError
ZenRowsRateLimitError = _zr_client_mod.ZenRowsRateLimitError

# Exception tuple used by tiered scrape fallback. Catches:
#   - ZenRowsScrapeError: structured 4xx/5xx from ZenRows API (incl. HTTP 422
#     RESP001 "could not get content" — the common anti-bot case that NEEDS
#     premium proxy)
#   - ZenRowsRateLimitError: 429
#   - requests.RequestException: ReadTimeout, ConnectionError, ChunkedEncoding,
#     etc. — transient network errors that bypass ZenRows' own error wrapping.
# Bug fix history: previously the fallback caught only ZenRowsScrapeError, so a
# basic-mode ReadTimeout would skip tiers 2-3 entirely. ~4,800 rows on a
# property-management sheet got "Error" verdicts that should've been Qualified
# or Disqualified once premium proxy kicked in.
_SCRAPE_FALLBACK_EXC = (
    ZenRowsScrapeError,
    ZenRowsRateLimitError,
    requests.exceptions.RequestException,
)
extract_company_text = _zr_extract_mod.extract_company_text

SheetsClient = _gs_client_mod.SheetsClient
extract_sheet_id = _gs_client_mod.extract_sheet_id
col_index_to_letter = _gs_client_mod.col_index_to_letter

# Sibling skill modules
from column_detect import detect_columns, detect_output_columns  # noqa: E402
from cost_log import append_run                                   # noqa: E402
from jobstore import JobStore, JOBS_DIR as JOBS_DIR_DEFAULT       # noqa: E402
from sources import CsvSource, SheetSource                        # noqa: E402
import run_journal                                                # noqa: E402
from prompts import (                                             # noqa: E402
    build_description_system,
    build_scrape_system,
    description_user_prompt,
    scrape_user_prompt,
)


# ---- Constants ----

DEFAULT_DESCRIPTION_MODEL = "google/gemini-2.5-flash-lite"
DEFAULT_SCRAPE_MODEL = "deepseek/deepseek-chat-v3.1"
DEFAULT_ESCALATION_MODEL = "anthropic/claude-sonnet-4.6"

OUTPUT_HEADERS = ("ICP Score", "ICP Verdict", "Scoring Source", "ICP Reasoning", "Scrape Content")

# Per-row cap on the trafilatura-extracted text we persist in the Scrape Content
# column. 20K chars fits comfortably under Sheets' 50K cell limit and gives a
# downstream personalization skill ample raw signal (2-3 pages' worth) without
# bloating spreadsheets. Trim from the end on overflow.
SCRAPE_CONTENT_CAP = 20_000


def _trim_scrape(text: str) -> str:
    """Trim scraped text to SCRAPE_CONTENT_CAP. Empty input passes through."""
    if not text:
        return ""
    if len(text) <= SCRAPE_CONTENT_CAP:
        return text
    return text[:SCRAPE_CONTENT_CAP]


# ZenRows per-scrape cost estimate (rough; varies by plan + flags used)
ZENROWS_COST_BASIC = 0.002       # basic request
ZENROWS_COST_PREMIUM = 0.005     # JS render + residential proxy

ESCALATION_SCORE_LOWER = 5
ESCALATION_SCORE_UPPER = 7


# ---- Helpers ----


def normalize_url(domain_or_url: str) -> Optional[str]:
    """Turn a raw domain cell into a fetchable URL.

    Accepts: "designdesk.io", "https://designdesk.io", "www.designdesk.io",
    "DesignDesk.IO/about". Returns the URL or None if the cell is blank/junk.
    """
    if not domain_or_url:
        return None
    s = str(domain_or_url).strip()
    if not s:
        return None
    if not s.startswith(("http://", "https://")):
        s = "https://" + s
    return s


def is_blank(cell: Any) -> bool:
    return cell is None or (isinstance(cell, str) and not cell.strip())


def safe_int_score(value: Any) -> Optional[int]:
    try:
        n = int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None
    if 1 <= n <= 10:
        return n
    return None


# ---- ICP loading ----


def load_icp(icp_file: Optional[str], icp_text: Optional[str]) -> Tuple[str, str]:
    """Return (icp_name, icp_definition).

    Exactly one of icp_file or icp_text must be provided.
    """
    if icp_file and icp_text:
        raise ValueError("Provide --icp-file or --icp-text, not both.")
    if icp_file:
        path = Path(icp_file).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"ICP file not found: {path}")
        text = path.read_text(encoding="utf-8").strip()
        if not text:
            raise ValueError(f"ICP file is empty: {path}")
        return (path.stem, text)
    if icp_text:
        if not icp_text.strip():
            raise ValueError("ICP text is empty.")
        return ("<inline>", icp_text.strip())
    raise ValueError("Provide --icp-file or --icp-text.")


# ---- Scoring engine ----


class Scorer:
    """Encapsulates one scoring session against one ICP."""

    def __init__(
        self,
        icp_definition: str,
        description_model: str,
        scrape_model: str,
        escalation_model: str,
        or_client: OpenRouterClient,
        zr_client: ZenRowsClient,
        escalate_low_confidence: bool = True,
        zenrows_premium_on_retry: bool = True,
        description_only: bool = False,
        scrape_only: bool = False,
        zenrows_extra_retry: bool = True,
    ):
        self._icp = icp_definition
        self._desc_sys = build_description_system(icp_definition)
        self._scrape_sys = build_scrape_system(icp_definition)
        self._desc_model = description_model
        self._scrape_model = scrape_model
        self._escalation_model = escalation_model
        self._or = or_client
        self._zr = zr_client
        self._escalate_low_conf = escalate_low_confidence
        self._zenrows_premium_on_retry = zenrows_premium_on_retry
        self._description_only = description_only
        self._scrape_only = scrape_only
        self._zenrows_extra_retry = zenrows_extra_retry
        # Aggregate cost / usage tracking
        self.totals = {
            "llm_calls_by_model": {},      # model_id -> {"input": N, "output": N, "cached_input": N, "cost": float}
            "zenrows_scrape_calls": 0,
            "zenrows_premium_calls": 0,
            "zenrows_cost_usd": 0.0,
            "escalations": 0,
            "scrape_calls": 0,
            "description_calls": 0,
        }

    # ---- Public entry ----

    def score_row(
        self,
        *,
        company_name: str,
        domain: str,
        description: str,
        scrape_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Score a single row. Returns the writeback dict with fields:
            score, verdict, source, reasoning, error (None on success)
        """
        url = scrape_url or normalize_url(domain)

        # --scrape-only short-circuits straight to scrape mode, even when a
        # description is present. Useful for stress-testing the scrape path
        # or when the user wants to bypass possibly-noisy descriptions.
        if self._scrape_only:
            if not url:
                return self._error_result("no domain/URL to scrape")
            try:
                scraped_text = self._do_scrape(url)
            except ZenRowsError as exc:
                return self._error_result(f"scrape failed: {exc}")
            if not scraped_text:
                # An empty scrape (blocked/JS-heavy site) carries no signal.
                # If a description exists, score from it rather than clobbering
                # the row with a meaningless 1/Disqualified.
                if description and description.strip():
                    try:
                        result = self._call_description(company_name, domain, description)
                    except OpenRouterError as exc:
                        return self._error_result(f"description-mode LLM error: {exc}")
                    return self._build_writeback(result, source="description")
                return {
                    "score": 1,
                    "verdict": "Disqualified",
                    "source": "scrape_empty",
                    "reasoning": "no usable site content",
                    "error": None,
                    "scrape_content": "",
                }
            try:
                result = self._call_scrape(company_name, domain, scraped_text, self._scrape_model)
            except OpenRouterError as exc:
                return self._error_result(f"scrape-mode LLM error: {exc}", scraped_text=scraped_text)
            final = self._maybe_escalate_scrape(company_name, domain, scraped_text, result)
            return self._build_writeback(final, source="scrape", scraped_text=scraped_text)

        # Step 1: try description mode if we have a description
        if description and description.strip():
            try:
                result = self._call_description(company_name, domain, description)
            except OpenRouterError as exc:
                return self._error_result(f"description-mode LLM error: {exc}")

            needs_scrape = bool(result.get("needs_scrape"))
            if not needs_scrape:
                # Description was conclusive enough; use it
                # Optionally escalate if score is in the borderline band with low confidence
                final = self._maybe_escalate_description(
                    company_name, domain, description, result
                )
                return self._build_writeback(final, source="description")

            # LLM signaled needs_scrape:true. In description-only mode, take
            # the description score anyway but mark source as "description_thin"
            # so the user can target these rows for a phase-2 scrape pass.
            if self._description_only:
                return self._build_writeback(result, source="description_thin")

        # Step 2: scrape mode (description was missing OR LLM said needs_scrape)
        if self._description_only:
            # No description, and scraping is disabled this run. Mark for phase 2.
            return {
                "score": "",
                "verdict": "Pending",
                "source": "needs_scrape",
                "reasoning": "no description; defer to phase-2 scrape run",
                "error": None,
                "scrape_content": "",
            }
        if not url:
            return self._error_result("no domain/URL to scrape")
        try:
            scraped_text = self._do_scrape(url)
        except ZenRowsError as exc:
            return self._error_result(f"scrape failed: {exc}")

        if not scraped_text:
            # Empty scrape with no signal. Fall back to the description if we
            # have one (we may be here because the LLM flagged needs_scrape on a
            # thin-but-present description) rather than clobbering with a 1.
            if description and description.strip():
                try:
                    result = self._call_description(company_name, domain, description)
                except OpenRouterError as exc:
                    return self._error_result(f"description-mode LLM error: {exc}")
                return self._build_writeback(result, source="description")
            return {
                "score": 1,
                "verdict": "Disqualified",
                "source": "scrape_empty",
                "reasoning": "no usable site content",
                "error": None,
                "scrape_content": "",
            }

        try:
            result = self._call_scrape(company_name, domain, scraped_text, self._scrape_model)
        except OpenRouterError as exc:
            return self._error_result(f"scrape-mode LLM error: {exc}", scraped_text=scraped_text)

        # Step 3: escalation
        final = self._maybe_escalate_scrape(company_name, domain, scraped_text, result)
        return self._build_writeback(final, source="scrape", scraped_text=scraped_text)

    # ---- LLM calls ----

    def _call_description(self, company_name: str, domain: str, description: str) -> Dict[str, Any]:
        self.totals["description_calls"] += 1
        response = self._or.chat(
            model=self._desc_model,
            messages=[
                {"role": "system", "content": self._desc_sys},
                {"role": "user", "content": description_user_prompt(company_name, domain, description)},
            ],
            json_mode=True,
            temperature=0.0,
            max_tokens=300,
        )
        self._record_usage(self._desc_model, response)
        return self._or.parse_json_content(response)

    def _call_scrape(
        self, company_name: str, domain: str, scraped_text: str, model: str
    ) -> Dict[str, Any]:
        self.totals["scrape_calls"] += 1
        response = self._or.chat(
            model=model,
            messages=[
                {"role": "system", "content": self._scrape_sys},
                {"role": "user", "content": scrape_user_prompt(company_name, domain, scraped_text)},
            ],
            json_mode=True,
            temperature=0.0,
            max_tokens=400,
        )
        self._record_usage(model, response)
        return self._or.parse_json_content(response)

    def _maybe_escalate_description(
        self, company_name: str, domain: str, description: str, result: Dict[str, Any]
    ) -> Dict[str, Any]:
        """If description-mode score is borderline, escalate to the smart model.

        Two escalation paths depending on mode:

        - **description_only mode (no scraping allowed):** call the escalation
          model with the SAME description as input. No fresh data; we're
          buying smart-model judgment, not new context. The Sonnet-vs-Flash-Lite
          audit on construction firms (May 2026) showed Flash-Lite overshoots
          on score-7 cases (~50% false positives among 7s). Escalating any
          6-7 catches most of that systematic error for ~$0.006/row.

        - **default mode (scraping allowed):** the original logic - if score
          is borderline AND confidence is low/medium, scrape the company
          website and re-score with the smart model on scraped text. This
          uses fresh data to break the tie.

        In description_only mode the confidence gate is dropped: even
        "high"-confidence 7s from the cheap model are often wrong per the
        audit, so we escalate the whole 6-7 band unconditionally.
        """
        if not self._escalate_low_conf:
            return result
        score = safe_int_score(result.get("score")) or 0
        in_band = ESCALATION_SCORE_LOWER <= score <= ESCALATION_SCORE_UPPER

        if self._description_only:
            if not in_band:
                return result
            try:
                self.totals["escalations"] += 1
                return self._call_description_with_model(
                    company_name, domain, description, self._escalation_model
                )
            except OpenRouterError:
                return result

        # Default mode: scrape-based escalation, gated on weak confidence
        confidence = str(result.get("confidence", "")).lower()
        weak = confidence in ("low", "medium")
        if in_band and weak:
            url = normalize_url(domain)
            if url:
                try:
                    scraped = self._do_scrape(url)
                    if scraped:
                        self.totals["escalations"] += 1
                        return self._call_scrape(
                            company_name, domain, scraped, self._escalation_model
                        )
                except (ZenRowsError, OpenRouterError):
                    # Fall back to the description result silently if escalation fails
                    return result
        return result

    def _call_description_with_model(
        self, company_name: str, domain: str, description: str, model: str
    ) -> Dict[str, Any]:
        """Description-mode call against a specific model (used for escalation)."""
        self.totals["description_calls"] += 1
        response = self._or.chat(
            model=model,
            messages=[
                {"role": "system", "content": self._desc_sys},
                {"role": "user", "content": description_user_prompt(company_name, domain, description)},
            ],
            json_mode=True,
            temperature=0.0,
            max_tokens=300,
        )
        self._record_usage(model, response)
        return self._or.parse_json_content(response)

    def _maybe_escalate_scrape(
        self, company_name: str, domain: str, scraped_text: str, result: Dict[str, Any]
    ) -> Dict[str, Any]:
        """If scrape-mode score is borderline, re-ask the escalation model."""
        if not self._escalate_low_conf:
            return result
        score = safe_int_score(result.get("score")) or 0
        confidence = str(result.get("confidence", "")).lower()
        in_band = ESCALATION_SCORE_LOWER <= score <= ESCALATION_SCORE_UPPER
        weak = confidence in ("low", "medium")
        if in_band and weak:
            try:
                self.totals["escalations"] += 1
                return self._call_scrape(
                    company_name, domain, scraped_text, self._escalation_model
                )
            except OpenRouterError:
                return result
        return result

    # ---- Scrape ----

    # ZenRows per-row fallback ladder. The goal is to fail rarely without
    # blowing the "protected results" budget. Each row consumes AT MOST ONE
    # protected slot (the premium tier), even when we have to try multiple
    # times.
    #
    # Tier 1 (basic): cheap, fast. Datacenter proxies, no JS. Most non-SPA
    #   sites without anti-bot protection succeed here.
    # Tier 2 (premium + JS + wait): the all-the-bells-and-whistles fallback.
    #   Premium residential proxies bypass Cloudflare / PerimeterX. JS render
    #   handles SPAs. The `wait` parameter gives sites time to render and trips
    #   anti-bot timing checks that flag too-quick scrapes.
    # Tier 3 (premium + JS + wait + country): same protected budget, just
    #   adds geo-targeting and a longer wait. Tried only when Tier 2 returned
    #   thin content (often a "blocked" interstitial). Same protected budget
    #   as Tier 2, just slower.

    def _do_scrape(self, url: str) -> str:
        # Tier 1: basic scrape
        try:
            self.totals["zenrows_scrape_calls"] += 1
            self.totals["zenrows_cost_usd"] += ZENROWS_COST_BASIC
            html = self._zr.scrape(url, js_render=False, premium_proxy=False, max_retries=1)
            text = extract_company_text(html, url=url)
            if text and len(text) > 200:
                return text
        except _SCRAPE_FALLBACK_EXC:
            text = ""

        if not self._zenrows_premium_on_retry:
            return text

        # Tier 2: premium proxy + JS + 2.5s wait (handles Cloudflare, anti-bot
        # timing checks, lazy-rendered content)
        try:
            self.totals["zenrows_premium_calls"] += 1
            self.totals["zenrows_cost_usd"] += ZENROWS_COST_PREMIUM
            html = self._zr.scrape(
                url,
                js_render=True,
                premium_proxy=True,
                wait=2500,
                max_retries=1,
            )
            text2 = extract_company_text(html, url=url)
            if text2 and len(text2) > 200:
                return text2
            text = text2 or text
        except _SCRAPE_FALLBACK_EXC:
            pass

        # Tier 3: another premium call with a different proxy IP (rotating)
        # and a longer wait. Catches sites where the Tier 2 proxy got flagged
        # by anti-bot OR the page needed more time. This is a SECOND protected
        # request, billed separately - skip it if zenrows_extra_retry is off
        # (which the orchestrator can toggle to stay under the protected cap).
        if not self._zenrows_extra_retry:
            return text
        try:
            self.totals["zenrows_premium_calls"] += 1
            self.totals["zenrows_cost_usd"] += ZENROWS_COST_PREMIUM
            html = self._zr.scrape(
                url,
                js_render=True,
                premium_proxy=True,
                wait=4500,
                max_retries=2,
                backoff_base=2.0,
            )
            text3 = extract_company_text(html, url=url)
            if text3 and len(text3) > 200:
                return text3
            return text3 or text
        except _SCRAPE_FALLBACK_EXC:
            return text  # whatever we had from tier 2 (may be thin/empty)

    # ---- Cost tracking ----

    def _record_usage(self, model: str, response: dict) -> None:
        usage = self._or.usage_tokens(response)
        cost = or_estimate_cost(
            model,
            usage["input"],
            usage["output"],
            usage["cached_input"],
        )
        bucket = self.totals["llm_calls_by_model"].setdefault(
            model, {"input": 0, "output": 0, "cached_input": 0, "cost": 0.0, "calls": 0}
        )
        bucket["input"] += usage["input"]
        bucket["output"] += usage["output"]
        bucket["cached_input"] += usage["cached_input"]
        bucket["cost"] += cost
        bucket["calls"] += 1

    # ---- Result formatting ----

    def _build_writeback(
        self,
        result: Dict[str, Any],
        source: str,
        scraped_text: str = "",
    ) -> Dict[str, Any]:
        score = safe_int_score(result.get("score"))
        if score is None:
            return self._error_result(
                f"model returned invalid score: {result.get('score')!r}",
                scraped_text=scraped_text,
            )
        verdict = "Qualified" if score >= 7 else "Disqualified"
        reasoning = str(result.get("reasoning", ""))[:200]
        return {
            "score": score,
            "verdict": verdict,
            "source": source,
            "reasoning": reasoning,
            "error": None,
            # Persist trafilatura text for downstream personalization. Empty
            # when scoring came from the description column (no scrape happened).
            "scrape_content": _trim_scrape(scraped_text),
        }

    @staticmethod
    def _error_result(message: str, scraped_text: str = "") -> Dict[str, Any]:
        return {
            "score": "",
            "verdict": "Error",
            "source": "failed",
            "reasoning": message[:200],
            "error": message,
            # Keep whatever we managed to scrape even on a downstream LLM error,
            # so the user can debug or use it for personalization regardless.
            "scrape_content": _trim_scrape(scraped_text),
        }


# ---- Sheet orchestration ----


def ensure_output_columns(
    sheets: SheetsClient, spreadsheet_id: str, worksheet_title: str, headers: List[Any]
) -> Dict[str, int]:
    """Make sure the four output columns exist. Return the column indices."""
    detected = detect_output_columns(headers)
    missing = [name for name, idx in detected.items() if idx is None]
    if not missing:
        return detected
    # Append the missing ones at the right edge in canonical order
    to_append = [h for h in OUTPUT_HEADERS if h in missing]
    start_col = sheets.append_columns(spreadsheet_id, worksheet_title, to_append)
    # Re-detect against the updated headers
    for i, h in enumerate(to_append):
        detected[h] = start_col + i
    return detected


def _describe_mode(args) -> str:
    """Human label for the scoring mode, used in the run journal."""
    if args.pilot:
        return f"pilot ({args.pilot} rows, scrape)"
    if args.scrape_only:
        return "force-scrape"
    if args.description_only:
        return "description-only" + (" +escalate" if args.escalate_borderline else "")
    return "hybrid"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    src_group = parser.add_mutually_exclusive_group(required=True)
    src_group.add_argument("--sheet-url", help="Google Sheets URL or ID")
    src_group.add_argument(
        "--csv-path",
        help=(
            "Score a local CSV instead of a Google Sheet. Read and written as a "
            "STREAM, so multi-GB / hundreds-of-thousands-of-rows files run "
            "without exhausting memory. Results go to a NEW sidecar file "
            "<name>.scored.csv (the original is never modified)."
        ),
    )
    parser.add_argument(
        "--csv-output",
        help="Override the sidecar path (CSV mode only; default <name>.scored.csv).",
    )
    parser.add_argument("--worksheet", help="Worksheet tab to score (default: first tab)")
    icp_group = parser.add_mutually_exclusive_group(required=True)
    icp_group.add_argument("--icp-file", help="Path to ICP markdown file")
    icp_group.add_argument("--icp-text", help="Inline ICP definition")
    parser.add_argument("--description-model", default=DEFAULT_DESCRIPTION_MODEL)
    parser.add_argument("--scrape-model", default=DEFAULT_SCRAPE_MODEL)
    parser.add_argument("--escalation-model", default=DEFAULT_ESCALATION_MODEL)
    parser.add_argument("--max-rows", type=int, help="Cap number of rows scored (for testing)")
    parser.add_argument(
        "--write-batch-size",
        type=int,
        default=100,
        help=(
            "Batch-write results back to the sheet every N rows. Default 100. "
            "Each flush is one Sheets API write request; default keeps us well "
            "under the 60 writes/min/user quota even when bursts happen. "
            "Tradeoff: up to N rows of work are buffered in memory and lost on "
            "hard crash (resume mode re-scores them on next run). Drop to 25 if "
            "you want smaller crash windows at the cost of more 429s; raise to "
            "250+ if you've already lifted the Sheets quota in GCP."
        ),
    )
    parser.add_argument("--force-rescore", action="store_true", help="Re-score rows that already have a score")
    parser.add_argument("--no-escalation", action="store_true", help="Disable smart-model escalation on borderline scores")
    parser.add_argument("--no-zenrows-premium-retry", action="store_true", help="Don't fall back to premium proxy on scrape retry")
    parser.add_argument(
        "--domain-col",
        type=int,
        help="Override auto-detected domain column (1-based index). Skips detection.",
    )
    parser.add_argument(
        "--description-col",
        type=int,
        help="Override auto-detected description column (1-based index). 0 = no description col.",
    )
    parser.add_argument(
        "--company-col",
        type=int,
        help="Override auto-detected company name column (1-based index). 0 = no company col.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print plan, don't call APIs or write sheet")
    parser.add_argument(
        "--description-only",
        action="store_true",
        help=(
            "Description-only mode: skip rows without a description, do NOT "
            "scrape even if the LLM signals needs_scrape:true, and disable "
            "smart-model escalation. Useful for phase-1 cheap pass over a "
            "list; phase 2 then runs without this flag to handle the rows "
            "that fell through. Rows the LLM flagged needs_scrape get "
            "Scoring Source = 'description_thin' so you can target them later."
        ),
    )
    parser.add_argument(
        "--escalate-borderline",
        action="store_true",
        help=(
            "Opt-in: in --description-only mode, re-score any 6-7 score "
            "with the smart model (Sonnet by default) using the same "
            "description. Catches the cheap model's systematic overshoot "
            "in the 6-7 band. About 6x cost increase per 1000 rows but "
            "raises verdict-agreement-with-Sonnet from 91pct to 97pct on "
            "construction ICP testing. Off by default for cost reasons."
        ),
    )
    parser.add_argument(
        "--scrape-only",
        action="store_true",
        help=(
            "Skip description-mode entirely and scrape every row via "
            "ZenRows, then score the scraped content with the scrape "
            "model. Useful for stress-testing the scrape path or when "
            "you don't trust the sheet's description column. Mutually "
            "exclusive with --description-only."
        ),
    )
    parser.add_argument(
        "--pilot",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Calibration pilot: score the FIRST N data rows of the sheet "
            "in pure-scrape mode (always uses ZenRows + the scrape model, "
            "no description path) and force-rescore those rows so the "
            "same N rows are used on every re-pilot. This lets a user "
            "validate the ICP definition against ground-truth scraped "
            "data before committing API spend on a full-sheet run. "
            "Implies --scrape-only --force-rescore --max-rows N. Typical "
            "value: 20."
        ),
    )
    parser.add_argument(
        "--no-zenrows-extra-retry",
        action="store_true",
        help=(
            "Disable the Tier 3 ZenRows fallback (a SECOND premium call "
            "with a fresh proxy IP + longer wait, fired only when Tier 2 "
            "returned thin content). Tier 3 costs an extra protected slot "
            "per failure; turn off if you're approaching the 40k/mo "
            "protected cap and would rather accept a few more scrape "
            "failures than overflow the plan."
        ),
    )
    parser.add_argument(
        "--rescore-score-range",
        type=int,
        nargs=2,
        metavar=("LOW", "HIGH"),
        default=None,
        help=(
            "Targeted re-score: only process rows whose existing ICP Score "
            "is between LOW and HIGH (inclusive). Implies --force-rescore "
            "for the matched rows. Useful for cleaning up a borderline band "
            "(e.g. --rescore-score-range 6 7 to re-evaluate every 6-7 row). "
            "Combine with --scrape-only to force ZenRows + DeepSeek on the "
            "matched rows."
        ),
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=12,
        help=(
            "Number of parallel scoring workers. Each worker gets its own "
            "OpenRouter and ZenRows client. Default 12 is the empirically "
            "safe value: high enough to saturate ZenRows-bound latency, low "
            "enough that ZenRows doesn't start returning ReadTimeout / "
            "RemoteDisconnected errors on bigger sheets. Raise to 20-30 only "
            "if you've also raised the Sheets API write quota in GCP and your "
            "ZenRows plan can take the concurrent load (Startup tier handles "
            "~30 reliably on small sheets but degrades on 5k+). Set to 1 for "
            "sequential mode (debugging)."
        ),
    )
    parser.add_argument(
        "--export-only",
        action="store_true",
        help=(
            "CSV mode: skip scoring and just (re)write the sidecar .scored.csv "
            "from results already in the SQLite job store. Use after a "
            "--no-export run, or to regenerate the sidecar."
        ),
    )
    parser.add_argument(
        "--no-export",
        action="store_true",
        help=(
            "CSV mode: score into the SQLite job store but do NOT write the "
            "sidecar .scored.csv (export later with --export-only)."
        ),
    )
    parser.add_argument(
        "--jobs-dir",
        default=None,
        help="Override the job-store dir (default ~/.olympolabs/scoring-jobs). Mainly for tests.",
    )
    args = parser.parse_args()

    if args.description_only and args.scrape_only:
        sys.stderr.write("ERROR: --description-only and --scrape-only are mutually exclusive.\n")
        return 2

    # --pilot N is a friendly shortcut for the calibration step at the top
    # of every run. It implies the three flags that together "score the same
    # first-N rows with pure-scrape, every time": max-rows=N, scrape-only,
    # force-rescore. We OR them into args (rather than overwriting) so a user
    # who passed them explicitly still sees consistent behavior.
    if args.pilot:
        if args.pilot < 1:
            sys.stderr.write("ERROR: --pilot N must be >= 1.\n")
            return 2
        if args.description_only:
            sys.stderr.write(
                "ERROR: --pilot is incompatible with --description-only "
                "(the pilot always scrapes to test the ICP against ground "
                "truth, not description quality).\n"
            )
            return 2
        args.max_rows = args.pilot
        args.scrape_only = True
        args.force_rescore = True
        print(f"=== Pilot mode: scoring the first {args.pilot} rows in pure-scrape mode ===")
        print("    (forces re-scoring so the same N rows are used on every re-pilot)")

    # ---- Resolve ICP ----
    icp_name, icp_def = load_icp(args.icp_file, args.icp_text)
    print(f"ICP: {icp_name} ({len(icp_def)} chars)")

    # ---- Resolve the source (Google Sheet or local CSV) ----
    # Both expose the same interface (see sources.py); everything below is
    # source-agnostic and drives the run through the SQLite job store.
    detected_score_col = None  # 1-based ICP-Score column (sheets only, for resume)
    if args.csv_path:
        if args.worksheet:
            print("NOTE: --worksheet is ignored for CSV input.")
        source = CsvSource(args.csv_path, output_path=args.csv_output)
        print(f"Source: {source.describe()}")
        headers = source.read_header()
    else:
        sheets = SheetsClient()
        sheet_id = extract_sheet_id(args.sheet_url)
        worksheets = sheets.list_worksheets(sheet_id)
        if not worksheets:
            sys.stderr.write("ERROR: spreadsheet has no worksheets\n")
            return 3
        if args.worksheet:
            ws = next((w for w in worksheets if w["title"] == args.worksheet), None)
            if not ws:
                sys.stderr.write(
                    f"ERROR: worksheet {args.worksheet!r} not found. Available: "
                    + ", ".join(w["title"] for w in worksheets)
                    + "\n"
                )
                return 3
        else:
            ws = worksheets[0]
        worksheet_title = ws["title"]
        print(f"Worksheet: {worksheet_title!r} ({ws['rowCount']} rows x {ws['columnCount']} cols)")
        source = SheetSource(
            sheets,
            sheet_id,
            worksheet_title,
            col_index_to_letter=col_index_to_letter,
            sheet_url=args.sheet_url,
        )
        headers = source.read_header()

    if not headers:
        sys.stderr.write("ERROR: source is empty (no header row).\n")
        return 3
    print(f"Headers ({len(headers)}): {[str(h) for h in headers]}")

    # ---- Detect / confirm input columns ----
    detected = detect_columns(headers)
    if args.domain_col is not None:
        detected["domain"] = args.domain_col or None
    if args.description_col is not None:
        detected["description"] = args.description_col or None
    if args.company_col is not None:
        detected["company"] = args.company_col or None
    print(f"Detected columns: {detected}")
    if not detected.get("domain"):
        sys.stderr.write("ERROR: could not detect a domain column. Pass --domain-col N.\n")
        return 4

    # ---- Ensure output columns (sheets only; CSV gets them in the sidecar) ----
    if source.kind == "sheet":
        existing_out = detect_output_columns(headers)
        detected_score_col = existing_out.get("ICP Score")
        if not args.dry_run:
            output_cols = ensure_output_columns(sheets, sheet_id, worksheet_title, headers)
            print(f"Output columns: {output_cols}")
            source.set_output_columns(output_cols["ICP Score"], output_cols["ICP Reasoning"])
            source.refresh()  # re-read so the score column is visible for resume
            detected_score_col = output_cols["ICP Score"]

    # ---- Rescore-range validation ----
    rescore_low, rescore_high = (None, None)
    if args.rescore_score_range:
        rescore_low, rescore_high = args.rescore_score_range
        if rescore_low > rescore_high:
            sys.stderr.write(f"ERROR: --rescore-score-range LOW ({rescore_low}) > HIGH ({rescore_high}).\n")
            return 2
        print(f"Targeted re-score: only including rows currently scored in [{rescore_low}, {rescore_high}].")

    # ---- Open the durable job store (enables resume + bounded memory) ----
    jobs_dir = Path(args.jobs_dir).expanduser() if args.jobs_dir else JOBS_DIR_DEFAULT
    store = JobStore(source.identity(), jobs_dir=jobs_dir)
    print(f"Job store: {store.path}")
    mode = _describe_mode(args)
    store.set_meta({
        "source": source.describe(),
        "source_kind": source.kind,
        "icp": icp_name,
        "mode": mode,
        "description_model": args.description_model,
        "scrape_model": args.scrape_model,
        "escalation_model": args.escalation_model,
    })
    recovered = store.reset_queued()
    if recovered:
        print(f"Recovered {recovered} in-flight row(s) from a previous interrupted run.")

    # ---- Export-only short-circuit (CSV) ----
    if args.export_only:
        if source.kind != "csv":
            sys.stderr.write("ERROR: --export-only only applies to --csv-path input.\n")
            return 2
        out = source.finalize(store, OUTPUT_HEADERS)
        c = store.counts()
        print(f"Re-exported {c.get('total', 0)} stored row(s) to {out}")
        store.close()
        return 0

    # ---- Ingest source rows into the job store (streaming) ----
    # Resume semantics live here: by default a row that already has a score
    # (sheet cell, or marked done in the store) is skipped; --force-rescore
    # re-queues everything; --rescore-score-range re-queues only the matched
    # band. Ingest is a generator so memory stays flat on huge CSVs.
    ingest_stats = {"considered": 0, "skipped": 0, "ingested": 0}

    def _existing_score(row_id, cells):
        if source.kind == "sheet" and detected_score_col and detected_score_col - 1 < len(cells):
            return safe_int_score(cells[detected_score_col - 1])
        return store.existing_score(row_id)

    def _already_scored(row_id, cells):
        if source.kind == "sheet" and detected_score_col and detected_score_col - 1 < len(cells):
            if not is_blank(cells[detected_score_col - 1]):
                return True
        return store.existing_status(row_id) == "done"

    dom_i = detected["domain"] - 1
    desc_i = (detected["description"] - 1) if detected.get("description") else None
    name_i = (detected["company"] - 1) if detected.get("company") else None

    def _ingest_items():
        n_in = 0
        for row_id, source_ref, cells in source.iter_rows():
            ingest_stats["considered"] += 1
            domain = cells[dom_i] if 0 <= dom_i < len(cells) else ""
            desc = str(cells[desc_i] or "") if (desc_i is not None and 0 <= desc_i < len(cells)) else ""
            name = str(cells[name_i] or "") if (name_i is not None and 0 <= name_i < len(cells)) else ""

            # Nothing to score from: no domain to scrape AND no description.
            if is_blank(domain) and is_blank(desc):
                ingest_stats["skipped"] += 1
                continue
            # Scrape-only can't fall back to a description, so a blank-domain row
            # can't be scored - skip rather than clobber any prior score.
            if args.scrape_only and is_blank(domain):
                ingest_stats["skipped"] += 1
                continue

            if rescore_low is not None:
                es = _existing_score(row_id, cells)
                if es is None or not (rescore_low <= es <= rescore_high):
                    ingest_stats["skipped"] += 1
                    continue
            elif not args.force_rescore:
                if _already_scored(row_id, cells):
                    ingest_stats["skipped"] += 1
                    continue

            yield {
                "id": row_id,
                "source_ref": source_ref,
                "company": name,
                "domain": str(domain),
                "description": desc,
            }
            n_in += 1
            ingest_stats["ingested"] = n_in
            if args.max_rows and n_in >= args.max_rows:
                return

    store.upsert_pending(_ingest_items())
    print(
        f"Ingested {ingest_stats['ingested']} row(s) "
        f"(considered {ingest_stats['considered']}, skipped {ingest_stats['skipped']})."
    )
    pending_total = store.pending_count()
    print(f"Pending to score: {pending_total}")
    if pending_total == 0:
        print("Nothing to do.")
        store.close()
        return 0

    if args.dry_run:
        print("\n=== DRY RUN ===")
        for r in store.peek_pending(5):
            preview = (r["description"] or "")[:60]
            print(
                f"  row id {r['id']} (ref {r['source_ref']}): "
                f"company={r['company']!r} domain={r['domain']!r} desc={preview!r}"
            )
        if pending_total > 5:
            print(f"  ... and {pending_total - 5} more")
        store.close()
        return 0

    # OpenRouter and ZenRows clients are now created lazily per worker thread
    # inside get_scorer() below. Each worker gets its own clients so they don't
    # share rate-limiter state.
    #
    # Escalation policy:
    # - In default (scrape-allowed) mode, escalation scrapes the company site
    #   and re-scores with the smart model on scraped text when the cheap
    #   model returns a borderline 5-7 score with low/medium confidence.
    # - In --description-only mode, escalation is OFF by default - the user
    #   has explicitly chosen the cheapest path. To opt back in to Sonnet
    #   re-scoring of the 6-7 band in description_only mode, pass
    #   --escalate-borderline (uses the same description, no scrape).
    effective_escalate = not args.no_escalation
    if args.description_only and not args.escalate_borderline:
        effective_escalate = False
    # Per-thread scorer pool. Each worker thread lazily creates its own Scorer
    # with its own OpenRouter + ZenRows clients on first use. This avoids
    # contention on each client's internal rate-limiter state and lets us
    # parallelize without locks on the LLM/scrape path.
    #
    # Aggregated totals live in `scorers_list` (collected on a lock); each
    # element is a Scorer whose `.totals` will be summed at the end.
    thread_local = threading.local()
    scorers_list: List[Scorer] = []
    scorers_list_lock = threading.Lock()

    def get_scorer() -> Scorer:
        if not hasattr(thread_local, "scorer"):
            s = Scorer(
                icp_definition=icp_def,
                description_model=args.description_model,
                scrape_model=args.scrape_model,
                escalation_model=args.escalation_model,
                or_client=OpenRouterClient(),
                zr_client=ZenRowsClient(),
                escalate_low_confidence=effective_escalate,
                zenrows_premium_on_retry=not args.no_zenrows_premium_retry,
                description_only=args.description_only,
                scrape_only=args.scrape_only,
                zenrows_extra_retry=not args.no_zenrows_extra_retry,
            )
            with scorers_list_lock:
                scorers_list.append(s)
            thread_local.scorer = s
        return thread_local.scorer

    # Safety net behind Patches A + B. If score_row still raises a transient
    # network exception (e.g. RequestException leaked past the tiered fallback,
    # or a brand-new failure mode), retry up to 2 more times before giving up
    # and marking the row "Error". Permanent exceptions (auth, parse errors,
    # ZenRows 4xx that isn't a timeout) fail immediately - no point retrying.
    _TRANSIENT_EXC = (
        requests.exceptions.ReadTimeout,
        requests.exceptions.ConnectionError,
        requests.exceptions.ChunkedEncodingError,
        ZenRowsRateLimitError,
    )
    _TRANSIENT_BACKOFFS = [3.0, 8.0]

    def process_one(row):
        row_id = row["id"]
        fields = {
            "company_name": row.get("company", ""),
            "domain": row.get("domain", ""),
            "description": row.get("description", ""),
        }
        sc = get_scorer()
        last_exc: Optional[Exception] = None
        for attempt in range(len(_TRANSIENT_BACKOFFS) + 1):
            try:
                return row_id, sc.score_row(**fields)
            except _TRANSIENT_EXC as exc:
                last_exc = exc
                if attempt < len(_TRANSIENT_BACKOFFS):
                    time.sleep(_TRANSIENT_BACKOFFS[attempt])
                    continue
                break
            except Exception as exc:
                last_exc = exc
                break
        return row_id, {
            "score": "",
            "verdict": "Error",
            "source": "failed",
            "reasoning": f"unhandled exception: {type(last_exc).__name__}: {str(last_exc)[:160]}",
            "error": str(last_exc),
            "scrape_content": "",
        }

    # ---- Score loop: claim small batches from the job store, score them
    # concurrently, record results back. Peak memory is bounded by the claim
    # batch size (NOT the list size) - this is what lets multi-GB CSVs run
    # without crashing. Results are durable in SQLite after every flush, and for
    # the sheet source they're also written back to the sheet live.
    started_at = time.time()
    written = 0
    errored = 0
    claim_size = max(args.concurrency * 8, 200)
    write_batch = args.write_batch_size
    result_buffer: List[Tuple[int, Dict[str, Any]]] = []

    def flush_results() -> None:
        nonlocal result_buffer
        if not result_buffer:
            return
        store.record_results(result_buffer)        # durable
        source.write_incremental(result_buffer)    # sheets: live write-back; csv: no-op
        result_buffer = []

    print(
        f"Scoring {pending_total} row(s) with concurrency={args.concurrency} "
        f"(claim batch {claim_size}, write batch {write_batch})..."
    )
    with ThreadPoolExecutor(max_workers=max(1, args.concurrency)) as ex:
        while True:
            batch = store.claim_pending(claim_size)
            if not batch:
                break
            futures = [ex.submit(process_one, row) for row in batch]
            for fut in as_completed(futures):
                row_id, result = fut.result()
                if result.get("error"):
                    errored += 1
                result_buffer.append((row_id, result))
                written += 1
                if len(result_buffer) >= write_batch:
                    flush_results()
                    print(f"  ... {written}/{pending_total} scored (flushed batch)")
    flush_results()

    elapsed = time.time() - started_at
    print(f"\nScored {written} rows in {elapsed:.1f}s with {len(scorers_list)} worker(s). Errors: {errored}.")

    # ---- Aggregate per-worker totals into a single rollup ----
    def merge_totals(scorers):
        rollup = {
            "description_calls": 0,
            "scrape_calls": 0,
            "escalations": 0,
            "zenrows_scrape_calls": 0,
            "zenrows_premium_calls": 0,
            "zenrows_cost_usd": 0.0,
            "llm_calls_by_model": {},
        }
        for s in scorers:
            for k in ("description_calls", "scrape_calls", "escalations",
                      "zenrows_scrape_calls", "zenrows_premium_calls"):
                rollup[k] += s.totals.get(k, 0)
            rollup["zenrows_cost_usd"] += s.totals.get("zenrows_cost_usd", 0.0)
            for model, bucket in s.totals.get("llm_calls_by_model", {}).items():
                tgt = rollup["llm_calls_by_model"].setdefault(model, {
                    "input": 0, "output": 0, "cached_input": 0, "cost": 0.0, "calls": 0
                })
                for k in ("input", "output", "cached_input", "calls"):
                    tgt[k] += bucket.get(k, 0)
                tgt["cost"] += bucket.get("cost", 0.0)
        return rollup

    # A throwaway scorer is created above in `scorer = Scorer(...)`; we replaced
    # that pattern. Build the rollup from the actually-used per-worker scorers:
    scorer_totals = merge_totals(scorers_list) if scorers_list else {
        "description_calls": 0, "scrape_calls": 0, "escalations": 0,
        "zenrows_scrape_calls": 0, "zenrows_premium_calls": 0,
        "zenrows_cost_usd": 0.0, "llm_calls_by_model": {},
    }
    # Shim a fake `.totals` interface for the rest of the function (no other
    # code changes needed - it just reads `scorer.totals["..."]`):
    class _AggregatedTotals:
        def __init__(self, t): self.totals = t
    scorer = _AggregatedTotals(scorer_totals)

    # ---- Cost summary ----
    llm_cost = sum(b["cost"] for b in scorer.totals["llm_calls_by_model"].values())
    zenrows_cost = scorer.totals["zenrows_cost_usd"]
    total_cost = llm_cost + zenrows_cost
    print(f"\nCost summary:")
    for model, bucket in scorer.totals["llm_calls_by_model"].items():
        print(
            f"  {model}: {bucket['calls']} calls, "
            f"in={bucket['input']} out={bucket['output']} cached={bucket['cached_input']} "
            f"=> ${bucket['cost']:.4f}"
        )
    print(f"  ZenRows: {scorer.totals['zenrows_scrape_calls']} basic + {scorer.totals['zenrows_premium_calls']} premium calls => ${zenrows_cost:.4f}")
    print(f"  Escalations triggered: {scorer.totals['escalations']}")
    print(f"  TOTAL: ${total_cost:.4f}")

    # ---- Export sidecar (CSV only) ----
    if source.kind == "csv":
        if args.no_export:
            print(
                "--no-export set: results are saved in the job store; "
                "run with --export-only later to write the sidecar CSV."
            )
        else:
            out = source.finalize(store, OUTPUT_HEADERS)
            print(f"Sidecar written: {out}")

    # ---- Cost log (one JSONL line per run) ----
    cost_record = {
        "source": source.describe(),
        "source_kind": source.kind,
        "icp_profile": icp_name,
        "rows_scored": written,
        "rows_errored": errored,
        "scrape_calls": scorer.totals["scrape_calls"],
        "description_calls": scorer.totals["description_calls"],
        "escalations": scorer.totals["escalations"],
        "llm_by_model": scorer.totals["llm_calls_by_model"],
        "zenrows_basic_calls": scorer.totals["zenrows_scrape_calls"],
        "zenrows_premium_calls": scorer.totals["zenrows_premium_calls"],
        "llm_cost_usd": round(llm_cost, 6),
        "zenrows_cost_usd": round(zenrows_cost, 6),
        "total_cost_usd": round(total_cost, 6),
        "elapsed_seconds": round(elapsed, 2),
        "models": {
            "description": args.description_model,
            "scrape": args.scrape_model,
            "escalation": args.escalation_model,
        },
    }
    if source.kind == "sheet":
        cost_record["sheet_id"] = sheet_id
        cost_record["sheet_url"] = args.sheet_url
        cost_record["worksheet"] = worksheet_title
    append_run(cost_record)

    # ---- Run journal (the feedback loop): best-effort, never fail the run ----
    try:
        journal_path = run_journal.append_entry({
            "source": source.describe(),
            "icp": f"{icp_name} ({len(icp_def)} chars)",
            "mode": mode,
            "models": {
                "description": args.description_model,
                "scrape": args.scrape_model,
                "escalation": args.escalation_model,
            },
            "rows_scored": written,
            "rows_errored": errored,
            "rows_skipped": ingest_stats["skipped"],
            "source_breakdown": store.source_breakdown(),
            "zenrows_basic_calls": scorer.totals["zenrows_scrape_calls"],
            "zenrows_premium_calls": scorer.totals["zenrows_premium_calls"],
            "escalations": scorer.totals["escalations"],
            "llm_cost_usd": round(llm_cost, 6),
            "zenrows_cost_usd": round(zenrows_cost, 6),
            "total_cost_usd": round(total_cost, 6),
            "elapsed_seconds": round(elapsed, 2),
            "error_samples": store.error_samples(8),
        })
        print(f"Run journal updated: {journal_path}")
    except Exception as exc:
        print(f"(run journal skipped: {exc})")

    store.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
