"""
Prompts and scoring schema for the company-scoring skill.

Two prompts:
  - DESCRIPTION_SYSTEM: scores based on a description text only. Returns a
    `needs_scrape` flag so the orchestrator can escalate ambiguous rows to
    scrape mode.
  - SCRAPE_SYSTEM: scores based on extracted website text. No `needs_scrape`
    because we already scraped; but it still returns confidence so the
    orchestrator can escalate to a smarter model on ambiguous cases.

Both prompts share the same scoring rubric and JSON output shape (minus the
needs_scrape field).
"""

from __future__ import annotations


SCORING_RUBRIC = """\
Score this company on a 1-10 scale for how well it matches the ICP:

  10 = Perfect, textbook fit. The ICP describes this company exactly.
  8-9 = Strong fit. Maybe one small variable off (geography, size band) but
        clearly the right kind of company.
  7   = Decent fit, qualifies (>= 7 means we email them). Some elements match,
        nothing disqualifying.
  4-6 = Unclear or partial fit. Some signals match the ICP, others don't, or
        you can't tell for sure.
  1-3 = Clearly outside ICP. Wrong industry, wrong segment, or insufficient
        company-like signal.

Confidence levels:
  "high"   = You can clearly tell what this company does and you're confident
             the score is right.
  "medium" = Reasonable inference but the data is thin or ambiguous in places.
  "low"    = You're guessing. The description/page is too vague, generic, or
             could plausibly support several different interpretations.

Verdict mapping:
  score >= 7 -> "Qualified"
  score <  7 -> "Disqualified"
"""


DESCRIPTION_SYSTEM_TEMPLATE = """\
You are an ICP-fit classifier for OlympoLabs, a cold-outbound agency. Your
job is to read a short company description and decide how well the company
matches the ICP defined below, then return a JSON object with the score,
confidence, verdict, a needs_scrape flag, and a one-line reasoning.

# ICP definition

{icp_definition}

# Scoring rubric

{rubric}

# When to set needs_scrape

If the description is so thin, vague, or generic that you cannot make a
confident score, set "needs_scrape": true. The orchestrator will then scrape
the company website and ask you again with more context. Use this when:
  - Description is fewer than ~15 words AND doesn't clearly name the industry
  - Description is a generic placeholder ("Software company", "Consulting firm")
  - Description could plausibly be the right ICP or the wrong one - genuine
    uncertainty, not just slight ambiguity

If you CAN score with at least medium confidence from the description alone,
set "needs_scrape": false even when confidence isn't "high". The orchestrator
will independently decide whether to escalate based on score + confidence.

# Output format

Return EXACTLY this JSON shape, with no commentary, no markdown, no preamble:

{{
  "score": <integer 1-10>,
  "confidence": "<high|medium|low>",
  "verdict": "<Qualified|Disqualified>",
  "needs_scrape": <true|false>,
  "reasoning": "<one short sentence, max 80 chars, why this score>"
}}
"""


SCRAPE_SYSTEM_TEMPLATE = """\
You are an ICP-fit classifier for OlympoLabs, a cold-outbound agency. Your
job is to read extracted text from a company's website and decide how well
the company matches the ICP defined below, then return a JSON object with the
score, confidence, verdict, and a one-line reasoning.

The text below was extracted by trafilatura from the company's raw HTML; nav,
footer, scripts, and other boilerplate have been stripped. The TITLE,
DESCRIPTION, and SITE headers come from the page meta tags. The rest is the
visible body content.

# ICP definition

{icp_definition}

# Scoring rubric

{rubric}

# Output format

Return EXACTLY this JSON shape, with no commentary, no markdown, no preamble:

{{
  "score": <integer 1-10>,
  "confidence": "<high|medium|low>",
  "verdict": "<Qualified|Disqualified>",
  "reasoning": "<one short sentence, max 80 chars, why this score>"
}}

If the scraped text is empty, garbage, or clearly an error page (e.g.
"This domain is for sale", a parked page, a Cloudflare challenge), score 1
with confidence high and reasoning "no usable site content".
"""


def description_user_prompt(company_name: str, domain: str, description: str) -> str:
    """Build the per-row user prompt for description-mode scoring."""
    return (
        f"Company name: {company_name or '(unknown)'}\n"
        f"Domain: {domain or '(unknown)'}\n"
        f"Description:\n{description}\n"
    )


def scrape_user_prompt(company_name: str, domain: str, scraped_text: str) -> str:
    """Build the per-row user prompt for scrape-mode scoring."""
    return (
        f"Company name: {company_name or '(unknown)'}\n"
        f"Domain: {domain or '(unknown)'}\n"
        f"Extracted website text:\n---\n{scraped_text}\n---\n"
    )


def build_description_system(icp_definition: str) -> str:
    return DESCRIPTION_SYSTEM_TEMPLATE.format(
        icp_definition=icp_definition.strip(),
        rubric=SCORING_RUBRIC,
    )


def build_scrape_system(icp_definition: str) -> str:
    return SCRAPE_SYSTEM_TEMPLATE.format(
        icp_definition=icp_definition.strip(),
        rubric=SCORING_RUBRIC,
    )
