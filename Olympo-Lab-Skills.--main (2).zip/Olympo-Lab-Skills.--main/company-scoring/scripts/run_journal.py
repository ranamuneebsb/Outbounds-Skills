"""
Run journal for the company-scoring skill - the feedback/learning loop.

After every run, score_sheet.py appends one structured Markdown entry here so
that learnings, error patterns, and cost trends accumulate IN the skill (the
file lives under references/, so it travels with the skill and is in context the
next time the skill runs).

This is the capture half of the loop. The apply half is the `/improve` ritual
documented in SKILL.md: Claude reads the recent entries below, spots patterns
(creeping scrape-fail rates, a vertical that keeps erroring, the cheap model
overshooting a band), and proposes concrete edits to the ICP templates /
SKILL.md defaults / scrape ladder for the user to approve.

Writing is best-effort: a journal failure must never fail a scoring run, so the
caller wraps append_entry() in a try/except.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

JOURNAL_PATH = Path(__file__).resolve().parent.parent / "references" / "run-journal.md"

_HEADER = """# Company-Scoring Run Journal

Append-only log of every scoring run: what was scored, how it went, what broke,
and what it cost. New entries are added to the TOP (most recent first).

Use `/improve` (see SKILL.md) to review recent entries and fold the learnings
back into the skill - refine ICP templates, adjust model defaults, tune the
scrape ladder. Do NOT hand-edit past entries; they're an audit trail.

---
"""


def _fmt_pct(numerator: int, denominator: int) -> str:
    if denominator <= 0:
        return "0.0%"
    return f"{100.0 * numerator / denominator:.1f}%"


def render_entry(record: Dict[str, Any]) -> str:
    """Render one journal entry as Markdown."""
    ts = record.get("timestamp") or datetime.now(timezone.utc).isoformat()
    source = record.get("source", "?")
    icp = record.get("icp", "?")
    mode = record.get("mode", "?")
    models = record.get("models", {}) or {}
    scored = int(record.get("rows_scored", 0))
    errored = int(record.get("rows_errored", 0))
    skipped = int(record.get("rows_skipped", 0))
    attempted = scored  # scored already counts done+error this run

    breakdown = record.get("source_breakdown", {}) or {}
    breakdown_str = ", ".join(f"{k}={v}" for k, v in sorted(breakdown.items())) or "n/a"

    zr_basic = int(record.get("zenrows_basic_calls", 0))
    zr_prem = int(record.get("zenrows_premium_calls", 0))
    cost = float(record.get("total_cost_usd", 0.0))
    llm_cost = float(record.get("llm_cost_usd", 0.0))
    zr_cost = float(record.get("zenrows_cost_usd", 0.0))
    elapsed = float(record.get("elapsed_seconds", 0.0))
    rate = (scored / elapsed) if elapsed > 0 else 0.0

    lines: List[str] = []
    lines.append(f"## {ts} — {source}")
    lines.append("")
    lines.append(f"- **ICP:** {icp}")
    lines.append(f"- **Mode:** {mode}")
    lines.append(
        f"- **Models:** desc=`{models.get('description','?')}`, "
        f"scrape=`{models.get('scrape','?')}`, esc=`{models.get('escalation','?')}`"
    )
    lines.append(
        f"- **Rows:** {scored} scored, {errored} errored "
        f"({_fmt_pct(errored, attempted)}), {skipped} skipped at ingest"
    )
    lines.append(f"- **Scoring-source breakdown:** {breakdown_str}")
    lines.append(
        f"- **ZenRows:** {zr_basic} basic + {zr_prem} premium "
        f"(premium rate {_fmt_pct(zr_prem, zr_basic + zr_prem)})"
    )
    lines.append(
        f"- **Cost:** ${cost:.4f} (llm ${llm_cost:.4f} + zenrows ${zr_cost:.4f}); "
        f"escalations: {int(record.get('escalations', 0))}"
    )
    lines.append(f"- **Elapsed:** {elapsed:.0f}s (~{rate:.1f} rows/s)")

    samples = record.get("error_samples", []) or []
    if samples:
        lines.append("- **Error samples:**")
        for s in samples[:8]:
            ref = s.get("domain") or s.get("source_ref") or "?"
            err = (s.get("error") or "").replace("\n", " ")[:160]
            lines.append(f"    - `{ref}` — {err}")

    notes = record.get("notes")
    if notes:
        lines.append(f"- **Notes:** {notes}")

    lines.append("")
    lines.append("---")
    lines.append("")
    return "\n".join(lines)


def append_entry(record: Dict[str, Any], journal_path: Path = JOURNAL_PATH) -> Path:
    """Prepend a new entry to the journal (most-recent-first). Returns the path.

    Creates the file with a header if it doesn't exist yet.
    """
    journal_path.parent.mkdir(parents=True, exist_ok=True)
    record.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
    entry = render_entry(record)

    if journal_path.exists():
        existing = journal_path.read_text(encoding="utf-8")
        if existing.startswith(_HEADER):
            body = existing[len(_HEADER):]
        else:
            # Unexpected/legacy content - keep it below the new header.
            body = "\n" + existing
    else:
        body = "\n"

    journal_path.write_text(_HEADER + "\n" + entry + body, encoding="utf-8")
    return journal_path
