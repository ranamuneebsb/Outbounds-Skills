"""
SQLite-backed work queue for the company-scoring skill.

WHY THIS EXISTS
---------------
The original orchestrator read the entire source into memory, built one big
`pending` list, and submitted every row as a thread-pool Future at once. On a
small Google Sheet that's fine. On a hundreds-of-thousands-of-rows CSV (the
Globaltize ecom list was ~3GB) it pins RAM/CPU and crashes the laptop.

The fix is a durable on-disk work queue. Rows are ingested once into a SQLite
DB; the orchestrator then *claims* small batches, scores them, and records the
results back. Memory is bounded by the claim batch size, not the list size.

As a bonus, the queue makes resume bulletproof: a crashed or Ctrl-C'd run picks
up exactly where it left off because "done" lives in the DB, not in the volatile
process. (`status='queued'` rows - claimed but not finished when the process
died - are reset to 'pending' on the next open.)

JOB IDENTITY
------------
Each source (a sheet+worksheet, or an absolute CSV path) maps to a stable
job id, so re-running the same command resumes the same DB under
~/.olympolabs/scoring-jobs/<job_id>.db.

This module is intentionally dependency-free (stdlib `sqlite3` only) so it adds
nothing to install footprint.
"""

from __future__ import annotations

import hashlib
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple

JOBS_DIR = Path.home() / ".olympolabs" / "scoring-jobs"

# Columns we persist per row. Input fields are written at ingest; result fields
# are filled in by record_results().
_RESULT_FIELDS = ("score", "verdict", "source", "reasoning", "error", "scrape_content")


def job_id_for(identity: str) -> str:
    """Derive a stable, filesystem-safe job id from a source identity string.

    identity examples:
      - "sheet:1AbC...:Sheet1"
      - "csv:/Users/me/lists/globaltize.csv"
    """
    return hashlib.sha1(identity.encode("utf-8")).hexdigest()[:16]


def db_path_for(identity: str, jobs_dir: Path = JOBS_DIR) -> Path:
    return jobs_dir / f"{job_id_for(identity)}.db"


class JobStore:
    """A durable, resumable work queue backed by one SQLite file.

    All DB access is serialized behind a lock. In the orchestrator only the main
    thread touches the DB (workers just score), but the lock keeps the store
    safe to share if that ever changes.
    """

    def __init__(self, identity: str, jobs_dir: Path = JOBS_DIR):
        self.identity = identity
        jobs_dir.mkdir(parents=True, exist_ok=True)
        self.path = jobs_dir / f"{job_id_for(identity)}.db"
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        # WAL: readers don't block the writer; survives crashes cleanly.
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._init_schema()

    def _init_schema(self) -> None:
        with self._lock:
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS rows (
                    id             INTEGER PRIMARY KEY,   -- source row order (0-based data row)
                    source_ref     TEXT,                  -- sheet A1 row number, or CSV row number
                    company        TEXT,
                    domain         TEXT,
                    description    TEXT,
                    status         TEXT NOT NULL DEFAULT 'pending',  -- pending|queued|done|error
                    score          INTEGER,
                    verdict        TEXT,
                    source         TEXT,
                    reasoning      TEXT,
                    error          TEXT,
                    scrape_content TEXT                   -- trafilatura text from ZenRows; empty when scored from description
                );
                CREATE INDEX IF NOT EXISTS idx_rows_status ON rows(status);
                CREATE TABLE IF NOT EXISTS meta (
                    key   TEXT PRIMARY KEY,
                    value TEXT
                );
                """
            )
            # Migration for DBs created before scrape_content existed.
            # ALTER TABLE ADD COLUMN is idempotent-ish: it throws on second run, so we probe pragma first.
            existing_cols = {r["name"] for r in self._conn.execute("PRAGMA table_info(rows)")}
            if "scrape_content" not in existing_cols:
                self._conn.execute("ALTER TABLE rows ADD COLUMN scrape_content TEXT")
            self._conn.commit()

    # ---- meta ------------------------------------------------------------

    def set_meta(self, mapping: Dict[str, Any]) -> None:
        with self._lock:
            self._conn.executemany(
                "INSERT INTO meta(key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                [(str(k), "" if v is None else str(v)) for k, v in mapping.items()],
            )
            self._conn.commit()

    def get_meta(self, key: str, default: Optional[str] = None) -> Optional[str]:
        with self._lock:
            cur = self._conn.execute("SELECT value FROM meta WHERE key=?", (key,))
            row = cur.fetchone()
        return row["value"] if row else default

    # ---- ingest ----------------------------------------------------------

    def existing_status(self, row_id: int) -> Optional[str]:
        """Return the stored status for a row id, or None if not ingested yet."""
        with self._lock:
            cur = self._conn.execute("SELECT status FROM rows WHERE id=?", (row_id,))
            row = cur.fetchone()
        return row["status"] if row else None

    def existing_score(self, row_id: int) -> Optional[int]:
        with self._lock:
            cur = self._conn.execute("SELECT score FROM rows WHERE id=?", (row_id,))
            row = cur.fetchone()
        if not row or row["score"] is None:
            return None
        try:
            return int(row["score"])
        except (TypeError, ValueError):
            return None

    def upsert_pending(self, items: Iterable[Dict[str, Any]], batch: int = 1000) -> int:
        """Insert (or reset to pending) the given rows.

        Each item: {id, source_ref, company, domain, description}. An existing
        row at the same id is reset to 'pending' and its prior result cleared -
        this is what --force-rescore / rescore-range rely on. Returns the count
        upserted.
        """
        n = 0
        buf: List[Tuple[Any, ...]] = []

        def _flush() -> None:
            nonlocal buf
            if not buf:
                return
            with self._lock:
                self._conn.executemany(
                    "INSERT INTO rows (id, source_ref, company, domain, description, "
                    "status, score, verdict, source, reasoning, error, scrape_content) "
                    "VALUES (?, ?, ?, ?, ?, 'pending', NULL, NULL, NULL, NULL, NULL, NULL) "
                    "ON CONFLICT(id) DO UPDATE SET "
                    "source_ref=excluded.source_ref, company=excluded.company, "
                    "domain=excluded.domain, description=excluded.description, "
                    "status='pending', score=NULL, verdict=NULL, source=NULL, "
                    "reasoning=NULL, error=NULL, scrape_content=NULL",
                    buf,
                )
                self._conn.commit()
            buf = []

        for it in items:
            buf.append(
                (
                    int(it["id"]),
                    str(it.get("source_ref", "")),
                    it.get("company", ""),
                    it.get("domain", ""),
                    it.get("description", ""),
                )
            )
            n += 1
            if len(buf) >= batch:
                _flush()
        _flush()
        return n

    # ---- claim / process -------------------------------------------------

    def reset_queued(self) -> int:
        """Reset rows left 'queued' by a crashed run back to 'pending'.

        Call once at startup before processing so an interrupted run resumes
        cleanly without dropping the in-flight batch.
        """
        with self._lock:
            cur = self._conn.execute(
                "UPDATE rows SET status='pending' WHERE status='queued'"
            )
            self._conn.commit()
            return cur.rowcount

    def claim_pending(self, limit: int) -> List[Dict[str, Any]]:
        """Atomically claim up to `limit` pending rows (mark them 'queued').

        Returns the claimed rows as dicts. An empty list means the queue is
        drained. Claiming marks rows 'queued' so a subsequent claim won't hand
        out the same rows; record_results() moves them to done/error.
        """
        with self._lock:
            cur = self._conn.execute(
                "SELECT id, source_ref, company, domain, description "
                "FROM rows WHERE status='pending' ORDER BY id LIMIT ?",
                (limit,),
            )
            rows = [dict(r) for r in cur.fetchall()]
            if rows:
                ids = [r["id"] for r in rows]
                self._conn.executemany(
                    "UPDATE rows SET status='queued' WHERE id=?",
                    [(i,) for i in ids],
                )
                self._conn.commit()
        return rows

    def record_results(self, results: Iterable[Tuple[int, Dict[str, Any]]]) -> None:
        """Persist a batch of (row_id, result) pairs.

        result is the writeback dict {score, verdict, source, reasoning, error, scrape_content}.
        scrape_content is the trafilatura text from the ZenRows scrape, or empty string
        when scoring came from the description column (no scrape happened).
        status becomes 'error' when result['error'] is truthy, else 'done'.
        """
        payload = []
        for row_id, res in results:
            status = "error" if res.get("error") else "done"
            score = res.get("score")
            score = score if isinstance(score, int) else None
            payload.append(
                (
                    status,
                    score,
                    res.get("verdict"),
                    res.get("source"),
                    res.get("reasoning"),
                    res.get("error"),
                    res.get("scrape_content") or "",
                    int(row_id),
                )
            )
        if not payload:
            return
        with self._lock:
            self._conn.executemany(
                "UPDATE rows SET status=?, score=?, verdict=?, source=?, "
                "reasoning=?, error=?, scrape_content=? WHERE id=?",
                payload,
            )
            self._conn.commit()

    # ---- export / stats --------------------------------------------------

    def iter_results(self) -> Iterator[Dict[str, Any]]:
        """Yield all scored rows ordered by id (for streaming CSV export).

        Uses a dedicated cursor so the generator streams from SQLite rather than
        materializing every row - memory stays flat on huge lists.
        """
        cur = self._conn.execute(
            "SELECT id, source_ref, score, verdict, source, reasoning, error, status, "
            "scrape_content FROM rows ORDER BY id"
        )
        for r in cur:
            yield dict(r)

    def counts(self) -> Dict[str, int]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT status, COUNT(*) AS n FROM rows GROUP BY status"
            )
            by_status = {r["status"]: r["n"] for r in cur.fetchall()}
            total = self._conn.execute("SELECT COUNT(*) AS n FROM rows").fetchone()["n"]
        by_status["total"] = total
        return by_status

    def pending_count(self) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) AS n FROM rows WHERE status='pending'"
            ).fetchone()
        return int(row["n"])

    def peek_pending(self, limit: int) -> List[Dict[str, Any]]:
        """Read (without claiming) the first `limit` pending rows - for dry-run."""
        with self._lock:
            cur = self._conn.execute(
                "SELECT id, source_ref, company, domain, description "
                "FROM rows WHERE status='pending' ORDER BY id LIMIT ?",
                (limit,),
            )
            return [dict(r) for r in cur.fetchall()]

    def error_samples(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Return a sample of errored rows for the run journal."""
        with self._lock:
            cur = self._conn.execute(
                "SELECT source_ref, domain, error FROM rows WHERE status='error' "
                "ORDER BY id LIMIT ?",
                (limit,),
            )
            return [dict(r) for r in cur.fetchall()]

    def source_breakdown(self) -> Dict[str, int]:
        """Count done rows by their Scoring Source (description/scrape/etc.)."""
        with self._lock:
            cur = self._conn.execute(
                "SELECT source, COUNT(*) AS n FROM rows "
                "WHERE status IN ('done','error') GROUP BY source"
            )
            return {(r["source"] or "?"): r["n"] for r in cur.fetchall()}

    def close(self) -> None:
        with self._lock:
            self._conn.commit()
            self._conn.close()
