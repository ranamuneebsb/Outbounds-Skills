"""
Source/sink abstraction for the company-scoring skill.

Two input sources, one common shape so the orchestrator doesn't branch all over:

  - SheetSource: a Google Sheet worksheet. Results are written back into four
    columns on the sheet (the original behavior), batched, with 429 backoff.
  - CsvSource: a local CSV file. Supports arbitrarily large files because both
    read and write are STREAMING - the file is never held in memory. Results go
    to a NEW sidecar file `<name>.scored.csv` (the original is never rewritten),
    produced in a second streaming pass that merge-joins the original rows with
    the scored results from the job store (both ordered by row id).

The orchestrator injects the Google Sheets client + helpers into SheetSource so
this module stays free of the foundation-loading dance in score_sheet.py.

Common interface (duck-typed, both classes implement it):
    identity()        -> str   stable id for the job store DB
    describe()        -> str   human label for logs
    read_header()     -> list  the header row (list of cell strings)
    iter_rows()       -> yields (row_id:int, source_ref:str, cells:list)
    write_incremental(results)  persist a batch of (row_id, result) live
                                (sheets: writes back; csv: no-op)
    finalize(store, output_headers)  produce final output
                                (csv: stream the sidecar; sheets: no-op)
"""

from __future__ import annotations

import csv
import sys
import time
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Tuple

# CSV cells in scraped/enriched exports can be large (whole descriptions). Lift
# the field-size limit so csv.reader doesn't choke on a fat cell.
try:
    csv.field_size_limit(sys.maxsize)
except OverflowError:  # 32-bit platforms reject sys.maxsize
    csv.field_size_limit(2**31 - 1)


# ---- CSV ----------------------------------------------------------------


class CsvSource:
    """Streaming CSV source. Writes a sidecar <name>.scored.csv on finalize."""

    kind = "csv"

    def __init__(self, csv_path: str, output_path: Optional[str] = None):
        self.path = Path(csv_path).expanduser().resolve()
        if not self.path.exists():
            raise FileNotFoundError(f"CSV not found: {self.path}")
        if output_path:
            self.output_path = Path(output_path).expanduser().resolve()
        else:
            self.output_path = self.path.with_name(self.path.stem + ".scored" + self.path.suffix)

    def identity(self) -> str:
        return f"csv:{self.path}"

    def describe(self) -> str:
        return f"CSV {self.path}"

    def _open_reader(self):
        # newline="" per csv docs; utf-8 with replacement so a stray byte in a
        # 3GB export doesn't abort the whole run.
        return open(self.path, "r", encoding="utf-8", errors="replace", newline="")

    def read_header(self) -> List[str]:
        with self._open_reader() as fh:
            reader = csv.reader(fh)
            for row in reader:
                return [str(c) for c in row]
        return []

    def iter_rows(self) -> Iterator[Tuple[int, str, List[Any]]]:
        with self._open_reader() as fh:
            reader = csv.reader(fh)
            header_seen = False
            row_id = 0
            for row in reader:
                if not header_seen:
                    header_seen = True
                    continue
                # row_id is the 0-based DATA row index; source_ref mirrors the
                # 1-based spreadsheet row number (header = row 1) for symmetry.
                yield row_id, str(row_id + 2), row
                row_id += 1

    def write_incremental(self, results: Iterable[Tuple[int, Dict[str, Any]]]) -> None:
        # CSV can't be randomly updated cheaply; results live in the job store
        # and the sidecar is produced once in finalize(). Nothing to do live.
        return

    def finalize(self, store, output_headers: Tuple[str, ...]) -> Path:
        """Stream the original CSV + scored results into the sidecar file.

        Merge-join: the original rows are in id order (file order); the store's
        iter_results() is ordered by id too. We walk both in lockstep so memory
        stays O(1) regardless of file size. Rows that were skipped at ingest
        (no store entry) get blank ICP columns.
        """
        results_iter = store.iter_results()
        cur_result: Optional[Dict[str, Any]] = next(results_iter, None)

        tmp = self.output_path.with_suffix(self.output_path.suffix + ".part")
        with self._open_reader() as fin, open(
            tmp, "w", encoding="utf-8", newline=""
        ) as fout:
            reader = csv.reader(fin)
            writer = csv.writer(fout)
            header_seen = False
            row_id = 0
            for row in reader:
                if not header_seen:
                    header_seen = True
                    writer.writerow(list(row) + list(output_headers))
                    continue
                # Advance the store cursor to this row id (skipping any gaps).
                while cur_result is not None and cur_result["id"] < row_id:
                    cur_result = next(results_iter, None)
                if cur_result is not None and cur_result["id"] == row_id:
                    extra = [
                        _csv_cell(cur_result.get("score")),
                        cur_result.get("verdict") or "",
                        cur_result.get("source") or "",
                        cur_result.get("reasoning") or "",
                        cur_result.get("scrape_content") or "",
                    ]
                else:
                    extra = ["", "", "", "", ""]  # row was skipped at ingest
                writer.writerow(list(row) + extra)
                row_id += 1
        tmp.replace(self.output_path)
        return self.output_path


def _csv_cell(value: Any) -> Any:
    return "" if value is None else value


# ---- Google Sheet -------------------------------------------------------


class SheetSource:
    """Google Sheet worksheet source. Writes results back into the sheet."""

    kind = "sheet"

    def __init__(
        self,
        sheets,                       # SheetsClient instance (injected)
        sheet_id: str,
        worksheet_title: str,
        *,
        col_index_to_letter: Callable[[int], str],
        score_col: Optional[int] = None,
        end_col: Optional[int] = None,
        sheet_url: str = "",
    ):
        self._sheets = sheets
        self.sheet_id = sheet_id
        self.worksheet_title = worksheet_title
        self.sheet_url = sheet_url or sheet_id
        self._col_to_letter = col_index_to_letter
        self.score_col = score_col
        self.end_col = end_col
        self._cached_rows: Optional[List[List[Any]]] = None

    def identity(self) -> str:
        return f"sheet:{self.sheet_id}:{self.worksheet_title}"

    def describe(self) -> str:
        return f"Sheet {self.sheet_id} / {self.worksheet_title!r}"

    def set_output_columns(self, score_col: int, end_col: int) -> None:
        self.score_col = score_col
        self.end_col = end_col

    def _read_all(self) -> List[List[Any]]:
        if self._cached_rows is None:
            self._cached_rows = self._sheets.read_full_sheet(self.sheet_id, self.worksheet_title)
        return self._cached_rows

    def refresh(self) -> None:
        """Drop the cached read so the next iter_rows re-reads (used after the
        output columns are appended)."""
        self._cached_rows = None

    def read_header(self) -> List[str]:
        # Read only row 1 - cheap, and avoids pulling the whole sheet before the
        # output columns are appended (iter_rows does the one full read later).
        hdr = self._sheets.read_range(self.sheet_id, f"{self.worksheet_title}!1:1")
        return [str(c) for c in hdr[0]] if hdr else []

    def iter_rows(self) -> Iterator[Tuple[int, str, List[Any]]]:
        rows = self._read_all()
        for i, row in enumerate(rows[1:]):
            # row_id = 0-based data row; source_ref = 1-based sheet row (header=1)
            yield i, str(i + 2), row

    def write_incremental(self, results: Iterable[Tuple[int, Dict[str, Any]]]) -> None:
        if self.score_col is None or self.end_col is None:
            raise RuntimeError("SheetSource output columns not set before write.")
        score_letter = self._col_to_letter(self.score_col)
        end_letter = self._col_to_letter(self.end_col)
        updates = []
        for row_id, res in results:
            sheet_row = row_id + 2  # header row is 1
            a1 = f"{self.worksheet_title}!{score_letter}{sheet_row}:{end_letter}{sheet_row}"
            updates.append(
                {
                    "range": a1,
                    "values": [[
                        res["score"],
                        res["verdict"],
                        res["source"],
                        res["reasoning"],
                        res.get("scrape_content") or "",
                    ]],
                }
            )
        if not updates:
            return
        self._batch_write_with_backoff(updates)

    def _batch_write_with_backoff(self, updates: List[dict]) -> None:
        # Retry-with-backoff on Sheets 429s (write-rate quota). Without this a
        # single rate-limit burst would crash the run; with it the run just
        # slows until the quota bucket refills.
        backoffs = [2, 5, 10, 20, 40, 60, 90]
        attempt = 0
        while True:
            try:
                self._sheets.batch_write(self.sheet_id, updates)
                return
            except Exception as exc:  # HttpError lives in googleapiclient
                msg = str(exc)
                is_429 = "429" in msg or "RATE_LIMIT_EXCEEDED" in msg or "Quota exceeded" in msg
                if not is_429 or attempt >= len(backoffs):
                    raise
                wait = backoffs[attempt]
                attempt += 1
                print(
                    f"  [sheets 429] write quota hit; sleeping {wait}s "
                    f"(attempt {attempt}/{len(backoffs)})"
                )
                time.sleep(wait)

    def finalize(self, store, output_headers: Tuple[str, ...]) -> None:
        # Sheet results are written live in write_incremental(); nothing to do.
        return
