"""
Per-run cost logging for the company-scoring skill.

Appends one JSON line per run to ~/.olympolabs/scoring-costs.log. The format
is JSONL so:
  - Future runs can tail the file to compute monthly totals
  - The log is greppable / inspectable in a text editor
  - Parsing is trivial: `python3 -c "import json; print(sum(json.loads(l)['total_cost_usd'] for l in open('~/.olympolabs/scoring-costs.log').readlines()))"`

Per run we record:
  - timestamp
  - sheet ID + URL
  - ICP profile name (or "<inline>" if free-text)
  - row counts (total, scored, skipped, scrape_calls, escalations)
  - token usage and cost per model
  - total cost (LLM + ZenRows estimate)
  - duration in seconds
  - any errors encountered
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


DEFAULT_LOG_PATH = Path.home() / ".olympolabs" / "scoring-costs.log"


def append_run(record: Dict[str, Any], log_path: Path = DEFAULT_LOG_PATH) -> None:
    """Append one run record to the log file as JSONL.

    Creates the parent dir if needed. Sets mode 0644 on the file (logs are
    not credentials; readable is fine, but stay user-owned).
    """
    log_path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(record)
    payload.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
    line = json.dumps(payload, ensure_ascii=False)
    with open(log_path, "a", encoding="utf-8") as fh:
        fh.write(line + "\n")
    os.chmod(log_path, 0o644)


def month_total_usd(log_path: Path = DEFAULT_LOG_PATH, year_month: str | None = None) -> float:
    """Sum costs for a given YYYY-MM (defaults to current month UTC).

    Returns 0.0 if the log doesn't exist. Skips malformed lines silently.
    """
    if not log_path.exists():
        return 0.0
    if year_month is None:
        year_month = datetime.now(timezone.utc).strftime("%Y-%m")

    total = 0.0
    for line in log_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        ts = record.get("timestamp", "")
        if ts.startswith(year_month):
            total += float(record.get("total_cost_usd") or 0.0)
    return total
