"""
Google Sheets API client.

Wraps the read + write operations the company-scoring skill (and future List
Builder, Reply Handler) need. Auth lives in auth.py.

Design:
- Sheets uses A1 notation for ranges. We expose helpers that work in either
  A1 ("Sheet1!A2:F100") or structured form (worksheet name + row/col ints).
- Header detection is a separate helper (column_detect.py in the skill) - this
  module just reads/writes; it doesn't know which column means what.
- Sheet IDs: extracted from URLs via `extract_sheet_id()`. The Google Sheet
  share URL pattern is `https://docs.google.com/spreadsheets/d/<ID>/edit?...`.
- Writes are batched per call (one batch_update for many cell updates) to
  stay within API quotas (Sheets v4 has per-100-second-per-user limits).
"""

from __future__ import annotations

import re
import warnings
from typing import Any, Iterable, List, Optional, Sequence

warnings.filterwarnings("ignore", category=FutureWarning, module=r"google\..*")

from sheets_auth import get_sheets_service  # noqa: E402


_SHEET_ID_RE = re.compile(r"/spreadsheets/d/([a-zA-Z0-9_-]+)")


def extract_sheet_id(url_or_id: str) -> str:
    """Pull the spreadsheet ID out of a Sheets URL, or pass it through.

    Accepts:
        - Full URLs: https://docs.google.com/spreadsheets/d/ABC123/edit?...
        - Bare IDs: ABC123

    Raises ValueError if neither form matches.
    """
    m = _SHEET_ID_RE.search(url_or_id)
    if m:
        return m.group(1)
    # bare-ID heuristic: Google sheet IDs are usually 40+ url-safe chars
    if re.fullmatch(r"[a-zA-Z0-9_-]{20,}", url_or_id):
        return url_or_id
    raise ValueError(
        f"Could not extract a spreadsheet ID from: {url_or_id!r}. "
        "Provide a full https://docs.google.com/spreadsheets/d/.../edit URL "
        "or a bare spreadsheet ID."
    )


class SheetsClient:
    """Thin wrapper for the Sheets v4 read + write surface we need."""

    def __init__(self, service=None):
        self._service = service or get_sheets_service()

    # ---- metadata --------------------------------------------------------

    def get_metadata(self, spreadsheet_id: str) -> dict:
        """Return the spreadsheet metadata (title, sheets, etc.)."""
        return (
            self._service.spreadsheets()
            .get(spreadsheetId=spreadsheet_id, includeGridData=False)
            .execute()
        )

    def list_worksheets(self, spreadsheet_id: str) -> List[dict]:
        """Return a list of {sheetId, title, rowCount, columnCount} per worksheet."""
        meta = self.get_metadata(spreadsheet_id)
        return [
            {
                "sheetId": s["properties"]["sheetId"],
                "title": s["properties"]["title"],
                "rowCount": s["properties"]["gridProperties"]["rowCount"],
                "columnCount": s["properties"]["gridProperties"]["columnCount"],
            }
            for s in meta.get("sheets", [])
        ]

    # ---- reads -----------------------------------------------------------

    def read_range(self, spreadsheet_id: str, a1_range: str) -> List[List[Any]]:
        """Read a range in A1 notation; return rows as lists of cell values.

        Trailing empty cells in a row may be truncated by the API; callers
        should not rely on every row being the same length.
        """
        resp = (
            self._service.spreadsheets()
            .values()
            .get(spreadsheetId=spreadsheet_id, range=a1_range)
            .execute()
        )
        return resp.get("values", [])

    def read_full_sheet(self, spreadsheet_id: str, worksheet_title: str) -> List[List[Any]]:
        """Read every used cell in a worksheet by title."""
        return self.read_range(spreadsheet_id, worksheet_title)

    # ---- writes ----------------------------------------------------------

    def write_range(
        self,
        spreadsheet_id: str,
        a1_range: str,
        values: Sequence[Sequence[Any]],
        value_input_option: str = "USER_ENTERED",
    ) -> dict:
        """Overwrite a range with the given values.

        value_input_option:
          - "RAW" - values are stored exactly as given.
          - "USER_ENTERED" - Sheets parses as if typed (numbers stay numbers,
            "=A1+B1" becomes a formula). Use this for normal data writes.
        """
        return (
            self._service.spreadsheets()
            .values()
            .update(
                spreadsheetId=spreadsheet_id,
                range=a1_range,
                valueInputOption=value_input_option,
                body={"values": [list(row) for row in values]},
            )
            .execute()
        )

    def batch_write(
        self,
        spreadsheet_id: str,
        updates: Iterable[dict],
        value_input_option: str = "USER_ENTERED",
    ) -> dict:
        """Apply multiple range updates in one call.

        Each `update` is a dict like:
            {"range": "Sheet1!E2:H2", "values": [[8, "Qualified", "description", "Strong fit because..."]]}

        Strongly preferred over many single write_range calls when scoring
        many rows - Sheets has per-100-seconds quotas and batching is cheap.
        """
        return (
            self._service.spreadsheets()
            .values()
            .batchUpdate(
                spreadsheetId=spreadsheet_id,
                body={
                    "valueInputOption": value_input_option,
                    "data": [
                        {"range": u["range"], "values": [list(row) for row in u["values"]]}
                        for u in updates
                    ],
                },
            )
            .execute()
        )

    def append_columns(
        self,
        spreadsheet_id: str,
        worksheet_title: str,
        headers: Sequence[str],
    ) -> int:
        """Append new columns with the given headers right after the last
        populated header in row 1.

        Most sheets have a grid that's wider than the data (default 26
        columns; user data fills only the first N). We want our new headers
        adjacent to the existing data, not at the grid edge. So we read the
        header row, find the last non-empty cell, and append from there.

        If the new headers would exceed the grid's columnCount, the grid is
        extended via batchUpdate.appendDimension first.

        Returns the 1-based column index where the FIRST new header was
        placed.
        """
        meta = self.get_metadata(spreadsheet_id)
        target = next(
            (s for s in meta["sheets"] if s["properties"]["title"] == worksheet_title),
            None,
        )
        if not target:
            raise ValueError(f"Worksheet {worksheet_title!r} not found in spreadsheet.")
        grid_cols = target["properties"]["gridProperties"]["columnCount"]
        sheet_id_int = target["properties"]["sheetId"]

        # Read row 1 to find last populated header
        header_row = self.read_range(spreadsheet_id, f"{worksheet_title}!1:1")
        if header_row and header_row[0]:
            row = header_row[0]
            last_populated = 0
            for i, cell in enumerate(row, start=1):
                if cell is not None and str(cell).strip():
                    last_populated = i
        else:
            last_populated = 0
        start_col = last_populated + 1
        end_col = last_populated + len(headers)

        # Extend grid if needed
        if end_col > grid_cols:
            extra = end_col - grid_cols
            self._service.spreadsheets().batchUpdate(
                spreadsheetId=spreadsheet_id,
                body={
                    "requests": [{
                        "appendDimension": {
                            "sheetId": sheet_id_int,
                            "dimension": "COLUMNS",
                            "length": extra,
                        }
                    }]
                },
            ).execute()

        start_col_letter = _col_index_to_letter(start_col)
        end_col_letter = _col_index_to_letter(end_col)
        a1 = f"{worksheet_title}!{start_col_letter}1:{end_col_letter}1"
        self.write_range(spreadsheet_id, a1, [list(headers)])
        return start_col


def _col_index_to_letter(idx: int) -> str:
    """Convert a 1-based column index to A1 letters. 1->A, 27->AA, 703->AAA."""
    if idx < 1:
        raise ValueError("Column index must be >= 1")
    letters = ""
    while idx > 0:
        idx, rem = divmod(idx - 1, 26)
        letters = chr(ord("A") + rem) + letters
    return letters


def col_index_to_letter(idx: int) -> str:
    """Public alias for _col_index_to_letter (1-based to letter)."""
    return _col_index_to_letter(idx)
