"""
Google Sheets API authentication.

Same auth strategy as plusvibe-api's fetch_kb.py path B (ADC), but with
spreadsheets scope:

  Recommended: `gcloud auth application-default login --scopes=https://www.googleapis.com/auth/spreadsheets`

The skill authenticates AS the user, so they can read+write any sheet they
have edit access to. No service-account dance, no link-share-as-edit needed.
Falls back to a service-account JSON if GOOGLE_APPLICATION_CREDENTIALS is set
- useful for CI / headless setups.
"""

from __future__ import annotations

import os
import sys
import warnings
from typing import Optional

warnings.filterwarnings("ignore", category=FutureWarning, module=r"google\..*")

from google.oauth2 import service_account  # type: ignore
from googleapiclient.discovery import build  # type: ignore


SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]


def get_sheets_service():
    """Build a Sheets v4 service client, preferring ADC, falling back to SA.

    Order:
      1. GOOGLE_APPLICATION_CREDENTIALS - service account JSON path (CI use).
      2. ADC - typically set up via `gcloud auth application-default login`.

    Raises a clear RuntimeError if neither is available, pointing the user at
    the gcloud setup command.
    """
    creds_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if creds_path:
        if not os.path.exists(creds_path):
            raise RuntimeError(
                f"GOOGLE_APPLICATION_CREDENTIALS={creds_path} not found. "
                "Either unset it to use ADC, or point at a real service-account JSON."
            )
        creds = service_account.Credentials.from_service_account_file(
            creds_path, scopes=SCOPES
        )
    else:
        try:
            from google.auth import default as default_creds  # type: ignore
            creds, _project = default_creds(scopes=SCOPES)
        except Exception as exc:
            raise RuntimeError(
                "No Google credentials configured. Run:\n"
                "  gcloud auth application-default login \\\n"
                "    --scopes=openid,email,https://www.googleapis.com/auth/spreadsheets\n"
                "  gcloud auth application-default set-quota-project <your-project-id>\n"
                f"Underlying error: {exc}"
            ) from exc
    return build("sheets", "v4", credentials=creds, cache_discovery=False)
