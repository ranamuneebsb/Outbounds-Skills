"""OpenRouter API shared client for OlympoLabs skills."""

from openrouter_auth import Credentials, MissingCredentials, load_credentials
from client import (
    OpenRouterAuthError,
    OpenRouterClient,
    OpenRouterError,
    OpenRouterModelError,
    OpenRouterRateLimitError,
    OpenRouterTimeoutError,
)
from pricing import ModelPrice, estimate_cost, lookup

__all__ = [
    "Credentials",
    "MissingCredentials",
    "ModelPrice",
    "OpenRouterAuthError",
    "OpenRouterClient",
    "OpenRouterError",
    "OpenRouterModelError",
    "OpenRouterRateLimitError",
    "estimate_cost",
    "load_credentials",
    "lookup",
]
