"""
OpenRouter model pricing table for cost estimation.

Prices are in USD per million tokens. OpenRouter publishes live prices at
https://openrouter.ai/models - this table is a snapshot for local cost-tracking
math. It will drift; refresh periodically. The `unknown` fallback returns zero
so cost estimates degrade gracefully when a new model is used.

Cached input pricing only matters for Anthropic models on OpenRouter; for
others we use the same value as `input` (no cache discount available).

Updated: 2026-05.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class ModelPrice:
    name: str
    input_per_m: float          # $/M input tokens (uncached)
    output_per_m: float         # $/M output tokens
    cached_input_per_m: float   # $/M cached input tokens (= input_per_m if no cache discount)


# Live snapshot from OpenRouter on 2026-05-25. Re-pull periodically with:
#   curl -sS https://openrouter.ai/api/v1/models -H "Authorization: Bearer $KEY" \
#     | python3 -c "import json,sys; ..."
# Only models the skill might pick are listed here; others fall back to
# zero-cost (unknown) so estimates degrade gracefully.
PRICING: Dict[str, ModelPrice] = {
    # Google - cheapest tier; 1M context
    "google/gemini-2.0-flash-lite-001": ModelPrice(
        "google/gemini-2.0-flash-lite-001", 0.075, 0.30, 0.075
    ),
    "google/gemini-2.5-flash-lite": ModelPrice(
        "google/gemini-2.5-flash-lite", 0.10, 0.40, 0.10
    ),
    "google/gemini-2.5-flash": ModelPrice(
        "google/gemini-2.5-flash", 0.30, 2.50, 0.30
    ),

    # OpenAI
    "openai/gpt-4o-mini": ModelPrice(
        "openai/gpt-4o-mini", 0.15, 0.60, 0.15
    ),
    "openai/gpt-4o": ModelPrice(
        "openai/gpt-4o", 2.50, 10.00, 2.50
    ),

    # DeepSeek
    "deepseek/deepseek-chat-v3.1": ModelPrice(
        "deepseek/deepseek-chat-v3.1", 0.21, 0.79, 0.21
    ),
    "deepseek/deepseek-chat": ModelPrice(
        "deepseek/deepseek-chat", 0.229, 0.914, 0.229
    ),

    # Anthropic - prompt caching available (cached input = 10% of normal)
    "anthropic/claude-haiku-4.5": ModelPrice(
        "anthropic/claude-haiku-4.5", 1.00, 5.00, 0.10
    ),
    "anthropic/claude-sonnet-4.5": ModelPrice(
        "anthropic/claude-sonnet-4.5", 3.00, 15.00, 0.30
    ),
    "anthropic/claude-sonnet-4.6": ModelPrice(
        "anthropic/claude-sonnet-4.6", 3.00, 15.00, 0.30
    ),
}


_UNKNOWN_PRICE = ModelPrice("unknown", 0.0, 0.0, 0.0)


def lookup(model: str) -> ModelPrice:
    """Return the pricing for a given model id, or a zero-cost fallback.

    Pricing IDs may include suffixes (e.g. ":free", "::beta"); strip them.
    """
    base = model.split(":", 1)[0]
    return PRICING.get(base, _UNKNOWN_PRICE)


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cached_input_tokens: int = 0,
) -> float:
    """Estimate the USD cost of a single LLM call.

    Args:
        model: The OpenRouter model id used.
        input_tokens: Total input tokens for the call (cached + uncached).
        output_tokens: Total output tokens.
        cached_input_tokens: Subset of input_tokens that hit the cache. For
            Anthropic models on OpenRouter this is reported in the usage
            response under prompt_tokens_details.cached_tokens (or similar).

    Returns:
        Estimated USD cost. Returns 0.0 if the model is unknown to the table.
    """
    price = lookup(model)
    uncached_input = max(0, input_tokens - cached_input_tokens)
    return (
        uncached_input * price.input_per_m / 1_000_000.0
        + cached_input_tokens * price.cached_input_per_m / 1_000_000.0
        + output_tokens * price.output_per_m / 1_000_000.0
    )
