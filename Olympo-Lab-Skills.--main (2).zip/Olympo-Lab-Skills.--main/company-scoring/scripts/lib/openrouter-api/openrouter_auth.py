"""
OpenRouter API authentication.

Loads the API key from one of two sources, in order of precedence:

  1. Environment variable: OPENROUTER_API_KEY
  2. ~/.olympolabs/openrouter.json — JSON file with shape:
       {"api_key": "sk-or-..."}
     File mode should be 0600.

OpenRouter uses standard Bearer auth (Authorization: Bearer <key>), which is
the same shape as OpenAI's API. Get a key at https://openrouter.ai/keys.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


DEFAULT_CONFIG_PATH = Path.home() / ".olympolabs" / "openrouter.json"
KEYS_URL = "https://openrouter.ai/keys"


class MissingCredentials(Exception):
    """Raised when no OpenRouter API key is configured."""


@dataclass(frozen=True)
class Credentials:
    api_key: str


def load_credentials(config_path: Optional[Path] = None) -> Credentials:
    env_key = os.environ.get("OPENROUTER_API_KEY")
    if env_key:
        return Credentials(api_key=env_key)

    path = config_path or DEFAULT_CONFIG_PATH
    if path.exists():
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            raise MissingCredentials(
                f"OpenRouter config at {path} is not valid JSON: {exc}"
            ) from exc
        api_key = data.get("api_key")
        if api_key:
            return Credentials(api_key=api_key)

    raise MissingCredentials(
        "No OpenRouter API key configured. Set one of:\n"
        f"  1. ENV: export OPENROUTER_API_KEY=...\n"
        f"  2. FILE: {DEFAULT_CONFIG_PATH} containing "
        f'{{"api_key": "sk-or-..."}}'
        f" (chmod 600)\n"
        f"Get a key at: {KEYS_URL}"
    )
