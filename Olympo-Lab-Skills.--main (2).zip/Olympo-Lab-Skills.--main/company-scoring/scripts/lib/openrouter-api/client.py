"""
OpenRouter API client.

Thin wrapper over OpenRouter's OpenAI-compatible chat completions endpoint
(https://openrouter.ai/docs). Designed for use by OlympoLabs Claude skills
(company-scoring, future List Builder, future Reply Handler) so each skill
doesn't reimplement auth, retry, JSON-mode handling, and cost tracking.

Design choices:

- Base URL: https://openrouter.ai/api/v1
- Auth: `Authorization: Bearer <key>` (OpenAI-compatible)
- Endpoint: POST /chat/completions
- Sends standard `messages` array; the only OpenRouter-specific tweak is the
  `HTTP-Referer` and `X-Title` headers, used for routing analytics on
  OpenRouter's dashboard. Optional but recommended.
- JSON output: passes `response_format={"type": "json_object"}` when the
  caller asks for structured output. OpenRouter routes this to the underlying
  provider's equivalent (OpenAI native, Anthropic via tool calling, etc.).
- Token usage: returned in `usage` per OpenAI shape, plus extended fields
  from some providers (cached tokens, reasoning tokens for o-series, etc.).
  The client exposes everything verbatim.
"""

from __future__ import annotations

import json
import time
import warnings
from typing import Any, Iterable, List, Mapping, Optional

warnings.filterwarnings("ignore", message=".*OpenSSL.*", module=r"urllib3.*")

import requests

from openrouter_auth import Credentials, MissingCredentials, load_credentials  # noqa: E402


BASE_URL = "https://openrouter.ai/api/v1"
DEFAULT_TIMEOUT = 120.0  # LLM calls can take a while on slow models
DEFAULT_REFERER = "https://github.com/olympolabs"
DEFAULT_TITLE = "OlympoLabs Claude Skills"


class OpenRouterError(Exception):
    """Base for OpenRouter API errors."""

    def __init__(self, message: str, status_code: int | None = None, payload: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload or {}


class OpenRouterAuthError(OpenRouterError):
    """401 - API key invalid, missing, or revoked."""


class OpenRouterRateLimitError(OpenRouterError):
    """429 - rate-limited or out of credits. Back off and retry."""


class OpenRouterModelError(OpenRouterError):
    """400/422/etc - request was malformed or the model rejected it."""


class OpenRouterTimeoutError(OpenRouterError):
    """Network timeout or connection error talking to OpenRouter. Retryable."""


class OpenRouterClient:
    """Synchronous OpenRouter chat completions client."""

    def __init__(
        self,
        credentials: Optional[Credentials] = None,
        base_url: str = BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        session: Optional[requests.Session] = None,
        referer: str = DEFAULT_REFERER,
        title: str = DEFAULT_TITLE,
    ):
        self._creds = credentials or load_credentials()
        self._base = base_url.rstrip("/")
        self._timeout = timeout
        self._session = session or requests.Session()
        self._referer = referer
        self._title = title

    # ---- core call ------------------------------------------------------

    def chat(
        self,
        *,
        model: str,
        messages: Iterable[Mapping[str, Any]],
        json_mode: bool = False,
        temperature: float = 0.0,
        max_tokens: Optional[int] = None,
        provider: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: int = 3,
        backoff_base: float = 1.5,
    ) -> dict:
        """Call OpenRouter's chat completions endpoint.

        Args:
            model: OpenRouter model id (e.g. "anthropic/claude-sonnet-4.5",
                "deepseek/deepseek-chat-v3.1").
            messages: List of {role, content} dicts. For prompt caching on
                Anthropic models, content can be a list with `cache_control`
                blocks (see OpenRouter docs).
            json_mode: If True, request structured JSON output via
                `response_format={"type": "json_object"}`. Caller must still
                instruct the model to emit JSON in the prompt.
            temperature: Sampling temperature. Default 0 (deterministic) which
                is what we want for scoring.
            max_tokens: Optional output cap.
            provider: Optional provider routing preferences (e.g. preferring a
                specific upstream provider). See OpenRouter docs.
            extra_body: Additional body fields merged in last.
            max_retries: Retry on 429 / 5xx errors with exponential backoff.
            backoff_base: Base for backoff timing (seconds).

        Returns:
            The full response dict from OpenRouter. Notable fields:
              - choices[0].message.content (string)
              - usage.prompt_tokens, usage.completion_tokens, usage.total_tokens
              - usage.prompt_tokens_details.cached_tokens (Anthropic, others)
              - model (the actual model that served, may differ from requested
                if OpenRouter routed to a fallback)
              - id (request id for debugging)
        """
        body: dict = {
            "model": model,
            "messages": list(messages),
            "temperature": temperature,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if provider is not None:
            body["provider"] = dict(provider)
        if extra_body:
            body.update(dict(extra_body))

        last_error: Optional[Exception] = None
        for attempt in range(max_retries + 1):
            try:
                return self._post_chat(body)
            except (OpenRouterRateLimitError, OpenRouterTimeoutError) as exc:
                last_error = exc
                if attempt >= max_retries:
                    raise
                time.sleep(backoff_base * (2 ** attempt))
            except OpenRouterError as exc:
                # 5xx server errors are retryable; 4xx (except 429) are not
                if exc.status_code and 500 <= exc.status_code < 600 and attempt < max_retries:
                    last_error = exc
                    time.sleep(backoff_base * (2 ** attempt))
                else:
                    raise

        if last_error:
            raise last_error
        raise OpenRouterError("chat() exhausted retries without raising; should not happen")

    def _post_chat(self, body: dict) -> dict:
        headers = {
            "Authorization": f"Bearer {self._creds.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "HTTP-Referer": self._referer,
            "X-Title": self._title,
        }
        try:
            resp = self._session.post(
                f"{self._base}/chat/completions",
                headers=headers,
                json=body,
                timeout=self._timeout,
            )
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as exc:
            # Wrap bare network exceptions as a retryable OpenRouterTimeoutError
            # so the chat() retry loop catches them like rate-limit / 5xx.
            raise OpenRouterTimeoutError(
                f"Network error to OpenRouter (model={body.get('model','?')}): {exc}",
                status_code=None,
            ) from exc
        return self._handle_response(resp)

    def _handle_response(self, resp: requests.Response) -> dict:
        status = resp.status_code
        try:
            payload = resp.json() if resp.content else {}
        except ValueError:
            payload = {"raw": resp.text}

        if 200 <= status < 300:
            if not isinstance(payload, dict):
                raise OpenRouterError(
                    f"Unexpected non-dict response: {payload!r}",
                    status_code=status,
                )
            return payload

        message = ""
        if isinstance(payload, dict):
            err = payload.get("error")
            if isinstance(err, dict):
                message = err.get("message") or err.get("code") or ""
            elif isinstance(err, str):
                message = err
            if not message:
                message = payload.get("message") or ""
        if not message:
            message = f"HTTP {status}: {resp.text[:200]}"

        payload_dict = payload if isinstance(payload, dict) else None
        if status == 401:
            raise OpenRouterAuthError(
                f"OpenRouter rejected the API key: {message}. "
                f"Check ~/.olympolabs/openrouter.json or regenerate at "
                f"https://openrouter.ai/keys.",
                status_code=status,
                payload=payload_dict,
            )
        if status == 429:
            raise OpenRouterRateLimitError(
                f"OpenRouter rate limit or out of credits: {message}",
                status_code=status,
                payload=payload_dict,
            )
        if 400 <= status < 500:
            raise OpenRouterModelError(
                f"OpenRouter rejected the request ({status}): {message}",
                status_code=status,
                payload=payload_dict,
            )
        raise OpenRouterError(
            f"OpenRouter error ({status}): {message}",
            status_code=status,
            payload=payload_dict,
        )

    # ---- conveniences ---------------------------------------------------

    def parse_json_content(self, response: dict) -> Any:
        """Extract and parse the first choice's content as JSON.

        Raises OpenRouterError if the content is not valid JSON. The caller is
        responsible for providing prompts that consistently emit JSON; this is
        a thin helper around the parsing step.
        """
        try:
            content = response["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise OpenRouterError(f"Response missing choices[0].message.content: {response!r}") from exc
        if isinstance(content, list):
            # Some providers return content as blocks (Anthropic). Concatenate text blocks.
            content = "".join(
                block.get("text", "")
                for block in content
                if isinstance(block, dict) and block.get("type") == "text"
            )
        if not isinstance(content, str):
            raise OpenRouterError(f"Response content is not a string: {content!r}")

        # Strip markdown code fences if the model wrapped its JSON in them.
        # Anthropic models in particular tend to emit ```json ... ``` even
        # when response_format=json_object is requested, so handle it here
        # rather than forcing every caller to remember.
        cleaned = content.strip()
        if cleaned.startswith("```"):
            # Drop the first line (```json or just ```)
            parts = cleaned.split("\n", 1)
            cleaned = parts[1] if len(parts) == 2 else ""
            # Drop a trailing ``` (possibly preceded by whitespace/newline)
            cleaned = cleaned.rstrip()
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3].rstrip()

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as exc:
            raise OpenRouterError(
                f"Response content is not valid JSON: {content[:400]!r}"
            ) from exc

    def usage_tokens(self, response: dict) -> dict:
        """Pull a normalized usage dict from the response.

        Returns: {"input": N, "output": N, "cached_input": N, "total": N}
        Handles missing fields by zeroing them out.
        """
        u = response.get("usage", {}) or {}
        input_tok = int(u.get("prompt_tokens") or 0)
        output_tok = int(u.get("completion_tokens") or 0)
        details = u.get("prompt_tokens_details") or {}
        cached_tok = int(details.get("cached_tokens") or 0)
        total = int(u.get("total_tokens") or (input_tok + output_tok))
        return {
            "input": input_tok,
            "output": output_tok,
            "cached_input": cached_tok,
            "total": total,
        }
