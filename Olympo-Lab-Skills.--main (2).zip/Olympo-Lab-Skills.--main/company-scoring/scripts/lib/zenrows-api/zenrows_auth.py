"""
ZenRows API authentication.

ZenRows uses a simple `apikey` query parameter on each request - no headers.
The key is loaded from one of two places, in order of precedence:

  1. Environment variable: ZENROWS_API_KEY
  2. ~/.olympolabs/zenrows.json - JSON file with shape:
       {"api_key": "..."}
     File mode should be 0600.

Get a key from the ZenRows dashboard after creating an account.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


DEFAULT_CONFIG_PATH = Path.home() / ".olympolabs" / "zenrows.json"
KEYS_URL = "https://app.zenrows.com/"


class MissingCredentials(Exception):
    pass


@dataclass(frozen=True)
class Credentials:
    api_key: str


def load_credentials(config_path: Optional[Path] = None) -> Credentials:
    env_key = os.environ.get("ZENROWS_API_KEY")
    if env_key:
        return Credentials(api_key=env_key)

    path = config_path or DEFAULT_CONFIG_PATH
    if path.exists():
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            raise MissingCredentials(
                f"ZenRows config at {path} is not valid JSON: {exc}"
            ) from exc
        api_key = data.get("api_key")
        if api_key:
            return Credentials(api_key=api_key)

    raise MissingCredentials(
        "No ZenRows API key configured. Set one of:\n"
        f"  1. ENV: export ZENROWS_API_KEY=...\n"
        f"  2. FILE: {DEFAULT_CONFIG_PATH} containing "
        f'{{"api_key": "..."}}'
        f" (chmod 600)\n"
        f"Get a key at: {KEYS_URL}"
    )
