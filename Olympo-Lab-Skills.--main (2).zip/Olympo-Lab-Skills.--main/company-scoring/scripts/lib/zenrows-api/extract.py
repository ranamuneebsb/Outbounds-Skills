"""
Text extraction from raw HTML.

The ZenRows API gives us raw HTML; the LLM doesn't need the HTML, it needs the
visible meaningful text. `trafilatura` is the workhorse here - it's tuned for
extracting article-like content from real-world messy web pages, handling
boilerplate (nav, footer, ads, cookie banners) much better than a naive parser.

For company-scoring use cases where the page is a marketing site rather than
an article, we ask trafilatura to keep the main content + metadata (title,
description, og tags). That gives the LLM enough to classify the company.
"""

from __future__ import annotations

import re
from typing import Optional

import trafilatura


def extract_company_text(html: str, url: Optional[str] = None, max_chars: int = 12000) -> str:
    """Pull the meaningful text from a company website's HTML.

    The output combines:
      - Page title (if available)
      - Meta description / og:description
      - Main content (article-like text trafilatura found)

    Boilerplate (nav, footer, scripts, styles) is stripped. The result is
    capped at `max_chars` to keep LLM input bounded; this matters because some
    marketing sites are 50k+ tokens of raw HTML.

    Args:
        html: Raw HTML string from ZenRows.
        url: Optional URL the HTML came from (helps trafilatura with relative
            link resolution but is not required).
        max_chars: Cap on the returned text length. Default 12000 ~= 3000
            tokens, plenty for a classifier.

    Returns:
        A clean text blob. Empty string if nothing extractable.
    """
    if not html or not html.strip():
        return ""

    # First grab metadata + main content via trafilatura
    extracted = trafilatura.extract(
        html,
        url=url,
        include_comments=False,
        include_tables=True,        # company sites often put services / numbers in tables
        include_links=False,
        include_images=False,
        with_metadata=False,
        favor_recall=True,           # marketing sites have weird structures - lean toward including more
        deduplicate=True,
    ) or ""

    # Then pull title + description from the meta tags, separately, so
    # they're at the top of the output (LLM reads top-to-bottom).
    meta = trafilatura.extract_metadata(html, default_url=url)
    header_parts = []
    if meta:
        if getattr(meta, "title", None):
            header_parts.append(f"TITLE: {meta.title.strip()}")
        if getattr(meta, "description", None):
            header_parts.append(f"DESCRIPTION: {meta.description.strip()}")
        sitename = getattr(meta, "sitename", None)
        if sitename:
            header_parts.append(f"SITE: {sitename.strip()}")

    header = "\n".join(header_parts)
    body = extracted.strip()

    combined = (header + "\n\n" + body).strip() if header else body
    combined = _collapse_whitespace(combined)
    if len(combined) > max_chars:
        combined = combined[:max_chars].rstrip() + "...[truncated]"
    return combined


def _collapse_whitespace(text: str) -> str:
    """Squash runs of blank lines + repeated spaces so we waste fewer tokens."""
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()
