"""
ZenRows API client.

Wraps the ZenRows Universal Scraper API
(https://docs.zenrows.com/universal-scraper-api/api-reference). The endpoint is
GET-only and parameters live entirely in the query string. Auth is the
`apikey` query param (yes, in the URL - it's how ZenRows works).

Design:
- Two-mode scraping: `basic` (no JS, no proxies, $0.001-ish/request) and
  `premium` (JS rendering + residential proxies, $0.005-ish). The company-
  scoring skill calls `basic` first, falls back to `premium` on retry. Most
  company landing pages render fine in basic mode.
- Retries: exponential backoff on 429 + 5xx, capped at max_retries.
- Returns raw HTML by default; callers run it through `extract.py` to get
  clean text for LLM consumption.
"""

from __future__ import annotations

import time
import warnings
from typing import Optional

warnings.filterwarnings("ignore", message=".*OpenSSL.*", module=r"urllib3.*")

import requests

from zenrows_auth import Credentials, MissingCredentials, load_credentials  # noqa: E402


BASE_URL = "https://api.zenrows.com/v1/"
DEFAULT_TIMEOUT = 30.0


class ZenRowsError(Exception):
    def __init__(self, message: str, status_code: int | None = None, payload: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload or {}


class ZenRowsAuthError(ZenRowsError):
    """401 - API key invalid."""


class ZenRowsRateLimitError(ZenRowsError):
    """429 - too many requests, back off."""


class ZenRowsScrapeError(ZenRowsError):
    """4xx/5xx - target site or ZenRows couldn't handle the request."""


class ZenRowsClient:
    """Synchronous ZenRows scrape client."""

    def __init__(
        self,
        credentials: Optional[Credentials] = None,
        base_url: str = BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        session: Optional[requests.Session] = None,
    ):
        self._creds = credentials or load_credentials()
        self._base = base_url
        self._timeout = timeout
        self._session = session or requests.Session()

    def scrape(
        self,
        url: str,
        *,
        js_render: bool = False,
        premium_proxy: bool = False,
        wait_for: Optional[str] = None,
        wait: Optional[int] = None,
        country: Optional[str] = None,
        block_resources: Optional[str] = None,
        max_retries: int = 2,
        backoff_base: float = 1.5,
    ) -> str:
        """Fetch a URL via ZenRows and return raw HTML.

        Args:
            url: Target page URL (full https://...).
            js_render: Enable JS rendering. Slower and more expensive but
                required for SPAs (Next.js apps, React landing pages, etc).
            premium_proxy: Use residential proxy pool. More expensive but
                bypasses Cloudflare, PerimeterX, etc. Use as a fallback.
            wait_for: Optional CSS selector to wait for before extracting HTML.
                Only honored when js_render=True.
            wait: Optional milliseconds to wait after navigation completes,
                before extracting HTML. Useful for sites that:
                  - Have lazy-rendered content (give JS a moment to finish)
                  - Use anti-bot timing checks (a too-quick scrape trips them)
                Typical values: 2000-4000ms. Only honored with js_render=True.
            country: Optional 2-letter country code (lowercase, e.g. "ca", "us")
                to route requests through. Helps when the target site geo-blocks
                or when you want IPs matching the target audience.
            block_resources: Comma-separated resource types to skip downloading
                (e.g. "image,stylesheet,font"). Cuts page weight + speeds up
                scrapes but may interfere with anti-bot fingerprinting on
                aggressive sites - use sparingly.
            max_retries: Retry on 429 and 5xx.
            backoff_base: Base for exponential backoff (seconds).

        Returns:
            Raw HTML string. Empty string is possible if the target returned
            an empty body; the caller should detect this.

        Raises:
            ZenRowsAuthError, ZenRowsRateLimitError, ZenRowsScrapeError.
        """
        params: dict = {
            "apikey": self._creds.api_key,
            "url": url,
        }
        if js_render:
            params["js_render"] = "true"
        if premium_proxy:
            params["premium_proxy"] = "true"
        if wait_for:
            params["wait_for"] = wait_for
        if wait:
            params["wait"] = str(int(wait))
        if country:
            params["proxy_country"] = country
        if block_resources:
            params["block_resources"] = block_resources

        last_error: Optional[Exception] = None
        for attempt in range(max_retries + 1):
            try:
                return self._do_scrape(params)
            except ZenRowsRateLimitError as exc:
                last_error = exc
                if attempt >= max_retries:
                    raise
                time.sleep(backoff_base * (2 ** attempt))
            except ZenRowsScrapeError as exc:
                if exc.status_code and 500 <= exc.status_code < 600 and attempt < max_retries:
                    last_error = exc
                    time.sleep(backoff_base * (2 ** attempt))
                else:
                    raise
            except (
                requests.exceptions.ReadTimeout,
                requests.exceptions.ConnectionError,
                requests.exceptions.ChunkedEncodingError,
            ) as exc:
                # Transient network errors that bypass ZenRows' own status-code
                # wrapping (e.g. ZenRows API connection drops mid-request, target
                # site hangs past our timeout). Retry with the same exponential
                # backoff as 429/5xx. Without this, a single ReadTimeout escapes
                # to the caller and skips any tiered-fallback logic upstream.
                last_error = exc
                if attempt >= max_retries:
                    raise
                time.sleep(backoff_base * (2 ** attempt))

        if last_error:
            raise last_error
        raise ZenRowsError("scrape() exhausted retries without raising; should not happen")

    def _do_scrape(self, params: dict) -> str:
        resp = self._session.get(self._base, params=params, timeout=self._timeout)
        status = resp.status_code
        if 200 <= status < 300:
            return resp.text or ""

        message = resp.text[:200] if resp.text else f"HTTP {status}"
        if status == 401:
            raise ZenRowsAuthError(
                f"ZenRows rejected the API key: {message}. "
                f"Check ~/.olympolabs/zenrows.json.",
                status_code=status,
            )
        if status == 429:
            raise ZenRowsRateLimitError(
                f"ZenRows rate limit hit: {message}",
                status_code=status,
            )
        raise ZenRowsScrapeError(
            f"ZenRows scrape failed ({status}): {message}",
            status_code=status,
        )
