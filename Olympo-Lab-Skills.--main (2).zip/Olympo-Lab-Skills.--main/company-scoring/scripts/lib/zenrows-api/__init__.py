"""ZenRows API shared client + text extraction for OlympoLabs skills."""

from zenrows_auth import Credentials, MissingCredentials, load_credentials
from client import (
    ZenRowsAuthError,
    ZenRowsClient,
    ZenRowsError,
    ZenRowsRateLimitError,
    ZenRowsScrapeError,
)
from extract import extract_company_text

__all__ = [
    "Credentials",
    "MissingCredentials",
    "ZenRowsAuthError",
    "ZenRowsClient",
    "ZenRowsError",
    "ZenRowsRateLimitError",
    "ZenRowsScrapeError",
    "extract_company_text",
    "load_credentials",
]
