#!/usr/bin/env python3
"""
Preflight doctor for the company-scoring skill.

Run this FIRST when anything looks broken:

    python3 scripts/doctor.py

It checks every external dependency the skill needs and prints PASS/FAIL with
the exact remediation command for each failure. This exists so that a missing
dependency is fixed in seconds - NOT reconstructed by hand. The skill ships
complete and self-contained; if a check fails, it's an install/credentials
problem, never a missing-code problem.

Exit code 0 = all good, 1 = one or more checks failed.
"""

from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
LIB_DIR = SCRIPTS_DIR / "lib"
OLYMPO = Path.home() / ".olympolabs"

GREEN = "\033[0;32m"
RED = "\033[0;31m"
YELLOW = "\033[1;33m"
NC = "\033[0m"

_results = []


def check(name: str, ok: bool, fix: str = "") -> None:
    _results.append(ok)
    if ok:
        print(f"{GREEN}  PASS{NC}  {name}")
    else:
        print(f"{RED}  FAIL{NC}  {name}")
        if fix:
            for line in fix.strip("\n").splitlines():
                print(f"        {YELLOW}{line}{NC}")


def main() -> int:
    print("company-scoring doctor\n======================\n")

    # 1. Vendored foundations resolve
    print("Bundled foundations (scripts/lib/):")
    for pkg in ("openrouter-api", "zenrows-api", "google-sheets-api"):
        present = (LIB_DIR / pkg / "client.py").exists()
        check(
            f"{pkg} vendored",
            present,
            f"Foundations are missing from the bundle. Re-run the repo installer:\n"
            f"  cd ~/Desktop/OlympoLabs-Skills && ./install.sh\n"
            f"(install.sh vendors the foundation packages into each skill's scripts/lib/)",
        )

    # 2. Python deps
    print("\nPython dependencies:")
    deps = [
        ("requests", "requests"),
        ("googleapiclient", "google-api-python-client"),
        ("google.auth", "google-auth"),
        ("trafilatura", "trafilatura"),
    ]
    for mod, pip_name in deps:
        try:
            importlib.import_module(mod)
            ok = True
        except Exception:
            ok = False
        check(
            f"import {mod}",
            ok,
            f"pip3 install --user {pip_name}",
        )

    # 3. SQLite (stdlib, but confirm it's usable)
    try:
        import sqlite3  # noqa: F401
        sqlite3.connect(":memory:").close()
        ok = True
    except Exception:
        ok = False
    check("sqlite3 usable", ok, "Reinstall Python with sqlite support.")

    # 4. Credentials
    print("\nCredentials:")
    or_path = OLYMPO / "openrouter.json"
    check(
        "OpenRouter key (~/.olympolabs/openrouter.json)",
        _valid_key_file(or_path),
        'mkdir -p ~/.olympolabs && echo \'{"api_key":"sk-or-..."}\' > ~/.olympolabs/openrouter.json\n'
        "chmod 600 ~/.olympolabs/openrouter.json   # key from https://openrouter.ai/keys",
    )
    zr_path = OLYMPO / "zenrows.json"
    check(
        "ZenRows key (~/.olympolabs/zenrows.json)",
        _valid_key_file(zr_path),
        'echo \'{"api_key":"..."}\' > ~/.olympolabs/zenrows.json\n'
        "chmod 600 ~/.olympolabs/zenrows.json   # key from https://app.zenrows.com/",
    )

    # 5. gcloud ADC (only needed for the Sheets path; CSV path doesn't use it)
    print("\nGoogle Sheets auth (only needed for --sheet-url, not --csv-path):")
    adc_ok = _adc_available()
    check(
        "gcloud Application Default Credentials",
        adc_ok,
        "gcloud auth application-default login \\\n"
        "  --scopes=openid,email,https://www.googleapis.com/auth/spreadsheets\n"
        "gcloud auth application-default set-quota-project <your-project-id>",
    )

    print()
    passed = sum(1 for r in _results if r)
    total = len(_results)
    if all(_results):
        print(f"{GREEN}All {total} checks passed. You're good to run.{NC}")
        return 0
    print(f"{RED}{total - passed} of {total} checks failed - fix the items above, then re-run.{NC}")
    print(
        f"{YELLOW}Note: the gcloud check only matters for scoring a Google Sheet. "
        f"CSV scoring (--csv-path) works without it.{NC}"
    )
    return 1


def _valid_key_file(path: Path) -> bool:
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text())
    except Exception:
        return False
    return bool(data.get("api_key"))


def _adc_available() -> bool:
    try:
        from google.auth import default as default_creds  # type: ignore

        default_creds(scopes=["https://www.googleapis.com/auth/spreadsheets"])
        return True
    except Exception:
        return False


if __name__ == "__main__":
    sys.exit(main())
