# ICP profile template

An ICP profile file is a plain markdown file the company-scoring skill loads
verbatim as the `icp_definition` passed to the LLM. The skill does not
parse this file in any special way - it just embeds the entire text inside
the scoring system prompt. Write it for an LLM reader: be specific, list
concrete signals, list disqualifiers.

Save profiles under `~/.olympolabs/icp-profiles/<client-slug>.md`. At run
time the skill asks: "Which ICP profile? (or paste one-off)".

A solid ICP profile has four sections:

```markdown
# {{ Client name }} ICP

## Who counts as a fit

A clear one-paragraph definition of the target company. Industry, business
model, customer they serve, size or revenue band, geography, anything that
distinguishes "fit" from "not fit".

Example: "US-based commercial real estate bridge financing brokerages that
fund $1M-$10M loans for small to mid commercial property investors. Focus
on Sun Belt geography. Excludes residential, hard-money personal loans, and
business credit."

## Positive signals (any of these = stronger fit)

- Industry/vertical: list 3-6 keywords that ought to appear in the company
  description or on their website
- Services/products: what they should be selling
- Target customer of THEIR business: who their end customer is
- Size proxies: revenue band, employee count, market cap if relevant
- Geography: states / countries / regions

## Negative signals (any of these = disqualify or score < 5)

- Wrong vertical: list industries that share keywords but are NOT the target
- Wrong size: "individual sole proprietors", "enterprise > 1000 employees", etc.
- Wrong customer: "B2C only", "consumer-facing", etc.
- Wrong geography
- Common look-alikes that get falsely qualified

## Edge cases

Any nuance the model should know about:
- "Subsidiary of X parent counts as fit even though parent doesn't"
- "Companies pivoting from Y to Z still count"
- "Treat franchise networks as N separate companies, not one"
```

## Why this shape

The LLM is going to see this text on every single scoring call. The clearer
and more concrete the signals, the more consistent the scoring. Vague ICPs
("growth-stage SaaS companies") produce vague scores. Specific ICPs ("Series
B-D SaaS companies, $5M-$50M ARR, sales-led GTM, 25-200 employees, US +
Canada") produce sharp scores.

## Reusing across runs

Save each ICP profile separately - one per client. Re-use by passing
`--icp-file ~/.olympolabs/icp-profiles/<slug>.md`. Profiles can be edited
between runs and the next run will reflect the updates.

For a one-off list where you don't want a saved profile, pass `--icp-text`
with the ICP inline.
