# Company-Scoring Run Journal

Append-only log of every scoring run: what was scored, how it went, what broke,
and what it cost. New entries are added to the TOP (most recent first).

Use `/improve` (see SKILL.md) to review recent entries and fold the learnings
back into the skill - refine ICP templates, adjust model defaults, tune the
scrape ladder. Do NOT hand-edit past entries; they're an audit trail.

---

## 2026-06-03T02:29:37.695533+00:00 — CSV /Users/bryanlopez/Downloads/EMC Financial - Government Contractors - Leads.csv

- **ICP:** <inline> (167 chars)
- **Mode:** pilot (20 rows, scrape)
- **Models:** desc=`google/gemini-2.5-flash-lite`, scrape=`deepseek/deepseek-chat-v3.1`, esc=`anthropic/claude-sonnet-4.6`
- **Rows:** 20 scored, 0 errored (0.0%), 0 skipped at ingest
- **Scoring-source breakdown:** scrape=20
- **ZenRows:** 20 basic + 1 premium (premium rate 4.8%)
- **Cost:** $0.0499 (llm $0.0049 + zenrows $0.0450); escalations: 0
- **Elapsed:** 48s (~0.4 rows/s)

---

## 2026-06-03T02:06:00.085455+00:00 — CSV /private/tmp/scoring-test.csv

- **ICP:** <inline> (74 chars)
- **Mode:** pilot (2 rows, scrape)
- **Models:** desc=`google/gemini-2.0-flash-lite-001`, scrape=`deepseek/deepseek-chat-v3.1`, esc=`anthropic/claude-sonnet-4.6`
- **Rows:** 2 scored, 0 errored (0.0%), 0 skipped at ingest
- **Scoring-source breakdown:** scrape=2
- **ZenRows:** 2 basic + 0 premium (premium rate 0.0%)
- **Cost:** $0.0044 (llm $0.0004 + zenrows $0.0040); escalations: 0
- **Elapsed:** 6s (~0.3 rows/s)

---

## 2026-06-03T02:02:26.082828+00:00 — CSV /private/tmp/scoring-test.csv

- **ICP:** <inline> (74 chars)
- **Mode:** hybrid
- **Models:** desc=`google/gemini-2.0-flash-lite-001`, scrape=`deepseek/deepseek-chat-v3.1`, esc=`anthropic/claude-sonnet-4.6`
- **Rows:** 2 scored, 2 errored (100.0%), 0 skipped at ingest
- **Scoring-source breakdown:** failed=2
- **ZenRows:** 1 basic + 0 premium (premium rate 0.0%)
- **Cost:** $0.0020 (llm $0.0000 + zenrows $0.0020); escalations: 0
- **Elapsed:** 0s (~9.1 rows/s)
- **Error samples:**
    - `anthropic.com` — scrape failed: ZenRows rejected the API key: {"code":"AUTH003","detail":"The apikey sent in your request is not valid. Please retry by adding a valid apikey alo
    - `sony.com` — description-mode LLM error: OpenRouter rejected the request (404): No endpoints found for google/gemini-2.0-flash-lite-001.

---

## 2026-06-03T02:02:02.340007+00:00 — CSV /private/tmp/scoring-test.csv

- **ICP:** <inline> (74 chars)
- **Mode:** pilot (2 rows, scrape)
- **Models:** desc=`google/gemini-2.0-flash-lite-001`, scrape=`deepseek/deepseek-chat-v3.1`, esc=`anthropic/claude-sonnet-4.6`
- **Rows:** 2 scored, 2 errored (100.0%), 0 skipped at ingest
- **Scoring-source breakdown:** failed=2
- **ZenRows:** 2 basic + 0 premium (premium rate 0.0%)
- **Cost:** $0.0040 (llm $0.0000 + zenrows $0.0040); escalations: 0
- **Elapsed:** 0s (~10.0 rows/s)
- **Error samples:**
    - `anthropic.com` — scrape failed: ZenRows rejected the API key: {"code":"AUTH003","detail":"The apikey sent in your request is not valid. Please retry by adding a valid apikey alo
    - `sony.com` — scrape failed: ZenRows rejected the API key: {"code":"AUTH003","detail":"The apikey sent in your request is not valid. Please retry by adding a valid apikey alo

---

_No runs yet. The first scoring run will add an entry above this line._
