#!/usr/bin/env python3
"""
scrape_domains — scrape each UNIQUE domain behind a contacts sheet (ZenRows
basic -> premium fallback + trafilatura) and write a `Scrape Content` column
back per row, so the personalization skill can build first-lines without
re-scraping.

Key design points (lessons from this pipeline):
  - PER-DOMAIN, not per-contact: many contacts share a company; scrape each
    domain ONCE and fan the text back to every contact at that domain.
  - --send-safe-only (default): only scrape domains of rows with Send Safe = Yes.
  - Self-caffeinates (the Mac's 1-min idle sleep otherwise kills long runs).
  - Checkpoints the domain->content map to JSON after every batch; resumes
    (skips already-scraped domains) so a kill costs nothing.
  - Reuses company-scoring's tested ZenRows client + trafilatura extractor.

Runs under ~/.olympolabs/venv (modern TLS).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_VENV_PY = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV_PY.exists() and Path(sys.executable).resolve() != _VENV_PY.resolve():
    os.execv(str(_VENV_PY), [str(_VENV_PY)] + sys.argv)

import argparse
import json
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE / "lib" / "google-sheets-api"))
# reuse company-scoring's tested ZenRows + extractor
_CS_LIB = Path.home() / ".claude" / "skills" / "company-scoring" / "scripts" / "lib" / "zenrows-api"
sys.path.insert(0, str(_CS_LIB))

from client import ZenRowsClient, ZenRowsError  # noqa: E402
from extract import extract_company_text  # noqa: E402

SCRAPE_HEADER = "Scrape Content"
MIN_USABLE = 120  # chars; below this, retry premium


def _prevent_sleep() -> None:
    try:
        subprocess.Popen(["caffeinate", "-dimsw", str(os.getpid())],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("  [keep-awake] caffeinate assertion held for this run.")
    except (FileNotFoundError, OSError):
        pass


def _norm_domain(w: str) -> str:
    # Delegate to the single canonical normalizer (olympo_core); fall back to an
    # identical local impl if _pipeline isn't importable (standalone use).
    try:
        import os as _os, sys as _sys
        _sys.path.insert(0, _os.path.join(_os.path.dirname(__file__), "..", "..", "_pipeline"))
        from olympo_core import norm_domain as _nd
        return _nd(w)
    except Exception:
        w = (w or "").strip().lower().replace("https://", "").replace("http://", "").replace("www.", "")
        return w.split("/")[0].split("?")[0].strip()


def scrape_one(client: ZenRowsClient, domain: str, max_chars: int) -> str:
    """Basic scrape -> premium fallback. Returns extracted text (or '')."""
    url = f"https://{domain}"
    # 1) cheap basic pass
    try:
        html = client.scrape(url, js_render=False, premium_proxy=False, max_retries=1)
        text = extract_company_text(html, url, max_chars=max_chars)
        if text and len(text) >= MIN_USABLE:
            return text
    except ZenRowsError:
        pass
    # 2) premium fallback (JS + residential proxy) for SPAs / Cloudflare
    try:
        html = client.scrape(url, js_render=True, premium_proxy=True, wait=2500, max_retries=1)
        text = extract_company_text(html, url, max_chars=max_chars)
        return text or ""
    except ZenRowsError:
        return ""


def load_checkpoint(path: str) -> Dict[str, str]:
    if path and os.path.exists(path):
        try:
            return json.load(open(path, encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_checkpoint(path: str, data: Dict[str, str]) -> None:
    if not path:
        return
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, path)
    except OSError:
        pass


# ---- sheet IO ----

def _sheet_id(url: str) -> str:
    import re
    m = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", url)
    return m.group(1) if m else url


def read_rows(sheet_url: str, tab: str):
    """Read ONLY the header + Website + Send Safe columns. Avoids pulling the big
    Scrape Content column (12k chars/row), which made a full A:Z read ~20MB/slow
    and re-paid it on every resume."""
    from sheets_auth import get_sheets_service  # unique to google-sheets-api lib
    svc = get_sheets_service()
    sid = _sheet_id(sheet_url)
    header = svc.spreadsheets().values().get(
        spreadsheetId=sid, range=f"{tab}!A1:Z1").execute().get("values", [[]])[0]
    hl = [h.strip().lower() for h in header]
    di = hl.index("website") if "website" in hl else 1
    si = hl.index("send safe") if "send safe" in hl else None
    dcol, scol = _a1col(di + 1), (_a1col(si + 1) if si is not None else None)
    ranges = [f"{tab}!{dcol}2:{dcol}"] + ([f"{tab}!{scol}2:{scol}"] if scol else [])
    vr = svc.spreadsheets().values().batchGet(spreadsheetId=sid, ranges=ranges).execute()["valueRanges"]
    doms = [r[0] if r else "" for r in vr[0].get("values", [])]
    safes = [r[0] if r else "" for r in (vr[1].get("values", []) if scol else [])]
    rows = []
    for i, draw in enumerate(doms):
        safe = (safes[i].strip().lower() == "yes") if i < len(safes) else False
        rows.append({"domain": _norm_domain(draw), "safe": safe})
    return svc, sid, header, rows


def ensure_scrape_col(svc, sid, tab, header) -> int:
    """Return 0-based index of the Scrape Content column, adding it if absent."""
    hl = [h.strip().lower() for h in header]
    if SCRAPE_HEADER.lower() in hl:
        return hl.index(SCRAPE_HEADER.lower())
    idx = len(header)
    col = _a1col(idx + 1)
    svc.spreadsheets().values().update(
        spreadsheetId=sid, range=f"{tab}!{col}1", valueInputOption="RAW",
        body={"values": [[SCRAPE_HEADER]]}).execute()
    return idx


def _a1col(n: int) -> str:
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def write_scrape_col(svc, sid, tab, col_idx, rows, content: Dict[str, str], chunk=300):
    # Small chunks: Scrape Content can be ~12k chars/row, so big batches (2000)
    # produce multi-MB requests that break the pipe. 300 rows keeps each request
    # well under payload limits and the run under the 60 writes/min cap.
    col = _a1col(col_idx + 1)
    values = [[content.get(r["domain"], "")] if r["safe"] else [""] for r in rows]
    for i in range(0, len(values), chunk):
        block = values[i:i + chunk]
        for attempt in range(4):
            try:
                svc.spreadsheets().values().update(
                    spreadsheetId=sid, range=f"{tab}!{col}{i + 2}", valueInputOption="RAW",
                    body={"values": block}).execute()
                break
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(2 * (attempt + 1))


def main() -> int:
    p = argparse.ArgumentParser(description="Scrape unique domains behind a contacts sheet; write Scrape Content per row.")
    p.add_argument("--contacts-sheet", required=True)
    p.add_argument("--tab", default="Contacts")
    p.add_argument("--all-domains", action="store_true", help="Scrape every domain, not just Send Safe = Yes rows.")
    p.add_argument("--max-chars", type=int, default=12000)
    p.add_argument("--workers", type=int, default=12)
    p.add_argument("--limit", type=int, help="Cap unique domains (pilot).")
    p.add_argument("--checkpoint", default="/tmp/scrape-domains.json")
    p.add_argument("--retry-empty", action="store_true", help="Re-scrape domains whose cached content is empty (recover failures).")
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()
    _prevent_sleep()

    svc, sid, header, rows = read_rows(args.contacts_sheet, args.tab)
    want = [r for r in rows if (args.all_domains or r["safe"]) and r["domain"]]
    domains = sorted({r["domain"] for r in want})
    print(f"rows: {len(rows):,} | target rows: {len(want):,} | UNIQUE domains: {len(domains):,}")

    done = load_checkpoint(args.checkpoint)
    if args.retry_empty:
        pending = [d for d in domains if d not in done or not done.get(d)]
    else:
        pending = [d for d in domains if d not in done]
    if args.limit:
        pending = pending[:args.limit]
    print(f"already scraped (resume): {len(done):,} | to scrape now: {len(pending):,}")
    if args.dry_run:
        print("DRY RUN — no scraping."); return 0
    if not pending:
        print("Nothing to scrape; writing Scrape Content column from checkpoint...")

    client = ZenRowsClient()
    lock = threading.Lock()
    t0 = time.time()
    n = 0
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(scrape_one, client, d, args.max_chars): d for d in pending}
        for fut in as_completed(futs):
            d = futs[fut]
            try:
                text = fut.result()
            except Exception:
                text = ""
            with lock:
                done[d] = text
                n += 1
                if n % 100 == 0:
                    save_checkpoint(args.checkpoint, done)
                    hit = sum(1 for v in done.values() if v)
                    print(f"  ...{n:,}/{len(pending):,} scraped | {hit:,} with content | {time.time()-t0:.0f}s")
    save_checkpoint(args.checkpoint, done)
    hits = sum(1 for d in domains if done.get(d))
    print(f"\nScraped {len(pending):,} new domains. {hits:,}/{len(domains):,} domains have content "
          f"({hits*100//max(len(domains),1)}%).")

    # write Scrape Content back to the sheet (per send-safe row, by domain)
    col_idx = ensure_scrape_col(svc, sid, args.tab, header)
    write_scrape_col(svc, sid, args.tab, col_idx, rows, done)
    filled = sum(1 for r in rows if (args.all_domains or r["safe"]) and done.get(r["domain"]))
    print(f"Wrote '{SCRAPE_HEADER}' to {filled:,} rows (col {_a1col(col_idx+1)}).")
    print("Next: personalization skill reads the Scrape Content column.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
