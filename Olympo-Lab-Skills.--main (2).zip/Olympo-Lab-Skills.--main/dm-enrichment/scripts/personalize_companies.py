#!/usr/bin/env python3
"""
personalize_companies — generate 3 per-COMPANY personalization fields from the
Scrape Content column, via Claude Sonnet on OpenRouter, and write them back to
every decision-maker at that company (dedup by domain -> 1 LLM call per company,
no overspend).

Fields (OlympoLabs PlusVibe schema):
  custom_growth_idea : "we can run a campaign targeting <their ICP persona> at
                        <segment> so you can <their core outcome>"
  custom_competitors : "<X> and <Y>"  (real if recognized, else a category
                        descriptor — never invent specific names)
  custom_icp         : their ICP in as few words as possible

Self-caffeinates, checkpoints (resume-safe), reads only needed columns.
Runs under ~/.olympolabs/venv.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_VENV_PY = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV_PY.exists() and Path(sys.executable).resolve() != _VENV_PY.resolve():
    os.execv(str(_VENV_PY), [str(_VENV_PY)] + sys.argv)

import argparse
import json
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE / "lib" / "google-sheets-api"))
sys.path.insert(0, str(Path.home() / ".claude" / "skills" / "company-scoring" / "scripts" / "lib" / "openrouter-api"))

from client import OpenRouterClient, OpenRouterError  # noqa: E402  (openrouter-api/client.py)

MODEL = "anthropic/claude-sonnet-4.6"
COST_LOG = Path.home() / ".olympolabs" / "personalize-costs.log"
OUT_COLS = ["custom_growth_idea", "custom_competitors", "custom_icp"]
SCRAPE_CAP = 4000

SYSTEM = (
    "You are a B2B go-to-market analyst helping OlympoLabs, a cold-outbound agency, "
    "pitch its done-for-you lead-generation service to a software company. Given that "
    "company's website content, infer who THEY sell to and produce three fields. "
    "Return ONLY a JSON object with keys growth_idea, competitors, icp.\n\n"
    "growth_idea: ONE punchy sentence, an outbound campaign OlympoLabs would run FOR "
    "this company. Use EXACTLY this shape: 'we can run a campaign targeting <their ICP "
    "decision-maker persona> at <their target customer segment> so you can <the core "
    "outcome their product delivers>'. Lowercase start, no period needed. It must "
    "reflect who THIS company sells to. KEEP IT UNDER 25 WORDS — tight and concrete, "
    "ONE persona, ONE segment, ONE outcome; no stacked clauses, no run-ons, cut filler. "
    "Example: 'we can run a campaign targeting VP of Operations at mid-market financial "
    "services firms so you can land your first anchor clients'.\n\n"
    "competitors: their two most obvious direct competitors as '<X> and <Y>'. If you "
    "genuinely recognize this company and its real competitors, name them (e.g. "
    "'Hubstaff and Time Doctor'). If you do NOT recognize it, DO NOT invent specific "
    "company names — instead give a short category descriptor (e.g. 'other workflow-"
    "automation vendors').\n\n"
    "icp: their ideal customer in as few words as possible — a short noun phrase, not a "
    "sentence (e.g. 'executives managing distributed or remote workforces')."
)


def _prevent_sleep() -> None:
    try:
        subprocess.Popen(["caffeinate", "-dimsw", str(os.getpid())],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("  [keep-awake] caffeinate held.")
    except (FileNotFoundError, OSError):
        pass


def _norm_domain(w: str) -> str:
    w = (w or "").strip().lower().replace("https://", "").replace("http://", "").replace("www.", "")
    return w.split("/")[0].split("?")[0].strip()


def _a1col(n: int) -> str:
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _sheet_id(url: str) -> str:
    import re
    m = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", url)
    return m.group(1) if m else url


def generate(client: OpenRouterClient, company: str, domain: str, scrape: str) -> Optional[dict]:
    content = scrape[:SCRAPE_CAP] if scrape else ""
    user = f"Company: {company}\nDomain: {domain}\n\nWebsite content:\n{content if content else '(no scrape; infer from the company name and domain)'}"
    try:
        resp = client.chat(model=MODEL, json_mode=True, temperature=0.4, max_tokens=320,
                           messages=[{"role": "system", "content": SYSTEM},
                                     {"role": "user", "content": user}])
    except OpenRouterError:
        return None
    try:
        obj = client.parse_json_content(resp)
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    tok = client.usage_tokens(resp)
    return {
        "custom_growth_idea": str(obj.get("growth_idea", "")).strip(),
        "custom_competitors": str(obj.get("competitors", "")).strip(),
        "custom_icp": str(obj.get("icp", "")).strip(),
        "_in": tok.get("prompt_tokens", 0), "_out": tok.get("completion_tokens", 0),
    }


def load_ckpt(path: str) -> Dict[str, dict]:
    if path and os.path.exists(path):
        try:
            return json.load(open(path, encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_ckpt(path: str, data: Dict[str, dict]) -> None:
    if not path:
        return
    try:
        tmp = path + ".tmp"
        json.dump(data, open(tmp, "w", encoding="utf-8"))
        os.replace(tmp, path)
    except OSError:
        pass


def read_companies(sheet_url, tab):
    from sheets_auth import get_sheets_service
    svc = get_sheets_service()
    sid = _sheet_id(sheet_url)
    header = svc.spreadsheets().values().get(spreadsheetId=sid, range=f"{tab}!A1:Z1").execute().get("values", [[]])[0]
    hl = [h.strip().lower() for h in header]
    def ci(name, dflt):
        return hl.index(name) if name in hl else dflt
    ca, cb, cj, cm = ci("company", 0), ci("website", 1), ci("send safe", 9), ci("scrape content", 12)
    cols = {x: _a1col(x + 1) for x in (ca, cb, cj, cm)}
    ranges = [f"{tab}!{cols[ca]}2:{cols[ca]}", f"{tab}!{cols[cb]}2:{cols[cb]}",
              f"{tab}!{cols[cj]}2:{cols[cj]}", f"{tab}!{cols[cm]}2:{cols[cm]}"]
    vr = svc.spreadsheets().values().batchGet(spreadsheetId=sid, ranges=ranges).execute()["valueRanges"]
    def col(i):
        return [r[0] if r else "" for r in vr[i].get("values", [])]
    comp, dom, safe, scr = col(0), col(1), col(2), col(3)
    n = max(len(comp), len(dom), len(safe), len(scr))
    rows = []
    for i in range(n):
        rows.append({
            "company": comp[i] if i < len(comp) else "",
            "domain": _norm_domain(dom[i] if i < len(dom) else ""),
            "safe": (safe[i].strip().lower() == "yes") if i < len(safe) else False,
            "scrape": scr[i] if i < len(scr) else "",
        })
    return svc, sid, header, rows


def ensure_cols(svc, sid, tab, header):
    hl = [h.strip().lower() for h in header]
    idx = {}
    nxt = len(header)
    add = []
    for name in OUT_COLS:
        if name.lower() in hl:
            idx[name] = hl.index(name.lower())
        else:
            idx[name] = nxt
            add.append((nxt, name))
            nxt += 1
    for i, name in add:
        svc.spreadsheets().values().update(spreadsheetId=sid, range=f"{tab}!{_a1col(i+1)}1",
            valueInputOption="RAW", body={"values": [[name]]}).execute()
    return idx


def write_cols(svc, sid, tab, idx, rows, results: Dict[str, dict], chunk=1000):
    lo = min(idx[c] for c in OUT_COLS)
    hi = max(idx[c] for c in OUT_COLS)
    width = hi - lo + 1
    order = sorted(OUT_COLS, key=lambda c: idx[c])
    block = []
    for r in rows:
        row_vals = [""] * width
        if r["safe"]:
            res = results.get(r["domain"])
            if res:
                for c in OUT_COLS:
                    row_vals[idx[c] - lo] = res.get(c, "")
        block.append(row_vals)
    startcol = _a1col(lo + 1)
    for i in range(0, len(block), chunk):
        seg = block[i:i + chunk]
        for attempt in range(4):
            try:
                svc.spreadsheets().values().update(spreadsheetId=sid,
                    range=f"{tab}!{startcol}{i+2}", valueInputOption="RAW",
                    body={"values": seg}).execute()
                break
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(2 * (attempt + 1))


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--contacts-sheet", required=True)
    p.add_argument("--tab", default="Contacts")
    p.add_argument("--workers", type=int, default=10)
    p.add_argument("--limit", type=int, help="Cap unique companies (pilot).")
    p.add_argument("--checkpoint", default="/tmp/personalize.json")
    p.add_argument("--preview", type=int, help="Generate N companies, print results, write nothing.")
    args = p.parse_args()
    _prevent_sleep()

    svc, sid, header, rows = read_companies(args.contacts_sheet, args.tab)
    safe_rows = [r for r in rows if r["safe"] and r["domain"]]
    # dedup by domain (keep the row with the most scrape content)
    by_dom: Dict[str, dict] = {}
    for r in safe_rows:
        cur = by_dom.get(r["domain"])
        if cur is None or len(r["scrape"]) > len(cur["scrape"]):
            by_dom[r["domain"]] = r
    domains = sorted(by_dom)
    print(f"rows: {len(rows):,} | send-safe: {len(safe_rows):,} | unique companies: {len(domains):,}")

    ckpt = load_ckpt(args.checkpoint)
    pending = [d for d in domains if d not in ckpt]
    npre = args.preview or args.limit
    if npre:
        pending = pending[:npre]
    print(f"already done (resume): {len(ckpt):,} | to generate now: {len(pending):,}")

    client = OpenRouterClient()
    lock = threading.Lock()
    tin = tout = 0
    n = 0
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(generate, client, by_dom[d]["company"], d, by_dom[d]["scrape"]): d for d in pending}
        for fut in as_completed(futs):
            d = futs[fut]
            res = fut.result()
            with lock:
                n += 1
                if res:
                    tin += res.pop("_in", 0); tout += res.pop("_out", 0)
                    ckpt[d] = res
                if not args.preview and n % 50 == 0:
                    save_ckpt(args.checkpoint, ckpt)
                    print(f"  ...{n:,}/{len(pending):,} | in={tin:,} out={tout:,} tok")
    cost = tin / 1e6 * 3.0 + tout / 1e6 * 15.0  # Sonnet ~ $3/M in, $15/M out
    print(f"\nGenerated {n:,} companies. Tokens in={tin:,} out={tout:,} -> ~${cost:.2f}")

    if args.preview:
        print("\n=== PREVIEW (no writes) ===")
        for d in pending:
            r = ckpt.get(d)
            if not r:
                print(f"\n[{d}] (failed)"); continue
            print(f"\n[{by_dom[d]['company']} — {d}]")
            print(f"  growth_idea: {r['custom_growth_idea']}")
            print(f"  competitors: {r['custom_competitors']}")
            print(f"  icp:         {r['custom_icp']}")
        return 0

    save_ckpt(args.checkpoint, ckpt)
    idx = ensure_cols(svc, sid, args.tab, header)
    write_cols(svc, sid, args.tab, idx, rows, ckpt)
    filled = sum(1 for r in rows if r["safe"] and ckpt.get(r["domain"]))
    print(f"Wrote {OUT_COLS} to {filled:,} send-safe rows.")
    try:
        with COST_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "companies": len(ckpt),
                                "in": tin, "out": tout, "cost": round(cost, 2)}) + "\n")
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
