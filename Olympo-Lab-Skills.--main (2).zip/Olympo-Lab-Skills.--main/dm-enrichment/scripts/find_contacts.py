#!/usr/bin/env python3
"""
find_contacts — AI Ark People Search ONLY (no email export) across the
qualified companies, keeping every contact that matches the target decision-
maker titles, minus the people the user already has.

This is the cheap "who are the decision-makers" pull:
  - People Search (POST /people) by company domain + SMART title filter
  - keep ALL matching GTM decision-makers per company (not a top-K pick)
  - NO email export (POST /people/export/single is never called) — emails are
    run later through the user's own waterfall
  - exclude people already in a provided CSV (match on first+last+domain)
  - optionally skip whole companies already present in that CSV (--skip-known-
    companies) — the only way to avoid re-spending People Search credits on
    accounts already worked

Cost: ~0.5 credit per person RETURNED by People Search (billed per person, not
per request). There is NO server-side name-exclusion, so --skip-known-companies
is the real credit lever; person exclusion only cleans the output.

Runs under ~/.olympolabs/venv (AI Ark needs TLS 1.2+).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

_VENV_PY = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV_PY.exists() and Path(sys.executable).resolve() != _VENV_PY.resolve():
    os.execv(str(_VENV_PY), [str(_VENV_PY)] + sys.argv)

import argparse
import csv
import datetime
import json
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

import requests


def _prevent_sleep() -> None:
    """Keep the Mac awake for this process's lifetime (the machine's 1-min idle
    sleep otherwise suspends long AI Ark runs and drops connections). caffeinate
    -w <pid> auto-releases on exit; does not change the user's power settings."""
    try:
        subprocess.Popen(["caffeinate", "-dimsw", str(os.getpid())],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("  [keep-awake] caffeinate assertion held for this run.")
    except (FileNotFoundError, OSError):
        pass


_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE / "lib" / "google-sheets-api"))

CREDS = Path.home() / ".olympolabs" / "aiark.json"
BASE = "https://api.ai-ark.com/api/developer-portal/v1"
COST_LOG = Path.home() / ".olympolabs" / "dm-enrichment-costs.log"
TIMEOUT = 90
REQ_INTERVAL = 0.22  # ~4.5 req/s, under AI Ark's 5/s limit

OUTPUT_HEADERS = [
    "Company", "Website", "ICP Score", "First Name", "Last Name", "Title",
    "Seniority", "Department", "LinkedIn", "AI Ark Company ID", "AI Ark Person ID",
]

# Target decision-maker titles for the PRINT / SIGNAGE -> EVENT-AGENCY pitch.
# These are the people who spec, source, and buy physical event production
# materials (booth graphics, signage, banners, event collateral). Fed to AI
# Ark's SMART title matcher. Groups: A Owner/Exec, B Production & Operations,
# C Procurement/Sourcing, D Creative/Design, E Event leadership.
SEARCH_TITLES = [
    # A — Owner / Executive
    "founder", "co-founder", "owner", "ceo", "chief executive officer",
    "president", "managing director", "managing partner", "partner", "principal",
    # B — Production & Operations
    "vp production", "vice president of production", "director of production",
    "head of production", "production director", "production manager",
    "event production manager", "vp operations", "vice president of operations",
    "director of operations", "head of operations", "operations manager",
    "event operations manager", "chief operating officer", "coo",
    # C — Procurement / Sourcing
    "procurement manager", "director of procurement", "head of procurement",
    "purchasing manager", "director of purchasing", "strategic sourcing",
    "sourcing manager", "vendor manager",
    # D — Creative / Design
    "creative director", "design director", "art director", "head of creative",
    # E — Event leadership
    "vp events", "vice president of events", "director of events",
    "head of events", "event director", "senior event manager", "event manager",
]

# Client-side gate (SMART matching is loose — keep only real print/signage
# economic buyers). KEEP = a relevant-function token must be present. EXCLUDE =
# a wrong-function token kills it even if a KEEP token also matched (this is
# what drops "Director of Sales Operations", "Event Marketing Manager", "Event
# Coordinator", etc.). Rule: keep iff has(KEEP) AND not has(EXCLUDE). EXCLUDE
# wins on ties — that's deliberate (sales/marketing/etc. don't buy print).
KEEP = [
    "founder", "owner", "ceo", "chief executive", "president",
    "managing director", "managing partner", "principal", "partner",
    "production", "operations", "operating", "coo",
    "procurement", "purchasing", "sourcing", "vendor", "buyer",
    "creative", "design", "art director",
    "event", "events",
]
EXCLUDE = [
    "assistant", "intern", "coordinator", "trainee", "apprentice",
    "sales", "marketing", "revenue", "business development", "demand",
    "account executive", "account manager", "customer success", "client success",
    "recruit", "talent", "human resources", " hr ", "people ops",
    "finance", "accounting", "controller", "payroll", "legal", "counsel",
    "engineer", "developer", "software", "data ", "analyst", "scientist",
    "architect", "security", " it ", "information technology", "helpdesk",
    "product manager", "product owner", "support", "advisor", "investor",
    "board member", "student", "enablement", "representative", "chief of staff",
    "partnership", "channel",
]

# Ranking tiers — pick the most senior / highest-leverage print buyers first
# when capping. TIER1 = owner/exec + director-level production/ops/procurement/
# creative (prime vendor deciders); TIER2 = manager-level + event leadership.
TIER1 = ["founder", "co-founder", "cofounder", "co founder", "owner", "co-owner",
         "ceo", "chief executive", "president", "managing director",
         "managing partner", "principal", "partner", "coo", "chief operating",
         "director of production", "head of production", "production director",
         "vp production", "vice president of production", "director of operations",
         "head of operations", "vp operations", "director of procurement",
         "head of procurement", "creative director", "design director"]
TIER2 = ["production manager", "operations manager", "procurement manager",
         "purchasing manager", "sourcing manager", "art director",
         "head of creative", "director of events", "head of events",
         "event director", "vp events", "vice president of events"]


class ArkError(Exception):
    pass


def load_key() -> str:
    d = json.loads(CREDS.read_text())
    return d.get("api_key") or d.get("token")


def _headers(key: str) -> Dict[str, str]:
    return {"X-TOKEN": key, "Content-Type": "application/json"}


def get_credits(key: str) -> Optional[float]:
    try:
        r = requests.get(f"{BASE}/payments/credits", headers=_headers(key), timeout=TIMEOUT)
        if r.status_code == 200:
            return float(r.json().get("total"))
    except Exception:
        pass
    return None


class _Rate:
    def __init__(self, interval: float):
        self._i = interval
        self._lock = threading.Lock()
        self._next = 0.0

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            if self._next > now:
                time.sleep(self._next - now)
                now = time.monotonic()
            self._next = now + self._i


_RATE = _Rate(REQ_INTERVAL)


def _post(key: str, path: str, body: dict) -> requests.Response:
    for attempt in range(4):
        _RATE.wait()
        r = requests.post(f"{BASE}{path}", headers=_headers(key), json=body, timeout=TIMEOUT)
        if r.status_code == 429:
            time.sleep(1.5 * (attempt + 1))
            continue
        return r
    return r


def people_search(key: str, domain: str, size: int) -> List[dict]:
    body = {
        "account": {"domain": {"any": {"include": [domain]}}},
        "contact": {"experience": {"current": {"title": {"any": {"include": {
            "mode": "SMART", "content": SEARCH_TITLES}}}}}},
        "page": 0, "size": size,
    }
    r = _post(key, "/people", body)
    if r.status_code == 404:
        return []
    if r.status_code != 200:
        raise ArkError(f"people search HTTP {r.status_code}: {r.text[:160]}")
    return r.json().get("content") or []


def _title_of(p: dict) -> str:
    prof = p.get("profile", {}) or {}
    return (prof.get("title") or prof.get("headline") or "")


def keep_title(title: str) -> bool:
    t = f" {title.lower()} "
    if any(k in t for k in EXCLUDE):
        return False
    return any(k in t for k in KEEP)


# RULE: never send to mail behind Barracuda or Mimecast — they shred cold
# outbound and burn sending reputation. AI Ark surfaces the company's email
# gateway natively in People Search via company.technologies (a list of
# {category, name}); the security gateway shows up as a tech named
# barracuda/mimecast. We detect it at the contact-pull stage so these companies
# are dropped BEFORE we ever spend an email-finding credit on them.
MAIL_BLOCKLIST = ("barracuda", "mimecast")


def mail_blocked(person: dict) -> bool:
    techs = (person.get("company", {}) or {}).get("technologies") or []
    for t in techs:
        name = (t.get("name") or "").lower()
        if any(b in name for b in MAIL_BLOCKLIST):
            return True
    return False


def rank_title(title: str) -> int:
    """0 = founder/C-level, 1 = VP/Head GTM, 2 = everything else kept."""
    t = title.lower()
    if any(k in t for k in TIER1):
        return 0
    if any(k in t for k in TIER2):
        return 1
    return 2


def enrich_company(key: str, company: dict, size: int, max_per: Optional[int],
                   exclude_people: set) -> List[dict]:
    domain = company["website"]
    if not domain:
        return []
    try:
        people = people_search(key, domain, size)
    except ArkError:
        return []
    # Barracuda/Mimecast is a company-wide email gateway, so if ANY returned
    # person at this company shows it, the whole company is unsendable — drop it.
    if any(mail_blocked(p) for p in people):
        return []
    rows = []
    for p in people:
        prof = p.get("profile", {}) or {}
        dept = p.get("department", {}) or {}
        title = _title_of(p)
        if not keep_title(title):
            continue
        fn = (prof.get("first_name") or "").strip()
        ln = (prof.get("last_name") or "").strip()
        if (fn.lower(), ln.lower(), domain) in exclude_people:
            continue  # already have this person
        link = (p.get("link", {}) or {}).get("linkedin") or ""
        rows.append({
            "Company": company["company"],
            "Website": domain,
            "ICP Score": company["score"],
            "First Name": fn,
            "Last Name": ln,
            "Title": title,
            "Seniority": dept.get("seniority") or "",
            "Department": dept.get("department") or dept.get("function") or "",
            "LinkedIn": link,
            "AI Ark Company ID": company["aiark_id"],
            "AI Ark Person ID": p.get("id") or "",
            "_rank": rank_title(title),
        })
    rows.sort(key=lambda r: r["_rank"])
    if max_per:
        rows = rows[:max_per]
    for r in rows:
        r.pop("_rank", None)
    return rows


# ---- source + exclusion --------------------------------------------------

def _norm_domain(d: str) -> str:
    d = (d or "").strip().lower().replace("https://", "").replace("http://", "").replace("www.", "")
    return d.split("/")[0].split("?")[0]


def read_qualified(sheet_url: str, min_score: int) -> List[dict]:
    from client import SheetsClient, extract_sheet_id
    c = SheetsClient()
    sid = extract_sheet_id(sheet_url)
    left = c.read_range(sid, "Companies!A2:B")    # Company, Website
    right = c.read_range(sid, "Companies!I2:K")   # AI Ark ID, ICP Score, ICP Verdict
    out = []
    for i in range(min(len(left), len(right))):
        lo = (left[i] + ["", ""])[:2]
        ri = (right[i] + ["", "", ""])[:3]
        company, website = lo[0], _norm_domain(lo[1])
        aiark_id, score, verdict = ri[0], ri[1], ri[2]
        if str(verdict).strip().lower() != "qualified":
            continue
        try:
            sc = int(score)
        except (ValueError, TypeError):
            continue
        if sc < min_score or not website:
            continue
        out.append({"company": company, "website": website, "aiark_id": aiark_id, "score": sc})
    return out


def load_exclusion(csv_path: str) -> "tuple[set, set]":
    """Return (people_keys, known_domains). people_keys = {(first,last,domain)}."""
    people, domains = set(), set()
    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            d = _norm_domain(row.get("company_website") or row.get("Website") or "")
            if d:
                domains.add(d)
            fn = (row.get("first_name") or "").strip().lower()
            ln = (row.get("last_name") or "").strip().lower()
            if fn and ln and d:
                people.add((fn, ln, d))
    return people, domains


# ---- writers -------------------------------------------------------------

def write_contacts_sheet(title: str, rows: List[dict]) -> str:
    from sheets_auth import get_sheets_service
    service = get_sheets_service()
    created = service.spreadsheets().create(
        body={"properties": {"title": title},
              "sheets": [{"properties": {"title": "Contacts",
                          "gridProperties": {"rowCount": len(rows) + 10, "columnCount": max(26, len(OUTPUT_HEADERS))}}}]},
        fields="spreadsheetId,spreadsheetUrl",
    ).execute()
    sid = created["spreadsheetId"]
    values = [OUTPUT_HEADERS] + [[r[h] for h in OUTPUT_HEADERS] for r in rows]
    for i in range(0, len(values), 2000):
        chunk = values[i:i + 2000]
        service.spreadsheets().values().update(
            spreadsheetId=sid, range=f"Contacts!A{i + 1}", valueInputOption="RAW",
            body={"values": chunk}).execute()
    return created["spreadsheetUrl"]


def write_csv(path: str, rows: List[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(OUTPUT_HEADERS)
        for r in rows:
            w.writerow([r[h] for h in OUTPUT_HEADERS])


def main() -> int:
    p = argparse.ArgumentParser(description="AI Ark People Search (no email) for qualified companies, minus people already owned.")
    p.add_argument("--source-sheet", required=True)
    p.add_argument("--exclude-csv", help="CSV of people already owned (cols: first_name,last_name,company_website).")
    p.add_argument("--skip-known-companies", action="store_true",
                   help="Skip companies whose domain is already in --exclude-csv (the real credit saver).")
    p.add_argument("--only-known-companies", action="store_true",
                   help="Inverse: search ONLY companies whose domain IS in --exclude-csv (gap-fill net-new PEOPLE at already-touched accounts; person-level dedup still drops the people you already own).")
    p.add_argument("--min-score", type=int, default=7)
    p.add_argument("--search-size", type=int, default=8, help="People Search page size per company. THIS is the credit lever (~0.5 credit per person returned).")
    p.add_argument("--max-per-company", type=int, default=5, help="Keep at most N ranked contacts/company in the OUTPUT (founder/C-level first).")
    # Per-campaign title targeting (comma-separated). When unset, the built-in
    # defaults (events/production buyer) are used — WRONG for most campaigns, so
    # set these per campaign just like enrich_waterfall.py does.
    p.add_argument("--search-titles", help="People Search recall net (AI Ark SMART). Overrides SEARCH_TITLES.")
    p.add_argument("--keep-titles", help="Client-side gate: a contact is kept only if its title contains one of these. Overrides KEEP.")
    p.add_argument("--exclude-titles", help="Client-side gate: a contact is dropped if its title contains one of these (wins over keep). Overrides EXCLUDE.")
    p.add_argument("--tier1-titles", help="Top-rank keywords (kept first when capping). Overrides TIER1.")
    p.add_argument("--tier2-titles", help="Second-rank keywords. Overrides TIER2.")
    p.add_argument("--limit", type=int, help="Cap number of companies (pilot).")
    p.add_argument("--max-credits", type=float, help="Stop once this many credits have been spent (budget gate; checked between batches). Companies are processed highest ICP score first.")
    p.add_argument("--checkpoint-csv", help="Write collected contacts to this CSV after every batch (crash insurance).")
    p.add_argument("--workers", type=int, default=5)
    p.add_argument("--out-title", default="OlympoLabs — B2B SaaS Decision-Makers")
    p.add_argument("--csv-path", help="Write contacts to a local CSV instead of a sheet.")
    p.add_argument("--dry-run", action="store_true", help="Report scope + estimate; no People Search calls.")
    args = p.parse_args()

    # Per-campaign title overrides — reassign the module globals the helper
    # functions (people_search / keep_title / rank_title) read at call time.
    def _split(s):
        return [t.strip().lower() for t in s.split(",") if t.strip()]
    global SEARCH_TITLES, KEEP, EXCLUDE, TIER1, TIER2
    if args.search_titles:
        SEARCH_TITLES = _split(args.search_titles)
    if args.keep_titles:
        KEEP = _split(args.keep_titles)
    if args.exclude_titles is not None:
        EXCLUDE = _split(args.exclude_titles)
    if args.tier1_titles:
        TIER1 = _split(args.tier1_titles)
    if args.tier2_titles:
        TIER2 = _split(args.tier2_titles)

    _prevent_sleep()

    key = load_key()
    companies = read_qualified(args.source_sheet, args.min_score)
    exclude_people, known_domains = (set(), set())
    if args.exclude_csv:
        exclude_people, known_domains = load_exclusion(args.exclude_csv)
        print(f"Exclusion: {len(exclude_people):,} known people across {len(known_domains):,} known domains.")

    before_skip = len(companies)
    if args.only_known_companies and known_domains:
        companies = [c for c in companies if c["website"] in known_domains]
        print(f"Only-known mode: searching {len(companies):,} already-touched companies (person-level dedup still applies).")
    elif args.skip_known_companies and known_domains:
        companies = [c for c in companies if c["website"] not in known_domains]
        print(f"Skipping {before_skip - len(companies):,} already-worked companies; {len(companies):,} net-new remain.")

    companies = sorted(companies, key=lambda c: -c["score"])
    if args.limit:
        companies = companies[:args.limit]
    print(f"Companies to search: {len(companies):,}")

    if args.dry_run:
        print("DRY RUN — no API calls. Re-run without --dry-run to pull.")
        return 0
    if not companies:
        print("Nothing to search.")
        return 1

    bal0 = get_credits(key)
    if bal0 is not None:
        print(f"AI Ark credits: {bal0:,.1f}")

    rows: List[dict] = []
    done = 0
    stopped_on_budget = False
    batch = max(args.workers * 6, 30)
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        for start in range(0, len(companies), batch):
            chunk = companies[start:start + batch]
            futs = {ex.submit(enrich_company, key, c, args.search_size, args.max_per_company, exclude_people): c for c in chunk}
            for fut in as_completed(futs):
                done += 1
                try:
                    rows.extend(fut.result())
                except Exception as e:
                    print(f"  ! {futs[fut]['company']}: {e}")
            # crash insurance: persist what we have after every batch
            if args.checkpoint_csv:
                try:
                    write_csv(args.checkpoint_csv, rows)
                except OSError:
                    pass
            # budget gate: poll the (free) credits endpoint between batches
            spent_note = ""
            if args.max_credits and bal0 is not None:
                now = get_credits(key)
                if now is not None:
                    spent = bal0 - now
                    spent_note = f" | spent ~{spent:,.0f} cr"
                    if spent >= args.max_credits:
                        print(f"  ...searched {done}/{len(companies)} companies, {len(rows):,} contacts kept{spent_note}")
                        print(f"  >> credit budget reached (~{spent:,.0f} >= {args.max_credits:,.0f}); stopping cleanly.")
                        stopped_on_budget = True
                        break
            print(f"  ...searched {done}/{len(companies)} companies, {len(rows):,} contacts kept{spent_note}")

    if not rows:
        print("No contacts found.")
        return 1

    comps_with = len({r["Website"] for r in rows})
    print(f"\n{len(rows):,} contacts across {comps_with:,} companies "
          f"(of {done:,} searched). Avg {len(rows)/max(done,1):.1f} contacts/company.")

    if args.csv_path:
        write_csv(args.csv_path, rows)
        target = args.csv_path
        print(f"Wrote -> {args.csv_path}")
    else:
        target = write_contacts_sheet(args.out_title, rows)
        print(f"Created Contacts sheet:\n  {target}")

    bal1 = get_credits(key)
    used = (bal0 - bal1) if (bal0 is not None and bal1 is not None) else None
    if used is not None:
        print(f"Credits used: {used:,.1f}  (balance {bal1:,.1f})  "
              f"~{used/max(done,1):.2f}/company, ~{used/max(len(rows),1):.2f}/contact")
    try:
        with COST_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps({
                "ts": datetime.datetime.now().isoformat(timespec="seconds"),
                "mode": "people-search-no-email",
                "companies_searched": done, "contacts": len(rows),
                "credits_used": used, "target": target,
            }) + "\n")
    except OSError:
        pass
    print("\nNext: run your email waterfall on these contacts (no emails were pulled here).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
