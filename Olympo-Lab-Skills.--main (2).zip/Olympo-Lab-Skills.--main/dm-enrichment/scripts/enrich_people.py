#!/usr/bin/env python3
"""
dm-enrichment — find decision-makers for the QUALIFIED companies and attach
verified emails, via AI Ark People Search + Export-with-email.

Pipeline position (the phase after scoring):

    list-builder -> company-scoring -> (filter Qualified) -> ★ dm-enrichment ★ -> verify -> normalize -> personalize -> PlusVibe

For each qualified company it:
  1. People Search (POST /people) by domain -> candidate people w/ title,
     seniority, department, LinkedIn  (NO email in this response)
  2. Ranks them and picks the top K decision-makers (owner/founder cluster
     first, then marketing/growth/paid-media leadership)
  3. Export Single (POST /people/export/single) per pick -> BounceBan-verified
     email (status VALID / CATCH_ALL / INVALID ...)
  4. Writes one row PER CONTACT to a new "Contacts" sheet, carrying the
     company's ICP Score so the pool stays prioritisable.

Runs under ~/.olympolabs/venv (modern TLS — AI Ark needs TLS 1.2+).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

_VENV_PY = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV_PY.exists() and Path(sys.executable).resolve() != _VENV_PY.resolve():
    os.execv(str(_VENV_PY), [str(_VENV_PY)] + sys.argv)

import argparse
import csv
import datetime
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

import requests

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE / "lib" / "google-sheets-api"))

CREDS = Path.home() / ".olympolabs" / "aiark.json"
BASE = "https://api.ai-ark.com/api/developer-portal/v1"
COST_LOG = Path.home() / ".olympolabs" / "dm-enrichment-costs.log"
TIMEOUT = 90

OUTPUT_HEADERS = [
    "Company", "Website", "ICP Score", "First Name", "Last Name", "Title",
    "Seniority", "Email", "Email Status", "Domain Type", "LinkedIn",
    "AI Ark Company ID", "AI Ark Person ID",
]

# Titles we ask AI Ark to bias the People Search toward.
SEARCH_TITLES = [
    "founder", "owner", "ceo", "chief executive officer", "president",
    "managing director", "managing partner", "partner", "principal",
    "chief marketing officer", "cmo", "vp marketing", "marketing director",
    "director of marketing", "head of marketing", "head of growth",
    "paid media director", "director of paid media", "ppc director",
    "performance marketing", "client services director",
]

# Client-side ranking. Tier 1 = the buyer of our offer (agency owner/leadership).
TIER1 = ["founder", "co-founder", "cofounder", "co founder", "owner", "co-owner",
         "chief executive", "ceo", "president", "principal", "managing director",
         "managing partner", "proprietor"]
TIER2 = ["chief marketing", "cmo", "marketing director", "director of marketing",
         "head of marketing", "vp marketing", "vice president of marketing",
         "head of growth", "growth", "paid media", "ppc", "performance marketing",
         "demand generation", "media director", "client services",
         "business development", "chief strategy", "partner", "digital marketing director",
         "account director"]
EXCLUDE = ["assistant", "administrative", "intern", "coordinator", "receptionist",
           "bookkeeper", "accountant", "recruiter", "talent acquisition",
           "human resources", " hr ", "developer", "engineer", "designer",
           "photographer", "videographer", "copywriter", "qa ", "support",
           "specialist", "analyst"]


class ArkError(Exception):
    pass


def load_key() -> str:
    d = json.loads(CREDS.read_text())
    return d.get("api_key") or d.get("token")


def _headers(key: str) -> Dict[str, str]:
    return {"X-TOKEN": key, "Content-Type": "application/json"}


def get_credits(key: str) -> Optional[float]:
    try:
        r = requests.get(f"{BASE}/payments/credits", headers=_headers(key), timeout=TIMEOUT)
        if r.status_code == 200:
            return float(r.json().get("total"))
    except Exception:
        pass
    return None


def _post(key: str, path: str, body: dict) -> requests.Response:
    """POST with a small 429 backoff."""
    for attempt in range(4):
        r = requests.post(f"{BASE}{path}", headers=_headers(key), json=body, timeout=TIMEOUT)
        if r.status_code == 429:
            time.sleep(1.5 * (attempt + 1))
            continue
        return r
    return r


# ---- AI Ark calls --------------------------------------------------------

def people_search(key: str, domain: str, size: int) -> List[dict]:
    body = {
        "account": {"domain": {"any": {"include": [domain]}}},
        "contact": {"experience": {"current": {"title": {"any": {"include": {
            "mode": "SMART", "content": SEARCH_TITLES}}}}}},
        "page": 0, "size": size,
    }
    r = _post(key, "/people", body)
    if r.status_code == 404:
        return []
    if r.status_code != 200:
        raise ArkError(f"people search HTTP {r.status_code}: {r.text[:160]}")
    return r.json().get("content") or []


def export_email(key: str, linkedin_url: str) -> Optional[dict]:
    """Export single person by LinkedIn URL -> verified email dict, or None."""
    r = _post(key, "/people/export/single", {"url": linkedin_url})
    if r.status_code != 200:
        return None
    d = r.json()
    email = d.get("email") or {}
    out = (email.get("output") or [{}])[0] if isinstance(email, dict) else {}
    if not out.get("address"):
        return None
    return {
        "address": out.get("address"),
        "status": out.get("status"),          # VALID / INVALID / UNKNOWN ...
        "domain_type": out.get("domainType"),  # CATCH_ALL / ...
        "found": out.get("found"),
        "person_id": d.get("id"),
    }


# ---- ranking -------------------------------------------------------------

def _has(title: str, kws: List[str]) -> bool:
    t = f" {title.lower()} "
    return any(k in t for k in kws)


def rank_person(p: dict) -> int:
    prof = p.get("profile", {}) or {}
    dept = p.get("department", {}) or {}
    title = (prof.get("title") or prof.get("headline") or "")
    sen = (dept.get("seniority") or "").lower()
    link = (p.get("link", {}) or {}).get("linkedin")
    if not link:
        return -1  # can't export without a LinkedIn URL
    score = 0
    if _has(title, TIER1) or sen == "founder":
        score = 100
    elif _has(title, TIER2) and sen in ("c_suite", "vp", "director", "senior", "manager"):
        score = 60
    elif sen == "c_suite":
        score = 50
    else:
        score = 8
    if _has(title, EXCLUDE) and not _has(title, TIER1):
        score -= 70
    return score


def pick_contacts(people: List[dict], k: int) -> List[dict]:
    ranked = sorted(
        [(rank_person(p), p) for p in people], key=lambda x: -x[0])
    return [p for s, p in ranked if s > 0][:k]


# ---- per-company enrichment ----------------------------------------------

def enrich_company(key: str, company: dict, k: int, size: int) -> List[dict]:
    domain = company["website"]
    if not domain:
        return []
    try:
        people = people_search(key, domain, size)
    except ArkError:
        return []
    picks = pick_contacts(people, k)
    rows = []
    for p in picks:
        prof = p.get("profile", {}) or {}
        dept = p.get("department", {}) or {}
        link = (p.get("link", {}) or {}).get("linkedin") or ""
        em = export_email(key, link)
        if not em:
            continue  # no verified email -> skip this contact
        rows.append({
            "Company": company["company"],
            "Website": domain,
            "ICP Score": company["score"],
            "First Name": prof.get("first_name") or "",
            "Last Name": prof.get("last_name") or "",
            "Title": prof.get("title") or prof.get("headline") or "",
            "Seniority": dept.get("seniority") or "",
            "Email": em["address"],
            "Email Status": em["status"] or "",
            "Domain Type": em["domain_type"] or "",
            "LinkedIn": link,
            "AI Ark Company ID": company["aiark_id"],
            "AI Ark Person ID": em["person_id"] or p.get("id") or "",
        })
    return rows


# ---- source + sink -------------------------------------------------------

def read_qualified(sheet_url: str, min_score: int) -> List[dict]:
    from client import SheetsClient, extract_sheet_id
    c = SheetsClient()
    sid = extract_sheet_id(sheet_url)
    left = c.read_range(sid, "Companies!A2:B")       # Company, Website
    right = c.read_range(sid, "Companies!I2:K")       # AI Ark ID, ICP Score, ICP Verdict
    out = []
    for i in range(min(len(left), len(right))):
        lo = (left[i] + ["", ""])[:2]
        ri = (right[i] + ["", "", ""])[:3]
        company, website = lo[0], lo[1]
        aiark_id, score, verdict = ri[0], ri[1], ri[2]
        if str(verdict).strip().lower() != "qualified":
            continue
        try:
            sc = int(score)
        except (ValueError, TypeError):
            continue
        if sc < min_score:
            continue
        out.append({"company": company, "website": website, "aiark_id": aiark_id, "score": sc})
    return out


def stratify(companies: List[dict], per_band: Optional[int], limit: Optional[int]) -> List[dict]:
    if per_band:
        bands: Dict[int, list] = {}
        for c in companies:
            bands.setdefault(c["score"], []).append(c)
        out = []
        for band in sorted(bands, reverse=True):
            rows = bands[band]
            step = max(1, len(rows) // per_band)
            out.extend(rows[::step][:per_band])
        return out
    if limit:
        return companies[:limit]
    return companies


def write_contacts_sheet(title: str, rows: List[dict]) -> str:
    from sheets_auth import get_sheets_service
    service = get_sheets_service()
    created = service.spreadsheets().create(
        body={"properties": {"title": title},
              "sheets": [{"properties": {"title": "Contacts",
                          "gridProperties": {"rowCount": len(rows) + 10, "columnCount": max(26, len(OUTPUT_HEADERS))}}}]},
        fields="spreadsheetId,spreadsheetUrl",
    ).execute()
    sid = created["spreadsheetId"]
    values = [OUTPUT_HEADERS] + [[r[h] for h in OUTPUT_HEADERS] for r in rows]
    service.spreadsheets().values().update(
        spreadsheetId=sid, range="Contacts!A1", valueInputOption="RAW", body={"values": values}).execute()
    return created["spreadsheetUrl"]


def write_csv(path: str, rows: List[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(OUTPUT_HEADERS)
        for r in rows:
            w.writerow([r[h] for h in OUTPUT_HEADERS])


def main() -> int:
    p = argparse.ArgumentParser(description="Enrich qualified companies with decision-maker contacts (AI Ark).")
    p.add_argument("--source-sheet", required=True, help="The scored sheet (Qualified rows are read from it).")
    p.add_argument("--min-score", type=int, default=7, help="Only enrich companies with ICP Score >= this (default 7).")
    p.add_argument("--per-band", type=int, help="Stratified review sample: N companies per score band.")
    p.add_argument("--limit", type=int, help="Cap total companies enriched.")
    p.add_argument("--contacts-per-company", type=int, default=2)
    p.add_argument("--max-contacts", type=int, help="Stop once this many contacts are collected (takes highest-scored companies first). Good for a capped test run.")
    p.add_argument("--search-size", type=int, default=12, help="People Search page size per company.")
    p.add_argument("--workers", type=int, default=5)
    p.add_argument("--out-title", help="Title for the new Contacts sheet.")
    p.add_argument("--csv-path", help="Write contacts to a local CSV instead of a sheet.")
    p.add_argument("--dry-run", action="store_true", help="Show which companies would be enriched; no API calls.")
    args = p.parse_args()

    key = load_key()
    companies = read_qualified(args.source_sheet, args.min_score)
    companies = stratify(companies, args.per_band, args.limit)
    print(f"Qualified companies to enrich (score>={args.min_score}): {len(companies)}")
    if args.dry_run:
        for c in companies[:40]:
            print(f"  [{c['score']}] {c['company'][:32]:32s} {c['website']}")
        print(f"... ({len(companies)} total)")
        return 0
    if not companies:
        print("Nothing to enrich.")
        return 1

    bal0 = get_credits(key)
    if bal0 is not None:
        print(f"AI Ark credits: {bal0:,.1f}")

    # When capping total contacts, enrich the highest-scored companies first
    # and stop early (batched) so we don't spend on the whole qualified set.
    max_contacts = args.max_contacts
    if max_contacts:
        companies = sorted(companies, key=lambda c: -c["score"])

    rows: List[dict] = []
    done = 0
    batch_size = max(args.workers * 6, 30)
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        for start in range(0, len(companies), batch_size):
            if max_contacts and len(rows) >= max_contacts:
                break
            batch = companies[start:start + batch_size]
            futs = {ex.submit(enrich_company, key, c, args.contacts_per_company, args.search_size): c for c in batch}
            for fut in as_completed(futs):
                done += 1
                try:
                    rows.extend(fut.result())
                except Exception as e:
                    print(f"  ! {futs[fut]['company']}: {e}")
            print(f"  ...enriched {done}/{len(companies)} companies, {len(rows)} contacts so far")

    if max_contacts:
        rows = rows[:max_contacts]

    if not rows:
        print("No contacts found.")
        return 1

    # Stats
    valid = sum(1 for r in rows if str(r["Email Status"]).upper() == "VALID")
    catch = sum(1 for r in rows if str(r["Domain Type"]).upper() == "CATCH_ALL")
    comps_with = len({r["Website"] for r in rows})
    print(f"\n{len(rows)} contacts across {comps_with} companies (of {done} processed). "
          f"VALID emails: {valid} | catch-all: {catch}")

    if args.csv_path:
        write_csv(args.csv_path, rows)
        target = args.csv_path
        print(f"Wrote -> {args.csv_path}")
    else:
        title = args.out_title or "OlympoLabs — Google Ads Agency Contacts"
        target = write_contacts_sheet(title, rows)
        print(f"Created Contacts sheet:\n  {target}")

    bal1 = get_credits(key)
    used = (bal0 - bal1) if (bal0 is not None and bal1 is not None) else None
    if used is not None:
        print(f"Credits used: {used:,.1f}  (balance {bal1:,.1f})")
    try:
        with COST_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps({
                "ts": datetime.datetime.now().isoformat(timespec="seconds"),
                "companies": len(companies), "contacts": len(rows),
                "valid": valid, "catch_all": catch, "credits_used": used, "target": target,
            }) + "\n")
    except OSError:
        pass
    print("\nNext: verify (MillionVerifier on non-AI-Ark / catch-all) -> name-normalizer -> personalization -> PlusVibe.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
