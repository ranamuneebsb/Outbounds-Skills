#!/usr/bin/env python3
"""
dm-enrichment v2 — decision-maker discovery + a STAGED, PARALLEL email waterfall.

People come from AI Ark People Search. Emails are found by a first-hit-wins
waterfall in the user's exact order, each stage processing only the running
misses, each stage internally parallel:

    1. Blitz       (LinkedIn URL -> email)      50 rps, flat-rate -> try first (cheapest, fastest)
    2. AI Ark      (LinkedIn URL -> email)      5 rps, BounceBan-verified
    3. KITT        (name + domain -> email)     realtime; needs ~/.olympolabs/kitt.json
    4. Icypeas     (name + domain -> email)     BULK async (up to 5000/job) for the misses
    5. LeadMagic   (name + domain -> email)     5 rps

Then MillionVerifier verifies EVERY email regardless of source — including AI Ark
(its "verified" status is unreliable: ~23% fail MV). Send Safe = "Yes" iff the MV
result is "ok". Pass --no-verify-aiark to skip AI Ark emails (old, unsafe
behavior). Needs ~/.olympolabs/millionverifier.json.

Providers whose key file is missing are skipped (graceful), so the pipeline runs
on whatever is configured today and gets stronger as keys are added.

Ranking fixes vs v1: rank decision-makers on TITLE keywords (AI Ark's seniority
field is unreliable), hard-exclude non-buyers (account mgr / coordinator /
finance / creative / IT / intern), junk-record guard (skip platform domains),
and never pad a weak 2nd contact.

Runs under ~/.olympolabs/venv (modern TLS).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

_VENV_PY = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV_PY.exists() and Path(sys.executable).resolve() != _VENV_PY.resolve():
    os.execv(str(_VENV_PY), [str(_VENV_PY)] + sys.argv)

import argparse
import csv
import datetime
import json
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional, Tuple

import requests


def _prevent_sleep() -> None:
    """Keep the Mac awake for THIS process's lifetime. The machine's idle-sleep
    timer (often 1 min) otherwise suspends long network jobs and drops their
    connections — the cause of 'processes dying suddenly'. caffeinate -w <pid>
    holds a no-display/no-idle/no-disk/no-system-sleep assertion until we exit,
    then releases it automatically (does NOT change the user's power settings).
    No-op off macOS or if caffeinate is missing."""
    try:
        subprocess.Popen(["caffeinate", "-dimsw", str(os.getpid())],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("  [keep-awake] caffeinate assertion held for this run.")
    except (FileNotFoundError, OSError):
        pass

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE / "lib" / "google-sheets-api"))

CREDS = Path.home() / ".olympolabs"
COST_LOG = CREDS / "dm-enrichment-costs.log"
AIARK = "https://api.ai-ark.com/api/developer-portal/v1"

OUTPUT_HEADERS = [
    "Company", "Website", "ICP Score", "First Name", "Last Name", "Title",
    "Email", "Email Source", "Verification", "Send Safe", "LinkedIn", "AI Ark Company ID",
]


class _Rate:
    """Thread-safe rate limiter: at most one token per `interval` seconds across
    all workers. Lets us run many workers (to hide per-call latency) while keeping
    total throughput under a provider's req/s cap."""
    def __init__(self, interval: float):
        self._i = interval
        self._lock = __import__("threading").Lock()
        self._next = 0.0

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            if self._next > now:
                time.sleep(self._next - now)
                now = time.monotonic()
            self._next = now + self._i


# AI Ark export is fast per call (~0.8s, mostly 404 for unresolvable people) and
# does NOT 429 readily — so a tight rate cap just throttles the churn. Run it hot
# (429 backoff in find_aiark is the safety net) to finish the stage quickly.
_AIARK_RATE = _Rate(0.07)  # ~14 req/s
AIARK_WORKERS = 24


def load_key(filename: str) -> Optional[str]:
    p = CREDS / filename
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text()).get("api_key") or json.loads(p.read_text()).get("token")
    except (json.JSONDecodeError, OSError):
        return None


# ---------------------------------------------------------------- people search

SEARCH_TITLES = ["founder", "owner", "ceo", "chief executive officer", "president",
                 "managing director", "managing partner", "partner", "principal",
                 "chief marketing officer", "cmo", "vp marketing", "marketing director",
                 "head of growth", "paid media director", "director of paid media"]
TIER1 = ["founder", "co-founder", "cofounder", "co founder", "owner", "co-owner", "chief executive",
         "ceo", "president", "principal", "managing director", "managing partner", "proprietor"]
TIER2 = ["chief marketing", "cmo", "marketing director", "director of marketing", "head of marketing",
         "vp marketing", "vice president of marketing", "head of growth", "paid media", "ppc",
         "performance marketing", "demand generation", "media director", "digital marketing director"]
EXCLUDE = ["account manager", "account executive", "coordinator", "assistant", "administrative",
           "intern", "fellow", "receptionist", "bookkeeper", "accountant", "finance", "controller",
           "recruiter", "talent", "human resources", " hr ", "developer", "engineer", "designer",
           "creative director", "art director", "photographer", "videographer", "copywriter",
           "specialist", "analyst", "information technology", " it ", "support", "qa "]

PLATFORM_DOMAINS = {"google.com", "docs.google.com", "facebook.com", "linkedin.com", "youtube.com",
                    "instagram.com", "twitter.com", "x.com", "wix.com", "wordpress.com"}


def _norm_domain(w: str) -> str:
    # Delegate to the single canonical normalizer (olympo_core) so the waterfall's
    # read-side domain can never drift from the write-side / other stages.
    try:
        import os as _os, sys as _sys
        _sys.path.insert(0, _os.path.join(_os.path.dirname(__file__), "..", "..", "_pipeline"))
        from olympo_core import norm_domain as _nd
        return _nd(w)
    except Exception:
        w = (w or "").strip().lower().replace("https://", "").replace("http://", "").replace("www.", "")
        return w.split("/")[0].split("?")[0].strip()


def _has(title: str, kws: List[str]) -> bool:
    t = f" {title.lower()} "
    return any(k in t for k in kws)


def rank_person(p: dict) -> int:
    """Rank on TITLE (AI Ark seniority is unreliable). Higher = better DM."""
    prof = p.get("profile", {}) or {}
    title = prof.get("title") or prof.get("headline") or ""
    link = (p.get("link", {}) or {}).get("linkedin")
    if not link:
        return -1
    if _has(title, EXCLUDE) and not _has(title, TIER1):
        return -1  # hard exclude non-buyers
    if _has(title, TIER1):
        return 100
    if _has(title, TIER2):
        return 60
    return -1  # not a clear decision-maker -> drop (don't pad)


def people_search(key: str, domains, size: int = 100) -> List[dict]:
    """People Search by ONE or MANY company domains in a single call (batched
    discovery). 429-aware."""
    if isinstance(domains, str):
        domains = [domains]
    body = {"account": {"domain": {"any": {"include": domains}}},
            "contact": {"experience": {"current": {"title": {"any": {"include": {
                "mode": "SMART", "content": SEARCH_TITLES}}}}}},
            "page": 0, "size": size}
    for attempt in range(4):
        try:
            r = requests.post(f"{AIARK}/people", headers={"X-TOKEN": key, "Content-Type": "application/json"},
                              json=body, timeout=90)
            if r.status_code == 429:
                time.sleep(1.0 * (attempt + 1))
                continue
            if r.status_code != 200:
                return []
            return r.json().get("content") or []
        except requests.RequestException:
            return []
    return []


def _person_row(c: dict, p: dict) -> Optional[dict]:
    prof = p.get("profile", {}) or {}
    fn, ln = prof.get("first_name") or "", prof.get("last_name") or ""
    full = prof.get("full_name") or f"{fn} {ln}".strip()
    if full.strip().lower() == str(c["company"]).strip().lower():
        return None  # name == company -> junk
    return {"company": c["company"], "domain": _norm_domain(c["website"]), "score": c["score"],
            "aiark_id": c["aiark_id"], "first": fn, "last": ln, "full": full,
            "title": prof.get("title") or prof.get("headline") or "",
            "linkedin": (p.get("link", {}) or {}).get("linkedin") or ""}


def discover_people(aiark_key: str, companies: List[dict], per_company: int,
                    workers: int = 5, batch_domains: int = 8) -> List[dict]:
    """BATCHED discovery: many company domains per People Search call (≈8x fewer
    calls), then group returned people back to their company, rank by TITLE, and
    pick the top K decision-makers each. Junk-record guard drops platform domains."""
    by_domain: Dict[str, dict] = {}
    for c in companies:
        d = _norm_domain(c["website"])
        if d and d not in PLATFORM_DOMAINS:
            by_domain.setdefault(d, c)
    domains = list(by_domain.keys())
    batches = [domains[i:i + batch_domains] for i in range(0, len(domains), batch_domains)]
    out: List[dict] = []

    def one_batch(batch: List[str]) -> List[dict]:
        people = people_search(aiark_key, batch, size=100)
        groups: Dict[str, list] = {}
        for p in people:
            link = (p.get("company", {}) or {}).get("link", {}) or {}
            cdom = _norm_domain(link.get("domain") or link.get("website") or "")
            if cdom in by_domain:
                groups.setdefault(cdom, []).append(p)
        rows = []
        for dom, ppl in groups.items():
            c = by_domain[dom]
            ranked = sorted(((rank_person(p), p) for p in ppl), key=lambda x: -x[0])
            picked = 0
            for s, p in ranked:
                if s <= 0 or picked >= per_company:
                    break
                row = _person_row(c, p)
                if row:
                    rows.append(row)
                    picked += 1
        return rows

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = [ex.submit(one_batch, b) for b in batches]
        done = 0
        for fut in as_completed(futs):
            done += 1
            try:
                out.extend(fut.result())
            except Exception:
                pass
            if done % 20 == 0 or done == len(batches):
                print(f"  ...discovery batch {done}/{len(batches)} (~{min(done*batch_domains, len(domains)):,} companies), {len(out)} candidates")
    return out


# ---------------------------------------------------------------- email finders
# Each finder takes a person dict and returns an email string or None.

def find_blitz(key: str, p: dict) -> Optional[str]:
    if not p.get("linkedin"):
        return None
    try:
        r = requests.post("https://api.blitz-api.ai/v2/enrichment/email",
                          headers={"x-api-key": key, "Content-Type": "application/json"},
                          json={"person_linkedin_url": p["linkedin"]}, timeout=45)
        if r.status_code == 200 and r.json().get("found"):
            return r.json().get("email")
    except requests.RequestException:
        pass
    return None


def find_aiark(key: str, p: dict) -> Optional[str]:
    if not p.get("linkedin"):
        return None
    for attempt in range(3):
        _AIARK_RATE.wait()  # shared cap (~4.5 rps) so high concurrency stays under AI Ark's limit
        try:
            r = requests.post(f"{AIARK}/people/export/single",
                              headers={"X-TOKEN": key, "Content-Type": "application/json"},
                              json={"url": p["linkedin"]}, timeout=90)
        except requests.RequestException:
            return None
        if r.status_code == 429:  # backoff + retry so a rate-limit never silently drops an email
            time.sleep(0.6 * (attempt + 1))
            continue
        if r.status_code != 200:
            return None
        try:
            out = (r.json().get("email", {}) or {}).get("output") or [{}]
        except ValueError:
            return None
        cell = out[0] if out else {}
        if cell.get("address") and str(cell.get("status", "")).upper() == "VALID":
            return cell["address"]
        return None
    return None


def find_kitt(key: str, p: dict) -> Optional[str]:
    """KITT realtime finder. Response shape undocumented -> parse defensively."""
    try:
        r = requests.post("https://api.trykitt.ai/job/find_email",
                          headers={"x-api-key": key, "Content-Type": "application/json"},
                          json={"fullName": p["full"], "domain": p["domain"],
                                "linkedinStandardProfileURL": p.get("linkedin") or "",
                                "realtime": True}, timeout=60)
        if r.status_code != 200:
            return None
        d = r.json()
        # try the most likely shapes until we confirm the real one with a live key
        for path in (("email",), ("result", "email"), ("data", "email"), ("output", "email")):
            cur: Any = d
            ok = True
            for k in path:
                if isinstance(cur, dict) and k in cur:
                    cur = cur[k]
                else:
                    ok = False
                    break
            if ok and isinstance(cur, str) and "@" in cur:
                return cur
    except requests.RequestException:
        pass
    return None


def find_leadmagic(key: str, p: dict) -> Optional[str]:
    try:
        r = requests.post("https://api.leadmagic.io/v1/people/email-finder",
                          headers={"X-API-Key": key, "Content-Type": "application/json"},
                          json={"first_name": p["first"], "last_name": p["last"], "domain": p["domain"]},
                          timeout=60)
        if r.status_code == 200 and r.json().get("status") == "valid":
            return r.json().get("email")
    except requests.RequestException:
        pass
    return None


def find_icypeas_bulk(key: str, people: List[dict]) -> Dict[int, str]:
    """BULK Icypeas: submit all misses in one job, poll, return {index_in_people: email}."""
    H = {"Authorization": key, "Content-Type": "application/json"}
    data = [[p["first"], p["last"], p["domain"]] for p in people]
    ext = [str(i) for i in range(len(people))]
    try:
        sub = requests.post("https://app.icypeas.com/api/bulk-search", headers=H,
                            json={"name": "dm-enrichment", "task": "email-search",
                                  "data": data, "custom": {"externalIds": ext}}, timeout=60)
        if sub.status_code != 200 or not sub.json().get("success"):
            return {}
        file_id = sub.json().get("file")
        # Poll the RESULTS route directly (read route is 30/min) and stop as soon
        # as all rows are terminal — don't burn a fixed progress-poll budget.
        found: Dict[int, str] = {}
        n = len(people)
        for _ in range(20):  # ~20 * 5s = 100s ceiling
            time.sleep(5)
            items_all, nxt = [], None
            for _ in range(60):  # paginate the whole file
                body = {"mode": "bulk", "file": file_id, "limit": 100}
                if nxt:
                    body["sorts"] = nxt
                    body["next"] = True
                rd = requests.post("https://app.icypeas.com/api/bulk-single-searchs/read", headers=H, json=body, timeout=45)
                if rd.status_code != 200:
                    break
                j = rd.json()
                items = j.get("items", [])
                items_all.extend(items)
                nxt = j.get("sorts")
                if len(items) < 100:
                    break
            terminal = [it for it in items_all if it.get("status") not in ("NONE", "SCHEDULED", "IN_PROGRESS")]
            if items_all and len(terminal) >= min(len(items_all), n):
                for it in items_all:
                    emails = (it.get("results", {}) or {}).get("emails") or []
                    idx = it.get("userData", {}).get("externalId")
                    if emails and emails[0].get("email") and idx not in (None, "") \
                            and emails[0].get("certainty") in ("ultra_sure", "very_sure", "probable"):
                        found[int(idx)] = emails[0]["email"]
                break
        return found
    except (requests.RequestException, ValueError, KeyError):
        return {}


# ---------------------------------------------------------------- MV verify (single API, parallel)

def _mv_verify_one(key: str, email: str) -> str:
    """Verify ONE email via the MillionVerifier single-email API. 3 retries.
    Returns the lowercased result (ok/catch_all/invalid/unknown/disposable/...),
    or 'unknown' only after the call genuinely fails 3x."""
    for _ in range(3):
        try:
            r = requests.get("https://api.millionverifier.com/api/v3/",
                             params={"api": key, "email": email, "timeout": 10}, timeout=30)
            if r.status_code == 200:
                return (r.json().get("result") or "unknown").lower()
        except (requests.RequestException, ValueError):
            pass
    return "unknown"


def mv_verify(key: str, emails: List[str], workers: int = 20) -> Dict[str, str]:
    """Verify emails -> {email_lower: result} via the SINGLE-email API in parallel.

    Replaces the old bulk upload→fileinfo→download path, which silently returned
    nothing on large jobs (poll timeout / response-format drift) and caused every
    email to default to 'unknown'. The single API is the proven-reliable route:
    ~20 workers, 3 retries each verified ~6,820 emails in ~4 min. result in
    ok/catch_all/unknown/disposable/invalid/..."""
    if not emails:
        return {}
    out: Dict[str, str] = {}
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(_mv_verify_one, key, e): e for e in emails}
        for fut in as_completed(futs):
            e = futs[fut]
            try:
                out[e.strip().lower()] = fut.result()
            except Exception:
                out[e.strip().lower()] = "unknown"
            done += 1
            if done % 1000 == 0 or done == len(emails):
                print(f"  ...MV verified {done:,}/{len(emails):,}")
    return out


# ---------------------------------------------------------------- orchestrator

CHECKPOINT_PATH: Optional[str] = None


def _checkpoint(people: List[dict]) -> None:
    """Crash insurance: dump current people state (emails found so far) to CSV."""
    if not CHECKPOINT_PATH:
        return
    try:
        with open(CHECKPOINT_PATH, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(OUTPUT_HEADERS)
            for p in people:
                w.writerow([p.get("company", ""), p.get("domain", ""), p.get("score", ""),
                            p.get("first", ""), p.get("last", ""), p.get("title", ""),
                            p.get("email", ""), p.get("email_source", ""), p.get("verification", ""),
                            p.get("send_safe", ""), p.get("linkedin", ""), p.get("aiark_id", "")])
    except OSError:
        pass


def _is_stage_done(name: str) -> bool:
    return bool(CHECKPOINT_PATH and os.path.exists(f"{CHECKPOINT_PATH}.{name}.done"))


def _mark_stage_done(name: str) -> None:
    if CHECKPOINT_PATH:
        try:
            Path(f"{CHECKPOINT_PATH}.{name}.done").write_text("1")
        except OSError:
            pass


def run_stage(all_people: List[dict], pending_pairs, finder: Callable[[dict], Optional[str]],
              workers: int, source_name: str) -> Tuple[int, List[int]]:
    """Run a per-person finder over the pending pairs [(idx, person)]. Writes
    email/email_source into all_people AS results arrive and checkpoints every
    200 completions (intra-stage crash insurance). Returns (n_found, still_missing_idx)."""
    found = 0
    missing: List[int] = []
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(finder, p): i for i, p in pending_pairs}
        for fut in as_completed(futs):
            i = futs[fut]
            try:
                email = fut.result()
            except Exception:
                email = None
            done += 1
            if email:
                all_people[i]["email"] = email
                all_people[i]["email_source"] = source_name
                found += 1
            else:
                missing.append(i)
            if done % 200 == 0:
                _checkpoint(all_people)
    _checkpoint(all_people)
    return found, missing


def waterfall(keys: Dict[str, Optional[str]], people: List[dict]) -> None:
    """Mutate each person dict with email / email_source. First-hit-wins, staged.
    RESUME-AWARE: people who already have an email (pre-loaded from a checkpoint)
    are skipped, so a re-run continues a killed run instead of redoing it."""
    pending = [i for i, p in enumerate(people) if not p.get("email")]
    print(f"  (resume) {len(people) - len(pending)} already have emails; {len(pending)} to find")

    def remaining():
        return [(i, people[i]) for i in pending]

    stages = [
        ("blitz", keys.get("blitz"), find_blitz, 25),
        ("aiark", keys.get("aiark"), find_aiark, AIARK_WORKERS),
        ("kitt", keys.get("kitt"), find_kitt, 10),
    ]
    for name, key, fn, workers in stages:
        if _is_stage_done(name):
            print(f"  stage {name}: already complete (resume) — skipping")
            continue
        if not key or not pending:
            if not key:
                print(f"  stage {name}: SKIPPED (no key)")
            continue
        found, miss = run_stage(people, remaining(), lambda p, k=key, f=fn: f(k, p), workers, name)
        pending = miss
        print(f"  stage {name}: +{found} emails, {len(pending)} still missing")
        _checkpoint(people)
        _mark_stage_done(name)

    # Icypeas BULK for the misses
    if _is_stage_done("icypeas"):
        print("  stage icypeas: already complete (resume) — skipping")
    elif keys.get("icypeas") and pending:
        sub_people = [people[i] for i in pending]
        got = find_icypeas_bulk(keys["icypeas"], sub_people)
        new_pending = []
        for local_idx, i in enumerate(pending):
            if local_idx in got:
                people[i]["email"], people[i]["email_source"] = got[local_idx], "icypeas"
            else:
                new_pending.append(i)
        print(f"  stage icypeas(bulk): +{len(got)} emails, {len(new_pending)} still missing")
        pending = new_pending
        _checkpoint(people)
        _mark_stage_done("icypeas")
    elif not keys.get("icypeas"):
        print("  stage icypeas: SKIPPED (no key)")

    # LeadMagic for the remainder
    if _is_stage_done("leadmagic"):
        print("  stage leadmagic: already complete (resume) — skipping")
    elif keys.get("leadmagic") and pending:
        found, miss = run_stage(people, remaining(), lambda p, k=keys["leadmagic"]: find_leadmagic(k, p), 5, "leadmagic")
        pending = miss
        print(f"  stage leadmagic: +{found} emails, {len(pending)} still missing")
        _checkpoint(people)
        _mark_stage_done("leadmagic")
    elif not keys.get("leadmagic"):
        print("  stage leadmagic: SKIPPED (no key)")


def verify_emails(mv_key: Optional[str], people: List[dict], verify_aiark: bool = True) -> None:
    """MV-verify emails and set Send Safe = "Yes" iff the MV result is "ok".

    By default (verify_aiark=True) EVERY email is checked through MillionVerifier
    regardless of source — INCLUDING AI Ark. AI Ark's BounceBan "verified" status
    is NOT send-safe in practice: a 2026-06-17 run that re-checked 1,447 AI-Ark
    emails through MillionVerifier found 23% (335) failed — 299 catch_all, 21
    unknown, 15 invalid — i.e. they had been wrongly marked "Send Safe = Yes".
    True send-safe on that run dropped from 2,947 to 2,612 once AI Ark emails
    were verified. So we no longer trust source as a proxy for verification.

    Pass verify_aiark=False to restore the old (unsafe) behavior: trust AI Ark
    emails as pre-verified (Verification=aiark_verified, Send Safe=Yes) and only
    MV-check the rest."""
    skip_source = None if verify_aiark else "aiark"
    if not verify_aiark:
        for p in people:
            if p.get("email_source") == "aiark":
                p["verification"], p["send_safe"] = "aiark_verified", "Yes"

    def needs_verify(p: dict) -> bool:
        return bool(p.get("email")) and (skip_source is None or p.get("email_source") != skip_source)

    to_verify = sorted({p["email"] for p in people if needs_verify(p)})
    label = "all" if verify_aiark else "non-AI-Ark"
    if not mv_key:
        for p in people:
            if needs_verify(p):
                p["verification"], p["send_safe"] = "unverified", "?"
        print(f"  verify: SKIPPED (no MillionVerifier key) — {len(to_verify)} {label} emails left unverified")
        return
    results = mv_verify(mv_key, to_verify)
    for p in people:
        if needs_verify(p):
            res = results.get(p["email"].lower(), "unknown")
            p["verification"] = res
            p["send_safe"] = "Yes" if res == "ok" else "No"
    # Log the verification-result distribution so a silent all-unknown failure
    # (the bulk path's old failure mode) can't recur unnoticed.
    dist: Dict[str, int] = {}
    for p in people:
        if needs_verify(p):
            dist[p["verification"]] = dist.get(p["verification"], 0) + 1
    safe = sum(1 for p in people if p.get("send_safe") == "Yes")
    print(f"  verify: MillionVerifier checked {len(to_verify)} {label} emails; "
          f"result distribution {dict(sorted(dist.items(), key=lambda kv: -kv[1]))}")
    if to_verify and dist.get("unknown", 0) == sum(dist.values()):
        print("  verify: WARNING — every checked email came back 'unknown'; "
              "MillionVerifier likely failed (check the key / API). NOT treating as verified.")
    safe_note = "result=ok" if verify_aiark else "AI-Ark + ok"
    print(f"  verify: {safe} total send-safe ({safe_note})")


# ---------------------------------------------------------------- source + sink

def read_qualified(sheet_url: str, min_score: int) -> List[dict]:
    from client import SheetsClient, extract_sheet_id
    c = SheetsClient()
    sid = extract_sheet_id(sheet_url)
    left = c.read_range(sid, "Companies!A2:B")
    right = c.read_range(sid, "Companies!I2:K")
    out = []
    for i in range(min(len(left), len(right))):
        lo = (left[i] + ["", ""])[:2]
        ri = (right[i] + ["", "", ""])[:3]
        if str(ri[2]).strip().lower() != "qualified":
            continue
        try:
            sc = int(ri[1])
        except (ValueError, TypeError):
            continue
        if sc < min_score:
            continue
        out.append({"company": lo[0], "website": lo[1], "aiark_id": ri[0], "score": sc})
    return out


def read_contacts_sheet(sheet_url: str, tab: str = "Contacts") -> List[dict]:
    """Read an EXISTING contacts sheet (find_contacts.py output) and build the
    waterfall's people dicts directly — NO AI Ark people discovery, so we don't
    re-spend People Search credits on contacts we already have."""
    from client import SheetsClient, extract_sheet_id
    c = SheetsClient()
    sid = extract_sheet_id(sheet_url)
    grid = c.read_range(sid, f"{tab}!A1:K")
    if not grid:
        return []
    header = [h.strip().lower() for h in grid[0]]

    def col(*names):
        for n in names:
            if n in header:
                return header.index(n)
        return None
    ci = {
        "company": col("company", "company name"),
        "domain": col("website", "domain"),
        "score": col("icp score", "score"),
        "first": col("first name", "first"),
        "last": col("last name", "last"),
        "title": col("title"),
        "linkedin": col("linkedin"),
        "aiark_id": col("ai ark company id", "aiark company id"),
    }
    out = []
    for row in grid[1:]:
        def g(key):
            i = ci[key]
            return (row[i] if i is not None and i < len(row) else "") or ""
        fn, ln = g("first").strip(), g("last").strip()
        dom = _norm_domain(g("domain"))
        if not dom:
            continue
        try:
            sc = int(g("score"))
        except (ValueError, TypeError):
            sc = ""
        out.append({"company": g("company"), "domain": dom, "score": sc,
                    "aiark_id": g("aiark_id"), "first": fn, "last": ln,
                    "full": f"{fn} {ln}".strip(), "title": g("title"),
                    "linkedin": g("linkedin").strip()})
    return out


def load_checkpoint_emails(path: str) -> Dict[tuple, dict]:
    """Read a prior checkpoint CSV -> {(first,last,domain): {email,source,verification,send_safe}}
    for rows that already have an email. Used to resume a killed run."""
    out: Dict[tuple, dict] = {}
    if not path or not os.path.exists(path):
        return out
    try:
        for r in csv.DictReader(open(path, newline="", encoding="utf-8")):
            if not (r.get("Email") or "").strip():
                continue
            key = ((r.get("First Name") or "").strip().lower(),
                   (r.get("Last Name") or "").strip().lower(),
                   _norm_domain(r.get("Website") or ""))
            out[key] = {"email": r["Email"].strip(), "source": (r.get("Email Source") or "").strip(),
                        "verification": (r.get("Verification") or "").strip(),
                        "send_safe": (r.get("Send Safe") or "").strip()}
    except OSError:
        pass
    return out


def write_sheet(title: str, people: List[dict]) -> str:
    from sheets_auth import get_sheets_service
    rows = [p for p in people if p.get("email")]
    service = get_sheets_service()
    created = service.spreadsheets().create(
        body={"properties": {"title": title},
              "sheets": [{"properties": {"title": "Contacts",
                          "gridProperties": {"rowCount": len(rows) + 10, "columnCount": max(26, len(OUTPUT_HEADERS))}}}]},
        fields="spreadsheetId,spreadsheetUrl").execute()
    sid = created["spreadsheetId"]
    values = [OUTPUT_HEADERS] + [[
        p["company"], p["domain"], p["score"], p["first"], p["last"], p["title"],
        p["email"], p.get("email_source", ""), p.get("verification", ""), p.get("send_safe", ""),
        p["linkedin"], p["aiark_id"],
    ] for p in rows]
    for off in range(0, len(values), 2000):
        service.spreadsheets().values().update(
            spreadsheetId=sid, range=f"Contacts!A{off + 1}", valueInputOption="RAW",
            body={"values": values[off:off + 2000]}).execute()
    return created["spreadsheetUrl"]


def main() -> int:
    p = argparse.ArgumentParser(description="Decision-maker enrichment via a staged email waterfall.")
    p.add_argument("--source-sheet", help="SCORED company sheet — discovers people via AI Ark first (re-spends People Search credits).")
    p.add_argument("--contacts-sheet", help="EXISTING contacts sheet (find_contacts.py output) — runs the email waterfall directly on those people, NO re-discovery.")
    p.add_argument("--contacts-tab", default="Contacts", help="Worksheet/tab name in --contacts-sheet (default 'Contacts').")
    p.add_argument("--min-score", type=int, default=8)
    p.add_argument("--limit", type=int, help="Cap rows: companies in discover mode, contacts in --contacts-sheet mode (highest-scored first).")
    p.add_argument("--per-company", type=int, default=2)
    p.add_argument("--discover-workers", type=int, default=8)
    p.add_argument("--checkpoint-csv", help="Write people state to this CSV after every waterfall stage (crash insurance).")
    p.add_argument("--verify-aiark", action=argparse.BooleanOptionalAction, default=True,
                   help="MV-verify AI Ark emails too (default ON). AI Ark's 'verified' status is unreliable "
                        "(~23%% fail MV), so by default ALL emails go through MillionVerifier. Pass "
                        "--no-verify-aiark to trust AI Ark emails as pre-verified (old, unsafe behavior).")
    p.add_argument("--out-title", default="OlympoLabs — Agency Contacts (waterfall v2)")
    p.add_argument("--search-titles", help="Comma-separated titles for AI Ark People Search recall. "
                   "Overrides the built-in marketing/growth default — set per campaign.")
    p.add_argument("--tier1-titles", help="Comma-separated TIER1 (top decision-maker) title keywords for ranking. "
                   "A discovered person whose title matches TIER1 or TIER2 is kept; others are dropped.")
    p.add_argument("--tier2-titles", help="Comma-separated TIER2 (secondary decision-maker) title keywords for ranking.")
    args = p.parse_args()
    if not args.source_sheet and not args.contacts_sheet:
        p.error("Provide --contacts-sheet (run waterfall on existing contacts) or --source-sheet (discover then waterfall).")
    global CHECKPOINT_PATH, SEARCH_TITLES, TIER1, TIER2
    CHECKPOINT_PATH = args.checkpoint_csv
    # Per-campaign title targeting. People Search + rank_person read these module
    # globals by name, so reassigning here retargets discovery without threading
    # params through. Defaults (marketing/growth) are preserved when unset.
    def _csv_titles(s):
        return [t.strip().lower() for t in s.split(",") if t.strip()]
    if args.search_titles:
        SEARCH_TITLES = _csv_titles(args.search_titles)
    if args.tier1_titles:
        TIER1 = _csv_titles(args.tier1_titles)
    if args.tier2_titles:
        TIER2 = _csv_titles(args.tier2_titles)
    _prevent_sleep()

    keys = {k: load_key(f"{k}.json") for k in ("aiark", "blitz", "kitt", "icypeas", "leadmagic")}
    keys["millionverifier"] = load_key("millionverifier.json")
    if not keys["aiark"]:
        print("ERROR: aiark.json required for people discovery.", file=sys.stderr)
        return 2
    print("Providers configured:", ", ".join(k for k, v in keys.items() if v) or "(none)")
    print("Providers MISSING:", ", ".join(k for k, v in keys.items() if not v) or "(none)")

    if args.contacts_sheet:
        print("\n[1/3] Loading EXISTING contacts (no AI Ark discovery / no People-Search spend)...")
        people = read_contacts_sheet(args.contacts_sheet, args.contacts_tab)
        people.sort(key=lambda p: -(p["score"] if isinstance(p["score"], int) else 0))
        if args.limit:
            people = people[:args.limit]
        print(f"  -> {len(people)} contacts across {len({p['domain'] for p in people})} companies")
        # RESUME: pre-load emails already found in a prior (killed) run's checkpoint
        ckpt = load_checkpoint_emails(args.checkpoint_csv) if args.checkpoint_csv else {}
        if ckpt:
            n = 0
            for p in people:
                rec = ckpt.get((p["first"].lower(), p["last"].lower(), p["domain"]))
                if rec and rec["email"]:
                    p["email"], p["email_source"] = rec["email"], rec["source"]
                    if rec["verification"]:
                        p["verification"] = rec["verification"]
                    if rec["send_safe"]:
                        p["send_safe"] = rec["send_safe"]
                    n += 1
            print(f"  resume: pre-loaded {n:,} emails from checkpoint {args.checkpoint_csv}")
    else:
        companies = read_qualified(args.source_sheet, args.min_score)
        companies.sort(key=lambda c: -c["score"])
        if args.limit:
            companies = companies[:args.limit]
        print(f"\nQualified companies (score>={args.min_score}): {len(companies)}")
        print("\n[1/3] Discovering decision-makers (AI Ark People Search, title-ranked)...")
        people = discover_people(keys["aiark"], companies, args.per_company, args.discover_workers)
        print(f"  -> {len(people)} candidate contacts across {len({p['domain'] for p in people})} companies")
    if not people:
        return 1

    print("\n[2/3] Email waterfall (Blitz -> AI Ark -> KITT -> Icypeas -> LeadMagic)...")
    waterfall(keys, people)

    verify_label = "all emails" if args.verify_aiark else "non-AI-Ark emails"
    print(f"\n[3/3] Verifying {verify_label} (MillionVerifier)...")
    verify_emails(keys["millionverifier"], people, verify_aiark=args.verify_aiark)
    _checkpoint(people)

    with_email = [p for p in people if p.get("email")]
    by_source: Dict[str, int] = {}
    for p in with_email:
        by_source[p.get("email_source", "?")] = by_source.get(p.get("email_source", "?"), 0) + 1
    print(f"\n{len(with_email)}/{len(people)} contacts got an email "
          f"({len(with_email)*100//max(len(people),1)}% hit). By source: {by_source}")

    url = write_sheet(args.out_title, people)
    print(f"\nContacts sheet:\n  {url}")
    try:
        with COST_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": datetime.datetime.now().isoformat(timespec="seconds"),
                                "companies": len({p["domain"] for p in people if p.get("domain")}),
                                "candidates": len(people),
                                "emails": len(with_email), "by_source": by_source, "sheet": url}) + "\n")
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
