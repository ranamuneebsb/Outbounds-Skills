# Onboarding — OlympoLabs Skills

Welcome. This is a private internal toolkit — never share the credentials or the repo URL outside the team.

## 1. Prereqs (15 min, one-time)

- Mac with Homebrew + Python 3.10+
- A Claude Code license (claude.ai/code)
- GitHub access to this repo (ping Bryan with your GitHub username)
- `gcloud` CLI installed for Google Sheets read/write:
  ```bash
  brew install --cask google-cloud-sdk
  ```
- Three API keys you'll receive separately via DM (never commit these):
  - **OpenRouter** (LLM provider)
  - **ZenRows** (scraping)
  - **PlusVibe** (campaign sending)

## 2. Clone + install (3 min)

```bash
git clone git@github.com:bryanlopez-source/Olympo-Lab-Skills.-.git OlympoLabs-Skills
cd OlympoLabs-Skills
./install.sh
```

The installer:
- Copies all `.skill` bundles into `~/.claude/skills/`
- Prints next-step instructions for credentials + `gcloud`
- Is idempotent — safe to re-run any time

## 3. Drop your credentials at these exact paths

```bash
mkdir -p ~/.olympolabs
cat > ~/.olympolabs/openrouter.json <<'EOF'
{"api_key": "sk-or-..."}
EOF
cat > ~/.olympolabs/zenrows.json <<'EOF'
{"api_key": "..."}
EOF
cat > ~/.olympolabs/plusvibe.json <<'EOF'
{"api_key": "..."}
EOF
chmod 600 ~/.olympolabs/*.json
```

The skills read from these paths automatically. **Do not put keys in the repo.**

## 4. Google Sheets auth (one-time)

```bash
gcloud init                                   # pick your existing GCP project
gcloud services enable sheets.googleapis.com  # enable Sheets API on the project
gcloud auth application-default login \
  --scopes=openid,email,https://www.googleapis.com/auth/spreadsheets
gcloud auth application-default set-quota-project <your-project-id>
```

The skills authenticate AS you. Any sheet you own or have edit access to is writable.

## 5. Restart Claude Code

That's it. The skills auto-trigger from their description text. Try one to verify:

> Score the qualified companies in this sheet against an ICP for SaaS founders: https://docs.google.com/spreadsheets/d/.../edit

If `company-scoring` fires, you're set up.

## 6. What's in the box (7 skills)

Full descriptions in [README.md](README.md). Quick map:

| Skill | What it does |
|---|---|
| **copywriter** | Generate 10–20 cold email scripts from the winning-scripts knowledge base |
| **icp-keywords** | Generate INCLUDE / EXCLUDE / decision-maker title lists for Apollo, Clay, ZoomInfo, LinkedIn Sales Navigator |
| **company-scoring** | Score Google Sheets or CSVs of companies 1–10 for ICP fit; writes 5 columns including `Scrape Content` |
| **name-normalizer** | Clean up first-name and company columns for natural-reading merge tags |
| **personalization** | Per-row cold-email hooks generated from the `Scrape Content` column |
| **plusvibe-spintax** | Heavy spintax + spam-word audit on a finished script |
| **plusvibe-campaign-manager** | Upload finished spintaxed campaigns to PlusVibe via API |

Typical pipeline:

```
copywriter → plusvibe-spintax → plusvibe-campaign-manager
                                          ↑
company-scoring → name-normalizer → personalization
```

## 7. Updating later

```bash
cd OlympoLabs-Skills
git pull
./install.sh        # idempotent
```

Restart Claude Code if any SKILL.md descriptions changed.

## 8. When something breaks

1. **First, run the doctor:**
   ```bash
   python3 ~/.claude/skills/company-scoring/scripts/doctor.py
   ```
   It checks credentials, dependencies, gcloud ADC, and prints the exact fix for anything missing.

2. **Check the docs:**
   - [docs/setup-api-keys.md](docs/setup-api-keys.md)
   - [docs/setup-gcloud-adc.md](docs/setup-gcloud-adc.md)
   - [docs/troubleshooting.md](docs/troubleshooting.md)

3. **DM Bryan** if you're still stuck after the above.

## Hard rules

- **Never commit credentials.** The `.gitignore` blocks the obvious paths but stay vigilant.
- **Never share the repo URL or API keys outside the team.**
- **Don't push to `main` without a quick sanity check** — at minimum `./install.sh` should succeed after your changes.
- **Re-run `install.sh` after pulling.** Skill updates ship as `.skill` bundles; the installer copies them into Claude Code's skills directory.
