#!/usr/bin/env python3
"""
Sanity-check the Sheets ADC setup by reading a sheet's metadata.

Pass a Sheets URL or ID as the first arg. The script:
  1. Confirms ADC is configured.
  2. Resolves the spreadsheet ID from the input.
  3. Calls spreadsheets.get to confirm the credentials can READ the file.
  4. Lists the worksheet tabs.

If you skip the URL arg the script prints setup instructions and exits 2.

Usage:
    python3 ping.py https://docs.google.com/spreadsheets/d/.../edit
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from client import SheetsClient, extract_sheet_id  # noqa: E402


def main() -> int:
    if len(sys.argv) < 2:
        sys.stderr.write(
            "Usage: python3 ping.py <spreadsheet URL or ID>\n"
            "Provide a Google Sheets URL (https://docs.google.com/spreadsheets/d/.../edit)\n"
            "or a bare spreadsheet ID.\n"
        )
        return 2

    try:
        sheet_id = extract_sheet_id(sys.argv[1])
    except ValueError as exc:
        sys.stderr.write(f"{exc}\n")
        return 2

    print(f"Resolved sheet id: {sheet_id}")
    try:
        client = SheetsClient()
        worksheets = client.list_worksheets(sheet_id)
    except RuntimeError as exc:
        sys.stderr.write(f"AUTH ERROR: {exc}\n")
        return 3
    except Exception as exc:
        sys.stderr.write(f"API ERROR: {exc}\n")
        return 4

    print(f"OK - Sheets API can access this sheet.")
    print(f"Worksheets ({len(worksheets)}):")
    for ws in worksheets:
        print(f"  - {ws['title']!r}: {ws['rowCount']} rows x {ws['columnCount']} cols")
    return 0


if __name__ == "__main__":
    sys.exit(main())
