---
name: icp-keywords
description: Generate copy-pasteable INCLUDE keywords, EXCLUDE keywords, and DECISION-MAKER TITLES for a cold-outbound campaign, given the user's strategy + ICP description. All three lists are returned as comma-separated single lines ready to paste into Apollo, Clay, ZoomInfo, LinkedIn Sales Navigator, or any prospect-search tool. Trigger when the user wants to build targeting, "generate keywords for this ICP", "what should I search for in Apollo for X", "build include/exclude lists for [niche]", "help me target [industry] in [region]", "who should I reach out to for this campaign", or any variant of "I'm running a campaign for X selling Y to Z, give me the search list". User provides the strategy (who's selling what to whom) plus the ICP (industry, geography, size, signals). If either is missing, ask before generating. Pure conversational skill — no scripts, no API calls, no files written. Output is plain markdown.
---

# ICP Keywords

Take a user's campaign strategy + ICP definition and return three copy-pasteable lists they can drop straight into prospect-search tools:

1. **INCLUDE keywords** — what to search for
2. **EXCLUDE keywords** — what to filter out (the harder, higher-leverage list)
3. **DECISION-MAKER TITLES** — who to reach out to, ranked by relevance to the offer

This is a pure conversational skill. No CSV, no Sheet, no API call, no script execution. The agent's own reasoning is the engine. Output is plain markdown the user reads, copies, and pastes into Apollo / Clay / ZoomInfo / LinkedIn Sales Navigator / Lemlist / wherever.

## What inputs the user always provides

Two inputs, every run:

1. **STRATEGY** — who is selling what to whom, and why. Example: *"We're a lead-gen agency selling outbound services to marketing agencies that run Google Ads."* This tells you what the **offer** is, which drives the decision-maker title selection.

2. **ICP DEFINITION** — concrete targeting parameters: industry / vertical, geography, company-size band, and any specific signals (tech stack, certifications, lifecycle stage, etc.). Example: *"US marketing agencies, 10-50 people, focused on Google Ads."*

These two can come in the same sentence — they usually do. If the user's message is missing one (e.g. they describe the ICP but not the offer, or vice versa), **ask before generating**. Don't infer the missing half — the wrong inference produces the wrong decision-maker titles, which is the worst kind of bad output here because the user will run a campaign on it.

When to ask vs. when to proceed:

- Both present → generate immediately.
- Only ICP present (no offer/strategy) → ask: *"Got the ICP. What's the offer / what are you selling to them? It changes which decision-makers I'd suggest reaching out to."*
- Only offer/strategy present (no concrete ICP) → ask: *"Got the offer. What's the ICP — industry/vertical, geography, company size, any specific signals?"*
- Neither → ask both at once.

## How to think about each output list

### INCLUDE keywords

20-30 keywords that the prospect's company name, description, or website would plausibly contain if they ARE the ICP. Use **Title Case**, not lowercase — `Google Ads`, not `google ads`. Databases match either way but Title Case reads as the actual brand/term the prospect would have written.

**Always include both the abbreviation AND the full form for every technical term.** Databases match strings literally — if a prospect's site says "Pay Per Click" but you only included "PPC", you miss them. Pair every acronym:

- `PPC, Pay Per Click`
- `SEM, Search Engine Marketing`
- `CRO, Conversion Rate Optimization`
- `SEO, Search Engine Optimization`
- `LSA, Local Service Ads`

Mix of category types:

- **Direct industry / service-line terms** WITHOUT the "agency" suffix — databases match the keyword in any surrounding context, so `Google Ads` catches more than `Google Ads Agency`. (`Performance Marketing`, `Paid Search`, `Paid Acquisition`, `Demand Generation`, `Customer Acquisition`, `Paid Traffic`)
- **Agency-suffix variants** for a few of the highest-precision terms only (`PPC Agency`, `Paid Media Agency`, `Search Marketing Agency`) — useful when database content is generic
- **Specific service offerings** the ICP would list on their services page (`Landing Page Optimization`, `Google Shopping`, `YouTube Advertising`, `Local Service Ads`, `Conversion Optimization`)
- **Common tool/platform stack** when distinctive (`Google Ads Manager`, `Google Tag Manager`, `GA4`)

Avoid: keywords so broad they catch the whole internet (`digital`, `online`, `agency` alone), or so narrow they catch nothing (`Google Ads Premier Partner with 3+ years experience`).

### EXCLUDE keywords

25-40 keywords. **This is the highest-leverage list** — it's what separates a targeted list from a noisy one, and it's the hardest to do without industry knowledge. Aim for the higher end (30+) on most lists. The exclude list typically ends up LONGER than the include list because there are more ways to be the wrong company than the right one.

Six categories to cover (most lists need 4-5 of these):

1. **BUY-SIDE businesses** — companies that USE the service instead of SELL it. **This is the single biggest source of false positives** on cold-outbound lists. If you're targeting Google Ads agencies, an e-commerce brand that runs its own Google Ads will say "Google Ads" all over its site and show up in your search. Exclude the categories that are most likely to be the buyer:
   - `manufacturer, distributor, wholesaler, retailer, ecommerce brand, SaaS, software` (for any B2B services campaign)
   - `nonprofit, church, university, school, hospital, clinic, dental practice, law firm, accounting firm, insurance agency, real estate brokerage, mortgage company` (industries that often run their own marketing in-house)

2. **Solo operators** when targeting companies of 10+ people. Add aggressively because freelancers and consultants describe themselves with the same service-line keywords as agencies:
   - `freelance, consultant, consulting, contractor, coach, coaching, virtual assistant, independent consultant`

3. **Adjacent agencies — but only the ones that DON'T overlap with the target work.** Carefully — many agencies do multiple services. A PPC agency might also do SEO. Don't exclude `seo agency` reflexively unless the user has confirmed they only want pure-play PPC shops. Safe excludes are agencies in clearly unrelated service lines:
   - `web design only, graphic design, video production, photographer` (specify "only" when adjacent agencies might also do PPC)

4. **Wrong company-size signals** (`Fortune 500, enterprise` for SMB; `solopreneur` for 10+ ppl agencies)

5. **Off-vertical noise** when a keyword has unrelated meanings (`marketing executive` matches in-house people, exclude when targeting agencies; `dropshipping, affiliate` when targeting service businesses)

6. **Wrong-geography proxies** (`EMEA, APAC` when US-only) and **outsourcing-side noise** (`looking for an agency, agency rfp, hire a marketing agency`)

When in doubt, **include the exclude rather than skip it** — the user can remove items they don't want, but they can't know what to add without industry context.

### DECISION-MAKER TITLES (ranked)

25-35 job titles, ranked by who's most likely to (a) own the budget, (b) feel the pain the offer solves, (c) be reachable by cold outbound. The list is much longer than the "obvious" 5-10 because **databases match strings literally** — missing a title variant means missing the real people at companies that use that exact wording.

**For every relevant functional role, generate ALL the canonical title variants.** Five rules:

1. **Both word orders**: `Director of Paid Media` AND `Paid Media Director`
2. **Every seniority label for that function**: `Head of X`, `Director of X`, `VP X`, `Vice President X` (databases sometimes match `VP` but not `Vice President` or vice-versa)
3. **Abbreviation + full form for C-suite**: `CEO` AND `Chief Executive Officer`, `CFO` AND `Chief Financial Officer`, `CMO` AND `Chief Marketing Officer`
4. **Compound owner titles** for small-business / agency ICPs: `Founder`, `Co-Founder`, `Owner`, `Co-Owner`, `Agency Owner`, `Founder & CEO`, `Principal`, `Managing Director`, `Managing Partner`, `Partner`
5. **Every functional axis the offer might fit**. For a PPC-agency offer, the user might want Founder-level decision makers AND Paid Media decision makers AND Marketing Director decision makers AND Performance Marketing decision makers. Generate variants for each axis.

Always include a short *why* for each title (one line) so the user can sanity-check against their offer. **One title per line in the rationale** — never group multiple titles with slashes (the comma-separated paste line must match the rationale one-to-one).

Rank top-down: the strongest title first. Lower-ranked titles are fallbacks for prospects where the top title isn't present in the company.

Different offer types call for different decision-maker shapes:

- **Service-for-the-business-itself** (lead-gen for an agency, accounting for a law firm) → Owner / Founder / CEO / Managing Partner cluster as primary
- **Service-for-a-function** (CRM tool, marketing software) → VP / Director / Head Of [that function] cluster as primary
- **Service-for-IT-or-engineering** (infra, dev tools) → CTO / VP Engineering / Head of Platform / Lead [Engineer/Architect] cluster
- **High-stakes financial product** (commercial credit, insurance) → CFO / Owner / President / Treasurer cluster

For agencies specifically, the owner/founder is often a stronger target than the Marketing Director, because the owner cares about agency growth directly while marketing leaders within the agency are focused on their clients' campaigns. But include BOTH clusters in the list — the user filters down further.

## Output format

All three lists are formatted as **comma-separated strings on a single line** so the user can click once and paste into any prospect-database's keyword/title field. The user explicitly chose this format because most tools (Apollo, ZoomInfo, Clay, LinkedIn Sales Navigator filters) accept comma-separated input directly.

Below each comma-separated list, include the reasoning / per-item context separately so the user has the rationale without it polluting the paste-ready string.

Use this exact structure:

```
## ICP Keywords — [short campaign label]

**Strategy:** [echo the user's strategy in one line]
**ICP:** [echo the ICP in one line]

---

### INCLUDE keywords  (paste into Include / Keywords)

keyword 1, keyword 2, keyword 3, keyword 4, keyword 5, ...

### EXCLUDE keywords  (paste into Exclude / Negative Keywords)

exclude 1, exclude 2, exclude 3, exclude 4, ...

### DECISION-MAKER TITLES  (paste into Job Title)

Title 1, Title 2, Title 3, Title 4, ...

**Ranking & rationale (one title per line, ranked top → bottom):**
1. **Title 1** — [one-line why this title fits the offer]
2. **Title 2** — [one-line why]
3. **Title 3** — [one-line why]
...

---

**Notes:**
- [Optional: 1-3 lines on edge cases, alternate strategies, or which database flavors this list is tuned for]
```

Formatting rules — all three lists, including titles:

- **Single comma-separated line per list**, comma + space between items (`a, b, c`). This is THE paste-ready string the user copies. The rationale beneath the titles list is for human reading, not for paste.
- **One title per item** in both the comma-separated line AND the rationale block. Never group multiple titles with slashes (`Founder / CEO / Owner` — wrong; use three separate items: `Founder`, `CEO`, `Owner`). The user pastes by item — slash-grouping makes the prospect database treat the whole grouping as one literal title string and match zero rows.
- No trailing comma.
- No bullet points / no quotes / no markdown formatting inside the comma-separated string.
- Multi-word items stay as-is (`google ads agency` not `"google ads agency"`).
- If a keyword contains a comma (rare), rephrase to avoid it rather than escape it.
- Keep keyword items lowercase unless capitalization is part of the brand/acronym (`google ads`, `ROAS-focused`, `8(a) certified`, `GSA`).
- Decision-maker titles in Title Case (`Founder`, `Director of Marketing`) — that's how prospect databases match them.

## Iterating

After the initial output, the user often wants to tweak. Common tweak shapes:

- *"Make the includes broader/narrower"* — expand or contract the include list, regenerate.
- *"I'm worried about [X look-alike] showing up — add to excludes"* — add to the exclude list, regenerate.
- *"What about [different decision maker title]?"* — re-rank or add the title with a rationale.
- *"Format this for Apollo specifically"* — Apollo uses comma-separated lists; reformat without changing content.
- *"Same lists but for [different region / different size band]"* — re-run with the changed parameter.

Always show the FULL refreshed lists when iterating, not just the delta — the user wants to copy-paste the new full list, not patch the old one in their head.

## When NOT to use this skill

- The user has a CSV / Sheet already and wants it filtered or scored — that's `company-scoring`.
- The user wants per-row cold email personalization — that's `personalization`.
- The user wants to write actual email copy — that's `copywriter`.
- The user is asking which DATABASE to use (Apollo vs ZoomInfo vs Clay) — that's a tooling question, not a targeting question.

## Saving a keyword set for reuse (optional)

If the user wants to save a generated keyword set so they can reference it later or re-use across campaigns, write it to `~/.olympolabs/icp-keyword-sets/<slug>.md` in the exact output format above. The user can then re-paste from that file any time, or hand it to the next skill in the pipeline (e.g. List Builder, when that's built). Don't save by default — only when the user asks.
