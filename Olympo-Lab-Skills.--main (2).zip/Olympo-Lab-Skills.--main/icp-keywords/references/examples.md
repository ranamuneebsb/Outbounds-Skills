# Worked examples — icp-keywords

A few real-shape inputs and the kind of output the skill should produce. Use these to calibrate the bar for keyword breadth, exclude depth, and decision-maker reasoning.

All lists are comma-separated, single-line, paste-ready into Apollo / ZoomInfo / Clay / LinkedIn Sales Navigator.

---

## Example 1: lead-gen agency targeting Google-Ads-focused marketing agencies

**User input:** *"Hey, we are a lead-gen agency, and we're trying to get marketing agencies doing Google Ads. The companies we're hitting are in the United States, marketing agencies between 10 and 50 people."*

### Output

```
## ICP Keywords — US Google-Ads agencies, 10–50 ppl

**Strategy:** Lead-gen agency selling outbound services to marketing agencies that run Google Ads.
**ICP:** US-based marketing agencies, 10–50 people, focused on Google Ads.

---

### INCLUDE keywords  (paste into Include / Keywords)

Google Ads, PPC, Pay Per Click, Paid Search, Search Engine Marketing, SEM, PPC Agency, Google Ads Agency, Paid Media Agency, Search Marketing Agency, Performance Marketing, Paid Acquisition, Google Advertising, Conversion Rate Optimization, CRO, Google Shopping, YouTube Advertising, Local Service Ads, Landing Page Optimization, Conversion Optimization, Demand Generation, Customer Acquisition, Search Advertising, Paid Traffic

### EXCLUDE keywords  (paste into Exclude / Negative Keywords)

freelance, consultant, consulting, contractor, coach, coaching, virtual assistant, independent consultant, web design only, graphic design, video production, photographer, nonprofit, church, university, school, hospital, clinic, dental practice, law firm, accounting firm, insurance agency, real estate brokerage, mortgage company, manufacturer, distributor, wholesaler, retailer, ecommerce brand, SaaS, software

### DECISION-MAKER TITLES  (paste into Job Title)

Founder, Co-Founder, Owner, President, CEO, Chief Executive Officer, Managing Director, Partner, Co-Owner, Agency Owner, Founder & CEO, Principal, Vice President Marketing, VP Marketing, Vice President Growth, Head of Marketing, Marketing Director, Director of Marketing, Head of Paid Media, Paid Media Director, Director of Paid Media, PPC Director, Director of PPC, Head of PPC, Search Director, SEM Director, Director of Search, Performance Marketing Director, Director of Performance Marketing, Growth Director

**Ranking & rationale (one title per line, top → bottom):**
1. **Founder** — at 10–50 person agencies the founder still owns growth and pipeline; feels lead-gen pain directly.
2. **Co-Founder** — same logic at multi-founder agencies.
3. **Owner** — registered title at many agencies; databases sometimes match "Owner" but not "Founder".
4. **President** — owner-equivalent at agencies with that structure.
5. **CEO** — same as Founder at most agencies in this band; included for databases that match CEO specifically.
6. **Chief Executive Officer** — long form; databases sometimes match one but not the other.
7. **Managing Director** — UK / partnership-flavored equivalent of CEO.
8. **Partner** — at partnership-structured agencies.
9. **Co-Owner** — alternative ownership title.
10. **Agency Owner** — niche-specific title often used by smaller shops.
11. **Founder & CEO** — compound title common on LinkedIn profiles.
12. **Principal** — owner-equivalent at consulting-style shops.
13. **Vice President Marketing** — runs the agency's own marketing / new-business pipeline.
14. **VP Marketing** — abbreviated form.
15. **Vice President Growth** — newer label for the same function at growth-focused shops.
16. **Head of Marketing** — UK / startup-flavored variant.
17. **Marketing Director** — common variant; word-order matters for database matching.
18. **Director of Marketing** — other word order.
19. **Head of Paid Media** — function-specific lead; relevant if your offer targets the paid-media practice itself.
20. **Paid Media Director** — same role.
21. **Director of Paid Media** — other word order.
22. **PPC Director** — narrower function lead.
23. **Director of PPC** — other word order.
24. **Head of PPC** — UK / startup variant.
25. **Search Director** — even narrower function lead.
26. **SEM Director** — alternate abbreviation.
27. **Director of Search** — other word order.
28. **Performance Marketing Director** — performance-flavored agencies.
29. **Director of Performance Marketing** — other word order.
30. **Growth Director** — at growth-focused agencies; owns the new-business engine.

---

**Notes:**
- Tuned for Apollo / ZoomInfo where the keyword field searches company name + description + website.
- For LinkedIn Sales Navigator, the "Marketing & Advertising" industry filter + employees 10–50 is a stronger first cut; layer keywords as a secondary filter.
- Founder/CEO ranked above marketing-specific titles because at 10–50 ppl the founder usually owns commercial decisions — flip the order if your offer is operational rather than strategic.
```

---

## Example 2: financial product (commercial credit) for government contractors

**User input:** *"We offer commercial credit ($1M–$20M) to government contractors. ICP: US DoD and federal-agency suppliers, especially construction, defense manufacturing, and services."*

### Output

```
## ICP Keywords — US gov contractors needing $1–20M credit

**Strategy:** Selling commercial credit ($1M–$20M) to US government contractors.
**ICP:** US contractors serving DoD / federal agencies, with revenue large enough to use $1M–$20M in capital. Verticals: construction, defense manufacturing, federal services.

---

### INCLUDE keywords  (paste into Include / Keywords)

government contractor, federal contractor, dod contractor, department of defense, gsa schedule, gsa contract holder, federal acquisition, prime contractor, federal subcontractor, naics 23, naics 332, naics 5417, 8(a) certified, sdvosb, wosb, hubzone, security clearance, top secret cleared, itar registered, defense logistics, mil-spec, federal infrastructure, public works contractor, federal services, government services firm

### EXCLUDE keywords  (paste into Exclude / Negative Keywords)

nonprofit, university, state government, city government, consulting only, saas only, pure software vendor, staffing agency, looking for a contractor, bidder list, rfp respondent

### DECISION-MAKER TITLES  (paste into Job Title)

CFO, Chief Financial Officer, Owner, President, Managing Partner, VP Finance, Director of Finance, Controller, Treasurer, CEO

**Ranking & rationale (one title per line, top → bottom):**
1. **CFO** — owns capital strategy; direct buyer for a $1M–$20M credit line.
2. **Chief Financial Officer** — same role, fuller title; databases may match one but not the other.
3. **Owner** — at smaller federal contractors, the owner is the CFO in practice.
4. **President** — owner-equivalent at many federal contractors.
5. **Managing Partner** — same logic at partnership-structured firms.
6. **VP Finance** — at mid-market firms with a non-CFO finance org.
7. **Director of Finance** — same logic, lower seniority.
8. **Controller** — sometimes owns vendor / line-of-credit relationships at smaller shops.
9. **Treasurer** — explicit cash/financing function at larger contractors.
10. **CEO** — backup at firms where the CEO and CFO share commercial calls.

---

**Notes:**
- NAICS codes are the strongest single filter for federal contractors — combine NAICS-based filtering with these keywords for a precision-first list.
- "Looking for a contractor" / "bidder list" excludes catch noise from procurement portals that aren't the contractors themselves.
- 8(a), SDVOSB, WOSB, HUBZone are SBA certifications that signal both contractor status AND a higher likelihood of growth-stage capital needs.
```

---

## Calibration notes for the skill

- **Include keywords**: 20–30. Title Case. Pair every abbreviation with its full form (`PPC, Pay Per Click`). Drop the redundant `agency` suffix on most terms — the database matches the keyword in any surrounding context. Mix direct industry terms, specific service offerings the ICP lists on their services page, and common tool/platform names.
- **Exclude keywords**: 25–40 (aim higher, not lower). The hardest list to write. Six categories to cover: (a) **BUY-SIDE businesses** that USE the service — the single biggest source of false positives (`manufacturer, ecommerce brand, SaaS, nonprofit, hospital, law firm`), (b) solo operators (`freelance, consultant, coach`), (c) adjacent agencies with non-overlapping service lines (`web design only, graphic design, video production`), (d) wrong-size proxies, (e) off-vertical noise, (f) wrong-geography proxies. When in doubt include the exclude — the user can delete what they don't want.
- **Decision-maker titles**: 25–35. Comma-separated for paste, ranked rationale below — **one title per line, never slash-grouped**. For every relevant functional role, generate ALL canonical variants: both word orders (`Director of X` AND `X Director`), every seniority label (`Head of X`, `Director of X`, `VP X`, `Vice President X`), abbreviation + full form for C-suite, and every compound owner title for small-business ICPs.
- **Notes section**: 1–3 lines. Database-specific tips, ranking tradeoffs, or a contrarian alternate target — whatever's worth the user knowing but doesn't belong in the lists themselves.
