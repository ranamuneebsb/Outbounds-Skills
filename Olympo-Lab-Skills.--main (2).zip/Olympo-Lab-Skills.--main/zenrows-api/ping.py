#!/usr/bin/env python3
"""
Sanity-check the ZenRows API key by scraping a known-good URL.

Default target is `https://example.com` which is small and always up. Pass a
URL as the first arg to test against a different target.

Usage:
    python3 ping.py
    python3 ping.py https://www.designdesk.io
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from zenrows_auth import DEFAULT_CONFIG_PATH, MissingCredentials, load_credentials  # noqa: E402
from client import ZenRowsAuthError, ZenRowsClient, ZenRowsError  # noqa: E402
from extract import extract_company_text  # noqa: E402


DEFAULT_URL = "https://example.com"


def main() -> int:
    url = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_URL

    try:
        creds = load_credentials()
    except MissingCredentials as exc:
        sys.stderr.write(f"{exc}\n")
        return 2

    print(f"Credentials source: {DEFAULT_CONFIG_PATH}")
    print(f"API key (first 12): {creds.api_key[:12]}...")
    print(f"Scraping: {url}")
    print()

    client = ZenRowsClient(credentials=creds)
    try:
        html = client.scrape(url)
    except ZenRowsAuthError as exc:
        sys.stderr.write(f"AUTH FAILED: {exc}\n")
        return 3
    except ZenRowsError as exc:
        sys.stderr.write(f"SCRAPE ERROR: {exc}\n")
        return 4

    print(f"OK - got {len(html)} bytes of HTML")
    text = extract_company_text(html, url=url)
    print(f"Extracted text length: {len(text)} chars")
    print()
    print("--- first 600 chars of extracted text ---")
    print(text[:600])
    return 0


if __name__ == "__main__":
    sys.exit(main())
