#!/usr/bin/env python3
"""
waterfall_stage — email waterfall on the durable spine.

Each CONTACT is a JobStore unit, marked done the instant its email is resolved
(or all finders are exhausted). So a death/restart SKIPS done contacts and never
re-exports through AI Ark (1 credit each) — the per-unit version of the credit
guarantee. Per-contact first-hit-wins keeps the same economics as the staged
waterfall (Blitz tried first → AI Ark only sees Blitz-misses).

Finders, in priority order:  Blitz -> AI Ark -> KITT -> Icypeas -> LeadMagic.
Blitz/AIArk/KITT run per-contact (synchronous, first-hit-wins). Icypeas is bulk
(submit+poll), so it runs as a batched pass on the misses; LeadMagic then runs
on whatever's still missing — that keeps the priority order without making the
per-contact loop crawl on Icypeas's ~100s job latency.

Verification: EVERY email (AI Ark included — its own verification is unreliable)
goes through the MillionVerifier SINGLE API. An 'invalid' result DELETES the
address outright (apply_verdict); 'ok' = send-safe; catch_all/unknown are kept
for the operator-approved Scrubby pass.

Budget: --budget-aiark caps AI Ark export credits; once hit, AI Ark is skipped
for remaining contacts but the flat-rate finders still run.

Run under the venv. Supervisor progress via --jobstore.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_VENV = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV.exists() and Path(sys.executable).resolve() != _VENV.resolve():
    os.execv(str(_VENV), [str(_VENV)] + sys.argv)

import argparse
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts"))

from olympo_core import JobStore, Budget, prevent_sleep, sanity_ratio, contact_uid, reconcile  # noqa: E402
import enrich_waterfall as wf  # noqa: E402  (reuse find_blitz/find_aiark/find_kitt/find_leadmagic + read_contacts_sheet)

EMAIL_COLS = ["Email", "Email Source", "Verification", "Send Safe"]


def mv_single(key: str, email: str) -> str:
    for _ in range(3):
        try:
            r = requests.get("https://api.millionverifier.com/api/v3/",
                             params={"api": key, "email": email, "timeout": 10}, timeout=30)
            if r.status_code == 200:
                return (r.json().get("result") or "unknown").lower()
        except requests.RequestException:
            pass
    return "unknown"


def apply_verdict(res: dict, v: str) -> dict:
    """Apply a verifier verdict (MillionVerifier / Scrubby) to a result dict.

    RULE: an email determined INVALID is DELETED immediately — the address is
    wiped from the record so it can never reach the sender platform, in any tab
    or list. `ok` -> send-safe. Everything else (catch_all/unknown/disposable/
    role/unverified) -> not send-safe, email retained for catch-all review.
    """
    if v == "invalid":
        res["email"] = ""
        res["email_source"] = ""
        res["verification"] = "invalid"
        res["send_safe"] = "No"
    else:
        res["verification"] = v
        res["send_safe"] = "Yes" if v == "ok" else "No"
    return res


def _uid(p: dict) -> str:
    return contact_uid(p.get("linkedin", ""), p.get("first", ""), p.get("last", ""), p.get("domain", ""))


def process_contact(keys, budget, p) -> dict:
    # Waterfall priority: blitz -> ai ark -> kitt -> icypeas -> leadmagic.
    # Only the synchronous per-contact finders run here (blitz/aiark/kitt);
    # Icypeas (bulk) and then LeadMagic run as later passes on the misses so the
    # priority order is preserved without making the per-contact loop crawl.
    finders = [("blitz", wf.find_blitz), ("aiark", wf.find_aiark),
               ("kitt", wf.find_kitt)]
    email = src = None
    for name, fn in finders:
        if not keys.get(name):
            continue
        if name == "aiark" and budget.remaining() <= 0:
            continue  # AI Ark budget spent — skip it, keep trying flat-rate finders
        e = fn(keys[name], p)
        if e:
            email, src = e, name
            if name == "aiark":
                budget.add(1)
            break
    res = {"uid": _uid(p), "email": email or "", "email_source": src or "",
           "verification": "", "send_safe": ""}
    if email:
        # RULE: MillionVerifier-verify EVERY email regardless of source — AI Ark's
        # own verification is unreliable, so it gets MV-checked too.
        if keys.get("millionverifier"):
            apply_verdict(res, mv_single(keys["millionverifier"], email))
        else:
            res["verification"], res["send_safe"] = "unverified", "?"
    return res


def _mv(keys, res, email):
    if keys.get("millionverifier"):
        apply_verdict(res, mv_single(keys["millionverifier"], email))
    else:
        res["verification"], res["send_safe"] = "unverified", "?"


def process_blitz(keys, p) -> dict:
    """PHASE A: Blitz only. Blitz has no rate limit, so this pass runs at high
    concurrency over EVERY contact and resolves the bulk of them fast — instead of
    being serialized behind AI Ark's ~4.5 rps throttle in a per-contact chain."""
    res = {"uid": _uid(p), "email": "", "email_source": "", "verification": "", "send_safe": ""}
    if keys.get("blitz"):
        e = wf.find_blitz(keys["blitz"], p)
        if e:
            res["email"], res["email_source"] = e, "blitz"
            _mv(keys, res, e)
    return res


def process_aiark_kitt(keys, budget, p, prev) -> dict:
    """PHASE B: AI Ark -> KITT, only on Blitz-misses. This is where the rate limit
    lives, but it now runs over a much smaller set (the ~46% Blitz couldn't find)."""
    res = dict(prev); res["uid"] = _uid(p)
    for name, fn in [("aiark", wf.find_aiark), ("kitt", wf.find_kitt)]:
        if not keys.get(name):
            continue
        if name == "aiark" and budget.remaining() <= 0:
            continue
        e = fn(keys[name], p)
        if e:
            res["email"], res["email_source"] = e, name
            if name == "aiark":
                budget.add(1)
            _mv(keys, res, e)
            break
    return res


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--contacts-sheet")
    ap.add_argument("--tab", default="Contacts")
    ap.add_argument("--workers", type=int, default=10, help="Concurrency for the AI Ark/KITT pass (rate-limited).")
    ap.add_argument("--blitz-workers", type=int, default=32, help="Concurrency for the fast Blitz-first pass.")
    ap.add_argument("--budget-aiark", type=float, help="Max AI Ark export credits.")
    ap.add_argument("--jobstore", required=True)
    ap.add_argument("--progress", action="store_true")
    args = ap.parse_args()

    js = JobStore(args.jobstore)
    if args.progress:
        print(js.counts().get("done", 0), len(js.pending()))
        return 0

    prevent_sleep()
    keys = {k: wf.load_key(f"{k}.json") for k in ("aiark", "blitz", "kitt", "icypeas", "leadmagic")}
    keys["millionverifier"] = wf.load_key("millionverifier.json")
    budget = Budget(args.budget_aiark, "aiark-export")

    people = wf.read_contacts_sheet(args.contacts_sheet, args.tab)
    js.ingest((_uid(p), p) for p in people)
    pbu = {_uid(p): p for p in people}
    pending = js.pending()
    print(f"contacts: {len(people):,} | done (resume): {js.done_count():,} | to find now: {len(pending):,}")

    # PHASE A — Blitz on everything, fast (no rate limit). Mark ALL done (a Blitz
    # miss is recorded with email='' so later phases pick it up from results()).
    with ThreadPoolExecutor(max_workers=args.blitz_workers) as ex:
        futs = {ex.submit(process_blitz, keys, p): uid for uid, p in pending}
        n = 0
        for fut in as_completed(futs):
            uid = futs[fut]
            try:
                js.mark_done(uid, fut.result())
            except Exception as e:
                js.mark_error(uid, str(e)); continue
            n += 1
            if n % 1000 == 0:
                print(f"  [blitz] ...{n:,}/{len(pending):,}")
    hits = sum(1 for r in js.results().values() if r.get("email_source") == "blitz")
    print(f"  [blitz] pass done — {hits:,} resolved by Blitz")

    # PHASE B — AI Ark -> KITT, ONLY on the Blitz-misses (the rate-limited set).
    res0 = js.results()
    misses = [(uid, pbu[uid]) for uid, r in res0.items() if not r.get("email") and uid in pbu]
    print(f"  [aiark/kitt] {len(misses):,} Blitz-misses to chase")
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(process_aiark_kitt, keys, budget, pbu[uid], res0[uid]): uid for uid, _ in misses}
        n = 0
        for fut in as_completed(futs):
            uid = futs[fut]
            try:
                js.mark_done(uid, fut.result())
            except Exception as e:
                js.mark_error(uid, str(e)); continue
            n += 1
            if n % 500 == 0:
                print(f"  [aiark/kitt] ...{n:,}/{len(misses):,} | AI Ark spent ~{budget.spent:.0f}")

    # Icypeas BULK mop-up on the still-missing (Icypeas is bulk-designed, so it
    # runs as a final batched pass rather than per-contact — the 5th provider).
    if keys.get("icypeas"):
        res0 = js.results()
        pbu = {_uid(p): p for p in people}
        missing = [(uid, pbu[uid]) for uid, r in res0.items() if not r.get("email") and uid in pbu]
        added = 0
        for i in range(0, len(missing), 5000):  # Icypeas job cap
            chunk = missing[i:i + 5000]
            sub = [{"first": p.get("first", ""), "last": p.get("last", ""), "domain": p.get("domain", "")} for _, p in chunk]
            try:
                got = wf.find_icypeas_bulk(keys["icypeas"], sub)
            except Exception:
                got = {}
            for li, (uid, _) in enumerate(chunk):
                if got.get(li):
                    r = res0[uid]; r["email"], r["email_source"] = got[li], "icypeas"
                    if keys.get("millionverifier"):
                        apply_verdict(r, mv_single(keys["millionverifier"], got[li]))
                    js.mark_done(uid, r); added += 1
        print(f"  icypeas bulk mop-up: +{added} emails")

    # LeadMagic is LAST in the waterfall (after Icypeas), so it only runs on the
    # contacts still missing an email once every earlier provider has been tried.
    if keys.get("leadmagic"):
        res0 = js.results()
        pbu = {_uid(p): p for p in people}
        still = [(uid, pbu[uid]) for uid, r in res0.items() if not r.get("email") and uid in pbu]

        def _leadmagic_one(uid, p):
            e = wf.find_leadmagic(keys["leadmagic"], p)
            if not e:
                return None
            r = res0[uid]; r["email"], r["email_source"] = e, "leadmagic"
            if keys.get("millionverifier"):
                apply_verdict(r, mv_single(keys["millionverifier"], e))
            return uid, r

        added = 0
        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            for out in ex.map(lambda t: _leadmagic_one(*t), still):
                if out:
                    js.mark_done(out[0], out[1]); added += 1
        print(f"  leadmagic pass: +{added} emails")

    # NOTE: Barracuda/Mimecast filtering happens upstream at the contact-pull
    # stage (find_contacts.mail_blocked, off AI Ark's native company.technologies),
    # so those companies never reach this sheet — no MX pass needed here.

    # results -> write 4 columns back to the sheet, matched by uid
    results = js.results()
    got = [r for r in results.values() if r.get("email")]
    safe = [r for r in got if r.get("send_safe") == "Yes"]
    print(f"\n{len(got):,}/{len(results):,} emails found; {len(safe):,} send-safe.")
    # guard against the silent-verify failure: if we have emails but ~none verified OK, abort the write
    nonaiark = [r for r in got if r.get("email_source") != "aiark"]
    if nonaiark:
        sanity_ratio("mv-verify", nonaiark, lambda r: r.get("verification") in ("ok", "catch_all", "invalid", "unknown") and r.get("send_safe") in ("Yes", "No"), 0.5)
    _write_back(args.contacts_sheet, args.tab, results)
    return 0


def _write_back(sheet_url, tab, results):
    from olympo_core import read_columns, ensure_columns, write_block, a1col
    from olympo_auth import get_sheets_service
    import re
    sid = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", sheet_url).group(1)
    svc = get_sheets_service()
    header, cols = read_columns(svc, sid, tab, ["LinkedIn", "First Name", "Last Name", "Website"])
    n = max((len(v) for v in cols.values()), default=0)
    def uid_for(i):
        # SAME canonical uid the read side used — no second, drifting definition.
        return contact_uid(
            cols.get("LinkedIn", [""] * n)[i] if i < len(cols.get("LinkedIn", [])) else "",
            cols.get("First Name", [""] * n)[i] if i < len(cols.get("First Name", [])) else "",
            cols.get("Last Name", [""] * n)[i] if i < len(cols.get("Last Name", [])) else "",
            cols.get("Website", [""] * n)[i] if i < len(cols.get("Website", [])) else "")
    # RECONCILE: every found email must land on a sheet row. If a result's uid
    # matches no row, abort rather than silently drop it.
    sheet_uids = {uid_for(i) for i in range(n)}
    found = [u for u, r in results.items() if r.get("email")]
    placed = [u for u in found if u in sheet_uids]
    reconcile("waterfall-writeback", len(found), len(placed),
              leaked=[u for u in found if u not in sheet_uids])
    idx = ensure_columns(svc, sid, tab, header, EMAIL_COLS)
    lo = min(idx[c] for c in EMAIL_COLS)
    block = []
    for i in range(n):
        r = results.get(uid_for(i)) or {}
        block.append([r.get("email", ""), r.get("email_source", ""), r.get("verification", ""), r.get("send_safe", "")])
    write_block(svc, sid, tab, lo, block)
    print(f"wrote {EMAIL_COLS} to {n:,} rows.")


if __name__ == "__main__":
    raise SystemExit(main())
