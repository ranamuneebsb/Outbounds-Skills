#!/usr/bin/env python3
"""
expand_stage — squeeze MORE same-ICP contacts when the verified list is too small.

OPERATOR-INVOKED, AFTER step 5 (Scrubby). If the verified + catch-all-valid list
is too thin, the operator can ask to grow it for the SAME ICP — but only in ways
that keep quality and that STOP rather than bleed credits on a dud. Grounded in
AI Ark's real search API (docs.ai-ark.com), three structurings the original
domain-by-title build doesn't use:

  widen-titles   — SAME qualified companies, broadened contact filter (extra
                   relevant titles + seniority founder/head/senior + finance/exec
                   departments). More relevant SEATS per company. Highest quality,
                   cheapest (companies already passed the ICP gate). -> Contacts sheet.

  people-account — People Search by ACCOUNT filters with NO domain (industries +
                   employeeSize + location + the SAME DM titles/seniority/dept).
                   Surfaces same-ICP contacts at companies that never made the
                   original company list. -> Contacts sheet.

  more-companies — Company Search for MORE same-ICP companies via (a) lookalike
                   seeds (our best converters, max 5) and (b) STRATIFIED slicing
                   (employeeSize bands / NAICS / DESCRIPTION keywords) to beat the
                   100/page + totalPages ceilings. New companies are appended
                   UNSCORED -> the score stage re-qualifies them through the SAME
                   rubric before any DM-pull spend. -> Companies sheet.

QUALITY + CREDIT GUARDS (the point — never build garbage, never waste credits):
  • Dedup FIRST against the existing list; only NET-NEW counts.
  • Same quality filters as the main build (keep_title/EXCLUDE + Barracuda/Mimecast).
  • New companies are RE-SCORED through the same rubric (no auto-trust).
  • YIELD PROBE + ABORT: after a small probe window, if net-new-per-result is
    below --min-yield, STOP and report — don't spend the budget on a dud.
  • --budget hard cap. If nothing clears the bar, append NOTHING and say so.

The ICP is reused verbatim from an --icp-file (same account/title definition as the
original campaign) so "same exact ICP" is guaranteed, not re-guessed.

Run under the venv.
"""
from __future__ import annotations
import os, sys, json, time
from pathlib import Path
_VENV = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV.exists() and Path(sys.executable).resolve() != _VENV.resolve():
    os.execv(str(_VENV), [str(_VENV)] + sys.argv)

import argparse, requests
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts"))
from olympo_core import JobStore, Budget, prevent_sleep, norm_domain, contact_uid
from olympo_auth import get_sheets_service
import find_contacts as fc   # keep_title, EXCLUDE, mail_blocked, _title_of

BASE = "https://api.ai-ark.com/api/developer-portal/v1"


class OutOfCredits(RuntimeError):
    """AI Ark returned 402 — the account is out of credits. ABORT, never treat as empty."""


class AiArkAuthError(RuntimeError):
    """AI Ark returned 401 — bad key or wrong path. Surface, never treat as empty."""


def _key():
    return json.load(open(str(Path.home() / ".olympolabs" / "aiark.json")))["api_key"]


def _post(path, body, key):
    # Error-code handling per references/aiark-api.md §1:
    #   402 = out of credits  -> raise (abort); the old "treat as empty" hid the real cause
    #   401 = bad key / wrong path -> raise (surface), don't silently retry-into-empty
    #   400 = pagination-limit/bad band, 404 = genuinely empty -> stop paging this band
    #   429 / 5xx / network -> back off and retry
    for _ in range(3):
        try:
            r = requests.post(BASE + path, headers={"X-TOKEN": key, "Content-Type": "application/json"}, json=body, timeout=60)
            if r.status_code == 200:
                return r.json()
            if r.status_code == 402:
                raise OutOfCredits(f"AI Ark 402 (out of credits) on {path}. Top up before continuing.")
            if r.status_code == 401:
                raise AiArkAuthError(f"AI Ark 401 on {path} — check the API key and the request path.")
            if r.status_code in (400, 404):
                return {}
        except requests.RequestException:
            pass
        time.sleep(2)
    return {}


# ---- ICP -> AI Ark filter objects (confirmed schema) ---------------------------
def account_filter(icp, employee_band=None):
    a = icp.get("account", {}) or {}
    acc = {}
    if a.get("industries"):
        inc = {"any": {"include": {"mode": "WORD", "content": a["industries"]}}}
        if a.get("industries_exclude"):
            inc["any"]["exclude"] = {"mode": "WORD", "content": a["industries_exclude"]}
        acc["industries"] = inc
    if a.get("location"):
        acc["location"] = {"any": {"include": a["location"]}}
    if a.get("naics"):
        acc["naics"] = {"any": {"include": a["naics"]}}   # plain code array; the `any` wrapper is REQUIRED or AI Ark silently ignores it
    if a.get("keywords"):
        acc["keyword"] = {"any": {"include": {"sources": [{"mode": "SMART", "source": "DESCRIPTION"}], "content": a["keywords"]}}}
    if a.get("technologies"):
        acc["technologies"] = {"any": {"include": {"mode": "WORD", "content": a["technologies"]}}}
    band = employee_band or a.get("employeeSize")
    if band:
        rng = [{"start": band[0], "end": band[1]}] if isinstance(band, (list, tuple)) and band and not isinstance(band[0], (list, tuple)) else [{"start": s, "end": e} for s, e in band]
        acc["employeeSize"] = {"type": "RANGE", "range": rng}
    return acc


def contact_filter(icp, titles):
    ct = icp.get("contact", {}) or {}
    c = {"experience": {"current": {"title": {"any": {"include": {"mode": "SMART", "content": titles}}}}}}
    if ct.get("seniority"):
        c["seniority"] = {"any": {"include": ct["seniority"]}}
    if ct.get("department"):
        c["department"] = {"any": {"include": ct["department"]}}
    return c


# ---- dedup loaders -------------------------------------------------------------
def existing_people(svc, sid, tab):
    grid = svc.spreadsheets().values().get(spreadsheetId=sid, range=f"{tab}!A1:K").execute().get("values", [])
    if not grid:
        return set(), set()
    h = [c.strip().lower() for c in grid[0]]
    def ix(*names):
        for nm in names:
            if nm in h:
                return h.index(nm)
        return None
    fi, li, wi, lni = ix("first name"), ix("last name"), ix("website", "domain"), ix("linkedin")
    uids, domains = set(), set()
    for r in grid[1:]:
        def g(i):
            return (r[i] if i is not None and i < len(r) else "") or ""
        dom = norm_domain(g(wi))
        if dom:
            domains.add(dom)
        uids.add(contact_uid(g(lni), g(fi), g(li), dom))
    return uids, domains


def existing_company_domains(svc, sid):
    grid = svc.spreadsheets().values().get(spreadsheetId=sid, range="Companies!A2:B").execute().get("values", [])
    return {norm_domain((r + ["", ""])[1]) for r in grid if len(r) > 1 and norm_domain(r[1])}


# ---- people result -> canonical contact row (quality-filtered) -----------------
def person_to_row(p):
    if fc.mail_blocked(p):                       # Barracuda/Mimecast -> drop
        return None
    title = fc._title_of(p)
    if not fc.keep_title(title):                 # same EXCLUDE/KEEP gate as the build
        return None
    prof = p.get("profile", {}) or {}
    comp = (p.get("company", {}) or {})
    dom = norm_domain(comp.get("link", {}).get("domain") if isinstance(comp.get("link"), dict) else comp.get("domain") or "")
    fn = (prof.get("first_name") or "").strip()
    ln = (prof.get("last_name") or "").strip()
    li = (p.get("link", {}) or {}).get("linkedin") or ""
    if not (fn and ln and dom):
        return None
    return {"company": comp.get("name", ""), "domain": dom, "first": fn, "last": ln,
            "title": title, "linkedin": li, "uid": contact_uid(li, fn, ln, dom)}


# ---- yield-guarded harvest -----------------------------------------------------
def harvest_people(key, account, contact, seen_uids, budget, min_yield, probe_pages, max_pages):
    """Page through People Search; dedup; ABORT once net-new yield drops below floor."""
    new, returned, net = [], 0, 0
    for page in range(max_pages):
        if budget.remaining() <= 0:
            print("  budget cap reached — stopping."); break
        body = {"account": account, "contact": contact, "page": page, "size": 100}
        js = _post("/people", body, key)
        items = js.get("content") or []
        total_pages = js.get("totalPages", page + 1)
        if not items:
            break
        returned += len(items)
        budget.add(0.5 * len(items))             # People Search bills ~0.5 / person returned
        for p in items:
            row = person_to_row(p)
            if row and row["uid"] not in seen_uids:
                seen_uids.add(row["uid"]); new.append(row); net += 1
        if page + 1 >= probe_pages:
            y = net / max(returned, 1)
            if y < min_yield:
                print(f"  net-new yield {y:.0%} < floor {min_yield:.0%} after {page+1} pages — ABORTING (not worth more credits).")
                break
        if page + 1 >= total_pages:
            break
    return new, returned, net


def harvest_companies(key, icp, seed_domains, existing_doms, budget, min_yield, probe_pages, max_pages):
    """Lookalike + stratified Company Search; dedup vs existing; yield-abort. Returns NEW companies (unscored)."""
    bands = (icp.get("account", {}) or {}).get("employeeSize") or [[20, 500]]
    if bands and not isinstance(bands[0], (list, tuple)):
        bands = [bands]
    new, seen, returned, net = [], set(existing_doms), 0, 0
    for band in bands:                            # stratify by employee band to beat the per-search ceiling
        acc = account_filter(icp, employee_band=band)
        for page in range(max_pages):
            if budget.remaining() <= 0:
                print("  budget cap reached — stopping."); return new, returned, net
            body = {"account": acc, "page": page, "size": 100}
            if seed_domains:
                body["lookalikeDomains"] = seed_domains[:5]
            js = _post("/companies", body, key)   # Company Search is PLURAL; /company (singular) returns 401
            items = js.get("content") or []
            total_pages = js.get("totalPages", page + 1)
            if not items:
                break
            returned += len(items)
            budget.add(0.1 * len(items))             # Company Search bills ~0.1 / company returned — NOT free
            for c in items:
                dom = norm_domain((c.get("link", {}) or {}).get("domain") if isinstance(c.get("link"), dict) else c.get("domain") or "")
                if dom and dom not in seen:
                    seen.add(dom); new.append({"company": c.get("name", ""), "domain": dom}); net += 1
            if page + 1 >= probe_pages:
                y = net / max(returned, 1)
                if y < min_yield:
                    print(f"  band {band}: net-new yield {y:.0%} < floor {min_yield:.0%} — moving on (not worth more).")
                    break
            if page + 1 >= total_pages:
                break
    return new, returned, net


# ---- appenders -----------------------------------------------------------------
def append_contacts(svc, sid, tab, rows):
    HEAD = fc.OUTPUT_HEADERS
    body = [[r["company"], r["domain"], "100", r["first"], r["last"], r["title"], "", "", r["linkedin"], "", ""] for r in rows]
    svc.spreadsheets().values().append(spreadsheetId=sid, range=f"{tab}!A1",
        valueInputOption="RAW", insertDataOption="INSERT_ROWS", body={"values": body}).execute()


def append_companies(svc, sid, rows):
    body = [[r["company"], r["domain"], "", "", "", "", "", "", "", "", ""] for r in rows]  # verdict BLANK -> must be re-scored
    svc.spreadsheets().values().append(spreadsheetId=sid, range="Companies!A1",
        valueInputOption="RAW", insertDataOption="INSERT_ROWS", body={"values": body}).execute()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strategy", required=True, choices=["widen-titles", "people-account", "more-companies"])
    ap.add_argument("--icp-file", required=True, help="JSON: the SAME ICP (account filters + titles/seniority/department + lookalike_seeds).")
    ap.add_argument("--contacts-sheet", help="Working Contacts sheet (widen-titles / people-account append here; also the dedup source).")
    ap.add_argument("--contacts-tab", default="Contacts")
    ap.add_argument("--companies-sheet", help="Companies sheet (more-companies appends here; widen-titles reads qualified companies here).")
    ap.add_argument("--budget", type=float, required=True, help="Hard credit ceiling for this expansion.")
    ap.add_argument("--min-yield", type=float, default=0.15, help="Abort a strategy if net-new/returned falls below this after the probe.")
    ap.add_argument("--probe-pages", type=int, default=2, help="Pages to sample before the yield check kicks in.")
    ap.add_argument("--max-pages", type=int, default=50)
    args = ap.parse_args()

    icp = json.loads(Path(args.icp_file).read_text())
    key = _key()
    budget = Budget(args.budget, "expand")
    prevent_sleep()
    svc = get_sheets_service()

    def sid_of(url):
        import re
        return re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", url).group(1)

    if args.strategy in ("widen-titles", "people-account"):
        if not args.contacts_sheet:
            ap.error("this strategy needs --contacts-sheet.")
        csid = sid_of(args.contacts_sheet)
        seen_uids, _ = existing_people(svc, csid, args.contacts_tab)
        titles = (icp.get("contact", {}).get("titles") or []) + (icp.get("contact", {}).get("titles_widen") or [])
        contact = contact_filter(icp, titles)

        if args.strategy == "widen-titles":
            if not args.companies_sheet:
                ap.error("widen-titles needs --companies-sheet (the qualified companies to re-sweep).")
            ssid = sid_of(args.companies_sheet)
            from find_contacts import read_qualified
            companies = read_qualified(args.companies_sheet, 0)
            print(f"widen-titles: re-sweeping {len(companies):,} qualified companies for {len(titles)} relevant titles.")
            all_new = []
            for c in companies:
                if budget.remaining() <= 0:
                    print("  budget cap reached — stopping."); break
                acc = {"domain": {"any": {"include": [c["website"]]}}}
                got, ret, net = harvest_people(key, acc, contact, seen_uids, budget, args.min_yield, 999, 1)
                all_new += got
            new, returned, net = all_new, None, len(all_new)
        else:  # people-account
            account = account_filter(icp)
            print("people-account: People Search by industry+size+location (no domain), same DM titles.")
            new, returned, net = harvest_people(key, account, contact, seen_uids, budget, args.min_yield, args.probe_pages, args.max_pages)

        if not new:
            print("\nNO net-new quality contacts cleared the bar — appending NOTHING (won't pad the list)."); return 0
        append_contacts(svc, csid, args.contacts_tab, new)
        print(f"\n+{len(new):,} NET-NEW quality contacts appended. Re-run the WATERFALL (durable: only the new ones get enriched), then Scrubby.")
        print(f"  AI Ark spent ~{budget.spent:.0f} credits.")
        return 0

    # more-companies
    if not args.companies_sheet:
        ap.error("more-companies needs --companies-sheet.")
    ssid = sid_of(args.companies_sheet)
    existing_doms = existing_company_domains(svc, ssid)
    seeds = [norm_domain(d) for d in (icp.get("lookalike_seeds") or [])][:5]
    print(f"more-companies: lookalike(seeds={len(seeds)}) + stratified Company Search; dedup vs {len(existing_doms):,} existing.")
    new, returned, net = harvest_companies(key, icp, seeds, existing_doms, budget, args.min_yield, args.probe_pages, args.max_pages)
    if not new:
        print("\nNO net-new same-ICP companies cleared the bar — appending NOTHING."); return 0
    append_companies(svc, ssid, new)
    print(f"\n+{len(new):,} NET-NEW companies appended UNSCORED. Re-run SCORE (re-qualifies them through the SAME rubric) -> contacts -> waterfall.")
    print(f"  These are NOT trusted yet — the score gate decides. AI Ark spent ~{budget.spent:.0f} credits.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except OutOfCredits as e:
        print(f"\nABORTED: {e}\n  Out of AI Ark credits — appended NOTHING. Top up (GET /payments/credits) and re-run; dedup means no double-pull.")
        raise SystemExit(2)
    except AiArkAuthError as e:
        print(f"\nABORTED: {e}\n  Appended NOTHING.")
        raise SystemExit(2)
