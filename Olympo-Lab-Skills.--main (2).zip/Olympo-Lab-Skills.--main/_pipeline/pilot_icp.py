#!/usr/bin/env python3
"""Pilot: scrape N send-safe domains and extract each company's ICP (who they
sell to) as a short phrase. Prints domain -> ICP for review before scaling."""
import os, sys, json, requests
from pathlib import Path
_VENV = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV.exists() and Path(sys.executable).resolve() != _VENV.resolve():
    os.execv(str(_VENV), [str(_VENV)] + sys.argv)

sys.path.insert(0, "/Users/bryanlopez/Desktop/OlympoLabs-Skills/_pipeline")
sys.path.insert(0, str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts"))
import scrape_domains as sd  # gives scrape_one + a ZenRowsClient class
from olympo_auth import get_sheets_service
from olympo_core import a1col
from concurrent.futures import ThreadPoolExecutor

N = int(sys.argv[1]) if len(sys.argv) > 1 else 20
SID = "1iwmQ7IfFzpYOgwGioba0BRzNCNZC6zFU9wWnCWzt6ao"
ORKEY = json.load(open(str(Path.home() / ".olympolabs" / "openrouter.json")))["api_key"]
SYS = (
    "You analyze a wholesale/distribution company's website to describe WHO they sell to "
    "(their customers / ICP — the BUSINESSES they distribute to, not what they sell), and "
    "produce two fields. Return ONLY JSON: {\"icp\": \"...\", \"cause\": \"...\"}.\n\n"
    "icp: the customer type they sell to, as a short phrase, lowercase, no period. If they "
    "sell to MORE THAN TWO types, name only the FIRST TWO, joined with 'and'. "
    "Examples: 'bars and restaurants', 'plumbing and HVAC contractors', 'auto repair shops', "
    "'lumber and building materials dealers'.\n\n"
    "cause: a warm one-line cold-email fragment, format EXACTLY: 'so you can help more <icp> "
    "<the meaningful thing those customer businesses ultimately do in the world>'. Lowercase "
    "start, no period, keep it tight. The ending should capture the customers' real purpose. "
    "Examples: 'so you can help more bars and restaurants bring people together', "
    "'so you can help more contractors build stronger communities', "
    "'so you can help more farmers feed the country', "
    "'so you can help more repair shops keep people on the road'."
)


def gen(company, text):
    try:
        r = requests.post("https://openrouter.ai/api/v1/chat/completions",
                          headers={"Authorization": f"Bearer {ORKEY}", "Content-Type": "application/json"},
                          json={"model": "anthropic/claude-sonnet-4.6", "temperature": 0.3, "max_tokens": 90,
                                "response_format": {"type": "json_object"},
                                "messages": [{"role": "system", "content": SYS},
                                             {"role": "user", "content": f"Company: {company}\nDomain content:\n{text[:4500]}"}]},
                          timeout=60)
        content = r.json()["choices"][0]["message"]["content"].strip()
        import re
        m = re.search(r"\{.*\}", content, re.DOTALL)
        o = json.loads(m.group(0) if m else content)
        return o.get("icp", ""), o.get("cause", "")
    except Exception as e:
        return f"(error: {type(e).__name__})", ""


# read send-safe domains + company names
svc = get_sheets_service()
hdr = [h.strip().lower() for h in svc.spreadsheets().values().get(spreadsheetId=SID, range="Contacts!A1:Z1").execute().get("values", [[]])[0]]
ci, bi, si = hdr.index("company"), hdr.index("website"), hdr.index("send safe")
g = svc.spreadsheets().values().batchGet(spreadsheetId=SID, ranges=[
    f"Contacts!{a1col(ci+1)}2:{a1col(ci+1)}", f"Contacts!{a1col(bi+1)}2:{a1col(bi+1)}", f"Contacts!{a1col(si+1)}2:{a1col(si+1)}"]).execute()["valueRanges"]
comp = [r[0] if r else "" for r in g[0].get("values", [])]
dom = [r[0] if r else "" for r in g[1].get("values", [])]
safe = [r[0] if r else "" for r in g[2].get("values", [])]
seen, picks = set(), []
for i in range(len(safe)):
    if safe[i].strip().lower() == "yes" and i < len(dom):
        d = sd._norm_domain(dom[i])
        if d and d not in seen:
            seen.add(d); picks.append((comp[i] if i < len(comp) else "", d))
    if len(picks) >= N:
        break

client = sd.ZenRowsClient()
print(f"scraping + ICP-extracting {len(picks)} send-safe domains...\n")


def work(item):
    company, d = item
    text = sd.scrape_one(client, d, 6000)
    if not text:
        return company, d, "(no scrape)", ""
    ic, cause = gen(company, text)
    return company, d, ic, cause


with ThreadPoolExecutor(max_workers=8) as ex:
    results = list(ex.map(work, picks))

for company, d, ic, cause in results:
    print(f"\n{company[:34]} — {d}")
    print(f"  ICP:   {ic}")
    print(f"  cause: {cause}")
