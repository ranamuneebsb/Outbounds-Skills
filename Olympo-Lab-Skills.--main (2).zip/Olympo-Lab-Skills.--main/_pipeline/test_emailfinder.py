#!/usr/bin/env python3
"""Small test: People Search -> trackId -> Find Emails by trackId, measuring the
credit cost of EACH step. Proves the efficient 0.5(search) + 0.5(email-only)
model with no double profile charge."""
import sys, json, time, subprocess, threading, http.server, re
from pathlib import Path
sys.path.insert(0, "/Users/bryanlopez/Desktop/OlympoLabs-Skills/_pipeline")
sys.path.insert(0, str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts"))
import requests

BASE = "https://api.ai-ark.com/api/developer-portal/v1"
K = json.load(open(str(Path.home() / ".olympolabs" / "aiark.json")))["api_key"]
H = {"X-TOKEN": K, "Content-Type": "application/json"}
PORT = 8089
HOOK = "/tmp/aiark_emailfinder.jsonl"
open(HOOK, "w").close()


def bal():
    return requests.get(f"{BASE}/payments/credits", headers={"X-TOKEN": K}, timeout=30).json().get("total")


class Hd(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        open(HOOK, "a").write(self.rfile.read(n).decode("utf-8", "replace") + "\n")
        self.send_response(200); self.end_headers(); self.wfile.write(b"ok")
    def log_message(self, *a): pass


srv = http.server.HTTPServer(("0.0.0.0", PORT), Hd)
threading.Thread(target=srv.serve_forever, daemon=True).start()
tp = subprocess.Popen(["cloudflared", "tunnel", "--url", f"http://localhost:{PORT}"],
                      stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
url = None; t0 = time.time()
while time.time() - t0 < 45:
    line = tp.stdout.readline()
    if line:
        m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
        if m:
            url = m.group(0); break
    else:
        time.sleep(0.2)
print("tunnel:", url)
if not url:
    tp.terminate(); sys.exit("no tunnel")
time.sleep(3)

# STEP 1: People Search for one company (finance titles), small size
b0 = bal()
search_body = {
    "account": {"domain": {"any": {"include": ["wolfcreekcompany.com"]}}},
    "contact": {"experience": {"current": {"title": {"any": {"include": {
        "mode": "SMART", "content": ["cfo", "controller", "owner", "president", "ceo", "vp finance"]}}}}}},
    "page": 0, "size": 8,
}
r = requests.post(f"{BASE}/people", headers=H, json=search_body, timeout=60)
js = r.json()
tid = js.get("trackId")
people = js.get("content") or []
b1 = bal()
print(f"\n[1] People Search: {len(people)} people | trackId={tid} | cost: {b0-b1} credits ({(b0-b1)/max(len(people),1):.2f}/person)")

# STEP 2: Find Emails by trackId (email-only — profile already paid in search)
r2 = requests.post(f"{BASE}/people/email-finder", headers=H, json={"trackId": tid, "webhook": url + "/hook"}, timeout=60)
print(f"[2] email-finder submit: {r2.status_code} {r2.text[:160]}")

got = None
for _ in range(60):
    time.sleep(5)
    lines = [l for l in open(HOOK).read().splitlines() if l.strip()]
    if lines:
        got = lines; break
b2 = bal()
emails = 0
if got:
    obj = json.loads(got[-1])
    data = obj.get("data") or []
    emails = sum(1 for d in data if (d.get("email") or {}).get("output"))
    print(f"[2] webhook: {obj.get('statistics')} | records={len(data)} emails={emails}")
print(f"[2] email-finder cost: {b1-b2} credits  -> {(b1-b2)/max(emails,1):.2f} per email found")
print(f"\nTOTAL for {len(people)} contacts: search {b0-b1} + emails {b1-b2} = {b0-b2} credits")
tp.terminate(); srv.shutdown()
