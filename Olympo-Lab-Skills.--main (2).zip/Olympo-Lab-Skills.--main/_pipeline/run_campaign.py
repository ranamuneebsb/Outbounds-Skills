#!/usr/bin/env python3
"""
run_campaign — the unattended orchestrator.

After the 5-minute front-loaded setup (which produces a config JSON), this runs
the whole back half of the pipeline with ZERO further input:

    contacts -> waterfall -> normalize -> personalize

PERSONALIZATION BRANCH (asked at setup — "will this list have personalizations?"):
  • YES -> the list was SCORED by SCRAPING each domain (ZenRows) and rating off
    the scrape; that same scrape is reused for personalization, so we never scrape
    twice. There is NO standalone scrape stage — it's folded into scoring.
  • NO  -> the list was scored by DESCRIPTION only (no scrape), and there is no
    personalize stage. Scraping a list we won't personalize would be wasted spend.

Every stage runs under supervise.py (death-proof, resumes from its checkpoint),
each with its own progress probe and budget ceiling. Preflight checks Google auth
(auto-reauth if needed, at the start only) and every required API key BEFORE any
spend, so the run can't die halfway on a missing key or expired token.

Config (JSON) keys:
  sheet_url, source_sheet, exclude_csv, dm_titles, search_size, max_per_company,
  budgets{contacts,...}, stages[...], plus per-run paths.

Self-test:  run_campaign.py --selftest   (runs two stub stages under supervision)
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from olympo_auth import ensure_google_ready, check_publishing_hint  # noqa: E402

VENV = str(Path.home() / ".olympolabs" / "venv" / "bin" / "python")
DM = str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts")
SUPERVISE = str(HERE / "supervise.py")

# Required key files per stage (preflight checks these exist before spending).
STAGE_KEYS = {
    "ingest":      [],  # pure sheet reshape, no API keys (Google auth checked in preflight)
    # score: Sonnet rating (OpenRouter). It scrapes only when personalize=true,
    # in which case the personalize stage already enforces zenrows.json.
    "score":       ["openrouter.json"],
    "contacts":    ["aiark.json"],
    "waterfall":   ["aiark.json", "blitz.json", "kitt.json", "icypeas.json", "leadmagic.json", "millionverifier.json"],
    "normalize":   ["openrouter.json"],
    # personalize scrapes (ZenRows) + rates/writes (Sonnet via OpenRouter); the
    # scrape is the same one scoring used, so there's no separate scrape stage.
    "personalize": ["zenrows.json", "openrouter.json"],
}


def _keys_present(stage: str) -> list:
    base = Path.home() / ".olympolabs"
    return [k for k in STAGE_KEYS.get(stage, []) if not (base / k).exists()]


def build_stages(cfg: dict) -> list:
    """Map config -> ordered stage specs: {name, cmd[], progress_cmd, jobstore?}.
    Progress probes count the stage's own checkpoint so the supervisor knows when
    a stage is genuinely complete (pending==0)."""
    sheet = cfg["sheet_url"]
    ckpt = cfg.get("ckpt_dir", "/tmp/campaign")
    os.makedirs(ckpt, exist_ok=True)
    s = {}

    # INGEST — universal front door when you already HAVE a list (domains / companies
    # / contacts) instead of building one. Reshapes it into the canonical tab the
    # downstream stages read. domains/companies -> Companies tab on source_sheet;
    # contacts -> Contacts tab on the working sheet (then start at the waterfall).
    ig = cfg.get("ingest")
    if ig:
        kind = ig["kind"]
        out_sheet = sheet if kind == "contacts" else cfg.get("source_sheet")
        isent = f"{ckpt}/ingest.done"
        icmd = [VENV, f"{HERE}/ingest_stage.py", "--source", ig["source"], "--kind", kind,
                "--out-sheet", out_sheet, "--sentinel", isent]
        if ig.get("source_tab"):
            icmd += ["--source-tab", ig["source_tab"]]
        s["ingest"] = {"name": "ingest", "cmd": icmd,
                       "progress_cmd": f"bash -c 'test -f {isent} && echo 1 0 || echo 0 1'"}

    # SCORE — the governed front-of-funnel gate. Writes Qualified verdicts (+ score
    # + reason) onto the same Companies sheet the contacts stage then reads. Scrapes
    # only when personalize=true, and persists that scrape for the personalize stage
    # to reuse (scrape once). Requires a rubric.
    if cfg.get("source_sheet") and cfg.get("rubric"):
        sc = [VENV, f"{HERE}/score_stage.py", "--companies-sheet", cfg["source_sheet"],
              "--jobstore", f"{ckpt}/score.db", "--rubric", cfg["rubric"]]
        if cfg.get("personalize"):
            sc += ["--scrape"]
        if cfg.get("budgets", {}).get("score"):
            sc += ["--budget", str(cfg["budgets"]["score"])]
        s["score"] = {"name": "score", "cmd": sc, "jobstore": f"{ckpt}/score.db"}

    if cfg.get("source_sheet"):
        cc = [VENV, f"{HERE}/contacts_stage.py", "--source-sheet", cfg["source_sheet"],
              "--jobstore", f"{ckpt}/contacts.db",
              "--search-size", str(cfg.get("search_size", 10)),
              "--max-per-company", str(cfg.get("max_per_company", 8)),
              "--out-title", cfg.get("contacts_title", "OlympoLabs — Decision-Makers")]
        if cfg.get("exclude_csv"):
            cc += ["--exclude-csv", cfg["exclude_csv"]]
        if cfg.get("skip_known"):
            cc += ["--skip-known-companies"]
        if cfg.get("budgets", {}).get("contacts"):
            cc += ["--budget-credits", str(cfg["budgets"]["contacts"])]
        s["contacts"] = {"name": "contacts", "cmd": cc, "jobstore": f"{ckpt}/contacts.db"}

    wcmd = [VENV, f"{HERE}/waterfall_stage.py", "--contacts-sheet", sheet,
            "--jobstore", f"{ckpt}/waterfall.db", "--workers", "10"]
    if cfg.get("budgets", {}).get("waterfall_aiark"):
        wcmd += ["--budget-aiark", str(cfg["budgets"]["waterfall_aiark"])]
    s["waterfall"] = {"name": "waterfall", "cmd": wcmd, "jobstore": f"{ckpt}/waterfall.db"}

    normalizer = str(Path.home() / ".claude" / "skills" / "name-normalizer" / "scripts" / "normalize_sheet.py")
    nsent = f"{ckpt}/normalize.done"
    s["normalize"] = {
        "name": "normalize",
        # idempotent + fast; supervise by sentinel (retry whole stage on death)
        "cmd": ["bash", "-c", f"python3 {normalizer} --sheet-url '{sheet}' --concurrency 16 --write-batch-size 2000 && touch {nsent}"],
        "progress_cmd": f"bash -c 'test -f {nsent} && echo 1 0 || echo 0 1'",
    }

    # PERSONALIZE: only when the operator said this list has personalizations.
    # icp_cause_stage.py scrapes each send-safe domain AND rates it (custom_icp +
    # custom_cause) in one durable per-domain pass — the single scrape is the same
    # one scoring used, so there is NO separate scrape stage (step 7 removed).
    if cfg.get("personalize"):
        s["personalize"] = {
            "name": "personalize",
            # --reuse-scrape-jobstore: pull the scrape the score stage already paid
            # for (keyed by domain) instead of scraping again — scrape once.
            "cmd": [VENV, f"{HERE}/icp_cause_stage.py", "--sheet", sheet,
                    "--jobstore", f"{ckpt}/personalize.db", "--workers", "8",
                    "--reuse-scrape-jobstore", f"{ckpt}/score.db"],
            "jobstore": f"{ckpt}/personalize.db",
        }

    # Default order. 'scrubby' is reserved BEFORE personalize: catch-all-valids
    # only become sendable (Send Safe=Yes) once Scrubby confirms them, and
    # personalize keys off Send Safe=Yes — so personalize MUST run after Scrubby
    # or catch-all-valids would ship un-personalized. Stages not built/approved
    # are filtered out below (so 'scrubby' is simply skipped until it exists).
    tail = ["personalize"] if cfg.get("personalize") else []
    if ig and ig.get("kind") == "contacts":
        # contacts already provided -> skip build/score/DM-pull, start at the waterfall
        default = ["ingest", "waterfall", "scrubby", "normalize"] + tail
    else:
        default = (["ingest"] if ig else []) + ["score", "contacts", "waterfall", "scrubby", "normalize"] + tail
    order = cfg.get("stages", default)
    return [s[name] for name in order if name in s]


def run_stage(spec: dict, max_stalls: int = 3) -> int:
    sup = ["python3", SUPERVISE, "--max-stalls", str(max_stalls)]
    if spec.get("jobstore"):
        sup += ["--jobstore", spec["jobstore"]]
    else:
        sup += ["--progress-cmd", spec["progress_cmd"]]
    print(f"\n=== STAGE: {spec['name']} ===")
    return subprocess.run(sup + ["--"] + spec["cmd"]).returncode


# Rough per-unit cost model (AI Ark credits or USD) for the pre-spend estimate.
def estimate_costs(cfg: dict, stages: list) -> None:
    nco = cfg.get("approx_companies", 0)
    nct = cfg.get("approx_contacts", 0)
    ndo = cfg.get("approx_domains", 0)
    score_est = (f"~${nco * 0.005:,.2f} ZenRows + ~${nco / 1000 * 0.5:,.2f} Sonnet (scores by scrape)"
                 if cfg.get("personalize") else f"~${nco / 1000 * 0.5:,.2f} Sonnet (scores by description, no scrape)")
    est = {
        "ingest":      ("$0 — reshape only, no spend", None),
        "score":       (score_est, cfg.get("budgets", {}).get("score")),
        "contacts":    (f"~{nco * 3.5:,.0f} AI Ark credits", cfg.get("budgets", {}).get("contacts")),
        "waterfall":   (f"~{nct * 0.5:,.0f} AI Ark credits + flat-rate finders + MV", cfg.get("budgets", {}).get("waterfall_aiark")),
        "normalize":   (f"~${nct / 1000 * 0.15:,.2f} (Gemini Flash)", None),
        # personalize REUSES the score-stage scrape (scrape once) -> Sonnet only
        "personalize": (f"~${ndo * 0.004:,.2f} Sonnet (scrape reused from scoring — no re-scrape)", None),
    }
    print("  Cost estimate (approve ceilings before the run):")
    for spec in stages:
        e, ceil = est.get(spec["name"], ("?", None))
        cap = f" | ceiling {ceil:,.0f}" if ceil else ""
        print(f"    {spec['name']:11s} {e}{cap}")


def preflight(cfg: dict, stages: list) -> bool:
    print("=== PREFLIGHT ===")
    if not ensure_google_ready():
        print("  Google auth: FAILED (reauth did not complete).", file=sys.stderr)
        return False
    print("  Google auth: OK")
    estimate_costs(cfg, stages)
    missing = {}
    for spec in stages:
        m = _keys_present(spec["name"])
        if m:
            missing[spec["name"]] = m
    if missing:
        print(f"  Missing API keys: {missing}", file=sys.stderr)
        return False
    print(f"  API keys: OK for stages {[s['name'] for s in stages]}")
    print(f"  {check_publishing_hint()}")
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", help="Campaign config JSON.")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--from-stage", help="Resume the pipeline at this stage.")
    ap.add_argument("--approve", help="Comma-separated stage names the operator has approved to SPEND on. Un-approved spending stages halt with an estimate. Required — no spend without it.")
    args = ap.parse_args()

    if args.selftest:
        return selftest()
    if not args.config:
        ap.error("need --config (or --selftest)")

    cfg = json.loads(Path(args.config).read_text())
    stages = build_stages(cfg)
    if args.from_stage:
        names = [s["name"] for s in stages]
        stages = stages[names.index(args.from_stage):]
    if not preflight(cfg, stages):
        return 2

    # HARD RULE: every stage spends credits (AI Ark / models / enrichment APIs).
    # NONE runs without explicit per-stage operator approval (--approve a,b,c).
    # Ceilings are not approval. An un-approved spending stage HALTS the run.
    approved = set((args.approve or "").split(",")) if args.approve else set()
    for spec in stages:
        if spec["name"] not in approved:
            print(f"\n⛔ APPROVAL REQUIRED before spending on stage '{spec['name']}'.")
            estimate_costs(cfg, [spec])
            print(f"   To run it: re-invoke with  --approve {spec['name']}  (or list multiple).")
            print(f"   Halting — no credits will be spent without your go-ahead.")
            return 3
        rc = run_stage(spec)
        if rc != 0:
            print(f"\nPIPELINE HALTED at stage '{spec['name']}' (supervisor gave up). "
                  f"State is saved; fix the blocker and re-run with --from-stage {spec['name']}.", file=sys.stderr)
            return 1
    print("\n=== CAMPAIGN COMPLETE — all stages finished. ===")
    return 0


def selftest() -> int:
    """Two stub stages under supervision; the first 'dies' twice before finishing."""
    import tempfile
    work = tempfile.mkdtemp()
    stub = f"{work}/stub.py"
    Path(stub).write_text(
        "import sys,os\n"
        "f=sys.argv[1]; n=int(open(f).read()) if os.path.exists(f) else 0\n"
        "n+=1; open(f,'w').write(str(n))\n"
        "print(f'stub {f}: progress {n}/3')\n"
        "sys.exit(0 if n>=3 else 137)\n")
    stages = [
        {"name": "stubA", "cmd": ["python3", stub, f"{work}/a.txt"],
         "progress_cmd": f"python3 -c \"import os;n=int(open('{work}/a.txt').read()) if os.path.exists('{work}/a.txt') else 0;print(n, max(0,3-n))\""},
        {"name": "stubB", "cmd": ["python3", stub, f"{work}/b.txt"],
         "progress_cmd": f"python3 -c \"import os;n=int(open('{work}/b.txt').read()) if os.path.exists('{work}/b.txt') else 0;print(n, max(0,3-n))\""},
    ]
    print("=== PREFLIGHT (selftest) ===\n  Google auth: OK (skipped)\n  API keys: OK (stub)")
    for spec in stages:
        if run_stage(spec) != 0:
            print("SELFTEST FAIL at", spec["name"]); return 1
    print("\n=== SELFTEST: CAMPAIGN COMPLETE ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
