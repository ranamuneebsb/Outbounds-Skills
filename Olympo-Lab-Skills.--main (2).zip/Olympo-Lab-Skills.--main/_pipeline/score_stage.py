#!/usr/bin/env python3
"""
score_stage — the front-of-funnel GATE: durable, governed company scoring.

The front of the funnel is where the money is decided. A bad-fit company that
slips qualification gets paid for at every downstream stage (DM pull + email find
+ scrape + personalize), so one upstream error multiplies. This stage replaces
the old ad-hoc, non-reproducible LLM pass with a governed one:

  • PERSISTED RUBRIC  — scoring is against an explicit ICP rubric (--rubric /
    --rubric-file), so two runs of the same list score the same way.
  • RECORDED REASON   — every company gets a written 'why' (ICP Reason, col L),
    so a verdict is auditable, not a black box.
  • DURABLE           — each company is a JobStore unit; a death loses <=1 and
    never re-spends (same guarantee as the paid stages).
  • BUDGET-CAPPED     — --budget caps ZenRows scrapes; stops cleanly at the cap.
  • AUDIT GATE        — prints qualified/disqualified counts + a sample with
    reasons at the end, so the operator can sanity-check the gate BEFORE
    approving the (paid) contacts stage.

Scoring method follows the personalization branch (Rule: don't double-spend):
  --scrape : scrape each domain (ZenRows) and rate off the page. The scrape is
             PERSISTED in this stage's JobStore (keyed by domain) so the later
             personalize stage REUSES it instead of scraping again — scrape once.
  else     : rate off the sheet's description/industry columns only (no scrape).

Writes to the Companies tab at the positions the contacts stage reads:
  J = ICP Score (0-100)   K = ICP Verdict (Qualified|Disqualified)   L = ICP Reason

Run under the venv. Supervisor progress via --jobstore (or --progress).
"""
from __future__ import annotations
import os, sys, json, re
from pathlib import Path
_VENV = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV.exists() and Path(sys.executable).resolve() != _VENV.resolve():
    os.execv(str(_VENV), [str(_VENV)] + sys.argv)

import argparse, requests
from concurrent.futures import ThreadPoolExecutor, as_completed
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts"))
import scrape_domains as sd
from olympo_core import JobStore, Budget, prevent_sleep, norm_domain, a1col, reconcile, model_for
from olympo_auth import get_sheets_service

# Model comes from the central registry (olympo_core.MODELS) — not hardcoded here.
# Scoring is a cheap binary FIT judgment; the registry pins it to a cheap model.
MODEL = model_for("score")
ORKEY = json.load(open(str(Path.home() / ".olympolabs" / "openrouter.json")))["api_key"]
SYS = (
    "You are a STRICT B2B ICP qualifier. Given an ICP RUBRIC and a company's info, "
    "decide if the company fits the rubric. Return ONLY JSON: "
    "{\"qualified\": true|false, \"score\": 0-100, \"reason\": \"<=18 words\"}.\n"
    "score = how well it fits (0 = no fit, 100 = perfect). qualified = the company "
    "clearly fits the rubric with no hard disqualifier. Be CONSERVATIVE: if the info "
    "is too thin to confirm the fit, return qualified=false, a low score, and "
    "reason 'insufficient info' — never qualify on a guess."
)


def rate(rubric: str, company: str, info: str):
    try:
        r = requests.post("https://openrouter.ai/api/v1/chat/completions",
                          headers={"Authorization": f"Bearer {ORKEY}", "Content-Type": "application/json"},
                          json={"model": MODEL, "temperature": 0.0, "max_tokens": 120,
                                "response_format": {"type": "json_object"},
                                "messages": [{"role": "system", "content": SYS},
                                             {"role": "user", "content": f"ICP RUBRIC:\n{rubric}\n\nCOMPANY: {company}\nINFO:\n{info[:4500]}"}]},
                          timeout=60)
        c = r.json()["choices"][0]["message"]["content"].strip()
        m = re.search(r"\{.*\}", c, re.DOTALL)
        o = json.loads(m.group(0) if m else c)
        q = bool(o.get("qualified"))
        sc = int(o.get("score") or 0)
        return q, sc, str(o.get("reason", "")).strip()[:140]
    except Exception as e:
        return None, None, f"(rate error: {type(e).__name__})"


def read_companies(svc, sid):
    """Read A:H of the Companies tab -> [{row, company, domain, info}]. info is the
    description/industry context built from columns C..H (everything past A/B)."""
    grid = svc.spreadsheets().values().get(spreadsheetId=sid, range="Companies!A1:H").execute().get("values", [])
    if not grid:
        return []
    header = (grid[0] + [""] * 8)[:8]
    rows = []
    for i, raw in enumerate(grid[1:], start=2):
        row = (raw + [""] * 8)[:8]
        company, website = row[0], norm_domain(row[1])
        if not website:
            continue
        info = " | ".join(f"{header[j]}: {row[j]}" for j in range(2, 8) if row[j].strip())
        rows.append({"row": i, "company": company, "domain": website, "info": info})
    return rows


def main():
    global MODEL
    ap = argparse.ArgumentParser()
    ap.add_argument("--companies-sheet", required=True, help="Built company list (Companies tab).")
    ap.add_argument("--jobstore", required=True)
    ap.add_argument("--rubric", help="ICP rubric text (who qualifies).")
    ap.add_argument("--rubric-file", help="File holding the ICP rubric (overrides --rubric).")
    ap.add_argument("--scrape", action="store_true", help="Score by scraping each domain (personalization path); persists the scrape for reuse.")
    ap.add_argument("--qualify-floor", type=int, default=60, help="Min score to qualify even if the model says qualified.")
    ap.add_argument("--model", default=MODEL, help=f"Scoring model (default {MODEL} — cheap). Do NOT use Sonnet here.")
    ap.add_argument("--budget", type=float, help="Max ZenRows scrapes (scrape path only).")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--progress", action="store_true")
    args = ap.parse_args()
    MODEL = args.model
    if "sonnet" in MODEL.lower() or "opus" in MODEL.lower():
        print(f"REFUSING: scoring must run on a cheap model, not '{MODEL}'. Use Gemini Flash.", file=sys.stderr); return 2

    js = JobStore(args.jobstore)
    if args.progress:
        print(js.counts().get("done", 0), len(js.pending())); return 0

    rubric = (Path(args.rubric_file).read_text().strip() if args.rubric_file else (args.rubric or "")).strip()
    if not rubric:
        ap.error("need --rubric or --rubric-file (the ICP rubric is mandatory — scoring must be governed).")

    prevent_sleep()
    sid = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", args.companies_sheet).group(1)
    svc = get_sheets_service()
    rows = read_companies(svc, sid)
    js.ingest((r["domain"], r) for r in rows)
    pending = js.pending()
    print(f"companies: {len(rows):,} | done (resume): {js.done_count():,} | to score: {len(pending):,} | method: {'scrape' if args.scrape else 'description'}")

    budget = Budget(args.budget, "score-scrape")
    client = sd.ZenRowsClient() if args.scrape else None

    def work(uid, p):
        info, scrape = p.get("info", ""), ""
        if args.scrape:
            if budget.remaining() <= 0:           # cap hit: don't scrape more
                return uid, {"score": "", "verdict": "", "reason": "(budget cap — not scored)", "scrape": "", "row": p["row"]}
            scrape = sd.scrape_one(client, uid, 6000)
            budget.add(1)
            info = scrape or info                  # fall back to description if scrape empty
        q, sc, reason = rate(rubric, p.get("company", ""), info)
        if q is None:                              # LLM failure — leave unscored, don't guess a verdict
            return uid, {"score": "", "verdict": "", "reason": reason, "scrape": scrape, "row": p["row"]}
        qualified = q and sc >= args.qualify_floor
        return uid, {"score": sc, "verdict": "Qualified" if qualified else "Disqualified",
                     "reason": reason, "scrape": scrape, "row": p["row"]}

    n = 0
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(work, uid, p): uid for uid, p in pending}
        for fut in as_completed(futs):
            uid = futs[fut]
            try:
                _, res = fut.result()
            except Exception as e:
                js.mark_error(uid, str(e)); continue
            js.mark_done(uid, res); n += 1
            if n % 100 == 0:
                print(f"  ...{n:,}/{len(pending):,} | scrapes ~{budget.spent:.0f}")

    # write J/K/L (ICP Score / ICP Verdict / ICP Reason) by row, in 300-row chunks
    results = js.results()
    placed = sum(1 for r in rows if r["domain"] in results)
    reconcile("score-write", len(rows), placed, leaked=[r["domain"] for r in rows if r["domain"] not in results])
    maxrow = max((r["row"] for r in rows), default=1)
    block = []
    for i in range(2, maxrow + 1):
        res = next((results[r["domain"]] for r in rows if r["row"] == i), None)
        block.append([res.get("score", ""), res.get("verdict", ""), res.get("reason", "")] if res else ["", "", ""])
    for off in range(0, len(block), 300):
        chunk = block[off:off + 300]
        rng = f"Companies!{a1col(10)}{2 + off}:{a1col(12)}{1 + off + len(chunk)}"
        svc.spreadsheets().values().update(spreadsheetId=sid, range=rng,
                                           valueInputOption="RAW", body={"values": chunk}).execute()

    # AUDIT GATE — the operator reads this before approving the paid contacts stage.
    scored = [v for v in results.values() if v.get("verdict")]
    qual = [v for v in scored if v["verdict"] == "Qualified"]
    disq = [v for v in scored if v["verdict"] == "Disqualified"]
    unscored = len(rows) - len(scored)
    print(f"\n=== SCORING AUDIT ===")
    print(f"  {len(qual):,} qualified | {len(disq):,} disqualified | {unscored:,} unscored (LLM/budget) | of {len(rows):,}")
    def sample(label, items):
        print(f"  -- {label} sample --")
        for v in items[:6]:
            print(f"     [{v.get('score')}] {v.get('reason','')[:90]}")
    if qual: sample("QUALIFIED", qual)
    if disq: sample("DISQUALIFIED", disq)
    print("  Review the split + reasons above BEFORE approving the contacts (DM-pull) spend.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
