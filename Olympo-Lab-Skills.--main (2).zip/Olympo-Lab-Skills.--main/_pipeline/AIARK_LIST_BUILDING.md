# AI Ark list-building — the recipe (read before building any list)

Hard-won from the real-estate-developer build. `build_list.py` now enforces most
of this, but understand WHY.

## 1. The endpoint & cost
- Company Search = **`POST /companies`** (NOT `/company` — that 401s).
- Company Search costs **~0.1 credit per company *returned*** (NOT free — that
  earlier claim was wrong; verified live 2026-06-19). Still: **build the full
  population, then let `score_stage.py` qualify for precision** — but treat the
  pull as real spend (a 30k pull ≈ 3,000 credits) and `--preview` first. Never try
  to be clever with the search to avoid scoring — scoring is where precision belongs.
- A **402** mid-build = **out of credits** → abort and top up; never mistake it for
  "no results." The bigger downstream spend is People Search / DM pull (~0.5
  cr/person returned), waterfall, Scrubby.
- Authoritative contract now lives at `list-builder/references/aiark-api.md`.

## 2. Filter syntax — the #1 trap
Each filter needs the right wrapper or AI Ark **silently ignores it** and returns
the whole ~1.19M-company DB. Use the friendly spec in `build_list.py`
(`compile_search`) so you never hand-write these:

| Field | CORRECT shape |
|---|---|
| naics | `{"any": {"include": ["237210", ...]}}` — the `any` wrapper is REQUIRED |
| industries | `{"all"/"any": {"include": {"mode": "WORD", "content": [...]}}}` |
| employeeSize | `{"type": "RANGE", "range": [{"start": 10, "end": 100000}]}` |
| location | `{"any": {"include": ["United States"]}}` |
| keyword | `{"any": {"include": {"sources": [{"mode": "SMART", "source": "DESCRIPTION"}], "content": [...]}}}` |

**Ignored-filter smell:** if several *different* filters return the **same** total
(especially a huge round-ish number), the filter is being ignored. `build_list.py`
auto-checks every block against the location+employee-only baseline and ABORTS if a
"filtered" block ≈ baseline. Never trust a suspiciously large or identical count.

## 3. `industries` is a FIXED enum, not free text
Phrases like `"real estate developer"` are NOT valid tags and match almost nothing.
Use real enum values. Observed-valid (extend as you learn): `real estate`,
`construction`, `property development`, `real estate investment`,
`property management`, `commercial real estate`, `residential`, `proptech`,
`finance`, `home improvement`, `architecture`, `rental`. SIC is in the data but is
**not filterable** at request time.

## 4. ALWAYS validate the data model BEFORE choosing filters — don't guess
1. `build_list.py --inspect drhorton.com,hines.com,...` → see how KNOWN-good
   targets are actually tagged (industries / naics / sic). Pick filters off real tags.
2. `build_list.py --icp-file X --probe` → size every block FREE + run the
   ignored-filter guard. Confirm the population is the "multiple thousands" you expect.
3. Only then build.

A single tag rarely captures a segment cleanly (AI Ark tagging is inconsistent —
e.g., some commercial developers are tagged "property management"). So **union a few
precise signals** and let scoring filter. Accept a small recall gap rather than
scoring the whole vertical; sweep mis-tags later via `expand_stage.py`.

## 5. Revenue → employees (hard rule)
**Never use the revenue filter** (`build_list.py` refuses it). Translate a revenue
target into an employee floor by reasoning about revenue-per-employee for the
vertical, then use `employee_min`. Example: real-estate developers are asset-heavy,
labor-light (~$1M revenue/employee) → **$10M+ ≈ 10+ employees**.

## 6. Rubric discipline (for score_stage)
The employee floor is the SIZE/revenue proxy. The scorer's job is **FIT only**
(is it really a <ICP>?), NOT size. **Do not have the rubric re-impose a revenue
threshold** or disqualify on AI Ark's revenue estimate — those estimates are noisy
and will wrongly drop real targets. (In the developer build, a revenue clause in the
rubric dropped ~1,118 genuine 10+-employee developers before we caught it.)

## 7. Worked example — US real estate developers, $10M+
- Size proxy: `employee_min: 10`, `location: ["United States"]`.
- Union of two precise developer signals (`~/.olympolabs/red-build.json`):
  - `{"naics": ["237210", "236117"]}` — Land Subdivision + for-sale/operative builders (8,471).
  - `{"industries_all": ["real estate", "construction"]}` — developer-builders the
    NAICS misses, e.g. Pulte tagged by construction (5,785).
- Rubric (`~/.olympolabs/red-rubric.txt`): qualify genuine developers; disqualify
  brokers/PM/REIT/services on FIT; never on revenue.
