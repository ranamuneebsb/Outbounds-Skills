#!/usr/bin/env python3
"""
new_campaign — turn the 5-minute front-loaded interview into a validated
config.json that run_campaign.py consumes, and print the cost estimate so the
operator approves budget ceilings ONCE, up front.

The interview (conducted conversationally, then passed here as flags) is the ONLY
input the whole pipeline needs. Critical questions:
  --offer / targeting, --dm-titles, list specifics  (already baked into the built
  + scored source sheet), then the operator-approved volumes:
  --search-size, --max-per-company, and per-stage --budget ceilings.

Everything after this is mechanical: run_campaign.py --config <out>.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="campaign.json")
    ap.add_argument("--sheet-url", required=True, help="Working CONTACTS sheet (waterfall/normalize/scrape/personalize write here).")
    ap.add_argument("--source-sheet", help="Scored COMPANY sheet (contacts stage reads Qualified rows). Omit to skip the contacts stage.")
    # IMPORT an existing list instead of building one (universal front door).
    ap.add_argument("--import-source", help="CSV path or Sheet URL of a list you already have.")
    ap.add_argument("--import-kind", choices=["domains", "companies", "contacts"], help="What the imported list is.")
    ap.add_argument("--import-source-tab", help="Tab name if --import-source is a sheet.")
    ap.add_argument("--exclude-csv", help="CSV of contacts already owned.")
    ap.add_argument("--skip-known", action="store_true")
    ap.add_argument("--search-size", type=int, default=10)
    ap.add_argument("--max-per-company", type=int, default=8)
    # FRONT-OF-WORKFLOW QUESTION: "will this list have personalizations?"
    #   yes -> the list is scored by SCRAPING (ZenRows) and that scrape is reused
    #          for personalization; the personalize stage runs. No double scrape.
    #   no  -> the list is scored by DESCRIPTION only; no scrape, no personalize.
    ap.add_argument("--personalize", dest="personalize", action="store_true",
                    help="This list HAS personalizations -> scored by scrape, personalize stage runs.")
    ap.add_argument("--no-personalize", dest="personalize", action="store_false",
                    help="No personalizations -> scored by description, no scrape/personalize.")
    ap.set_defaults(personalize=None)
    ap.add_argument("--stages", default=None)
    # ICP rubric: enables the governed score stage. Required to score the list.
    ap.add_argument("--rubric", help="ICP rubric text (who qualifies) — enables the score stage.")
    ap.add_argument("--rubric-file", help="File with the ICP rubric (overrides --rubric).")
    ap.add_argument("--budget-score", type=float)
    ap.add_argument("--budget-contacts", type=float)
    ap.add_argument("--budget-waterfall-aiark", type=float)
    ap.add_argument("--approx-companies", type=int, default=0)
    ap.add_argument("--approx-contacts", type=int, default=0)
    ap.add_argument("--approx-domains", type=int, default=0)
    ap.add_argument("--ckpt-dir", default=None)
    args = ap.parse_args()

    # The personalization question is mandatory — it decides how the list was
    # scored (scrape vs description) and whether the personalize stage runs.
    if args.personalize is None:
        ap.error("answer the personalization question: pass --personalize OR --no-personalize.")

    rubric = (Path(args.rubric_file).read_text().strip() if args.rubric_file else (args.rubric or "")).strip()

    ingest = None
    if args.import_source or args.import_kind:
        if not (args.import_source and args.import_kind):
            ap.error("importing a list needs BOTH --import-source and --import-kind.")
        ingest = {"source": args.import_source, "kind": args.import_kind, "source_tab": args.import_source_tab}

    if args.stages:
        stages = [s.strip() for s in args.stages.split(",") if s.strip()]
    elif ingest and ingest["kind"] == "contacts":
        stages = ["ingest", "waterfall", "scrubby", "normalize"] + (["personalize"] if args.personalize else [])
    else:
        stages = (["ingest"] if ingest else []) + ["score", "contacts", "waterfall", "scrubby", "normalize"] + (["personalize"] if args.personalize else [])
    # contacts/score write to / read from the Companies (source) sheet. A
    # domains/companies import also targets source_sheet, so it's required too.
    needs_source = ("contacts" in stages) or ("score" in stages and rubric) or (ingest and ingest["kind"] in ("domains", "companies"))
    if needs_source and not args.source_sheet:
        ap.error("this run writes/reads a Companies sheet — pass --source-sheet (an empty target sheet is fine for an import).")

    cfg = {
        "sheet_url": args.sheet_url,
        "source_sheet": args.source_sheet,
        "exclude_csv": args.exclude_csv,
        "skip_known": args.skip_known,
        "search_size": args.search_size,
        "max_per_company": args.max_per_company,
        "personalize": args.personalize,
        "rubric": rubric,
        "ingest": ingest,
        "stages": stages,
        "budgets": {k: v for k, v in [("score", args.budget_score),
                                      ("contacts", args.budget_contacts),
                                      ("waterfall_aiark", args.budget_waterfall_aiark)] if v},
        "approx_companies": args.approx_companies,
        "approx_contacts": args.approx_contacts,
        "approx_domains": args.approx_domains,
        "ckpt_dir": args.ckpt_dir or f"/tmp/campaign-{Path(args.out).stem}",
    }
    Path(args.out).write_text(json.dumps(cfg, indent=2))
    print(f"wrote {args.out}\n")

    import run_campaign as rc
    specs = rc.build_stages(cfg)
    print("Pipeline:", " -> ".join(s["name"] for s in specs))
    rc.estimate_costs(cfg, specs)
    print(f"\nReview, then run unattended:\n  python3 {HERE}/run_campaign.py --config {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
