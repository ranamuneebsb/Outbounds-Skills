#!/usr/bin/env python3
"""
icp_cause_stage — scrape each unique send-safe domain and, from the scrape,
generate two personalization fields via Claude Sonnet:
  custom_icp   : who they sell to, max two types, "X and Y" (no braces)
  custom_cause : "so you can help more <icp> <their customers' real purpose>"
Also keeps the raw Scrape Content (so growth-idea/competitors can run later
with no re-scrape).

Per-domain durable (JobStore): scrape + LLM happen once per domain, marked done
the instant they finish -> a death loses <=1 domain, never re-spends. Writes the
three columns back, fanned to every send-safe contact at that domain.

Run under the venv. Supervisor progress via --jobstore (or --progress).
"""
from __future__ import annotations
import os, sys, json, re
from pathlib import Path
_VENV = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV.exists() and Path(sys.executable).resolve() != _VENV.resolve():
    os.execv(str(_VENV), [str(_VENV)] + sys.argv)

import argparse, requests
from concurrent.futures import ThreadPoolExecutor, as_completed
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts"))
import scrape_domains as sd
from olympo_core import JobStore, prevent_sleep, a1col, read_columns, ensure_columns, write_block, model_for
from olympo_auth import get_sheets_service

MODEL = model_for("personalize")  # Sonnet — the one stage that writes copy
ORKEY = json.load(open(str(Path.home() / ".olympolabs" / "openrouter.json")))["api_key"]
OUT_COLS = ["Scrape Content", "custom_icp", "custom_cause"]
SYS = (
    "You analyze a wholesale/distribution company's website to describe WHO they sell to "
    "(their customers / ICP — the BUSINESSES they distribute to, not what they sell), and "
    "produce two fields. Return ONLY JSON: {\"icp\": \"...\", \"cause\": \"...\"}.\n\n"
    "icp: the customer type they sell to, a short phrase, lowercase, no period. If they sell "
    "to MORE THAN TWO types, name only the FIRST TWO joined with 'and' (e.g. 'bars and "
    "restaurants', 'plumbing and HVAC contractors', 'lumber and building materials dealers').\n\n"
    "cause: a warm one-line cold-email fragment, format EXACTLY: 'so you can help more <icp> "
    "<the meaningful thing those customer businesses ultimately do in the world>'. Lowercase "
    "start, no period, tight. Examples: 'so you can help more bars and restaurants bring "
    "people together', 'so you can help more contractors build stronger communities', "
    "'so you can help more farmers feed the country'."
)


def gen(company, text):
    try:
        r = requests.post("https://openrouter.ai/api/v1/chat/completions",
                          headers={"Authorization": f"Bearer {ORKEY}", "Content-Type": "application/json"},
                          json={"model": MODEL, "temperature": 0.3, "max_tokens": 90,
                                "response_format": {"type": "json_object"},
                                "messages": [{"role": "system", "content": SYS},
                                             {"role": "user", "content": f"Company: {company}\nDomain content:\n{text[:4500]}"}]},
                          timeout=60)
        c = r.json()["choices"][0]["message"]["content"].strip()
        m = re.search(r"\{.*\}", c, re.DOTALL)
        o = json.loads(m.group(0) if m else c)
        return str(o.get("icp", "")).strip(), str(o.get("cause", "")).strip()
    except Exception:
        return "", ""


def read_targets(svc, sid, tab):
    # "Send Safe == yes" is the UNIFIED sendable flag: MV-ok contacts AND the
    # catch-all-valids that Scrubby later confirms (Scrubby flips them to Yes
    # before this stage runs). So personalizing every Send-Safe domain naturally
    # covers catch-all-valids too — no separate handling needed here.
    header, cols = read_columns(svc, sid, tab, ["Company", "Website", "Send Safe"])
    comp, dom, safe = cols.get("Company", []), cols.get("Website", []), cols.get("Send Safe", [])
    n = max(len(comp), len(dom), len(safe))
    rows = []
    for i in range(n):
        d = sd._norm_domain(dom[i] if i < len(dom) else "")
        rows.append({"company": comp[i] if i < len(comp) else "", "domain": d,
                     "safe": (safe[i].strip().lower() == "yes") if i < len(safe) else False})
    return header, rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sheet", required=True)
    ap.add_argument("--tab", default="Contacts")
    ap.add_argument("--jobstore", required=True)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--reuse-scrape-jobstore", help="Score-stage JobStore to reuse scrapes from (keyed by domain) — avoids scraping twice.")
    ap.add_argument("--progress", action="store_true")
    args = ap.parse_args()
    js = JobStore(args.jobstore)
    if args.progress:
        print(js.counts().get("done", 0), len(js.pending())); return 0

    prevent_sleep()
    sid = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", args.sheet).group(1)
    svc = get_sheets_service()
    header, rows = read_targets(svc, sid, args.tab)
    by_dom = {}
    for r in rows:
        if r["safe"] and r["domain"]:
            by_dom.setdefault(r["domain"], r["company"])
    js.ingest((d, {"company": c}) for d, c in by_dom.items())
    pending = js.pending()
    print(f"send-safe domains: {len(by_dom):,} | done (resume): {js.done_count():,} | to do: {len(pending):,}")

    # Reuse the scrape the score stage already paid for (keyed by domain), so a
    # personalized list scrapes ONCE total across scoring + personalization.
    reuse = {}
    if args.reuse_scrape_jobstore and os.path.exists(args.reuse_scrape_jobstore):
        rjs = JobStore(args.reuse_scrape_jobstore)
        reuse = {d: r.get("scrape", "") for d, r in rjs.results().items() if r.get("scrape")}
        print(f"reusing {len(reuse):,} score-stage scrapes (no re-scrape for those)")

    client = sd.ZenRowsClient()

    def work(uid, payload):
        text = reuse.get(uid) or sd.scrape_one(client, uid, 6000)
        if not text:
            return uid, {"scrape": "", "icp": "", "cause": ""}
        ic, cause = gen(payload.get("company", ""), text)
        return uid, {"scrape": text, "icp": ic, "cause": cause}

    n = 0
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(work, uid, p): uid for uid, p in pending}
        for fut in as_completed(futs):
            uid = futs[fut]
            try:
                _, res = fut.result()
            except Exception as e:
                js.mark_error(uid, str(e)); continue
            js.mark_done(uid, res)
            n += 1
            if n % 100 == 0:
                print(f"  ...{n:,}/{len(pending):,}")

    # write the 3 columns, fanned to every send-safe row by domain
    results = js.results()
    idx = ensure_columns(svc, sid, args.tab, header, OUT_COLS)
    cols_data = {c: [] for c in OUT_COLS}
    for r in rows:
        res = results.get(r["domain"]) if (r["safe"] and r["domain"]) else None
        cols_data["Scrape Content"].append([res.get("scrape", "") if res else ""])
        cols_data["custom_icp"].append([res.get("icp", "") if res else ""])
        cols_data["custom_cause"].append([res.get("cause", "") if res else ""])
    for c in OUT_COLS:
        write_block(svc, sid, args.tab, idx[c], cols_data[c], chunk=300)
    filled = sum(1 for r in rows if r["safe"] and results.get(r["domain"], {}).get("icp"))
    got = sum(1 for v in results.values() if v.get("icp"))
    print(f"\n{got:,}/{len(by_dom):,} domains have ICP/cause; wrote 3 cols to {filled:,} send-safe rows.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
