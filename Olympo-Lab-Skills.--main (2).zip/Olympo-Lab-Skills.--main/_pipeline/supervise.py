#!/usr/bin/env python3
"""
supervise — run a pipeline stage and keep it alive until it genuinely finishes.

The fix for "I left it 30 min and it died at 10%": this restarts the stage the
instant it dies (kill, crash, transient API death) and resumes from the job
store, so a death costs at most one in-flight unit — never the whole run. Holds
caffeinate for the entire supervised session (covers restart gaps too).

Smart-stop so a REAL error doesn't loop forever:
  - SUCCESS  when the job store has 0 pending units (everything done).
  - GIVE UP  after --max-stalls consecutive restarts that made ZERO progress
             (done_count didn't move) — then it reports the stuck units instead
             of burning attempts silently.

Usage:
  supervise.py --jobstore /path/x.db --max-stalls 3 -- <stage command...>
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from olympo_core import JobStore, prevent_sleep  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobstore", help="SQLite job store the stage writes to (progress measured here).")
    ap.add_argument("--progress-cmd", help="Alternative to --jobstore: a shell command that prints two ints '<done> <pending>'. Lets ANY stage (JSON/CSV checkpoint, sheet count) plug in.")
    ap.add_argument("--max-stalls", type=int, default=3, help="Give up after this many restarts with no new 'done' units.")
    ap.add_argument("--max-attempts", type=int, default=50)
    ap.add_argument("--backoff", type=float, default=5.0)
    ap.add_argument("cmd", nargs=argparse.REMAINDER, help="-- then the stage command")
    args = ap.parse_args()
    cmd = args.cmd[1:] if args.cmd and args.cmd[0] == "--" else args.cmd
    if not cmd:
        print("supervise: no command given", file=sys.stderr)
        return 2
    if not args.jobstore and not args.progress_cmd:
        print("supervise: need --jobstore or --progress-cmd", file=sys.stderr)
        return 2

    prevent_sleep()  # keep the Mac awake across the whole supervised session

    def _probe() -> tuple:
        """Return (done, pending). From --progress-cmd if given, else the JobStore."""
        if args.progress_cmd:
            try:
                out = subprocess.run(args.progress_cmd, shell=True, capture_output=True, text=True, timeout=60).stdout.split()
                return int(out[0]), int(out[1])
            except Exception:
                return -1, -1
        try:
            js = JobStore(args.jobstore)
            return js.done_count(), len(js.pending())
        except Exception:
            return -1, -1

    def done_count() -> int:
        return _probe()[0]

    def pending_count() -> int:
        return _probe()[1]

    stalls = 0
    for attempt in range(1, args.max_attempts + 1):
        before = done_count()
        print(f"\n[supervise] attempt {attempt}: done={before}, pending={pending_count()} — launching stage")
        rc = subprocess.run(cmd).returncode
        after = done_count()
        pend = pending_count()
        print(f"[supervise] stage exited rc={rc}; done {before}->{after}, pending={pend}")

        if pend == 0:
            print("[supervise] SUCCESS — 0 pending units.")
            return 0
        if after > before:
            stalls = 0  # made progress, keep going
        else:
            stalls += 1
            print(f"[supervise] no progress this attempt ({stalls}/{args.max_stalls} stalls)")
            if stalls >= args.max_stalls:
                print(f"[supervise] GIVING UP after {stalls} stalled attempts; {pend} units stuck. "
                      f"Investigate — likely an external block (credits/limit) or hard errors.", file=sys.stderr)
                return 1
        time.sleep(args.backoff)
    print("[supervise] hit max-attempts cap.", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
