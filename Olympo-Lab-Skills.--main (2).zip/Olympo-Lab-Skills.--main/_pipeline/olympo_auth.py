"""
olympo_auth — durable Google auth for the OlympoLabs fulfillment pipeline.

Goal: the user NEVER reauthorizes mid-run and NEVER types a command.

- get_sheets_service(): cached, auto-refreshing Sheets v4 client (same strategy
  as the vendored sheets_auth, works under both system python and the venv).
- ensure_google_ready(): PREFLIGHT. Validates the ADC refresh token actually
  works (proactively refreshes once). If — and only if — it can't, it runs the
  FULL reauth automatically: rebuilds the OAuth client-id-file from the existing
  ADC creds and launches `gcloud auth application-default login` (browser opens
  on its own). So reauth happens at the START of a run, never mid-run, and needs
  one browser click, not a terminal command.

PERMANENT FIX (one-time, removes reauth entirely): publish the
`olympo-labs-workflows` OAuth consent screen to "In production" in the Google
Cloud console. In "Testing" mode refresh tokens expire ~weekly and force this
reauth; in "Production" they don't. See check_publishing_hint().
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Tuple

ADC_PATH = Path.home() / ".config" / "gcloud" / "application_default_credentials.json"
SHEETS_SCOPE = ["https://www.googleapis.com/auth/spreadsheets"]
# gcloud now requires cloud-platform alongside the sheets scope.
REAUTH_SCOPES = "openid,email,https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/spreadsheets"
QUOTA_PROJECT = "olympolabs-copywriter"
_CLIENT_ID_FILE = "/tmp/olympo_oauth_client.json"


def _token_refreshes() -> bool:
    """True iff the ADC refresh token can mint a fresh access token RIGHT NOW."""
    try:
        from google.auth import default as default_creds
        from google.auth.transport.requests import Request
        creds, _ = default_creds(scopes=SHEETS_SCOPE)
        creds.refresh(Request())
        return bool(creds.valid)
    except Exception:
        return False


def _rebuild_client_id_file() -> str:
    """Reconstruct the OAuth Desktop client-id-file from the ADC creds so we can
    reauth against the org's own client (the default gcloud client is blocked
    for the Sheets scope)."""
    d = json.loads(ADC_PATH.read_text())
    client = {"installed": {
        "client_id": d["client_id"], "client_secret": d["client_secret"],
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "redirect_uris": ["http://localhost"],
    }}
    fd = os.open(_CLIENT_ID_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    os.write(fd, json.dumps(client).encode())
    os.close(fd)
    return _CLIENT_ID_FILE


def ensure_google_ready(auto_reauth: bool = True) -> bool:
    """PREFLIGHT: return True if Google auth is usable. If it isn't and
    auto_reauth is set, run the browser reauth automatically (no terminal
    typing) and re-check. Call this ONCE at the start of a run so a token never
    expires mid-pipeline."""
    if _token_refreshes():
        return True
    if not auto_reauth:
        return False
    if not ADC_PATH.exists():
        print("olympo_auth: no ADC file to rebuild the client from; run gcloud login once.", file=sys.stderr)
        return False
    print("olympo_auth: Google token needs reauth — launching browser sign-in (no action in terminal needed)...", file=sys.stderr)
    cidf = _rebuild_client_id_file()
    subprocess.run(["gcloud", "auth", "application-default", "login",
                    "--client-id-file", cidf, "--scopes", REAUTH_SCOPES], check=False)
    subprocess.run(["gcloud", "auth", "application-default", "set-quota-project", QUOTA_PROJECT], check=False)
    return _token_refreshes()


def get_sheets_service():
    from google.auth import default as default_creds
    from googleapiclient.discovery import build
    creds, _ = default_creds(scopes=SHEETS_SCOPE)
    return build("sheets", "v4", credentials=creds, cache_discovery=False)


def check_publishing_hint() -> str:
    return ("PERMANENT reauth fix: in Google Cloud console for project "
            "'olympo-labs-workflows' (OAuth client 558232065784...), set the OAuth "
            "consent screen Publishing status to 'In production'. Testing mode "
            "expires refresh tokens ~weekly; Production does not.")


if __name__ == "__main__":
    ok = ensure_google_ready(auto_reauth="--no-reauth" not in sys.argv)
    print("google auth ready:", ok)
    if ok:
        svc = get_sheets_service()
        print("sheets service built OK")
    print(check_publishing_hint())
