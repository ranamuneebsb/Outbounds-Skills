#!/usr/bin/env python3
"""
ingest_stage — the universal front door for a list you already have.

Sometimes the workflow doesn't start from an AI Ark build — you already have a
list (scraped from a directory, exported from somewhere, a CSV, a sheet). This
stage canonicalizes ANY such list into the exact sheet format the existing
stages read, so the SAME downstream pipeline runs unchanged.

Three kinds (set --kind):
  • domains    — a list of domains/URLs. -> Companies tab (Company derived from the
                 domain, Website normalized). Pipeline runs score?→contacts→...
  • companies  — rows with a company + website (plus any industry/description
                 columns, carried as Context for description-scoring). -> Companies tab.
  • contacts   — rows that are already PEOPLE (first/last + company/website, opt.
                 title/linkedin). -> Contacts tab. Pipeline starts at the waterfall
                 (no build/score/DM-pull needed — you already have the contacts).

Every imported company/domain is marked ICP Verdict = "Qualified" so the contacts
stage processes it; if a rubric is supplied the score stage OVERWRITES that with a
real verdict. NO spend here — pure reshape. Source columns are detected by fuzzy
header match. (Getting the raw list out of a specific directory/site is bespoke
per-source and happens BEFORE this — dump it to a CSV/sheet, then ingest.)

Run under the venv.
"""
from __future__ import annotations
import os, sys, csv, re
from pathlib import Path
_VENV = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV.exists() and Path(sys.executable).resolve() != _VENV.resolve():
    os.execv(str(_VENV), [str(_VENV)] + sys.argv)

import argparse
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from olympo_core import norm_domain, a1col

# Canonical output headers (must match what downstream stages read).
COMPANIES_HEADERS = ["Company", "Website", "Context", "", "", "", "", "",
                     "AI Ark Company ID", "ICP Score", "ICP Verdict"]   # A,B..I,J,K
CONTACTS_HEADERS = ["Company", "Website", "ICP Score", "First Name", "Last Name",
                    "Title", "Seniority", "Department", "LinkedIn",
                    "AI Ark Company ID", "AI Ark Person ID"]

ALIASES = {
    "company":  ["company", "company name", "name", "organization", "organisation", "account", "business", "employer"],
    "website":  ["website", "domain", "url", "company website", "web", "site", "company domain", "company url"],
    "first":    ["first name", "first", "firstname", "fname", "given name"],
    "last":     ["last name", "last", "lastname", "lname", "surname", "family name"],
    "title":    ["title", "job title", "position", "role", "headline"],
    "linkedin": ["linkedin", "linkedin url", "linkedin profile", "li url", "linkedin_url"],
}


def detect(header):
    h = [(c or "").strip().lower() for c in header]
    idx = {}
    for key, al in ALIASES.items():
        for a in al:
            if a in h:
                idx[key] = h.index(a)
                break
    return idx


def _company_from_domain(dom: str) -> str:
    sld = dom.split(".")[0] if dom else ""
    return sld.replace("-", " ").title() if sld else ""


def _context(header, row, idx):
    used = set(idx.values())
    parts = []
    for j, cell in enumerate(row):
        if j in used or not str(cell).strip():
            continue
        label = (header[j] if j < len(header) else "").strip()
        parts.append(f"{label}: {cell}".strip(": ") if label else str(cell))
    return " | ".join(parts)


def canonicalize(grid, kind):
    """Pure transform: raw grid -> (headers, rows2d, stats). No I/O, no spend."""
    stats = {"in": 0, "out": 0, "dropped": 0}
    if not grid:
        return ([], [], stats)
    header = grid[0]
    idx = detect(header)
    looks_like_header = bool(idx) or any(not str(c).replace(".", "").replace("-", "").isalnum() for c in header[:1])
    data = grid[1:] if looks_like_header else grid
    if kind == "domains" and not idx.get("website") and not looks_like_header:
        data = grid  # headerless single column of domains
    stats["in"] = len(data)

    rows = []
    if kind in ("domains", "companies"):
        for r in data:
            web = ""
            if idx.get("website") is not None and idx["website"] < len(r):
                web = r[idx["website"]]
            elif kind == "domains":
                web = r[0] if r else ""
            dom = norm_domain(web)
            if not dom:
                stats["dropped"] += 1
                continue
            comp = ""
            if idx.get("company") is not None and idx["company"] < len(r):
                comp = str(r[idx["company"]]).strip()
            comp = comp or _company_from_domain(dom)
            ctx = _context(header, r, idx) if looks_like_header else ""
            rows.append([comp, dom, ctx, "", "", "", "", "", "", "", "Qualified"])
        out_headers = COMPANIES_HEADERS
    else:  # contacts
        for r in data:
            def g(key):
                j = idx.get(key)
                return str(r[j]).strip() if j is not None and j < len(r) else ""
            first, last = g("first"), g("last")
            dom = norm_domain(g("website"))
            if not (first and last and dom):
                stats["dropped"] += 1
                continue
            comp = g("company") or _company_from_domain(dom)
            rows.append([comp, dom, "100", first, last, g("title"), "", "", g("linkedin"), "", ""])
        out_headers = CONTACTS_HEADERS

    stats["out"] = len(rows)
    return (out_headers, rows, stats)


def _read_source(source, tab):
    if str(source).startswith("http"):
        from olympo_auth import get_sheets_service
        sid = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", source).group(1)
        svc = get_sheets_service()
        rng = f"{tab}!A1:Z" if tab else "A1:Z"
        return svc.spreadsheets().values().get(spreadsheetId=sid, range=rng).execute().get("values", [])
    with open(source, newline="", encoding="utf-8-sig") as f:
        return [row for row in csv.reader(f)]


def _ensure_tab(svc, sid, tab):
    meta = svc.spreadsheets().get(spreadsheetId=sid).execute()
    if not any(s["properties"]["title"] == tab for s in meta.get("sheets", [])):
        svc.spreadsheets().batchUpdate(spreadsheetId=sid,
            body={"requests": [{"addSheet": {"properties": {"title": tab}}}]}).execute()


def _write(out_sheet, out_tab, headers, rows):
    from olympo_auth import get_sheets_service
    sid = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", out_sheet).group(1)
    svc = get_sheets_service()
    _ensure_tab(svc, sid, out_tab)
    svc.spreadsheets().values().update(spreadsheetId=sid, range=f"{out_tab}!A1",
        valueInputOption="RAW", body={"values": [headers]}).execute()
    for off in range(0, len(rows), 300):
        chunk = rows[off:off + 300]
        svc.spreadsheets().values().update(spreadsheetId=sid,
            range=f"{out_tab}!A{2 + off}", valueInputOption="RAW", body={"values": chunk}).execute()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, help="CSV path OR Google Sheet URL of the raw list.")
    ap.add_argument("--source-tab", default=None, help="Tab name if --source is a sheet.")
    ap.add_argument("--kind", required=True, choices=["domains", "companies", "contacts"])
    ap.add_argument("--out-sheet", required=True, help="Target Google Sheet URL to write the canonical tab into.")
    ap.add_argument("--out-tab", default=None, help="Defaults: Companies (domains/companies) or Contacts (contacts).")
    ap.add_argument("--sentinel", help="Touch this file on success (for sentinel-supervised runs).")
    args = ap.parse_args()

    out_tab = args.out_tab or ("Contacts" if args.kind == "contacts" else "Companies")
    grid = _read_source(args.source, args.source_tab)
    headers, rows, stats = canonicalize(grid, args.kind)
    if not rows:
        print(f"INGEST: 0 usable rows from {stats['in']} input ({stats['dropped']} dropped — missing domain/name?).", file=sys.stderr)
        return 2
    _write(args.out_sheet, out_tab, headers, rows)
    print(f"INGEST [{args.kind}]: {stats['in']} in -> {stats['out']} written to '{out_tab}' "
          f"({stats['dropped']} dropped for missing domain/name).")
    if args.kind == "contacts":
        print("  -> start the pipeline at the WATERFALL (contacts already provided).")
    else:
        print("  -> all marked Qualified; add a rubric to score, or go straight to contacts (DM pull).")
    if args.sentinel:
        Path(args.sentinel).write_text("ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
