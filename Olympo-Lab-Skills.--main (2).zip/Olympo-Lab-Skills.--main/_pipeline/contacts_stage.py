#!/usr/bin/env python3
"""
contacts_stage — decision-maker pull, on the durable spine.

This replaces the fragile find_contacts run that LOST ~997 AI Ark credits today:
the old script re-searched from the top on restart (re-spending). Here every
company is a JobStore unit, persisted the INSTANT its People Search returns, so a
death/restart SKIPS it — never re-spends. Budget-capped, supervisable.

Reuses find_contacts' People Search + title-filter logic (enrich_company).

Run under the venv (AI Ark TLS). Supervisor measures progress via:
    contacts_stage.py --jobstore X --progress   ->  prints "<done> <pending>"
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_VENV = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV.exists() and Path(sys.executable).resolve() != _VENV.resolve():
    os.execv(str(_VENV), [str(_VENV)] + sys.argv)

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts"))

from olympo_core import JobStore, Budget, BudgetExceeded, prevent_sleep  # noqa: E402
import find_contacts as fc  # noqa: E402  (reuse search/filter/enrich + writers)

CREDIT_PER_PERSON = 0.5


def load_companies(source_sheet, min_score, exclude_csv, skip_known, only_known):
    companies = fc.read_qualified(source_sheet, min_score)
    exclude_people, known_domains = (set(), set())
    if exclude_csv:
        exclude_people, known_domains = fc.load_exclusion(exclude_csv)
    if only_known and known_domains:
        companies = [c for c in companies if c["website"] in known_domains]
    elif skip_known and known_domains:
        companies = [c for c in companies if c["website"] not in known_domains]
    return companies, exclude_people


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-sheet")
    ap.add_argument("--exclude-csv")
    ap.add_argument("--skip-known-companies", action="store_true")
    ap.add_argument("--only-known-companies", action="store_true")
    ap.add_argument("--min-score", type=int, default=7)
    ap.add_argument("--search-size", type=int, default=10)
    ap.add_argument("--max-per-company", type=int, default=8)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--budget-credits", type=float, help="Hard ceiling; stop before exceeding.")
    ap.add_argument("--jobstore", required=True)
    ap.add_argument("--titles-file", help="JSON {search,keep,exclude,tier1,tier2} overriding the DM title config per campaign. The defaults are sales/marketing; pass this to retarget (e.g. finance/owner for AR funding).")
    ap.add_argument("--out-title", default="OlympoLabs — Decision-Makers")
    ap.add_argument("--out-csv")
    ap.add_argument("--progress", action="store_true", help="Print '<done> <pending>' and exit (for the supervisor).")
    args = ap.parse_args()

    if args.titles_file:
        import json as _json
        tc = _json.load(open(args.titles_file))
        for attr, key in [("SEARCH_TITLES", "search"), ("KEEP", "keep"), ("EXCLUDE", "exclude"),
                          ("TIER1", "tier1"), ("TIER2", "tier2")]:
            if key in tc:
                setattr(fc, attr, tc[key])
        print(f"titles override: {len(fc.SEARCH_TITLES)} search titles (campaign-specific)")

    js = JobStore(args.jobstore)

    if args.progress:
        c = js.counts()
        print(c.get("done", 0), len(js.pending()))
        return 0

    prevent_sleep()
    key = fc.load_key()
    companies, exclude_people = load_companies(
        args.source_sheet, args.min_score, args.exclude_csv,
        args.skip_known_companies, args.only_known_companies)
    # ingest is idempotent: only NEW companies are added; done ones stay done
    js.ingest((c["website"], c) for c in companies if c["website"])
    pending = js.pending()
    print(f"companies: {len(companies):,} | already done (resume): {js.done_count():,} | to search now: {len(pending):,}")

    budget = Budget(args.budget_credits, "contacts")

    def work(uid, company):
        rows = fc.enrich_company(key, company, args.search_size, args.max_per_company, exclude_people)
        return uid, rows

    try:
        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            futs = {ex.submit(work, uid, c): uid for uid, c in pending}
            n = 0
            for fut in as_completed(futs):
                uid = futs[fut]
                try:
                    _, rows = fut.result()
                except Exception as e:
                    js.mark_error(uid, str(e))
                    continue
                js.mark_done(uid, {"rows": rows})       # <-- persisted immediately, per company
                budget.add(len(rows) * CREDIT_PER_PERSON if rows else CREDIT_PER_PERSON)
                n += 1
                if n % 100 == 0:
                    print(f"  ...{n:,}/{len(pending):,} | ~{budget.spent:.0f} cr spent")
                budget.guard()  # stop cleanly before blowing the ceiling
    except BudgetExceeded as e:
        print(f"  budget ceiling reached: {e}. Stopping cleanly; resume later to continue.")

    # write everything from the DURABLE store (safe even if a prior run died)
    all_rows = []
    for res in js.results().values():
        all_rows.extend(res.get("rows", []))
    # dedupe by person id / name+domain
    seen, uniq = set(), []
    for r in all_rows:
        k = r.get("AI Ark Person ID") or (r.get("First Name"), r.get("Last Name"), r.get("Website"))
        if k in seen:
            continue
        seen.add(k); uniq.append(r)
    print(f"\n{len(uniq):,} contacts across {js.done_count():,} searched companies.")
    if args.out_csv:
        fc.write_csv(args.out_csv, uniq)
        print(f"wrote -> {args.out_csv}")
    elif uniq:
        url = fc.write_contacts_sheet(args.out_title, uniq)
        print(f"contacts sheet: {url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
