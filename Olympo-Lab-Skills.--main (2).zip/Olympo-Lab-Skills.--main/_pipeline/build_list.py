#!/usr/bin/env python3
"""
build_list — Stage 1: AI Ark Company Search -> canonical Companies sheet that
score_stage.py reads. Company Search is FREE (0 credits), so build the full
population at no cost; the governed scorer then qualifies for precision.

This script encodes the AI Ark list-building learnings so a build can't repeat
the mistakes we hit (see AIARK_LIST_BUILDING.md for the full recipe):

  • Endpoint is POST /companies (NOT /company — that 401s).
  • CORRECT filter syntax is built FOR you from a friendly spec, so you never
    hand-write the JSON wrong. The classic bug: naics/industries written without
    the {"any":{"include":[...]}} wrapper is SILENTLY IGNORED and returns the
    whole ~1.2M-company database. A friendly spec block looks like:
        {"naics": ["237210","236117"], "location": ["United States"], "employee_min": 10}
        {"industries_all": ["real estate","construction"], "location": [...], "employee_min": 10}
    Keys: naics[], industries_any[]/industries_all[], keywords[], location[],
          employee_min, employee_max.  (Raw "account": {...} still allowed for advanced use.)
  • REVENUE filtering is REFUSED (hard rule). Translate a revenue target into an
    employee floor and use employee_min instead.
  • IGNORED-FILTER GUARD: before building, every block is sized; if a filtered
    block returns ~the same count as location+employee alone, the filter was
    ignored and the build ABORTS with a clear message.

Modes:
  --probe            size every search block (FREE) + run the ignored-filter guard; don't build.
  --inspect d1,d2    print how AI Ark tags known companies (industries/naics/sic) so you can
                     validate the data model BEFORE choosing filters. Don't build.
  (default)          build + write the Companies sheet (A=Company, B=Website, C=Context;
                     J/K left blank for the scorer).
"""
from __future__ import annotations
import os, sys, json, time
from pathlib import Path
_VENV = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV.exists() and Path(sys.executable).resolve() != _VENV.resolve():
    os.execv(str(_VENV), [str(_VENV)] + sys.argv)

import argparse, requests
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from olympo_core import norm_domain
from olympo_auth import get_sheets_service

BASE = "https://api.ai-ark.com/api/developer-portal/v1"

# `industries` is a FIXED enum (not free text). These are values observed on real
# companies — use them, don't invent phrases like "real estate developer" (that's
# not a valid tag and matches almost nothing). Extend as you learn more.
KNOWN_INDUSTRIES = [
    "real estate", "construction", "property development", "real estate investment",
    "property management", "commercial real estate", "residential", "proptech",
    "finance", "home improvement", "architecture", "rental",
]


def _key():
    return json.load(open(str(Path.home() / ".olympolabs" / "aiark.json")))["api_key"]


# ---- CORRECT filter builders (the syntax that actually filters) ----------------
def _employee(lo, hi=100000):
    return {"type": "RANGE", "range": [{"start": int(lo), "end": int(hi)}]}


def _naics(codes):
    return {"any": {"include": [str(c) for c in codes]}}        # the `any` wrapper is REQUIRED


def _industries(words, mode):
    return {("all" if mode == "all" else "any"): {"include": {"mode": "WORD", "content": list(words)}}}


def _location(places):
    return {"any": {"include": list(places)}}


def _keyword(words, source="DESCRIPTION"):
    return {"any": {"include": {"sources": [{"mode": "SMART", "source": source}], "content": list(words)}}}


def compile_search(block):
    """Friendly spec block -> correct AI Ark `account` object. Refuses revenue."""
    if any(k in block for k in ("revenue", "revenue_min", "revenue_max")):
        raise SystemExit("RULE: revenue filtering is not allowed. Use employee_min as the size proxy.")
    if "account" in block:                                       # advanced raw passthrough
        acc = block["account"]
        if isinstance(acc, dict) and "revenue" in acc:
            raise SystemExit("RULE: revenue filtering is not allowed (found 'revenue' in raw account).")
        return acc
    acc = {}
    if block.get("naics"):
        acc["naics"] = _naics(block["naics"])
    if block.get("industries_all"):
        acc["industries"] = _industries(block["industries_all"], "all")
    elif block.get("industries_any"):
        acc["industries"] = _industries(block["industries_any"], "any")
    if block.get("keywords"):
        acc["keyword"] = _keyword(block["keywords"])
    if block.get("location"):
        acc["location"] = _location(block["location"])
    if block.get("employee_min") is not None:
        acc["employeeSize"] = _employee(block["employee_min"], block.get("employee_max", 100000))
    return acc


def _total(key, account):
    r = requests.post(BASE + "/companies", headers={"X-TOKEN": key, "Content-Type": "application/json"},
                      json={"account": account, "page": 0, "size": 1}, timeout=60)
    return r.json().get("totalElements") if r.status_code == 200 else None


def _baseline_account(acc):
    """Same account but stripped to location+employee only — the 'no real filter' baseline."""
    return {k: v for k, v in acc.items() if k in ("location", "employeeSize")}


def probe(key, searches):
    """FREE: size each block + flag any whose filter is being ignored."""
    print("PROBE (free — no build):")
    bad = False
    for i, block in enumerate(searches, 1):
        acc = compile_search(block)
        total = _total(key, acc)
        base_acc = _baseline_account(acc)
        ignored = base_acc != acc  # only meaningful if there IS a real filter beyond loc+emp
        base = _total(key, base_acc) if ignored else total
        flag = ""
        if ignored and base and total and total >= base * 0.95:
            flag = "  <-- WARNING: ~unfiltered; the industries/naics filter is being IGNORED (check syntax)"
            bad = True
        print(f"  block {i}: total={total:,}" + (f" (loc+emp baseline={base:,})" if ignored else "") + flag)
        time.sleep(0.2)
    if bad:
        print("  One or more filters were ignored — fix the spec before building.")
    return not bad


def inspect(key, domains):
    """Print how AI Ark tags KNOWN companies, so you can pick accurate filters."""
    print("INSPECT — how AI Ark tags these companies (industries / naics / sic):")
    for d in domains:
        d = norm_domain(d)
        r = requests.post(BASE + "/companies", headers={"X-TOKEN": key, "Content-Type": "application/json"},
                          json={"account": {"domain": {"any": {"include": [d]}}}, "page": 0, "size": 1}, timeout=60)
        c = (r.json().get("content") or [{}])[0] if r.status_code == 200 else {}
        if not c:
            print(f"  {d}: (no match)"); continue
        print(f"  {d}\n    industries: {c.get('industries')}\n    naics: {c.get('naics')}  sic: {c.get('sic')}")
        time.sleep(0.2)


# ---- build ---------------------------------------------------------------------
def _domain_of(c):
    link = c.get("link", {}) or {}
    return norm_domain(link.get("website") or link.get("domain_ltd") or link.get("domain") or "")


def _name_of(c):
    # The company name lives at summary.name (top-level 'name' is always None).
    s = c.get("summary") or {}
    return (s.get("name") or s.get("legal_name") or c.get("name") or "").strip()


def _context(c):
    parts = []
    if c.get("industries"):
        parts.append("Industries: " + ", ".join(c["industries"] if isinstance(c["industries"], list) else [str(c["industries"])]))
    if c.get("keywords"):
        kw = c["keywords"]; parts.append("Keywords: " + ", ".join((kw if isinstance(kw, list) else [str(kw)])[:25]))
    if c.get("naics"):
        parts.append("NAICS: " + ", ".join(c["naics"] if isinstance(c["naics"], list) else [str(c["naics"])]))
    if c.get("financial"):
        parts.append("Financial: " + json.dumps(c["financial"])[:300])
    if c.get("summary"):
        parts.append("Summary: " + str(c["summary"])[:600])
    return " | ".join(parts)[:1500]


def harvest(key, account, max_pages):
    H = {"X-TOKEN": key, "Content-Type": "application/json"}
    out = {}
    for page in range(max_pages):
        r = requests.post(BASE + "/companies", headers=H, json={"account": account, "page": page, "size": 100}, timeout=60)
        if r.status_code != 200:
            print(f"    page {page}: HTTP {r.status_code} {r.text[:80]}"); break
        j = r.json(); items = j.get("content") or []; total_pages = j.get("totalPages", page + 1)
        if not items:
            break
        for c in items:
            dom = _domain_of(c)
            if dom and dom not in out:
                out[dom] = {"company": _name_of(c), "domain": dom, "context": _context(c)}
        if (page + 1) % 10 == 0 or page + 1 >= total_pages:
            print(f"    page {page+1}/{total_pages} | unique so far: {len(out):,}")
        if page + 1 >= total_pages:
            break
        time.sleep(0.22)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--icp-file", help='JSON with "company_searches": [ <friendly block>, ... ]')
    ap.add_argument("--out-title", default="OlympoLabs — Companies")
    ap.add_argument("--out-sheet", help="Existing Companies sheet URL (else a new one is created).")
    ap.add_argument("--max-pages", type=int, default=600)
    ap.add_argument("--probe", action="store_true", help="Size each search block (free) + ignored-filter guard; don't build.")
    ap.add_argument("--inspect", help="Comma-separated domains: print their industries/naics/sic; don't build.")
    args = ap.parse_args()
    key = _key()

    if args.inspect:
        inspect(key, [d.strip() for d in args.inspect.split(",") if d.strip()]); return 0
    if not args.icp_file:
        ap.error("need --icp-file (or --inspect).")
    searches = (json.loads(Path(args.icp_file).read_text()).get("company_searches") or [])
    if not searches:
        ap.error('icp-file needs a non-empty "company_searches" array.')

    if args.probe:
        return 0 if probe(key, searches) else 2

    # IGNORED-FILTER GUARD before spending build time: abort if any filter is dead.
    if not probe(key, searches):
        ap.error("aborting build — a search filter is being ignored (see WARNING above). Fix the spec.")

    merged = {}
    for i, block in enumerate(searches, 1):
        acc = compile_search(block)
        print(f"  search {i}/{len(searches)} ...")
        for d, row in harvest(key, acc, args.max_pages).items():
            merged.setdefault(d, row)
        print(f"    -> running union: {len(merged):,} unique companies")

    rows = list(merged.values())
    HEAD = ["Company", "Website", "Context", "", "", "", "", "", "AI Ark Company ID", "ICP Score", "ICP Verdict"]
    values = [HEAD] + [[r["company"], r["domain"], r["context"], "", "", "", "", "", "", "", ""] for r in rows]
    svc = get_sheets_service()
    if args.out_sheet:
        import re
        sid = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", args.out_sheet).group(1)
    else:
        created = svc.spreadsheets().create(body={"properties": {"title": args.out_title},
            "sheets": [{"properties": {"title": "Companies",
                        "gridProperties": {"rowCount": len(values) + 10, "columnCount": 26}}}]},
            fields="spreadsheetId,spreadsheetUrl").execute()
        sid = created["spreadsheetId"]; print(f"\ncreated sheet: {created['spreadsheetUrl']}")
    for off in range(0, len(values), 1000):
        chunk = values[off:off + 1000]
        svc.spreadsheets().values().update(spreadsheetId=sid, range=f"Companies!A{1 + off}",
            valueInputOption="RAW", body={"values": chunk}).execute()
    print(f"wrote {len(rows):,} companies (UNSCORED) to the Companies tab. Next: score_stage.py with the rubric.")
    print(f"SHEET_ID={sid}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
