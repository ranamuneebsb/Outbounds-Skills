#!/usr/bin/env python3
"""Verify AI Ark bulk export end-to-end: stand up a local webhook receiver +
cloudflared tunnel, submit a small bulk job, capture the webhook payload, and
measure the credit rate. Proves the 0.5/email path before we build on it."""
import sys, json, time, subprocess, threading, http.server, re
from pathlib import Path
sys.path.insert(0, "/Users/bryanlopez/Desktop/OlympoLabs-Skills/_pipeline")
sys.path.insert(0, str(Path.home() / "Desktop" / "OlympoLabs-Skills" / "dm-enrichment" / "scripts"))
import requests
from olympo_core import JobStore

PORT = 8088
HOOK = "/tmp/aiark_hook.jsonl"
open(HOOK, "w").close()

class H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(n).decode("utf-8", "replace")
        with open(HOOK, "a") as f:
            f.write(body + "\n")
        self.send_response(200); self.end_headers(); self.wfile.write(b"ok")
    def do_GET(self):
        self.send_response(200); self.end_headers(); self.wfile.write(b"ok")
    def log_message(self, *a): pass

srv = http.server.HTTPServer(("0.0.0.0", PORT), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
print("receiver up on", PORT)

tp = subprocess.Popen(["cloudflared", "tunnel", "--url", f"http://localhost:{PORT}"],
                      stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
url = None; t0 = time.time()
while time.time() - t0 < 45:
    line = tp.stdout.readline()
    if not line:
        time.sleep(0.2); continue
    m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
    if m:
        url = m.group(0); break
print("tunnel url:", url)
if not url:
    tp.terminate(); sys.exit("no tunnel url")
time.sleep(3)  # let the tunnel fully establish

js = JobStore("/tmp/campaign-ar/contacts.db")
urls = []
for r in js.results().values():
    for row in r.get("rows", []):
        if row.get("LinkedIn"):
            urls.append(row["LinkedIn"])
        if len(urls) >= 10:
            break
    if len(urls) >= 10:
        break

k = json.load(open(str(Path.home() / ".olympolabs" / "aiark.json")))["api_key"]
def bal():
    return requests.get("https://api.ai-ark.com/api/developer-portal/v1/payments/credits",
                        headers={"X-TOKEN": k}, timeout=30).json().get("total")
b0 = bal()
hook = url + "/hook"
r = requests.post("https://api.ai-ark.com/api/developer-portal/v1/people/export",
                  headers={"X-TOKEN": k, "Content-Type": "application/json"},
                  json={"urls": urls, "webhook": hook}, timeout=30)
print("submit:", r.status_code, r.text[:200])

got = None
for _ in range(72):  # up to 6 min
    time.sleep(5)
    lines = [l for l in open(HOOK).read().splitlines() if l.strip()]
    if lines:
        got = lines; break

print("\nwebhook payloads received:", len(got) if got else 0)
if got:
    try:
        obj = json.loads(got[-1])
        print("PAYLOAD (keys):", list(obj.keys()) if isinstance(obj, dict) else type(obj))
        print(json.dumps(obj, indent=2)[:1800])
    except Exception:
        print("RAW:", got[-1][:1800])
b1 = bal()
print(f"\nCREDITS: {b0} -> {b1} = {b0-b1} for {len(urls)} URLs")
tp.terminate(); srv.shutdown()
