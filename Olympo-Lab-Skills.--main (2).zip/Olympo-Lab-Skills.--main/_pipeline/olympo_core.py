"""
olympo_core — durability spine for every pipeline stage.

The rule that was violated today: NEVER hold spent-credit results only in memory.
Everything here makes a process death cost at most ONE unit of work.

Pieces:
  prevent_sleep()         caffeinate for the process lifetime (no idle-sleep death)
  JobStore                SQLite work queue; every finished unit is persisted
                          IMMEDIATELY (id, result). Resume = re-open same DB.
  Budget                  per-stage credit/$ ceiling; hard-stops before overspend
  RateLimiter             provider-aware throughput cap (don't trip burst throttles)
  sanity_ratio()          loud abort when a stage's output looks broken
                          (e.g. 0% of emails verified OK -> don't write garbage)
  Sheet helpers           read only needed columns; write in small chunks w/ retry;
                          reconcile sheet-count vs jobstore-done-count.
"""
from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import threading
import time
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple


# ---------------------------------------------------------------- model registry
# SINGLE SOURCE OF TRUTH for which model each stage uses. Do not hardcode a model
# anywhere else. Scoring + normalize are cheap binary/extraction tasks -> a cheap,
# fast model. Personalization is the ONLY stage that writes customer-facing copy
# -> Sonnet. NEVER run scoring/normalize on Sonnet/Opus (it's ~30x the cost for no
# gain — this exact mistake burned a 12.8k-row scoring pass once).
MODELS: Dict[str, str] = {
    "score":       "google/gemini-2.5-flash",
    "normalize":   "google/gemini-2.5-flash",
    "personalize": "anthropic/claude-sonnet-4.6",
}


def model_for(stage: str) -> str:
    return MODELS[stage]


# ---------------------------------------------------------------- keep awake
def prevent_sleep() -> Optional[subprocess.Popen]:
    try:
        p = subprocess.Popen(["caffeinate", "-dimsw", str(os.getpid())],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("  [keep-awake] caffeinate held for this run.")
        return p
    except (FileNotFoundError, OSError):
        return None


# ---------------------------------------------------------------- durable job store
class JobStore:
    """A resumable work queue. ingest() is idempotent; mark_done() persists the
    result the instant a unit finishes, so nothing spent is ever lost."""

    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self._lock = threading.Lock()
        self._db = sqlite3.connect(path, check_same_thread=False, timeout=30)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute(
            "CREATE TABLE IF NOT EXISTS units("
            "id TEXT PRIMARY KEY, payload TEXT, status TEXT DEFAULT 'pending', "
            "result TEXT, error TEXT, updated REAL)")
        self._db.commit()

    def ingest(self, items: Iterable[Tuple[str, dict]]) -> int:
        n = 0
        with self._lock:
            for uid, payload in items:
                cur = self._db.execute(
                    "INSERT OR IGNORE INTO units(id,payload,status,updated) VALUES(?,?, 'pending', ?)",
                    (uid, json.dumps(payload), time.time()))
                n += cur.rowcount
            self._db.commit()
        return n

    def pending(self, limit: Optional[int] = None) -> List[Tuple[str, dict]]:
        q = "SELECT id,payload FROM units WHERE status IN ('pending','error')"
        if limit:
            q += f" LIMIT {int(limit)}"
        with self._lock:
            rows = self._db.execute(q).fetchall()
        return [(r[0], json.loads(r[1])) for r in rows]

    def mark_done(self, uid: str, result: dict) -> None:
        with self._lock:
            self._db.execute("UPDATE units SET status='done', result=?, error=NULL, updated=? WHERE id=?",
                             (json.dumps(result), time.time(), uid))
            self._db.commit()

    def mark_error(self, uid: str, err: str) -> None:
        with self._lock:
            self._db.execute("UPDATE units SET status='error', error=?, updated=? WHERE id=?",
                             (str(err)[:500], time.time(), uid))
            self._db.commit()

    def counts(self) -> Dict[str, int]:
        with self._lock:
            rows = self._db.execute("SELECT status,COUNT(*) FROM units GROUP BY status").fetchall()
        return {s: c for s, c in rows}

    def results(self) -> Dict[str, dict]:
        with self._lock:
            rows = self._db.execute("SELECT id,result FROM units WHERE status='done'").fetchall()
        return {r[0]: json.loads(r[1]) for r in rows if r[1]}

    def done_count(self) -> int:
        with self._lock:
            return self._db.execute("SELECT COUNT(*) FROM units WHERE status='done'").fetchone()[0]


# ---------------------------------------------------------------- budget ceiling
class BudgetExceeded(Exception):
    pass


class Budget:
    def __init__(self, ceiling: Optional[float], label: str = "stage"):
        self.ceiling = ceiling
        self.label = label
        self.spent = 0.0
        self._lock = threading.Lock()

    def add(self, amount: float) -> None:
        with self._lock:
            self.spent += amount

    def guard(self) -> None:
        if self.ceiling is not None and self.spent >= self.ceiling:
            raise BudgetExceeded(f"{self.label}: spent {self.spent:.1f} >= ceiling {self.ceiling:.1f}")

    def remaining(self) -> float:
        return float("inf") if self.ceiling is None else max(0.0, self.ceiling - self.spent)


# ---------------------------------------------------------------- rate limiter
class RateLimiter:
    def __init__(self, per_second: float):
        self._interval = 1.0 / per_second if per_second > 0 else 0.0
        self._lock = threading.Lock()
        self._next = 0.0

    def wait(self) -> None:
        if not self._interval:
            return
        with self._lock:
            now = time.monotonic()
            if self._next > now:
                time.sleep(self._next - now)
                now = time.monotonic()
            self._next = now + self._interval


# ---------------------------------------------------------------- sanity guard
def sanity_ratio(label: str, values: List[Any], good: Callable[[Any], bool], min_ratio: float) -> None:
    """Abort loudly if too few values pass `good` — catches silent failures that
    default everything to a bad outcome (the MillionVerifier-bulk class of bug)."""
    if not values:
        return
    ratio = sum(1 for v in values if good(v)) / len(values)
    if ratio < min_ratio:
        raise RuntimeError(f"SANITY FAIL [{label}]: only {ratio:.0%} passed (floor {min_ratio:.0%}). "
                           f"Refusing to write likely-broken output.")


# ---------------------------------------------------------------- canonical join keys
# Every stage joins rows by domain or by contact uid. They MUST agree byte-for-byte,
# or a stage silently writes a found result to the wrong (or no) row — the
# "93 scored, blank in sheet" / "custom_cause wrote 0" failure class. These are the
# single source of truth; no stage may define its own.
def norm_domain(w: str) -> str:
    """Canonical domain key: lowercased, scheme/www stripped, path + query removed."""
    w = (w or "").strip().lower().replace("https://", "").replace("http://", "").replace("www.", "")
    return w.split("/")[0].split("?")[0].strip()


def contact_uid(linkedin: str = "", first: str = "", last: str = "", domain: str = "") -> str:
    """Canonical per-contact key: LinkedIn URL if present, else first|last|domain.
    `domain` is normalized through norm_domain so read-side and write-side agree."""
    li = (linkedin or "").strip().lower()
    if li:
        return li
    return f"{(first or '').strip().lower()}|{(last or '').strip().lower()}|{norm_domain(domain)}"


def reconcile(label: str, n_in: int, accounted: int, leaked: Optional[List[Any]] = None) -> None:
    """Balance-the-books guard for a stage write: every input row must be accounted
    for (written, or deliberately dropped). If counts don't match, ABORT loudly
    rather than persist a partial sheet that reads as complete."""
    if accounted != n_in:
        sample = f" e.g. {list(leaked)[:5]}" if leaked else ""
        raise RuntimeError(f"RECONCILE FAIL [{label}]: {n_in} in but {accounted} accounted "
                           f"({n_in - accounted} unaccounted).{sample} Refusing to write a partial sheet.")


# ---------------------------------------------------------------- sheet helpers
def a1col(n: int) -> str:
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def read_columns(svc, sid: str, tab: str, names: List[str]) -> Tuple[List[str], Dict[str, List[str]]]:
    """Read ONLY the named columns (never the whole A:Z — that pulls big text
    columns and is slow). Returns (header, {name: [values...]})."""
    header = svc.spreadsheets().values().get(spreadsheetId=sid, range=f"{tab}!A1:Z1").execute().get("values", [[]])[0]
    hl = [h.strip().lower() for h in header]
    idx = {nm: hl.index(nm.lower()) for nm in names if nm.lower() in hl}
    ranges = [f"{tab}!{a1col(i + 1)}2:{a1col(i + 1)}" for i in idx.values()]
    vr = svc.spreadsheets().values().batchGet(spreadsheetId=sid, ranges=ranges).execute().get("valueRanges", [])
    out: Dict[str, List[str]] = {}
    for (nm, _), vrange in zip(idx.items(), vr):
        out[nm] = [r[0] if r else "" for r in vrange.get("values", [])]
    return header, out


def ensure_columns(svc, sid: str, tab: str, header: List[str], names: List[str]) -> Dict[str, int]:
    hl = [h.strip().lower() for h in header]
    idx, nxt = {}, len(header)
    for nm in names:
        if nm.lower() in hl:
            idx[nm] = hl.index(nm.lower())
        else:
            idx[nm] = nxt
            svc.spreadsheets().values().update(spreadsheetId=sid, range=f"{tab}!{a1col(nxt + 1)}1",
                valueInputOption="RAW", body={"values": [[nm]]}).execute()
            nxt += 1
    return idx


def write_block(svc, sid: str, tab: str, start_col_idx: int, block: List[List[str]],
                start_row: int = 2, chunk: int = 300, retries: int = 4) -> None:
    """Write a 2D block starting at (start_row, start_col_idx) in small chunks
    with retry. Small chunks avoid the multi-MB broken-pipe + the 60/min cap."""
    col = a1col(start_col_idx + 1)
    for i in range(0, len(block), chunk):
        seg = block[i:i + chunk]
        for attempt in range(retries):
            try:
                svc.spreadsheets().values().update(spreadsheetId=sid,
                    range=f"{tab}!{col}{start_row + i}", valueInputOption="RAW",
                    body={"values": seg}).execute()
                break
            except Exception:
                if attempt == retries - 1:
                    raise
                time.sleep(2 * (attempt + 1))


if __name__ == "__main__":
    # self-test the durable store (no network)
    import tempfile
    p = tempfile.mktemp(suffix=".db")
    js = JobStore(p)
    added = js.ingest([("a", {"x": 1}), ("b", {"x": 2}), ("a", {"x": 1})])
    assert added == 2, added
    js.mark_done("a", {"ok": True})
    js.mark_error("b", "boom")
    js2 = JobStore(p)  # reopen -> durable
    assert js2.counts().get("done") == 1, js2.counts()
    assert js2.done_count() == 1
    assert "a" in js2.results()
    assert len(js2.pending()) == 1  # b (error) is re-pending
    # budget + sanity
    b = Budget(10, "t"); b.add(11)
    try:
        b.guard(); raise AssertionError("should have raised")
    except BudgetExceeded:
        pass
    try:
        sanity_ratio("emails", ["ok"] * 1 + ["bad"] * 99, lambda v: v == "ok", 0.5)
        raise AssertionError("sanity should have raised")
    except RuntimeError:
        pass
    print("olympo_core self-test: PASS")
