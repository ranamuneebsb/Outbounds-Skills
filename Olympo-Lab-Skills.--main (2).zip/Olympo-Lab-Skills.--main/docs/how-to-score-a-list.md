# How to score a list of companies

The `company-scoring` skill takes a Google Sheet of companies and rates each
1-10 for ICP fit. You filter the sheet by `ICP Verdict == Qualified` after,
and the qualified rows become your outbound pool.

## What you need before starting

1. **A Google Sheet URL** — must have at least one column with company
   domains/URLs. Sheet should be accessible to your Google account.
2. **An ICP definition** — either as a markdown file at
   `~/.olympolabs/icp-profiles/<slug>.md` OR a description in chat.
3. **Working API keys** — OpenRouter, ZenRows, and gcloud ADC (one-time
   setup, see `setup-api-keys.md` and `setup-gcloud-adc.md`).

## Walkthrough — typical first run

Drop a message in Claude Code:

> Score this sheet for [ICP target]: `<URL>`

Example:
> Score this sheet for US-based SaaS firms with 50-200 employees:
> https://docs.google.com/spreadsheets/d/.../edit

The skill auto-triggers. Expect the following sequence:

### 1. Skill confirms the sheet + ICP

> "Sheet: `<title>` (16,540 rows × 25 cols). Detected columns:
> {domain, description, company}. ICP loaded: us-saas-50-200."

If the ICP doesn't exist yet, the skill writes a new profile from your chat
description. Verify it before continuing.

### 2. Skill asks which mode for the full run

> "Two modes for the full-sheet run:
>   (a) Conventional — uses descriptions when clear, scrapes only when not.
>       Cheaper ($0.0003/row).
>   (b) Force-scrape — ignores descriptions, scrapes every row. Pricier
>       ($0.003/row) but more accurate when you don't trust the description
>       column.
> Which mode?"

**Rule of thumb:**
- Clay / Apollo / LinkedIn Sales Nav exports → **conventional** (descriptions
  are usually decent)
- Google Maps scrapes / cold-pulled lists / domain-only files → **force-scrape**
  (descriptions are unreliable or absent)

### 3. Skill runs a 20-row calibration pilot

The pilot ALWAYS uses scrape mode (regardless of your mode choice). It tests
the ICP, not the data quality. Takes ~15-30 seconds, costs ~$0.05.

The skill then presents the 20 scored rows in chat, sorted by score:

> Row 6: **[8] Thrive Architects** — US architecture firm with clear building design specialties
> Row 5: [3] Martenson & Eisele — primarily land surveying, not architectural design
> Row 11: [1] Imagine Design Outdoors — landscape design, outside ICP
> ...

### 4. You sign off OR refine

Two paths:

- **"Looks good, continue"** → skill scales to the full sheet in the mode you
  picked in step 2.
- **"This is wrong because X"** → tell the skill specifically which rows are
  misclassified and why. The skill will edit the ICP file automatically and
  re-pilot the same 20 rows so you can compare before/after.

Examples of useful feedback:
- "AGM Renovations should be 1, not 7 — they're a kitchen remodel firm, not a
  full builder."
- "The ICP should exclude solo practitioners and shops under 5 employees."
- "Engineering firms with no architect on staff should be 1, not 3 — they're
  fully outside the ICP."

Most ICPs converge in 1-3 pilot iterations.

### 5. Full-sheet run

After sign-off, the skill confirms the cost estimate and runs the full sheet:

> "Calibration approved. About to score 14,000 rows in force-scrape mode.
>  Est cost: ~$42. Proceed?"

Concurrency 30, batch-writes every 50 rows, fully resume-safe. Progress prints
every 50 rows. Wall-clock typically 25-60 min for 10-15k rows depending on mode.

### 6. Optional 6-7 cleanup (only if you chose conventional/hybrid)

If you picked conventional mode in step 2, the skill suggests a final pass:

```bash
--rescore-score-range 6 7 --scrape-only
```

This catches the systematic Flash-Lite-on-description overshoot. Typically
60-70% of 6-7 rows flip to clearer Q/D verdicts. Cost is small (~$0.50-1).

**Skip this if you picked force-scrape** — every row was already scored by
DeepSeek on scraped content, no upside.

### 7. Filter the sheet for your outreach pool

Open the sheet in Sheets UI. Use AutoFilter on the `ICP Verdict` column,
select "Qualified". That's your shortlist. Export to CSV for upload to
PlusVibe (or wait for the future List Builder skill to automate this).

## Cost expectations

| Volume | Conventional | Force-scrape |
|---|---:|---:|
| 1,000 rows | ~$0.30 | ~$3 |
| 14,000 rows | ~$4 | ~$42 |
| 600,000 rows / mo | ~$180 | ~$1,800 |

ZenRows costs are flat ($129/mo Startup plan) up to 1M basic + 40K protected
results. We comfortably stay under those at any reasonable monthly volume.

## Gotchas

- **Don't skip the pilot.** Even with a polished ICP, the pilot catches edge
  cases (misleading industry tags in the source data, ambiguous edge cases the
  LLM interprets weirdly). 20 seconds saves you from a wrong 10,000-row run.
- **Resume mode is default.** If a run crashes, re-run with the same flags —
  it picks up where it left off. Don't pass `--force-rescore` unless you
  actually want to overwrite.
- **Auto-detect can miss unusual columns.** If your sheet uses
  `corporate_domain` instead of `domain`/`website`/`url`, the detector won't
  find it. Pass `--domain-col <N>` (1-based index) if needed.
- **Sheets API write quota.** ~100 writes per 100 sec per user. The skill
  batches writes every 50 rows so you won't hit this in normal use, but if
  several teammates score sheets at once on shared sheets you might.
