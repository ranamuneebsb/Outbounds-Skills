# Setting up your API keys

The skills authenticate to three external APIs. Each teammate sets these up once on their machine. All three keys live in `~/.olympolabs/` as JSON files with mode 600 (owner read/write only).

## OpenRouter (LLM access)

OpenRouter is the unified API we use to call cheap and smart LLMs (Gemini Flash, DeepSeek, Claude Sonnet) under one billing account.

**Each teammate uses their OWN OpenRouter account.** This keeps usage attributable.

1. Sign up at https://openrouter.ai
2. Add a payment method + load $10-50 of credit to start
3. Go to https://openrouter.ai/keys
4. Click "Create Key" → name it something like "olympolabs-skills-mac"
5. Copy the key (starts with `sk-or-v1-`)
6. Save it:

```bash
mkdir -p ~/.olympolabs
echo '{"api_key": "sk-or-v1-PASTE-YOUR-KEY-HERE"}' > ~/.olympolabs/openrouter.json
chmod 600 ~/.olympolabs/openrouter.json
```

7. Verify:

```bash
python3 ~/Desktop/OlympoLabs-Skills/openrouter-api/ping.py
```

You should see "OK - OpenRouter call succeeded" and a small token usage report.

### Daily cost expectation

- Company-scoring at hybrid mode: ~$0.13 per 1,000 rows
- Company-scoring at force-scrape: ~$0.79 per 1,000 rows (LLM only — ZenRows is separate)
- Copywriter run: ~$0.02 per batch generated
- Spintax run: ~$0.01 per batch processed

Top up when your OpenRouter balance is low. The skill will surface clear errors if it gets a 402 (out of credit).

## ZenRows (web scraping)

ZenRows handles the scraping side of company-scoring — fetches HTML for sites that don't have good descriptions, with anti-bot bypass.

The team is on the **Startup plan** ($129/mo, 1M basic + 40K protected results, ~30 concurrent). One plan shared across the team is fine — usage runs against the same monthly budget.

**Get the key from team lead, OR if you're spinning up your own ZenRows account:**

1. Sign up at https://www.zenrows.com
2. Go to https://app.zenrows.com/users/api-keys
3. Copy your API key
4. Save it:

```bash
echo '{"api_key": "your-zenrows-key"}' > ~/.olympolabs/zenrows.json
chmod 600 ~/.olympolabs/zenrows.json
```

5. Verify:

```bash
python3 ~/Desktop/OlympoLabs-Skills/zenrows-api/ping.py
```

You should see "OK - got HTML" and a snippet of extracted text from example.com.

### Daily usage expectation

The skill defaults are tuned for the Startup plan:
- Tier 1 (basic scrape): 1 credit each, against the 1M monthly cap
- Tier 2 (premium + JS render): 1 protected result, against the 40K monthly cap
- Tier 3 (extra retry with longer wait): another protected result, opt-out via `--no-zenrows-extra-retry`

At 600k rows/month scoring volume with ~5% premium fallback rate, you stay comfortably under both caps. Watch the cost log if you start hitting heavy retries.

## PlusVibe (sending platform)

This is the team's shared cold-email sending platform. **One key for the whole team — get from team lead.**

```bash
echo '{"api_key": "the-team-plusvibe-key"}' > ~/.olympolabs/plusvibe.json
chmod 600 ~/.olympolabs/plusvibe.json
```

Verify:

```bash
python3 ~/Desktop/OlympoLabs-Skills/plusvibe-api/ping.py
```

You should see a list of accessible PlusVibe workspaces (OLYMPO LABS, GLOBALTIZE, KATMAI, Clients Workspace, etc.).

## Why per-user vs shared

| Service | Per-user or shared? | Why |
|---|---|---|
| OpenRouter | Per-user | Usage-based billing, attributable cost tracking, easy revocation |
| ZenRows | Shared (one team key) | Fixed monthly plan, multiple keys = wasted spend |
| PlusVibe | Shared (one team key) | Single workspace tree, all team members operate on shared client accounts |
| gcloud ADC | Per-user (no key file) | Each teammate's own Google account authorizes Sheets access |

## Rotating keys

If a key leaks (committed by mistake, screenshotted into Slack, etc.):

1. Revoke it in the provider's dashboard immediately
2. Generate a fresh one
3. Update `~/.olympolabs/<service>.json` on your machine
4. For team-shared keys: notify team lead, who rotates the key everywhere

The `~/.olympolabs/` files are never in the repo — only your local copies.
