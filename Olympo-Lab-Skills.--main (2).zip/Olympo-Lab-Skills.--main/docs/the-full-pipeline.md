# The full pipeline — onboarding a new client end-to-end

This is the canonical workflow when a new outbound client signs up. Touches
all four skills + the external spam check + PlusVibe UI. Typical wall-clock
for a fresh onboarding: ~2 hours.

For per-step depth, see:
- `how-to-score-a-list.md`
- `how-to-generate-cold-email-scripts.md`
- `how-to-spintax-and-spam-check.md`
- `how-to-upload-a-campaign-to-plusvibe.md`

## Overview

```
1. Pull a list of leads (Clay/Apollo/LinkedIn)        ← outside our skills
2. Score the list                                     ← company-scoring
3. Filter to qualified                                ← Sheets UI
4. Generate scripts                                   ← copywriter
5. Trim to keepers in Cursor                          ← your editor
6. Spintax + run external spam check                  ← plusvibe-spintax + manual
7. Upload campaign to PlusVibe                        ← plusvibe-campaign-manager
8. Add leads + activate                               ← PlusVibe UI (for now)
```

## Step-by-step

### Step 1 — Get the lead list

Source from whichever provider fits the client's ICP (Clay, Apollo, LinkedIn
Sales Nav, Google Maps scrape, etc.). The list needs at least a domain
column. Ideally also a name + description.

Pull into a fresh Google Sheet. Make sure your `@olympolabs.com` account has
edit access.

### Step 2 — Score the list

```
You: Score this sheet for [ICP target]: <URL>
```

The skill auto-triggers. Answer the mode question (conventional or
force-scrape). Approve or refine the 20-row pilot. Let the full run finish.

Optional 6-7 cleanup if you chose conventional.

**Output:** the sheet now has 4 new columns at the right: `ICP Score`,
`ICP Verdict`, `Scoring Source`, `ICP Reasoning`.

**Cost:** $0.30 (conventional) to $3 (force-scrape) per 1,000 rows.

### Step 3 — Filter to qualified

In Sheets UI:
1. Data → Create a filter
2. Click the filter icon on the `ICP Verdict` column
3. Uncheck everything except "Qualified"

This is your outreach pool. Note the count — you'll need it.

(For now this is manual. Future List Builder skill will automate.)

### Step 4 — Generate scripts

Open a fresh Claude Code chat. Drop the client brief covering the 6 inputs
(see `how-to-generate-cold-email-scripts.md`):

```
You: Onboarding a new client, let me give you the brief:
     [client name, offer, ICP, pain points, case studies, sales assets,
      tone, volume]
```

The copywriter skill auto-triggers, generates 15 pairs across the 6 mentor
frameworks, saves to:

```
~/Desktop/OlympoLabs-Skills/copywriter-workspace/runs/<date>-<slug>/draft.md
```

Auto-opens in Cursor.

**Output:** `draft.md` with 15 framework-labeled pairs.

**Cost:** ~$0.02.

### Step 5 — Trim to keepers

In Cursor, in `draft.md`:
1. Read through the 15 pairs
2. Delete the 10-11 you don't want — keep the strongest 4-5
3. Edit the keepers in place (tighten CTAs, swap an asset name, sharpen a hook)
4. Save

**Output:** trimmed `draft.md`, same file path.

### Step 6 — Spintax + external spam check

In the same chat (or a new one):

```
You: Spintax the draft at <full path to draft.md>
```

The spintax skill processes the file, writes:
- `spintaxed.md` — frozen audit trail
- `final.md` — editable copy (auto-opens in Cursor)

Then YOU:
1. Copy contents of `final.md`
2. Paste into the team's external spam-check tool
3. Note flagged words/phrases
4. Edit `final.md` in Cursor to fix them
5. Save

**Output:** `final.md` ready for upload.

**Cost:** ~$0.01.

### Step 7 — Upload to PlusVibe

In the same chat:

```
You: Push <path-to-final.md> to PlusVibe in the <CLIENT> workspace
```

The campaign-manager skill triggers. Answer the campaign config inputs
(name, subjects, schedule, email accounts, wait times).

The skill creates the campaign in DRAFT and prints the URL.

**Output:** PlusVibe campaign in DRAFT mode at `app.plusvibe.ai/v2/campaign/<id>`.

**Cost:** ~$0.

### Step 8 — Add leads + activate

Open the PlusVibe UI at the campaign URL.

1. Export your filtered/qualified rows from the Sheet as a CSV
2. In PlusVibe: Leads → Upload CSV → map columns → assign to this campaign
3. Verify everything once more:
   - Sequences look right
   - Schedule timezone is what you intended
   - Email accounts attached are the right pool
   - Lead count matches what you uploaded
4. Click Activate

**Output:** live campaign sending per the schedule.

## Quick reference — what you say in Claude Code

| Step | Trigger phrase |
|---|---|
| 2 - Score | "Score this sheet for [ICP]: `<URL>`" |
| 4 - Generate | "Onboarding a new client, brief: ..." |
| 6 - Spintax | "Spintax the draft at `<path>`" |
| 7 - Upload | "Push `<path-to-final.md>` to PlusVibe in `<workspace>`" |

Each phrase triggers the right skill — you don't need slash commands.

## Where each artifact lives

```
~/Desktop/OlympoLabs-Skills/
└── copywriter-workspace/
    └── runs/
        └── 2026-05-25-acme-corp/         ← one folder per campaign
            ├── draft.md                   ← Copywriter output, you trim it
            ├── spintaxed.md               ← Spintax output, frozen
            └── final.md                   ← Spam-checked, ready for upload

Google Sheet (client list)                 ← your scoring + filtering happens here

PlusVibe UI                                 ← campaign + leads live here
```

## Cost expectation per new client onboarding

| Step | Cost |
|---|---:|
| 2 - Score 5k leads | $1.50-15 (depending on mode) |
| 4 - Copywriter | $0.02 |
| 6 - Spintax | $0.01 |
| 7 - Campaign upload | $0 |
| **Total per onboarding** | **$1.50-15** |

Vs the per-month sending costs (PlusVibe seats + ZenRows subscription +
OpenRouter LLM volume), the per-client onboarding cost is rounding error.

## Time expectation

Realistic wall-clock from "got the list" to "campaign live":

- Step 2 (scoring): 5-30 min unattended for the full run
- Step 3 (filter): 2 min
- Step 4 (copywriter): 5 min generation + 0 min review
- Step 5 (trim in Cursor): 15-30 min — the variable part, depends on how
  picky you are
- Step 6 (spintax + spam check): 5 min spintax + 15 min spam-check
- Step 7 (upload): 5 min
- Step 8 (leads + activate): 10-15 min

**Total active time:** ~1-1.5 hours of attention, plus 5-30 min unattended
scoring run. Spread across a morning is realistic.

## Gotchas

- **Don't skip the calibration pilot in scoring.** It's the 20 seconds that
  saves you from a wrong 10,000-row run.
- **Don't skip the external spam check between Spintax and Campaign Manager.**
  Spintax's audit catches obvious spam words but the external tool catches
  deliverability-pattern issues Spintax doesn't.
- **Don't auto-activate campaigns.** Always review in PlusVibe UI first.
  Especially check that the email accounts attached are right — uploading
  to the wrong workspace + wrong inboxes is the most expensive mistake here.
- **One campaign folder per client per day.** If you onboard the same client
  twice in a day (rare), rename the first folder before re-running so you
  don't overwrite.
