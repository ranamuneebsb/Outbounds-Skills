# How to upload a campaign to PlusVibe

The `plusvibe-campaign-manager` skill takes a fully-edited `final.md`
(spintaxed + spam-checked) and creates a configured campaign in PlusVibe
via API. The campaign lands in DRAFT — you activate it manually in the
PlusVibe UI after a final review.

## What you need before starting

1. **A `final.md` file** that's been through Spintax + your external spam
   check. Must contain `{{random|...}}` spin blocks (the skill refuses
   non-spintaxed input).
2. **Working PlusVibe API key** at `~/.olympolabs/plusvibe.json`.
3. **Knowledge of which PlusVibe workspace** to upload to. The team has
   workspaces for OLYMPO LABS, GLOBALTIZE, KATMAI, and Clients Workspace.

## Walkthrough

In Claude Code:

> Upload the final at <path> to PlusVibe in the GLOBALTIZE workspace

Or just:

> Push this to PlusVibe: <path-to-final.md>

The skill triggers and runs:

### 1. Skill confirms the file + workspace

> "Reading <path>/final.md. Detected 5 pairs (10 emails total) with 58 spin
> blocks. Uploading to workspace GLOBALTIZE (id: 69ed39f8...)."

If the workspace name is ambiguous (e.g., "OlympoLabs" could match OLYMPO
LABS or Clients Workspace), the skill asks you to pick.

### 2. Skill asks for the 6 campaign inputs

Same shape as the Copywriter interview but for campaign config:

| Input | Example |
|---|---|
| **Campaign name** | "GLOBALTIZE Apr 2026 - Construction GCs Wave 1" |
| **Subject lines** | One per kept pair, in pair order. Subjects can use `{{first_name}}`/`{{company_name}}` |
| **Schedule** | timezone (IANA — `America/New_York`, NOT "EST"), days of week, hours, daily limit, daily new-lead limit, start date |
| **Email accounts to attach** | "all ACTIVE in the workspace" OR a specific list of account IDs |
| **First wait time + follow-up gap** | Minutes before first send, days between step 1 and step 2 |
| **Activate after upload?** | Default no — campaign stays DRAFT for review |

Provide them in one consolidated message. Don't make the skill ping-pong
for each.

### 3. Skill builds the PlusVibe payload

- Parses each pair from `final.md`
- Converts the email bodies from markdown to HTML (`<div>`-wrapped paragraphs,
  per PlusVibe's expected format)
- Each first-touch email becomes a variation of step 1 (labeled A, B, C, ...)
- Each follow-up becomes a matching variation of step 2 (same letter, empty
  subject = reply-in-thread)
- PlusVibe's round-robin selection (`R_ROBIN`) rotates across variations

### 4. Skill calls the PlusVibe API

Two API calls behind the scenes:
1. `POST /campaign/add/campaign` — creates the campaign shell
2. `PATCH /campaign/update/campaign` — pushes the full config (sequences,
   schedule, email accounts, settings)

If either fails, the skill surfaces the error verbatim with the fix (auth,
validation, etc.).

### 5. Skill prints the campaign URL

```
===== Campaign created and configured =====
  campaign_id:   6a13c9896f0a7319522133e6
  workspace_id:  69ed39f8...
  name:          GLOBALTIZE Apr 2026 - Construction GCs Wave 1
  steps:         2
  variations:    5 per step
  accounts:      2,027
  status:        DRAFT (not yet sending)
  url:           https://app.plusvibe.ai/v2/campaign/6a13c9896f0a7319522133e6
```

### 6. You inspect the campaign in PlusVibe UI

Open the URL. Verify in PlusVibe's UI:
- Sequence step 1 has the right number of variations with the right subjects
- Sequence step 2 has matching variations with empty subjects (reply-in-thread)
- Schedule is correct (timezone is what you wanted)
- Email accounts attached are the right pool
- Status: DRAFT

### 7. You upload leads (manual, for now)

Currently the campaign-manager skill does NOT upload leads. You add them in
PlusVibe UI:
- Upload CSV of qualified leads (from your scored sheet, filtered by
  `ICP Verdict == Qualified`)
- Map columns to PlusVibe lead fields
- Add to the campaign

A future List Builder skill will automate this. For now: manual.

### 8. You activate the campaign

In PlusVibe UI, when you're ready: click Activate. Sending begins per the
schedule.

## How variation pairing works

A typical 5-keeper batch produces:

```
Step 1 (first-touch):
  Variation A: subject 1 + email_1 body of pair 1
  Variation B: subject 2 + email_1 body of pair 2
  Variation C: subject 3 + email_1 body of pair 3
  Variation D: subject 4 + email_1 body of pair 4
  Variation E: subject 5 + email_1 body of pair 5

Step 2 (follow-up):
  Variation A: (empty subject) + email_2 body of pair 1
  Variation B: (empty subject) + email_2 body of pair 2
  ... etc
```

PlusVibe's R_ROBIN variation selection should preserve the A/A, B/B, etc.
pairing at send time — meaning a lead who gets first-touch variation B should
get follow-up variation B as well. This keeps the angles aligned per-lead.
(Empirically not 100% verified — if you see follow-ups that don't logically
match their first-touches in PlusVibe's preview, surface to team lead.)

## Subject line conventions

- One subject per pair, in pair order.
- Subjects can include merge tags: `Quick question for {{first_name}}`,
  `60-day playbook for {{company_name}}`.
- Subjects can include spintax: `{{random|Quick question|Random thought}} for
  {{first_name}}`.
- Follow-up subjects are ALWAYS empty (PlusVibe replies in thread).

If you have one subject you want to use for all variations, just give the
skill that one subject — it duplicates across the variations.

## Schedule presets

If you say "default schedule," the skill uses:

```json
{
  "daily_limit": 100,
  "daily_limit_new_lead": 50,
  "start_date": "<tomorrow YYYY-MM-DD>",
  "end_date": "",
  "days": {"1": true, "2": true, "3": true, "4": true, "5": true},
  "timezone": "America/New_York",
  "timing": {"from": "09:00", "to": "18:00"}
}
```

Override anything by being specific in your interview answer.

## Gotchas

- **Status: DRAFT means nothing sends.** This is intentional. The skill
  never auto-activates unless you explicitly approve.
- **Don't use "EST"/"PST"/"CST" for timezone.** PlusVibe silently treats
  unknown timezone strings as UTC, which sends at wrong times. Always IANA
  (`America/New_York`, `America/Los_Angeles`, etc.).
- **Spintax guard.** If the file has 0 `{{random|...}}` blocks, the skill
  refuses to upload. Run Spintax first. The `--skip-spintax-check` escape
  hatch exists but should rarely be used.
- **No automatic activation.** Even if everything looks perfect, you click
  Activate in PlusVibe UI. The skill prints the URL — you go there.

## Cost expectation

PlusVibe API calls are free for plan members. The campaign-manager skill
costs ~$0 to run. Cost lives downstream in the actual email sending.
