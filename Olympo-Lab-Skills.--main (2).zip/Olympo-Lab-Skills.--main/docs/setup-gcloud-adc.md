# Setting up gcloud ADC for Google Sheets

The **company-scoring** skill needs to read AND write to Google Sheets. Read-only via "anyone with the link" sharing isn't enough — we need to write back four columns (Score, Verdict, Source, Reasoning).

We use **Application Default Credentials (ADC)** with Google's OAuth flow. Each teammate authorizes their own Google account once. No service-account JSON keys involved (those are blocked by most org policies anyway).

## One-time setup (~3 minutes)

### 1. Install gcloud CLI

```bash
brew install --cask google-cloud-sdk
```

If you don't have Homebrew: https://cloud.google.com/sdk/docs/install-sdk

### 2. Sign in with your Google account

```bash
gcloud auth login
```

Browser opens. Use your `@olympolabs.com` account (or whatever Google account owns the sheets you'll be scoring).

### 3. Authorize Application Default Credentials with Sheets scope

```bash
gcloud auth application-default login \
  --client-id-file=~/Desktop/OlympoLabs-Skills/shared-config/gcloud-oauth-client.json \
  --scopes=openid,email,https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/spreadsheets
```

Browser opens again. You may see "Google hasn't verified this app" — that's normal for our internal OAuth client. Click **Advanced → Go to OlympoLabs Skills (unsafe)** → **Allow**.

### 4. Set the quota project

```bash
gcloud auth application-default set-quota-project olympolabs-copywriter
```

This points API billing/quotas at the team's GCP project. Required by Google's client libraries.

### 5. Verify

```bash
gcloud auth application-default print-access-token | head -c 30
```

If you see a long token starting with `ya29.`, you're set. If you see an error, see "Troubleshooting" below.

## Why these specific scopes

| Scope | What it unlocks |
|---|---|
| `openid` | OAuth requires this for identity |
| `email` | gcloud needs to know which account you signed in as |
| `cloud-platform` | gcloud's parent scope; required for ADC even for non-GCP APIs |
| `spreadsheets` | Read + write access to any Google Sheet your account can access |

The Drive scope is NOT requested. The skill only touches sheets you can already access — it doesn't browse Drive or list your files.

## Why the shared OAuth client?

Google requires OAuth clients to be tied to a GCP project. Our project is `olympolabs-copywriter`. The OAuth client config (in `shared-config/gcloud-oauth-client.json`) identifies the **app** ("OlympoLabs Skills"), not any specific user. Each teammate still authorizes with their own Google account during step 3 above.

Distributing the OAuth client.json with the app is the official Google pattern for desktop applications. The file contains a `client_id` and a `client_secret`, but neither grants access on its own — they're just identifiers.

## Troubleshooting

### "Access blocked: This app's request is invalid"

The OAuth scopes are wrong. Make sure your command included **both** `cloud-platform` and `spreadsheets` (gcloud rejects the request without `cloud-platform`).

### "Google hasn't verified this app" warning

Expected — our OAuth client is in testing/internal mode. Click "Advanced" → "Go to OlympoLabs Skills (unsafe)" → "Allow". It's your own team's app.

### "API has not been used in project ..."

You need to enable the API on the GCP project. Team lead has likely done this for you, but if it shows up:

```bash
gcloud services enable sheets.googleapis.com --project=olympolabs-copywriter
gcloud services enable cloudresourcemanager.googleapis.com --project=olympolabs-copywriter
```

### Credentials expired after a few weeks

ADC tokens refresh automatically as long as your machine stays signed in. If you see "Reauthentication required" or similar, re-run:

```bash
gcloud auth application-default login \
  --client-id-file=~/Desktop/OlympoLabs-Skills/shared-config/gcloud-oauth-client.json \
  --scopes=openid,email,https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/spreadsheets
```

### "Service account key creation is disabled"

You don't need a service account. Make sure you're running `gcloud auth application-default login` (user OAuth), not `gcloud iam service-accounts keys create` (service account JSON).

## How to know it's working

After all 5 steps, run the company-scoring skill on any sheet. If it can read the sheet headers and write back the output columns, ADC is working.
