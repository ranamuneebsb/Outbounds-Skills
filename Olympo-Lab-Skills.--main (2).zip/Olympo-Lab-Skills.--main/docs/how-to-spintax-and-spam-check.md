# How to spintax a draft + run the spam check

The `plusvibe-spintax` skill adds heavy spintax variation to cold email
scripts using PlusVibe's `{{random|opt1|opt2|opt3}}` syntax, scrubs spam-
trigger words, and produces a file ready for the campaign upload step.

## What you need before starting

1. **A trimmed `draft.md`** from the copywriter step. Typically lives at
   `~/Desktop/OlympoLabs-Skills/copywriter-workspace/runs/<date>-<client>/draft.md`.
2. **Cursor open** (for editing the resulting `final.md` after the external
   spam check).
3. **Access to your external spam-check tool** (the team uses [tool name];
   ask team lead if unsure).

## Walkthrough

In Claude Code:

> Spintax the draft at ~/Desktop/OlympoLabs-Skills/copywriter-workspace/runs/2026-05-25-acme/draft.md

The skill auto-triggers. The "file mode" of plusvibe-spintax runs:

### 1. Skill reads and parses draft.md

Recognizes the per-pair heading structure (`## N. Framework:`, `**Email 1**`,
`**Email 2 (follow-up)**`) and extracts each email body.

### 2. Skill spintaxes each email body

Heavy spintax — every meaningful clause gets multiple options. The structural
markdown (headings, separators) stays untouched.

Example transformation:

```markdown
Before:
   {{first_name}}, how is {{company_name}} adding new clients right now?
After:
   {{first_name}}, {{random|how is|how's|what's how}} {{company_name}}
   {{random|adding new clients|landing new accounts|building pipeline}}
   {{random|right now|at the moment|these days}}?
```

### 3. Skill runs the spam-word audit

Scans the output for the heavy hitters (Call, Free, Guarantee, Get, Open to,
Best, Only, Limited time, Performance, Click here, Earn $X). Replaces any
that slipped in.

### 4. Skill writes TWO files to the same campaign folder

```
runs/<date>-<client>/
├── draft.md         ← your trimmed draft (unchanged)
├── spintaxed.md     ← Spintax output, FROZEN (audit trail; don't edit)
└── final.md         ← identical copy of spintaxed.md at write time
                       (this is the one you edit after spam-check)
```

### 5. Skill auto-opens `final.md` in Cursor

The chat also shows the full content + two trailing pointers:
```
Saved (audit): <path>/spintaxed.md
Saved + opened (edit here): <path>/final.md
```

### 6. You run final.md through the external spam tool

(For Olympolabs's specific spam tool, see team lead's docs. The team uses
an external word-pattern checker that catches things the LLM doesn't.)

Typical workflow:
1. Copy the contents of `final.md`
2. Paste into the external tool
3. Review the flagged words/phrases
4. Note any that need to change

### 7. You apply the spam-check fixes to final.md

Cursor is already open with `final.md`. Make the edits inline:
- Replace flagged words with safe synonyms (`Call` → `chat`, `Free` →
  `no-cost`, `Guarantee` → `what we typically see`)
- Save the file

### 8. final.md is now ready for upload

This is the file you hand to `plusvibe-campaign-manager` next. See
`how-to-upload-a-campaign-to-plusvibe.md`.

## What gets preserved unchanged

The Spintax skill leaves these alone:
- PlusVibe merge tags: `{{first_name}}`, `{{company_name}}`,
  `{{sender_signature}}`, `{{custom_growth_idea}}`, `{{custom_competitors}}`
- Specific numerical values: `4-8 meetings`, `$4.2M`, `11 days` — values stay
  exact, only formatting may vary (`4-8` ↔ `4 to 8`)
- Subject lines (we don't have any in the draft anyway)
- Already-spintaxed portions (if you partially-spintax a draft before)
- Brand / product / proper nouns: OlympoLabs, specific client names

## How heavy is the spintax?

Targets ~5-7 spin blocks per email body. The skill is calibrated for max
inbox uniqueness — almost every meaningful phrase gets options.

After processing a 5-pair batch, expect ~50-70 `{{random|...}}` blocks total
across the 10 email bodies.

## Why two files (spintaxed.md + final.md)?

- **`spintaxed.md`** is your immutable audit trail. The raw Spintax output
  before any human touched it. Useful for diffing if a campaign performs
  unexpectedly later.
- **`final.md`** is the working copy you edit after the external spam check.
  Diverges from `spintaxed.md` the moment you save edits to it.

Don't edit `spintaxed.md` by hand — if you need to start over, re-run the
spintax skill, which regenerates both files fresh.

## Gotchas

- **The campaign-manager skill will REFUSE to upload a file with 0 spin
  blocks** (it assumes you accidentally passed a draft.md instead of a
  final.md). Always run Spintax first.
- **External spam check is a manual step.** Not skipping is what keeps
  deliverability healthy. Even if Spintax's built-in audit was perfect,
  external tools catch deliverability-scoring patterns Spintax doesn't.
- **Don't run Spintax twice on the same file.** The skill is designed to
  partially-spintax cleanly, but consecutive runs add nested options that
  may not render as expected. If you need to re-do, delete `spintaxed.md`
  and `final.md` and re-run from `draft.md`.

## Cost expectation

~$0.01 per batch. Negligible.
