# Troubleshooting

## Skills don't show up after running `install.sh`

**Cause:** Claude Code only picks up new skill directories on startup.

**Fix:** Quit Claude Code completely (Cmd+Q) and reopen. New chat → the skills should be in the auto-loaded list.

## "API key rejected" / "Request not authorized" (OpenRouter, ZenRows, or PlusVibe)

**Cause:** Key is missing, expired, or formatted wrong.

**Fix:**
1. Check the file exists and is mode 600:
   ```bash
   ls -la ~/.olympolabs/*.json
   ```
2. Make sure it's valid JSON with the right shape:
   ```bash
   cat ~/.olympolabs/openrouter.json
   # Should print: {"api_key": "sk-or-v1-..."}
   ```
3. Verify the key independently:
   ```bash
   python3 ~/Desktop/OlympoLabs-Skills/openrouter-api/ping.py   # or zenrows-api/, plusvibe-api/
   ```
4. If verification fails, generate a fresh key in the provider's dashboard and re-save.

## "ERROR: cannot locate the plusvibe-api foundation"

**Cause:** The skill scripts expect the API foundations at `~/Desktop/OlympoLabs-Skills/` and they're not there (or the repo was cloned to a different location).

**Fix:** Make sure your clone of this repo is at `~/Desktop/OlympoLabs-Skills/`. If you cloned it elsewhere, either:
- Move it: `mv /your/clone/path ~/Desktop/OlympoLabs-Skills`
- Or set an env var pointing to where it actually lives:
  ```bash
  echo 'export OLYMPOLABS_SKILLS_HOME="/your/clone/path"' >> ~/.zshrc
  source ~/.zshrc
  ```

## Google Sheets API: "Permission denied" or "404 Not Found"

**Cause:** Either your gcloud ADC isn't set up, or the sheet isn't shared with the Google account you authenticated as.

**Fix:**
1. Check who you're authenticated as:
   ```bash
   gcloud auth list
   ```
   The `ACTIVE` account should be the one that owns or has access to the sheet.
2. Verify the sheet's share settings — the Google account in step 1 should be on the share list (even just as a viewer for reads; editor for writes).
3. Re-run ADC login if the access token is expired (see `setup-gcloud-adc.md`).

## Company-scoring: "no domain detected"

**Cause:** The sheet's header row doesn't have a column the auto-detector recognizes as a domain.

**Fix:** Rename one of the columns to `domain`, `website`, or `url`. Or pass the column index explicitly via `--domain-col <N>` (where N is the 1-based column index).

## ZenRows scrapes failing with high error rate (>15%)

**Cause:** Either the sites being scraped are dead/blocked, or there's a network issue.

**Investigate:**
1. Check a few of the errored rows manually — open the domains in a browser. Do they load? Do they have anti-bot challenges (Cloudflare, etc.)?
2. Verify your ZenRows account is in good standing: https://app.zenrows.com/billing
3. Try `--no-zenrows-extra-retry` to see if Tier 3 retries are the issue (rarely they make things worse).

## Copywriter: "fetch_kb.py failed: COPYWRITER_KB_FILE not set"

**Cause:** The skill needs an env var pointing at your local copy of the winning-scripts knowledge base.

**Fix:**
1. Get the team's winning-scripts Google Doc URL from team lead.
2. In the Doc: File → Download → Markdown (.md). Save to `~/.olympolabs/copywriter-kb.md`.
3. Add the env var:
   ```bash
   echo 'export COPYWRITER_KB_FILE="$HOME/.olympolabs/copywriter-kb.md"' >> ~/.zshrc
   source ~/.zshrc
   ```
4. Restart Claude Code.

## Campaign Manager: "Spintax guard fired - file has 0 spin blocks"

**Not a bug.** The skill is refusing to upload a draft that hasn't been through Spintax. Run the spintax skill on the file first to produce a `final.md`, then point Campaign Manager at that.

If you genuinely want to upload without spintax (rare — testing only), add `--skip-spintax-check` to the launcher invocation.

## Cost log seems wrong (e.g., DeepSeek shows zero cached_input)

Some OpenRouter models support prompt caching, some don't, and the discount rate varies. The skill defaults try to use caching when available but the per-model cached-rate config in `openrouter-api/pricing.py` is a snapshot — re-pull live pricing if you suspect drift.

## "ImportError: No module named X" running any skill

**Cause:** Python dependencies were never installed, or you've been switching Python versions.

**Fix:** Re-run `./install.sh` from the repo root — it checks deps and installs missing ones with `pip3 install --user`.

If it still fails:
```bash
pip3 install --user --upgrade \
  requests \
  google-api-python-client \
  google-auth \
  google-auth-oauthlib \
  trafilatura
```

## Something else weird

Open a Slack thread in `#engineering` with:
- The exact command you ran
- The error output (tail of any log file)
- Your OS + Python version (`uname -a`, `python3 --version`)
- Whether it's reproducible
