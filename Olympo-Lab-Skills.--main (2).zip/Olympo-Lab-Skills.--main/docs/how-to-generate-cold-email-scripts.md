# How to generate cold email scripts

The `copywriter` skill generates 10-20 framework-labeled cold email pairs
(first-touch + matched follow-up) for a new client, grounded in OlympoLabs's
winning-scripts knowledge base.

## What you need before starting

1. **The client's brief** — see "The six inputs" below.
2. **`~/.olympolabs/copywriter-kb.md`** — local markdown copy of the team's
   winning-scripts Google Doc. The `COPYWRITER_KB_FILE` env var must point
   at it. See `setup-api-keys.md` for the download steps.

## The six inputs (have these ready)

The skill interviews you for these. Have them prepared before invoking:

| Input | Example |
|---|---|
| **Offer + ICP** | "Performance-based cold outbound for B2B SaaS companies $50-500M ARR, targeting VP Operations" |
| **Pain points / value props** | "Ops teams burn 20+ hrs/week on manual data movement between CRM, billing, ticketing" — 2-4 sharp angles |
| **Case studies / proof** | Real numbers + named clients. "Cut Acme Corp's close cycle from 12 to 7 days, freed 30 hrs/week" |
| **Sales assets to offer in CTAs** | "We have a 3-min case study video, a one-pager on the methodology, and a sample weekly report" |
| **Tone + anti-patterns** | "Casual, operator-to-operator. Avoid: AI-powered, transform your business, any SaaS marketing language" |
| **Volume + special instructions** | "15 pairs. Lean into the time-savings angle" |

If you don't have all six, the skill will ASK — don't make stuff up. The
skill specifically refuses to invent case studies, stats, or assets.

## Walkthrough

In Claude Code:

> Onboarding a new client, let me give you the brief:
>
> [paste the six inputs as bullets or prose]

The skill triggers and runs the workflow:

### 1. Skill confirms it has all six inputs

If anything is missing, it asks. Don't auto-skip — sparse input produces
generic output.

### 2. Skill fetches your winning-scripts KB

Reads from `~/.olympolabs/copywriter-kb.md`. If the file is missing or stale,
the skill surfaces the error verbatim with the fix command.

### 3. Skill generates the batch

Default 15 pairs, distributed across 6 mentor frameworks:
1. Lead-magnet + named case-study
2. Frontend free-work offer (one sentence + P.S.)
3. Mechanism + guarantee / risk reversal
4. Pain-point question + solution + interest CTA + P.S.
5. Touchpoint + diagnosis + quick-solution CTA
6. Question + unique market insight + insight-implementation CTA

The skill skips frameworks the brief can't honestly support. E.g., if you
don't have a named industry-peer case study, framework #1 gets skipped.

### 4. Skill runs the 14-point final-pass audit

Catches em-dashes, "circling back" follow-up phrases, meeting-ask CTAs,
fabricated stats, etc. before returning.

### 5. Skill saves `draft.md` and auto-opens in Cursor

The batch is written to:
```
~/Desktop/OlympoLabs-Skills/copywriter-workspace/runs/<YYYY-MM-DD>-<client-slug>/draft.md
```

Cursor pops open with the file. The chat output shows the same content + a
"Saved + opened:" pointer at the end.

### 6. You trim and edit in Cursor

Open `draft.md` in Cursor. Standard workflow:
- Delete the pairs you don't want (focus on 4-8 keepers)
- Edit the keepers in place (tighten CTAs, swap an asset name, sharpen a hook)
- Save the file

Don't ask Claude to do the trimming — your editor is the selection tool.

### 7. Hand the trimmed file to Spintax

See `how-to-spintax-and-spam-check.md`. Drop in chat:

> Spintax the draft at <full path to draft.md>

## What draft.md looks like

```markdown
# Copywriter batch for ClientName - 2026-05-25

## Frameworks used
- Framework #1 - Lead-magnet + named case-study (×3)
- Framework #2 - Frontend asset offer + P.S. (×2)
- ...

---

## 1. Framework: #1 - Lead-magnet + named case-study

**Email 1**

{{first_name}},

Put together a short video walkthrough for {{company_name}} covering the
exact outbound play we ran for [Named Peer Client] to book 32 sales meetings
with [target] in 60 days - want me to send it over?

{{sender_signature}}

**Email 2 (follow-up)**

{{first_name}},

[different value angle, no "circling back" / "following up" phrases]

Want me to send the one-pager?

{{sender_signature}}

---

## 2. Framework: ...
```

## Gotchas

- **The skill refuses to invent.** No case studies / stats / sales assets
  beyond what you provided. If the output looks thin, your brief was thin.
- **No subject lines.** Body-only. Subjects get added at the Campaign Manager
  step (or you write them manually before upload).
- **No em dashes.** Hard rule. The skill uses regular hyphens.
- **Follow-ups never start with "following up" / "circling back".** Each
  follow-up is a NEW value angle. If you see those forbidden phrases in
  output, that's a bug — surface it.
- **`{{first_name}}` and `{{company_name}}` are PlusVibe merge tags.** Leave
  them as-is; PlusVibe expands them at send time.

## Cost expectation

~$0.02 per batch generated (15-20 pair output). Negligible — the cost lives
in the KB fetch (one-time) and the audit pass.
