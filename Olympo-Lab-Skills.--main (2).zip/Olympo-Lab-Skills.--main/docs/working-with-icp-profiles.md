# Working with ICP profiles

An ICP profile is a markdown file that defines your ideal customer for a
scoring run. The company-scoring skill reads it and uses its rules to
score 1-10 per row. Good ICPs produce sharp bimodal distributions (lots of
1s and 10s, few middle scores). Bad ICPs produce noisy middle scores and
wrong verdicts.

## Where ICPs live

```
~/.olympolabs/icp-profiles/
├── architecture-firms-us.md
├── construction-gc-canada.md
├── dental-offices-texas.md
└── ...
```

One file per ICP. Each file is the canonical definition — when you run
scoring, the skill reads the file at run time. If you edit it, the next
run uses the new rules.

## Anatomy of a good ICP file

See `templates/icp-profile-template.md` for the empty starter. The four
sections that matter:

### 1. "Who counts as a fit" (the core definition)

2-3 sentences that nail the segment. Be specific:
- Geography (country, region, state if relevant)
- Industry / business model
- Size band (employees / revenue)
- Decision-maker context

**Bad:** "Construction firms."

**Good:** "Canadian general contractors and builders, 10-50 employees,
mostly residential and commercial. Owners and VPs of Business Dev are the
target persona."

### 2. "Positive signals" (any of these = higher score)

5-10 concrete patterns the LLM should look for in the description or
scraped page. The more specific, the better the LLM scores.

**Bad:**
- Mentions construction
- Building work

**Good:**
- Self-describes as "general contractor", "GC", or "design-build firm"
- Mentions specific build segments: residential / commercial / industrial
  / civil
- Portfolio of completed buildings with named projects
- Based in Canada (provinces, Canadian cities)
- Self-performs construction (not just project management)

### 3. "Negative signals" (any of these = score under 5)

This is where the precision lives. The Sonnet audits showed that **the
cheap model is too generous by default** — it over-qualifies adjacent
industries. List the exact "looks similar but isn't" patterns:

**For a construction-GCs ICP:**
- Specialty trade only (electrical, plumbing, HVAC, roofing, painting)
- Architecture-only firms with no in-house build
- Engineering consultancies with no build work
- Construction equipment dealers / rental companies / suppliers
- Construction software / tech vendors
- Real estate developers who don't self-perform
- Staffing/recruiting firms (even if they place construction workers)
- Adjacent industries (oil & gas, mining, telecom) that do internal builds

The negative list is usually 2-3× longer than the positive list. That's
fine — most rows are NOT in the ICP, and you want them all flagged.

### 4. "Edge cases - how to handle"

The middle cases the LLM would otherwise guess at. Be explicit:

- "Design-build firms WITH a real architecture practice in-house" → FIT
- "Design-build firms that are really just GCs" → FIT
- "Solo practitioners (1 person)" → too small for SMB outreach, NOT FIT
- "Mega-firms (Gensler, HOK tier)" → too large for SMB outreach, NOT FIT
- "Multidisciplinary firms with architecture as one of three practices" →
  FIT only if architecture is mentioned on home page

## How the calibration loop refines an ICP

When you run scoring, the 20-row pilot scores against the current ICP. You
review and either sign off OR give specific feedback. The skill auto-edits
the file based on your feedback.

Feedback that works well:
- "X should be Qualified, it's a real GC doing build work"
- "Y is being marked too low — the ICP is missing the 'pre-fab modular
  builder' positive signal"
- "Engineering firms should ALWAYS be score 1, not 3"
- "Add 'staffing/recruiting' to the negative signals list"

Feedback that's vague (skill will ask for more):
- "The scoring is wrong"
- "I don't like this"
- "Make it more strict"

## Starting a new ICP — from scratch

```bash
cp ~/Desktop/OlympoLabs-Skills/templates/icp-profile-template.md \
   ~/.olympolabs/icp-profiles/dental-offices-texas.md
```

Fill in the bracketed sections with everything you know about the ICP. Be
specific. Then run scoring on a sample list — the calibration pilot will
expose what you missed.

## Starting a new ICP — by cloning an existing one

If the new ICP is "similar to construction-GCs but with these tweaks":

```bash
cp ~/.olympolabs/icp-profiles/construction-gc-canada.md \
   ~/.olympolabs/icp-profiles/construction-gc-texas.md
```

Open the new file and edit:
- Change "Canada" → "Texas" (or "US Sun Belt", or whatever)
- Adjust size band if different
- Adjust geographic exclusions

Then run the calibration pilot.

## Common patterns the LLM struggles with (without explicit ICP rules)

These are the patterns where the LLM defaults to "looks plausible →
Qualified" unless you explicitly call them out as DQ:

1. **Adjacent service providers** (firms that SERVE the ICP industry but
   aren't in it themselves)
   - "Software for construction firms" → not a construction firm
   - "Staffing for medical offices" → not a medical office
   - "Marketing agency for SaaS companies" → not a SaaS company

2. **Holding companies / parent orgs**
   - The parent is in the right industry but the entity you're targeting
     is admin/back-office

3. **Single-person LLCs / DBAs**
   - "Construction LLC" with 1 employee → too small for SMB outreach

4. **Out-of-geography branches**
   - US headquarters of a Canadian firm, vice versa

5. **Industry-adjacent terms that share keywords**
   - "Information architecture" → not an architecture firm
   - "Solution architect" → not an architecture firm
   - "Brand architecture" → not an architecture firm

Build these into the negative signals section of every ICP.

## When to write a new ICP vs reuse one

**Reuse / clone:**
- Same vertical, different geography ("dental offices in Texas" vs "dental
  offices in California")
- Same vertical, slightly different size band

**Write new:**
- Different vertical entirely
- Significantly different size band (SMB vs enterprise — different
  decision-makers, different signals)
- Different business model (B2C vs B2B)

## How long should an ICP file be?

The two we've shipped are ~2,800 chars (Canadian GCs) and ~3,700 chars
(US architecture firms). That's a good range. Under 1,500 chars usually
means you've under-specified the negatives, which leads to noisy scoring.

## Sharing ICPs across the team

Currently ICPs are per-user in `~/.olympolabs/icp-profiles/`. Two options
if the team needs to share:

1. **Copy-paste in Slack** — when someone writes a good ICP, paste the
   file contents in a team thread. Other teammates `Cmd+V` into their own
   profile folder.

2. **Add a `team-icp-profiles/` folder to this repo** — shared canonical
   ICPs that everyone gets via `git pull`. Discussed but not yet shipped.
   Team lead's call.

## The ICP is the lever

The skill is only as good as the ICP. The models, the concurrency, the
ZenRows tiering — all secondary. **A sharp ICP turns a noisy list into a
clean outreach pool. A vague ICP turns the same list into a partially
useless mess.**

Spend 15 minutes on the ICP file before the first run. Use the calibration
loop to sharpen it. Then reuse it for years.
