---
name: sales-brief
description: Generate a sales-call briefing for every Calendly booking on the morning of the call and post it to a Slack channel. By default briefs only "today's calls" (filter by start date in local timezone) and is meant to run daily at 8 AM via launchd / cron. Enriches the prospect via LeadMagic → Blitz → Icypeas cascade, scrapes the company website + LinkedIn profile via ZenRows, synthesizes a structured briefing with Sonnet (company snapshot, prospect dossier, talking points + leverage), and posts to a dedicated Slack channel via an incoming webhook. Trigger this skill whenever the user says "set up sales brief for my calls", "auto-brief me before sales calls", "research every booking on my Calendly", "send me a brief to Slack on the morning of each call", or anything resembling "give me a one-pager on every prospect who books a call". Skill is the briefing engine; the user wires the trigger externally (macOS launchd / cron / Cowork /schedule / Claude Code /loop). State (which bookings already processed) lives at ~/.olympolabs/sales-brief-state.json. Credentials at ~/.olympolabs/{calendly,leadmagic,blitz,icypeas,slack_webhook,openrouter,zenrows}.json.
---

# Sales Brief

Auto-generated one-pager for every new Calendly booking, delivered to Slack before the call.

## What it does

The orchestrator (`scripts/poll_and_brief.py`) is meant to run **every 30 minutes, all day** (via launchd / cron). It only briefs calls happening TODAY in your local timezone — so calls scheduled days in advance wait until their morning arrives, past calls auto-skip, and **same-day last-minute bookings get briefed within 30 min of when they come in** (not missed because the morning poll already ran). Same-day re-runs are deduped by the state file.

Each run:

1. **Pulls Calendly bookings** for the configured event type (Calendly v2 API)
2. **Filters to the configured window** (default: `--window today`)
3. **Skips already-briefed ones** by checking the local state file
4. For each remaining booking:
   a. **Enriches the prospect** via LeadMagic → Blitz → Icypeas cascade (first match wins). Returns LinkedIn URL, title, work history, bio.
   b. **Scrapes the company website** via ZenRows + trafilatura (the same foundation `company-scoring` uses)
   c. **Scrapes the prospect's LinkedIn profile** via ZenRows premium proxy (LinkedIn requires it)
   d. **Synthesizes a structured brief** with Claude Sonnet 4.6: company snapshot, prospect dossier, talking points + leverage
   e. **Posts to Slack** via an incoming webhook (one block-formatted message per brief)
5. **Records the booking UUID as processed** in `~/.olympolabs/sales-brief-state.json` so it never re-briefs the same call

The skill itself is the briefing engine. The trigger (every 30 min) is set up *outside* the skill — see "Wiring the trigger" below.

## What's in a brief (Slack format)

```
🔔 Sales Call · <prospect name> · <company>
   <scheduled time, formatted in your timezone>

📋 Company snapshot
   - Industry, size, stage
   - Products / services
   - Recent moves (news, hires, funding, launches)

👤 Prospect dossier
   - Title + tenure
   - LinkedIn URL
   - Public posts / signals
   - Career trajectory

🎯 Talking points & leverage (3-5 specific angles)
   - Hook 1 (with the company-specific or prospect-specific evidence)
   - Hook 2
   - ...

📝 Notes from the booking form (if any)
   - Whatever they wrote in the Calendly intake questions
```

## When to use this skill

Use whenever the user wants:
- An automated pre-call briefing pipeline
- A Slack one-pager for every prospect that books on a specific Calendly link
- To stop manually researching every booked sales call

Do NOT use for:
- One-off prospect research without a booking — that's a deep-research / web-search task
- Internal team calls (filter to the right Calendly event type so internal syncs don't trigger briefs)

## One-time setup (~15 min)

### 1. Slack incoming webhook (5 min)

See `references/slack-webhook-setup.md`. Result: a webhook URL scoped to a single channel like `#sales-briefs`. Save it:

```bash
mkdir -p ~/.olympolabs
cat > ~/.olympolabs/slack_webhook.json <<'EOF'
{"url": "https://hooks.slack.com/services/T.../B.../..."}
EOF
chmod 600 ~/.olympolabs/slack_webhook.json
```

### 2. Calendly Personal Access Token (3 min)

- Go to https://calendly.com/integrations/api_webhooks
- Generate a Personal Access Token (PAT)
- Save:

```bash
cat > ~/.olympolabs/calendly.json <<'EOF'
{
  "api_token": "eyJ...",
  "event_type_uri": "https://api.calendly.com/event_types/<UUID>",
  "user_uri": "https://api.calendly.com/users/<UUID>"
}
EOF
chmod 600 ~/.olympolabs/calendly.json
```

The skill's `doctor.py` will help you find the `event_type_uri` and `user_uri` from your Calendly URL (just paste e.g. `https://calendly.com/bryan/sales-call`).

### 3. Enrichment API keys (5 min)

You have three providers (cascade fallback — first match wins; cheaper / faster first):

```bash
cat > ~/.olympolabs/leadmagic.json  <<'EOF'
{"api_key": "..."}
EOF
cat > ~/.olympolabs/blitz.json      <<'EOF'
{"api_key": "..."}
EOF
cat > ~/.olympolabs/icypeas.json    <<'EOF'
{"api_key": "..."}
EOF
chmod 600 ~/.olympolabs/leadmagic.json ~/.olympolabs/blitz.json ~/.olympolabs/icypeas.json
```

Any provider whose key is missing is just skipped in the cascade. You can run with one, two, or all three.

### 4. Verify

```bash
python3 ~/.claude/skills/sales-brief/scripts/doctor.py
```

It checks every credential, every API connection, and reports exactly what's missing.

## Wiring the trigger (every 30 min, all day)

The skill doesn't schedule itself — pick a runner:

**Option A: macOS launchd (Recommended — always-on, no Claude Code needed)**
See `references/launchd-setup.md` for a ready-to-use `.plist` template that fires every 30 min with `--window today`. Catches same-day bookings within 30 min of when they're made.

**Option B: cron (Linux / Windows-WSL)**
```
*/30 * * * * /usr/bin/python3 /path/to/sales-brief/scripts/poll_and_brief.py --window today >> ~/.olympolabs/sales-brief.log 2>&1
```

**Option C: Claude Code `/loop`**
While Claude Code is open, run a 30-min poll:
```
/loop 30m python3 ~/.claude/skills/sales-brief/scripts/poll_and_brief.py --window today
```
Less reliable than launchd because it stops when Claude Code closes.

**Option D: Cowork `/schedule` (cloud-hosted, always-on)**
The most reliable but requires Cowork's scheduled-agents feature. The script needs access to your `~/.olympolabs/*.json` credentials in the cloud runtime.

## Manual mode

Without the trigger, you can run the script manually any time to catch up on briefs:

```bash
python3 ~/.claude/skills/sales-brief/scripts/poll_and_brief.py
```

It only processes bookings it hasn't seen before (state file), so running it multiple times by hand is safe.

Want to force re-brief a specific booking?

```bash
python3 ~/.claude/skills/sales-brief/scripts/poll_and_brief.py --force-booking <uuid>
```

## Decision rules

### Default model

`anthropic/claude-sonnet-4.6` — the briefing synthesis is judgment-heavy (deciding which company facts matter, what talking points actually leverage well). Sonnet earns its cost here. ~$0.05 per brief.

### Enrichment cascade order

1. **LeadMagic** (usually cheapest)
2. **Blitz**
3. **Icypeas**

Stop at first match (anything with a LinkedIn URL or substantive bio). Skip providers whose credentials aren't configured.

### Scrape sources

- Company website: scraped via ZenRows basic, falls through to premium on JS-heavy / Cloudflare sites
- LinkedIn profile: ZenRows premium proxy from the start (LinkedIn always requires JS rendering)

### State / dedupe

- Single state file: `~/.olympolabs/sales-brief-state.json`
- Schema: `{"processed_booking_uuids": ["<uuid1>", "<uuid2>", ...], "last_poll_at": "<iso8601>"}`
- A booking is "processed" the moment the Slack message is posted successfully — partial failures (e.g. scrape failed) DO mark the booking as processed; the brief will note what data was missing rather than being retried later with stale info.

### Time window for polling

Two-layer filter:
1. **Calendly fetch** pulls events with start_time in the last `--hours-back` hours (default 24h, which covers all of today plus yesterday — enough for a daily 8 AM run since today's morning calls are already in the past at run time).
2. **`--window` filter** narrows the fetch to the actual target window. Default: `--window today` = only events whose START is today in your local timezone.

Other `--window` values: `tomorrow` (preview-the-next-day mode, useful for an evening run), `all` (no filter — for catch-up), `last-N-hours` / `next-N-hours` (sliding windows).

Bookings outside the window are skipped silently — they'll get briefed automatically when their own day's poll fires.

The state file dedupes within a day. The default 8 AM + 12 PM backup launchd plist means a call briefed at 8 won't get re-briefed at noon.

## Mandatory final-pass audit

After every run, the orchestrator prints (and the doctor verifies):

1. **Briefs posted** — count of Slack messages successfully delivered this run
2. **Bookings skipped** — already in state, not new
3. **Errors** — any booking that failed enrichment AND scrape AND synthesis got POSTED with the available data, but is flagged in the log; the booking IS marked processed (we don't want to re-spam Slack on the next poll)
4. **Cost** — LLM + enrichment + scrape spend for this run

If any run posts zero briefs and zero errors, that's expected (no new bookings).

## Files

- `scripts/poll_and_brief.py` — main orchestrator
- `scripts/calendly_client.py` — Calendly v2 API wrapper
- `scripts/enrichment.py` — LeadMagic / Blitz / Icypeas cascade
- `scripts/research.py` — company + LinkedIn scrape helpers (uses ZenRows foundation)
- `scripts/brief_template.py` — Sonnet prompt + Slack Block Kit formatter
- `scripts/slack_client.py` — incoming-webhook poster
- `scripts/state.py` — JSON file state tracker
- `scripts/doctor.py` — credentials + connectivity diagnostic
- `references/credential-setup.md` — full credential setup
- `references/slack-webhook-setup.md` — Slack webhook walkthrough
- `references/launchd-setup.md` — macOS always-on runner
- `references/brief-format-example.md` — what a brief looks like
