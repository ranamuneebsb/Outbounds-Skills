# What a sales brief looks like in Slack

This is the rendered shape of one Slack message the orchestrator posts per
new Calendly booking.

---

🔔 **Sales Call · Sarah Chen · Anthropic**

VP Product · Wed Jun 18, 2026 · 2:00 PM UTC

[LinkedIn profile](https://www.linkedin.com/in/sarahchen)

---

**📋 Company snapshot**
- AI safety research lab, ~500 employees, Series C+
- Flagship: Claude (LLM family), released Claude 4.7 in May 2026
- Recent moves: $1.5B Anthropic-OpenAI talent migration in March; partnered with Apple for on-device AI in April
- Revenue: $5B ARR run-rate as of Q1 2026 (per The Information, May 2026)
- Hiring aggressively in safety + agentic AI (40+ open roles)

**👤 Prospect dossier**
- Joined Anthropic Dec 2024 from Stripe (was Head of Product, Payments)
- Owns product surface for Claude.ai consumer + Claude for Work
- Public: spoke at AI Engineer Summit June 2025 on "Latency budgets in agent loops"
- Active on LinkedIn (1-2 posts/month), mostly product-philosophy threads
- Based in San Francisco

**🎯 Talking points & leverage**

**1.** Lead with the on-device Apple partnership — they're publicly excited about it and it's a wedge into the consumer side she owns
   _Apple deal announced April 2026; Sarah commented on it on LinkedIn April 14_

**2.** Anchor on "agent latency" — she gave a whole talk on it last year, signals she cares about engineering tradeoffs beyond product polish
   _AI Engineer Summit June 2025 keynote: "Latency budgets in agent loops"_

**3.** If she pushes back on the cold outbound itself, mention you saw her Stripe → Anthropic transition; she's been through similar B2B-then-consumer pivots and knows the pattern
   _LinkedIn About section + work history from enrichment_

**4.** Avoid: pitching us as a competitor to their own Claude-for-Work copy generation. We complement it (we use Claude under the hood), not replace it.
   _Anthropic ToS + their own product page mentions cold-email generation as a top use case_

**📝 From the booking form**

**Q:** What are you hoping to get from this call?
**A:** Curious how OlympoLabs handles outbound personalization at scale — we've been thinking about a similar internal tool.

**Q:** Company name
**A:** Anthropic

---

## Notes on this example

- The bullet style is **fact-per-line**, not paragraphs. Reps scan, they don't read.
- Each talking point pairs the **hook** (what to say) with the **evidence** (why it'll land). The evidence is what saves the rep from sounding generic.
- "Avoid:" notes are optional but valuable when the LLM spots a clear miscue.
- If the LinkedIn scrape fails, the prospect dossier shrinks but the brief still posts — the missing-data note appears as a context block at the bottom.
- The brief stays under Slack's 50-block message limit and each text field stays under 3000 chars.

## Things you'll see in the wild

- **No-show prospects** still get briefed (we have no way to know in advance) — accept the slight noise.
- **Re-bookings** (same person reschedules) → Calendly issues a new event UUID, so you'll get a new brief for the new slot. Expected.
- **Recurring weekly events** are out of scope for v1 — every occurrence would trigger a brief.
- **Group calls** (more than one invitee) → the brief covers just the first invitee. Most sales calls are 1-on-1; if you commonly do group calls, ping the skill maintainer.
