# Always-on poller via macOS launchd

The sales-brief skill ships the orchestrator (`poll_and_brief.py`) but does NOT
install a system-level scheduler. The orchestrator runs with `--window today`
so it only briefs calls happening today in your local timezone. Past calls
auto-skip. Future calls wait until their day arrives.

**Cadence:** every 30 minutes, all day. This way:
- The 8 AM run picks up everything already on today's calendar (calls booked
  yesterday or earlier).
- The subsequent 30-min polls catch any **same-day** bookings — somebody
  booking a 2 PM call at 10 AM gets briefed within 30 min of the booking,
  long before the call starts.

The state file dedupes within the day — calls briefed at 8 AM won't get
re-briefed at 8:30, 9:00, etc.

For Linux equivalents: see the cron recipe at the bottom.

## macOS launchd — every 30 min (recommended)

1. Create the plist at `~/Library/LaunchAgents/com.olympolabs.sales-brief.plist`:

   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
   <plist version="1.0">
     <dict>
       <key>Label</key>
       <string>com.olympolabs.sales-brief</string>

       <key>ProgramArguments</key>
       <array>
         <string>/usr/bin/env</string>
         <string>python3</string>
         <string>/Users/YOUR_USER/.claude/skills/sales-brief/scripts/poll_and_brief.py</string>
         <string>--window</string>
         <string>today</string>
       </array>

       <!-- Every 30 minutes (1800 seconds), all day -->
       <key>StartInterval</key>
       <integer>1800</integer>

       <!-- Run once on load too, so the first install works immediately -->
       <key>RunAtLoad</key>
       <true/>

       <key>StandardOutPath</key>
       <string>/Users/YOUR_USER/.olympolabs/sales-brief.log</string>
       <key>StandardErrorPath</key>
       <string>/Users/YOUR_USER/.olympolabs/sales-brief.log</string>

       <key>EnvironmentVariables</key>
       <dict>
         <key>PATH</key>
         <string>/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin</string>
       </dict>
     </dict>
   </plist>
   ```

   Replace `YOUR_USER` with your macOS username. Save the file.

   Math: 48 polls/day. Each is one Calendly API call + (rarely) a brief
   generation if a new booking shows up. Calendly's rate limit is well above
   this. Worst case if a call gets booked at 10:01 AM, it briefs at 10:30 AM.

2. Load it:

   ```bash
   launchctl load ~/Library/LaunchAgents/com.olympolabs.sales-brief.plist
   ```

3. Verify it's loaded:

   ```bash
   launchctl list | grep sales-brief
   ```

4. Watch the log:

   ```bash
   tail -f ~/.olympolabs/sales-brief.log
   ```

   You'll see entries at 8 AM and 12 PM each day.

## Want briefs the evening BEFORE the call?

Add an 8 PM run that uses `--window tomorrow`:

```xml
<dict>
  <key>Hour</key><integer>20</integer>
  <key>Minute</key><integer>0</integer>
</dict>
```

…and a second plist that passes `--window tomorrow`. Two plists is cleaner
than one plist juggling both windows.

## Stop / restart / remove

- **Pause:** `launchctl unload ~/Library/LaunchAgents/com.olympolabs.sales-brief.plist`
- **Resume:** `launchctl load ~/Library/LaunchAgents/com.olympolabs.sales-brief.plist`
- **Permanent removal:** unload, then `rm ~/Library/LaunchAgents/com.olympolabs.sales-brief.plist`

## Linux / WSL cron

Every 30 min, all day:

```
*/30 * * * * /usr/bin/python3 $HOME/.claude/skills/sales-brief/scripts/poll_and_brief.py --window today >> $HOME/.olympolabs/sales-brief.log 2>&1
```

Add to your crontab via `crontab -e`. Same model as the launchd version: the script filters to today's calls and the state file dedupes, so 30-min polling is safe and catches both pre-existing morning calls and same-day last-minute bookings.

## Troubleshooting

- **Nothing happens at all** — check `~/.olympolabs/sales-brief.log` exists; if it doesn't, launchd never executed the job. The plist syntax is finicky; validate with `plutil ~/Library/LaunchAgents/com.olympolabs.sales-brief.plist`.
- **`python3: command not found`** — the launchd job's PATH is minimal. Either replace `/usr/bin/env python3` with the full absolute path to your python (`which python3`), or extend the `PATH` env var in the plist.
- **Auth errors in the log** — run `python3 ~/.claude/skills/sales-brief/scripts/doctor.py` interactively; the doctor will surface any missing credential the launchd job is failing on.
