# Creating a Slack incoming webhook for the sales-brief skill

Takes about 5 minutes. You create a Slack app, install it to your workspace, enable incoming webhooks, and copy the webhook URL into `~/.olympolabs/slack_webhook.json`.

## Steps

1. Go to **https://api.slack.com/apps** → **Create New App** → **From scratch**.
2. App name: `Sales Brief Bot` (or whatever). Workspace: the workspace where you want the briefs.
3. In the left sidebar → **Incoming Webhooks** → toggle **Activate Incoming Webhooks** to ON.
4. Scroll down → click **Add New Webhook to Workspace**.
5. Pick the channel where briefs should land (create `#sales-briefs` first if it doesn't exist). Click **Allow**.
6. Copy the **Webhook URL** that appears. It looks like `https://hooks.slack.com/services/T01234ABC/B01234DEF/abcdef1234567890...`
7. In a terminal:

   ```bash
   mkdir -p ~/.olympolabs
   cat > ~/.olympolabs/slack_webhook.json <<'EOF'
   {"url": "PASTE_YOUR_WEBHOOK_URL_HERE"}
   EOF
   chmod 600 ~/.olympolabs/slack_webhook.json
   ```

8. Smoke-test:

   ```bash
   curl -X POST -H 'Content-type: application/json' \
     --data '{"text":"sales-brief webhook test ✓"}' \
     "$(python3 -c 'import json; print(json.load(open("~/.olympolabs/slack_webhook.json".replace("~",__import__("os").path.expanduser("~"))))["url"])')"
   ```

   If you see `sales-brief webhook test ✓` in `#sales-briefs`, you're done.

## Notes

- One webhook = one channel. To send to a different channel later, create another webhook.
- If you ever lose or rotate the webhook URL, regenerate via the same App → Incoming Webhooks panel.
- The webhook URL is a **secret** — anyone with it can post to the channel. Don't commit it to git.
- If your workspace has app-install restrictions, ask the workspace admin to install the app for you.
