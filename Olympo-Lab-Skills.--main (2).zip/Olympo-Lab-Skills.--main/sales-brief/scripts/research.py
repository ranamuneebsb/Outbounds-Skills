"""
Web research helpers for the sales-brief skill.

Reuses the existing ZenRows + trafilatura foundation that the company-scoring
skill uses (no duplication). The interface:

  scrape_company(domain)  - returns trafilatura-extracted page text, or "" on failure
  scrape_linkedin(url)    - same, but always uses ZenRows premium proxy + JS render

Failures return empty strings — the caller decides whether to fall back to
"no data available" or skip the section.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

# Locate the shared foundations (same pattern the other skills use).
_SKILLS_ROOT_CANDIDATES = [
    Path(__file__).resolve().parent.parent.parent,
    Path.home() / "Desktop" / "OlympoLabs-Skills",
]
_SKILLS_ROOT = next(
    (p for p in _SKILLS_ROOT_CANDIDATES if (p / "zenrows-api" / "client.py").exists()),
    None,
)
if _SKILLS_ROOT is None:
    raise RuntimeError(
        "Cannot locate the zenrows-api foundation. Tried: "
        + ", ".join(str(p) for p in _SKILLS_ROOT_CANDIDATES)
    )

import importlib.util


def _load_module(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_name} from {file_path}")
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(Path(file_path).parent))
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


_zr_client_mod = _load_module("zr_client", _SKILLS_ROOT / "zenrows-api" / "client.py")
_zr_extract_mod = _load_module("zr_extract", _SKILLS_ROOT / "zenrows-api" / "extract.py")

ZenRowsClient      = _zr_client_mod.ZenRowsClient
ZenRowsError       = _zr_client_mod.ZenRowsError
extract_company_text = _zr_extract_mod.extract_company_text


# Per-row caps so the LLM batch stays a reasonable size.
COMPANY_TEXT_CAP = 12_000   # ~2-3 pages of trafilatura output
LINKEDIN_TEXT_CAP = 8_000   # LinkedIn profiles are usually compact


def _normalize_domain(domain_or_url: str) -> str:
    """Strip protocol/path so we have a bare hostname for the scrape URL."""
    d = (domain_or_url or "").strip()
    if d.startswith(("http://", "https://")):
        return d
    return "https://" + d.lstrip("/")


def scrape_company(domain: str) -> str:
    """Scrape a company's homepage. Returns trafilatura text capped at
    COMPANY_TEXT_CAP, or "" on failure (no exception, brief generator
    handles empty gracefully)."""
    if not domain:
        return ""
    try:
        client = ZenRowsClient()
    except Exception:
        return ""
    url = _normalize_domain(domain)
    # Try basic first; fall through to premium if basic returns empty.
    try:
        html = client.scrape(url, js_render=False, premium_proxy=False)
        text = extract_company_text(html, url=url, max_chars=COMPANY_TEXT_CAP) if html else ""
        if not text:
            html = client.scrape(url, js_render=True, premium_proxy=True)
            text = extract_company_text(html, url=url, max_chars=COMPANY_TEXT_CAP) if html else ""
    except ZenRowsError:
        return ""
    return text or ""


def scrape_linkedin(linkedin_url: str) -> str:
    """Scrape a LinkedIn profile. Always uses premium proxy + JS render because
    LinkedIn blocks basic requests. Returns trafilatura text capped at
    LINKEDIN_TEXT_CAP, or "" on failure."""
    if not linkedin_url:
        return ""
    try:
        client = ZenRowsClient()
    except Exception:
        return ""
    try:
        html = client.scrape(linkedin_url, js_render=True, premium_proxy=True)
        text = extract_company_text(html, url=linkedin_url, max_chars=LINKEDIN_TEXT_CAP) if html else ""
    except ZenRowsError:
        return ""
    return text or ""
