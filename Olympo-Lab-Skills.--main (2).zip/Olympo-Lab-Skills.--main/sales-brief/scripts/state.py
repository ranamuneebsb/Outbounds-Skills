"""
JSON-file state tracker for the sales-brief skill.

Tracks which Calendly booking UUIDs have already been briefed, so the
poll loop never re-briefs the same call. Single file at
~/.olympolabs/sales-brief-state.json — atomic writes via tempfile rename
so a crash mid-write can't corrupt it.
"""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Set


STATE_PATH = Path.home() / ".olympolabs" / "sales-brief-state.json"


def _empty_state() -> dict:
    return {"processed_booking_uuids": [], "last_poll_at": None}


def load_state() -> dict:
    """Return the current state dict. If the file doesn't exist, returns an
    empty skeleton (caller can use immediately; save_state() persists it)."""
    if not STATE_PATH.exists():
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        return _empty_state()
    try:
        with STATE_PATH.open("r", encoding="utf-8") as f:
            state = json.load(f)
    except (json.JSONDecodeError, OSError):
        # Corrupt file → start fresh rather than crash. The old data was
        # just "what was already briefed"; worst case we re-brief recent
        # bookings once.
        return _empty_state()
    # Defensive: normalize missing keys
    state.setdefault("processed_booking_uuids", [])
    state.setdefault("last_poll_at", None)
    return state


def save_state(state: dict) -> None:
    """Atomic write via tempfile + os.replace so partial-write crashes can't
    corrupt the file."""
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    state = dict(state)
    state["last_poll_at"] = datetime.now(timezone.utc).isoformat()
    tmp_fd, tmp_path = tempfile.mkstemp(dir=str(STATE_PATH.parent), prefix=".sales-brief-state.", suffix=".tmp")
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
        os.replace(tmp_path, STATE_PATH)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def already_processed(state: dict, booking_uuid: str) -> bool:
    return booking_uuid in set(state.get("processed_booking_uuids", []))


def mark_processed(state: dict, booking_uuid: str) -> dict:
    """Mutate + return state with the booking marked processed. Caller still
    needs to save_state() to persist."""
    seen: Set[str] = set(state.get("processed_booking_uuids", []))
    seen.add(booking_uuid)
    state["processed_booking_uuids"] = sorted(seen)
    return state
