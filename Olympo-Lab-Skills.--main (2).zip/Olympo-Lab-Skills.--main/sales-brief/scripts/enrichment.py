"""
Enrichment cascade: AI Ark → BlitzAPI → LeadMagic.

Given a prospect's email, tries each provider in order and returns the first
hit. Skips providers whose credentials aren't configured. Returns None if all
providers fail or no key is set.

Provider notes (verified against the real APIs):

  AI Ark      POST https://api.ai-ark.com/api/developer-portal/v1/people/reverse-lookup
              Header: X-TOKEN: <key>
              Response on hit: {"id": "...", "identifier": "linkedin-slug",
                                "profile": {full_name, headline, title, summary, ...},
                                "link": "...", "location": {default, city, state, ...},
                                "industry", "educations", "publications",
                                "position_groups", "skills", "company", "department"}
              Response on miss: HTTP 404 with {"error": "data not found"}
              Tried FIRST — user reports this as the most comprehensive
              database, and the response is the richest of the three.

  BlitzAPI    POST https://api.blitz-api.ai/v2/enrichment/email-to-person
              Header: x-api-key: <key>
              Response: {"found": bool, "person": {full_name, headline, about_me,
                         linkedin_url, experiences[], skills[], location{}, ...}}
              Solid fallback. Returns rich data on hits.

  LeadMagic   POST https://api.leadmagic.io/v1/people/email-to-profile
              Header: X-API-Key: <key>
              Response: {"profile_url": "https://linkedin.com/in/...",
                         "message": "...", "credits_consumed": N}
              Only returns a LinkedIn profile URL — we still need to scrape it
              downstream to get profile content. Lowest-fidelity but cheap
              (only 10 credits/hit). Last-resort fallback.

  Icypeas     NOT USED — Icypeas is an email FINDER (name+domain → email), not
              an email enricher. We already have the email; Icypeas can't help.

The unified `EnrichedProfile` shape this returns:
  {
    "provider": "blitz" | "leadmagic",
    "email": "...",
    "first_name": "...",
    "last_name": "...",
    "full_name": "...",
    "title": "...",          # headline / current job_title — may be empty for leadmagic
    "company_name": "...",   # current company from experiences[] — may be empty
    "company_domain": "...", # from experiences[].company_domain when present
    "linkedin_url": "...",   # ALWAYS the LinkedIn profile URL on a hit
    "bio": "...",            # about_me — may be empty
    "location": "...",       # human-readable, may be empty
    "raw": {...},            # provider's raw response, for debug + downstream
  }

Timeouts are tight (10s per call). A slow provider should fall through to the
next one fast, not stall the orchestrator. The whole cascade caps out around
~20s even when every provider misses or is sluggish.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


_CREDS_DIR = Path.home() / ".olympolabs"
_REQUEST_TIMEOUT = 10


class EnrichmentError(Exception):
    pass


def _load_key(filename: str) -> Optional[str]:
    """Return the api_key from ~/.olympolabs/<filename>, or None if missing."""
    path = _CREDS_DIR / filename
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            d = json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
    return d.get("api_key") or d.get("token")


# ---- Provider clients ----

def enrich_aiark(*, email: str, name: str = "", company: str = "") -> Optional[Dict[str, Any]]:
    """AI Ark reverse-people-lookup. Returns the unified profile dict or None."""
    key = _load_key("aiark.json")
    if not key:
        return None
    try:
        r = requests.post(
            "https://api.ai-ark.com/api/developer-portal/v1/people/reverse-lookup",
            headers={"X-TOKEN": key, "Content-Type": "application/json"},
            json={"search": email},
            timeout=_REQUEST_TIMEOUT,
        )
    except requests.RequestException:
        return None
    # 404 = "data not found" — clean miss. Anything else non-200 is unexpected; treat as miss.
    if r.status_code != 200:
        return None
    try:
        data = r.json()
    except ValueError:
        return None
    profile = data.get("profile") or {}
    # AI Ark stores LinkedIn slug in "identifier"; full URL sometimes in "link".
    linkedin_url = data.get("link") or ""
    identifier = data.get("identifier") or ""
    if not linkedin_url and identifier:
        linkedin_url = f"https://www.linkedin.com/in/{identifier}"
    # Pull current company + role from top-level "company" and "department" + first position_group
    company_obj = data.get("company") or {}
    company_name = (company_obj.get("name") if isinstance(company_obj, dict) else "") or company
    company_domain = (company_obj.get("domain") if isinstance(company_obj, dict) else "") or ""
    if not company_domain and isinstance(company_obj, dict):
        company_domain = company_obj.get("website") or ""
    # Location: use the human-readable "default" form
    loc = data.get("location") or {}
    loc_str = loc.get("default") or loc.get("short") or ""
    return {
        "provider": "aiark",
        "email": email,
        "first_name": profile.get("first_name", ""),
        "last_name": profile.get("last_name", ""),
        "full_name": profile.get("full_name") or name,
        "title": profile.get("title") or profile.get("headline", ""),
        "company_name": company_name,
        "company_domain": company_domain,
        "linkedin_url": linkedin_url,
        "bio": profile.get("summary") or "",
        "location": loc_str,
        "raw": data,
    }


def enrich_aiark_by_url(*, linkedin_url: str) -> Optional[Dict[str, Any]]:
    """AI Ark export/single — looks up a person by LinkedIn URL (not email).
    Use this when a thinner provider (LeadMagic, web-search fallback) gave
    us only a URL but no profile content. Returns the same unified shape
    as enrich_aiark()."""
    key = _load_key("aiark.json")
    if not key or not linkedin_url:
        return None
    try:
        r = requests.post(
            "https://api.ai-ark.com/api/developer-portal/v1/people/export/single",
            headers={"X-TOKEN": key, "Content-Type": "application/json"},
            json={"url": linkedin_url},
            timeout=_REQUEST_TIMEOUT,
        )
    except requests.RequestException:
        return None
    if r.status_code != 200:
        return None
    try:
        data = r.json()
    except ValueError:
        return None
    profile = data.get("profile") or {}
    if not profile:
        return None
    # Current-role detection: top-level "company" if present, else latest position_group
    company_obj = data.get("company") or {}
    company_name = (company_obj.get("name") if isinstance(company_obj, dict) else "") or ""
    company_domain = (company_obj.get("domain") if isinstance(company_obj, dict) else "") or ""
    current_title = profile.get("title") or profile.get("headline", "")
    pg = data.get("position_groups") or []
    if pg and isinstance(pg[0], dict):
        latest = pg[0]
        if not company_name and isinstance(latest.get("company"), dict):
            company_name = latest["company"].get("name", "")
        positions = latest.get("profile_positions") or []
        if positions and isinstance(positions[0], dict):
            current_title = current_title or positions[0].get("title", "")
    loc = data.get("location") or {}
    loc_str = loc.get("default") or loc.get("short") or ""
    return {
        "provider": "aiark_url",
        "email": data.get("email", ""),
        "first_name": profile.get("first_name", ""),
        "last_name": profile.get("last_name", ""),
        "full_name": profile.get("full_name", ""),
        "title": current_title,
        "company_name": company_name,
        "company_domain": company_domain,
        "linkedin_url": data.get("link") or linkedin_url,
        "bio": profile.get("summary") or "",
        "location": loc_str,
        "raw": data,
    }


def enrich_blitz(*, email: str, name: str = "", company: str = "") -> Optional[Dict[str, Any]]:
    """BlitzAPI reverse-email-lookup. Returns the unified profile dict or None."""
    key = _load_key("blitz.json")
    if not key:
        return None
    try:
        r = requests.post(
            "https://api.blitz-api.ai/v2/enrichment/email-to-person",
            headers={"x-api-key": key, "Content-Type": "application/json"},
            json={"email": email},
            timeout=_REQUEST_TIMEOUT,
        )
    except requests.RequestException:
        return None
    if r.status_code != 200:
        return None
    try:
        data = r.json()
    except ValueError:
        return None
    # Shape: {"found": bool, "person": {...} | null}
    if not data.get("found"):
        return None
    person = data.get("person") or {}
    if not person:
        return None
    # Pull the current job from experiences[] (job_is_current=true)
    experiences = person.get("experiences") or []
    current = next((e for e in experiences if e.get("job_is_current")), None) or (experiences[0] if experiences else {})
    # Build location string
    loc = person.get("location") or {}
    loc_str = " ".join(filter(None, [loc.get("city"), loc.get("state_code"), loc.get("country_code")]))
    return {
        "provider": "blitz",
        "email": email,
        "first_name": person.get("first_name", ""),
        "last_name": person.get("last_name", ""),
        "full_name": person.get("full_name") or name,
        "title": person.get("headline") or current.get("job_title", ""),
        "company_name": current.get("company_name") or company,
        "company_domain": current.get("company_domain", ""),
        "linkedin_url": person.get("linkedin_url", ""),
        "bio": person.get("about_me") or "",
        "location": loc_str,
        "raw": data,
    }


def enrich_leadmagic(*, email: str, name: str = "", company: str = "") -> Optional[Dict[str, Any]]:
    """LeadMagic email-to-profile (URL-only). Returns the unified profile dict or None.
    Only the linkedin_url is populated from LeadMagic — other fields come from the
    downstream LinkedIn scrape (or stay empty on miss)."""
    key = _load_key("leadmagic.json")
    if not key:
        return None
    try:
        r = requests.post(
            "https://api.leadmagic.io/v1/people/email-to-profile",
            headers={"X-API-Key": key, "Content-Type": "application/json"},
            json={"email": email},
            timeout=_REQUEST_TIMEOUT,
        )
    except requests.RequestException:
        return None
    if r.status_code != 200:
        return None
    try:
        data = r.json()
    except ValueError:
        return None
    # Shape on hit: {"profile_url": "https://www.linkedin.com/in/...", "message": "...", "credits_consumed": 10}
    # Shape on miss: {"message": "Profile not found.", "credits_consumed": 0}
    profile_url = data.get("profile_url") or ""
    if not profile_url:
        return None
    return {
        "provider": "leadmagic",
        "email": email,
        "first_name": "",
        "last_name": "",
        "full_name": name,
        "title": "",
        "company_name": company,
        "company_domain": "",
        "linkedin_url": profile_url,
        "bio": "",
        "location": "",
        "raw": data,
    }


# ---- Cascade orchestration ----

# Order matters: AI Ark first (user reports it as the most comprehensive
# database — and the response is the richest of the three). BlitzAPI second
# as a strong fallback. LeadMagic third as URL-only last-resort.
# Icypeas removed — it's an email finder, not enricher.
PROVIDERS: List[Callable[..., Optional[Dict[str, Any]]]] = [
    enrich_aiark,
    enrich_blitz,
    enrich_leadmagic,
]


def enrich(*, email: str, name: str = "", company: str = "") -> Optional[Dict[str, Any]]:
    """Run the cascade. Returns the first provider's hit, or None if all miss."""
    for fn in PROVIDERS:
        try:
            result = fn(email=email, name=name, company=company)
        except Exception:
            continue
        if result:
            return result
    return None


def configured_providers() -> List[str]:
    """Return the names of providers whose credential file is present."""
    names = []
    for filename in ("aiark.json", "blitz.json", "leadmagic.json"):
        if (_CREDS_DIR / filename).exists():
            names.append(filename.replace(".json", ""))
    return names
