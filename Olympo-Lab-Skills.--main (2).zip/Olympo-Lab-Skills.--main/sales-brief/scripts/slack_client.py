"""
Slack incoming-webhook poster.

Auth: a single webhook URL scoped to a single channel (created in Slack
app settings). Stored at ~/.olympolabs/slack_webhook.json as {"url": "..."}.

This is intentionally NOT a bot-token client — we only need one-way posting
to one channel. If we later need multi-channel posting, ephemeral messages,
or reading messages, we can upgrade to a bot token.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests


CREDS_PATH = Path.home() / ".olympolabs" / "slack_webhook.json"


class SlackError(Exception):
    pass


class SlackWebhook:
    def __init__(self, creds_path: Optional[Path] = None):
        path = creds_path or CREDS_PATH
        if not path.exists():
            raise SlackError(
                f"Slack webhook URL not found at {path}. "
                f"Create one in Slack at https://api.slack.com/messaging/webhooks "
                f"and save as {path} with key 'url'."
            )
        try:
            with path.open("r", encoding="utf-8") as f:
                creds = json.load(f)
        except json.JSONDecodeError as exc:
            raise SlackError(f"slack_webhook.json malformed: {exc}") from exc
        self._url = creds.get("url")
        if not self._url:
            raise SlackError(f"{path} missing 'url'")

    def post_blocks(self, blocks: List[Dict[str, Any]], *, fallback_text: str = "Sales brief") -> None:
        """Send a Block Kit message. fallback_text is what shows in Slack
        notifications (push, mobile preview)."""
        payload = {"text": fallback_text, "blocks": blocks}
        try:
            r = requests.post(self._url, json=payload, timeout=20)
        except requests.RequestException as exc:
            raise SlackError(f"webhook POST failed: {exc}") from exc
        if r.status_code != 200:
            raise SlackError(f"webhook POST returned {r.status_code}: {r.text[:200]}")

    def post_text(self, text: str) -> None:
        """Plain-text message. Use post_blocks for rich formatting."""
        try:
            r = requests.post(self._url, json={"text": text}, timeout=20)
        except requests.RequestException as exc:
            raise SlackError(f"webhook POST failed: {exc}") from exc
        if r.status_code != 200:
            raise SlackError(f"webhook POST returned {r.status_code}: {r.text[:200]}")
