#!/usr/bin/env python3
"""
Sales-brief orchestrator.

Designed to be run by launchd / cron / /loop / Cowork /schedule on the
"morning-of-meeting" cadence — by default, only bookings whose START is
TODAY in your local timezone get briefed. Past calls auto-skip. Future
calls wait until their day arrives. Same-day re-polls are deduped via
the state file.

For each in-window booking not yet briefed:
  1. Fetch invitee details
  2. Enrich the prospect via LeadMagic → Blitz → Icypeas cascade
  3. Scrape the company website (ZenRows + trafilatura)
  4. Scrape the prospect's LinkedIn profile (ZenRows premium)
  5. Generate a structured brief with Sonnet
  6. Post the brief to Slack via incoming webhook
  7. Mark the booking UUID as processed in the state file

A booking that fails enrichment AND scrape STILL gets briefed (with whatever
data was available) and marked processed — we don't want the next poll to
re-spam Slack with the same incomplete brief.

Run flags:
  --window today|tomorrow|next-N-hours|last-N-hours|all
                         Which bookings to consider. Default 'today' (most common case).
                         'tomorrow' is useful for an evening preview run.
                         'all' is for testing / catching up.
  --hours-back N         For 'last-N-hours' and 'next-N-hours' windows.
  --force-booking UUID   Re-brief a specific booking, bypass window + state file.
  --max-bookings N       Cap how many bookings to process (smoke-testing).
  --dry-run              Print the brief to stdout, don't post to Slack or mutate state.
"""

from __future__ import annotations

import argparse
import re
import sys
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent))

from calendly_client import CalendlyClient, CalendlyError, extract_uuid_from_uri  # noqa: E402
from enrichment       import enrich, configured_providers, enrich_aiark_by_url  # noqa: E402
from linkedin_search  import find_linkedin_url  # noqa: E402
from research         import scrape_company, scrape_linkedin  # noqa: E402
from brief_template   import generate_brief, format_slack_blocks, fallback_text  # noqa: E402
from slack_client     import SlackWebhook, SlackError  # noqa: E402
from state            import load_state, save_state, already_processed, mark_processed  # noqa: E402


def _in_window(start_time_iso: str, window: str, hours_back: int) -> bool:
    """Return True if a booking with the given start_time should be briefed
    under the configured window. start_time_iso comes from Calendly in UTC.
    The 'today' / 'tomorrow' comparisons use the local timezone of the machine
    running this script — that's what the user means by "the morning of"."""
    if not start_time_iso:
        return False
    try:
        start_utc = datetime.fromisoformat(start_time_iso.replace("Z", "+00:00"))
    except ValueError:
        return False
    start_local = start_utc.astimezone()
    now_local = datetime.now().astimezone()
    if window == "today":
        return start_local.date() == now_local.date()
    if window == "tomorrow":
        return start_local.date() == (now_local.date() + timedelta(days=1))
    if window == "all":
        return True
    if window.startswith("last-") and window.endswith("-hours"):
        try:
            n = int(window.removeprefix("last-").removesuffix("-hours"))
        except ValueError:
            return False
        cutoff = now_local - timedelta(hours=n)
        return cutoff <= start_local <= now_local
    if window.startswith("next-") and window.endswith("-hours"):
        try:
            n = int(window.removeprefix("next-").removesuffix("-hours"))
        except ValueError:
            return False
        cutoff = now_local + timedelta(hours=n)
        return now_local <= start_local <= cutoff
    # Unknown window string → safest default is to skip (caller passed bad input)
    return False


def _domain_from_email(email: str) -> str:
    """Pull the company domain out of an email address."""
    if not email or "@" not in email:
        return ""
    return email.split("@", 1)[1].strip().lower()


def _coerce_booking(event: Dict[str, Any], invitees: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Flatten Calendly's (event + invitees) pair into a single booking dict."""
    # For 1-on-1 calls, invitees is always length 1.
    inv = invitees[0] if invitees else {}
    questions = inv.get("questions_and_answers") or []
    return {
        "uuid":              extract_uuid_from_uri(event.get("uri", "")),
        "event_uuid":        extract_uuid_from_uri(event.get("uri", "")),
        "name":              inv.get("name") or inv.get("first_name", "") + " " + inv.get("last_name", ""),
        "email":             inv.get("email", ""),
        "company":           _company_from_qa(questions) or _company_from_domain(_domain_from_email(inv.get("email", ""))),
        "scheduled_time":    event.get("start_time", ""),
        "calendly_event_url": event.get("uri", ""),
        "questions_and_answers": [
            {"question": qa.get("question", ""), "answer": qa.get("answer", "")}
            for qa in questions if qa.get("question")
        ],
    }


def _company_from_qa(qa_list: List[Dict[str, Any]]) -> str:
    """Look for a 'company' answer in the intake form."""
    for qa in qa_list:
        q = (qa.get("question") or "").lower()
        if "company" in q or "organization" in q or "business" in q:
            ans = (qa.get("answer") or "").strip()
            if ans:
                return ans
    return ""


def _company_from_domain(domain: str) -> str:
    """Make a rough company name from an email domain. Used only when the
    intake form didn't ask for company name."""
    if not domain:
        return ""
    # Drop TLD, replace dashes/underscores with spaces, title case.
    bare = re.sub(r"\.[a-z]{2,}$", "", domain)
    bare = bare.split(".")[0]
    return bare.replace("-", " ").replace("_", " ").title()


def _process_booking(
    booking: Dict[str, Any],
    *,
    slack: Optional[SlackWebhook],
    dry_run: bool,
) -> Dict[str, Any]:
    """Returns a status dict: {"posted": bool, "error": str|None, "uuid": ..., "name": ...}"""
    result = {"uuid": booking["uuid"], "name": booking.get("name", ""), "posted": False, "error": None}
    email   = booking.get("email", "")
    company = booking.get("company", "")
    domain  = _domain_from_email(email)

    # ---- 1. Enrichment cascade ----
    try:
        profile = enrich(email=email, name=booking.get("name", ""), company=company)
    except Exception as exc:
        profile = None
        result["error"] = f"enrichment crashed: {exc}"

    # ---- 2. Scrape company website ----
    company_scrape = ""
    domain_to_scrape = (profile or {}).get("company_domain") or domain
    if domain_to_scrape:
        try:
            company_scrape = scrape_company(domain_to_scrape)
        except Exception:
            company_scrape = ""

    # ---- 3. Scrape LinkedIn profile (if we have a URL) ----
    # First try the URL the enrichment cascade gave us. If we don't have one,
    # fall back to a web-search-for-LinkedIn pass: search DDG/Google for
    # `site:linkedin.com/in NAME COMPANY` and use the first plausible match.
    # This catches the founders / early-stage prospects who aren't yet in any
    # B2B enrichment database.
    linkedin_url = (profile or {}).get("linkedin_url") or ""
    if not linkedin_url and booking.get("name"):
        try:
            linkedin_url = find_linkedin_url(
                name=booking.get("name", ""),
                company=booking.get("company", ""),
                domain=domain,
            ) or ""
        except Exception:
            linkedin_url = ""
        if linkedin_url:
            # Promote into the profile dict so the brief template + Slack header
            # both render the LinkedIn URL even when enrichment missed.
            if profile is None:
                profile = {"provider": "web_search", "linkedin_url": linkedin_url,
                           "full_name": booking.get("name", ""),
                           "company_name": booking.get("company", ""),
                           "first_name": "", "last_name": "", "title": "",
                           "company_domain": "", "bio": "", "location": "",
                           "raw": {"source": "web_search"}}
            else:
                profile["linkedin_url"] = linkedin_url
                profile.setdefault("provider", "web_search")

    # ---- 3b. Upgrade thin profiles via AI Ark's URL-based lookup ----
    # If we have a LinkedIn URL but the profile is thin (no bio / no title —
    # typical when LeadMagic or web-search gave us just a URL), call AI Ark's
    # /people/export/single which takes a URL and returns the same rich
    # shape as the email-based lookup. This rescues the brief quality without
    # depending on a flaky LinkedIn HTML scrape.
    needs_upgrade = bool(linkedin_url) and (
        not profile
        or not (profile.get("bio") or profile.get("title"))
    )
    if needs_upgrade:
        try:
            upgraded = enrich_aiark_by_url(linkedin_url=linkedin_url)
        except Exception:
            upgraded = None
        if upgraded:
            # Keep the email + any other useful fields from the original profile;
            # let the upgrade win on the richer fields.
            base = dict(profile) if profile else {"email": email}
            base.update({k: v for k, v in upgraded.items() if v or k not in base})
            base["provider"] = f"{(profile or {}).get('provider','')}+aiark_url".lstrip("+")
            profile = base

    linkedin_scrape = ""
    if linkedin_url:
        try:
            linkedin_scrape = scrape_linkedin(linkedin_url)
        except Exception:
            linkedin_scrape = ""

    # ---- 4. Generate the brief via LLM ----
    try:
        brief = generate_brief(
            booking=booking,
            profile=profile,
            company_scrape=company_scrape,
            linkedin_scrape=linkedin_scrape,
        )
    except Exception as exc:
        # If the LLM itself failed, still post a minimal degraded brief so
        # the rep has SOMETHING before the call. Mark processed regardless.
        brief = {
            "company_snapshot": f"- (brief generation failed: {str(exc)[:120]})",
            "prospect_dossier": "- (no synthesized dossier; see LinkedIn URL above if present)",
            "talking_points": [],
            "missing_data": "LLM synthesis failed; manual research recommended before the call.",
        }
        result["error"] = (result["error"] or "") + f" | brief gen failed: {exc}"

    # ---- 5. Format + post to Slack ----
    blocks = format_slack_blocks(booking=booking, profile=profile, brief=brief)
    if dry_run or slack is None:
        print("=" * 70)
        print("DRY-RUN brief for:", booking.get("name"), "·", booking.get("company"))
        print("=" * 70)
        import json as _json
        print(_json.dumps(blocks, indent=2))
        result["posted"] = True   # for accounting purposes in dry-run
        return result

    try:
        slack.post_blocks(blocks, fallback_text=fallback_text(booking))
        result["posted"] = True
    except SlackError as exc:
        result["error"] = (result["error"] or "") + f" | slack post failed: {exc}"
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Poll Calendly + post sales briefs to Slack.")
    parser.add_argument("--window", default="today",
                        help="Which bookings to consider: 'today' (default), 'tomorrow', "
                             "'last-N-hours', 'next-N-hours', or 'all'. "
                             "'today' = calls whose start is today in your local timezone.")
    parser.add_argument("--hours-back", type=int, default=24,
                        help="Calendly fetch window in hours (default 24). The --window filter is applied "
                             "on top of this. Increase if you want to catch bookings made far in advance.")
    parser.add_argument("--force-booking", help="UUID of a single booking to re-brief (bypasses --window AND state)")
    parser.add_argument("--max-bookings", type=int, help="Cap how many new bookings to process this run (smoke-testing)")
    parser.add_argument("--dry-run", action="store_true", help="Print briefs to stdout, don't post to Slack or update state")
    args = parser.parse_args()

    # Connectivity / config checks happen lazily — the doctor exists for explicit checks.
    try:
        calendly = CalendlyClient()
    except CalendlyError as exc:
        sys.stderr.write(f"ERROR: {exc}\n")
        return 2

    slack = None
    if not args.dry_run:
        try:
            slack = SlackWebhook()
        except SlackError as exc:
            sys.stderr.write(f"ERROR: {exc}\n")
            return 2

    providers = configured_providers()
    if not providers:
        sys.stderr.write(
            "WARNING: no enrichment providers configured. "
            "Drop a key at ~/.olympolabs/{leadmagic,blitz,icypeas}.json to enable.\n"
        )

    state = load_state()
    print(f"State: {len(state.get('processed_booking_uuids', []))} bookings already processed.")
    print(f"Enrichment providers active: {providers or '(none)'}")
    print(f"Polling Calendly for last {args.hours_back}h of bookings...")

    try:
        events = calendly.list_recent_scheduled_events(hours_back=args.hours_back)
    except CalendlyError as exc:
        sys.stderr.write(f"ERROR: {exc}\n")
        return 3
    print(f"  → {len(events)} events returned by Calendly")

    # Filter: drop already-processed bookings AND apply the time window.
    # --force-booking bypasses both filters (you explicitly want this one re-briefed).
    forced_uuid = args.force_booking.strip() if args.force_booking else None
    to_process = []
    skipped_processed = 0
    skipped_window = 0
    for event in events:
        uuid = extract_uuid_from_uri(event.get("uri", ""))
        if forced_uuid:
            if uuid == forced_uuid:
                to_process.append(event)
            continue
        if already_processed(state, uuid):
            skipped_processed += 1
            continue
        if not _in_window(event.get("start_time", ""), args.window, args.hours_back):
            skipped_window += 1
            continue
        to_process.append(event)
    print(f"  → {len(to_process)} bookings to brief  "
          f"(skipped: {skipped_processed} already-done, {skipped_window} outside --window={args.window})")

    if args.max_bookings and len(to_process) > args.max_bookings:
        print(f"  → capping to first {args.max_bookings} (per --max-bookings)")
        to_process = to_process[:args.max_bookings]

    if not to_process:
        save_state(state)  # touch last_poll_at
        return 0

    posted = 0
    errors: List[Dict[str, Any]] = []

    for event in to_process:
        uuid = extract_uuid_from_uri(event.get("uri", ""))
        try:
            invitees = calendly.list_invitees(uuid)
        except CalendlyError as exc:
            sys.stderr.write(f"  ! couldn't fetch invitees for {uuid}: {exc}\n")
            continue
        if not invitees:
            sys.stderr.write(f"  ! no invitees on event {uuid}, skipping\n")
            continue

        booking = _coerce_booking(event, invitees)
        print(f"  • {booking.get('name', '?'):30s}  {booking.get('email', ''):40s}  {booking.get('scheduled_time', '')}")

        try:
            result = _process_booking(booking, slack=slack, dry_run=args.dry_run)
        except Exception as exc:
            tb = traceback.format_exc(limit=3)
            sys.stderr.write(f"  ! unexpected failure processing {uuid}: {exc}\n{tb}\n")
            continue

        if result.get("posted"):
            posted += 1
        if result.get("error"):
            errors.append(result)

        # Mark processed regardless of partial failures (see SKILL.md).
        if not args.dry_run:
            mark_processed(state, uuid)
            save_state(state)   # persist after each booking — crash-safe

    print(f"\nDone. Posted {posted} brief(s). Errors: {len(errors)}.")
    for err in errors:
        print(f"  - {err.get('name')} ({err.get('uuid')}): {err.get('error')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
