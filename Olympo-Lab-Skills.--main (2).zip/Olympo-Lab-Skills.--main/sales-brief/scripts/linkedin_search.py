"""
LinkedIn URL finder via web search — last-resort fallback when the
enrichment cascade (BlitzAPI, LeadMagic) misses.

Strategy: scrape a search engine's results page for `site:linkedin.com/in
<name> <company>` and extract the first plausible /in/ profile URL.

We use DuckDuckGo's HTML SERP via ZenRows (the same scraping foundation
the rest of the skill uses). DDG is friendlier to scraping than Google
and doesn't paginate JS-heavy. If DDG misses entirely, we try Google as
a backup (ZenRows premium proxy required there).

Returns the LinkedIn URL on a hit, or None if no plausible match was found.
The downstream scrape_linkedin() in research.py is what actually pulls
profile content from that URL — this module just finds the URL.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Optional
from urllib.parse import quote_plus, urlparse, parse_qs, unquote

# Reuse the ZenRows foundation the company-scoring skill set up
_SKILLS_ROOT_CANDIDATES = [
    Path(__file__).resolve().parent.parent.parent,
    Path.home() / "Desktop" / "OlympoLabs-Skills",
]
_SKILLS_ROOT = next(
    (p for p in _SKILLS_ROOT_CANDIDATES if (p / "zenrows-api" / "client.py").exists()),
    None,
)
if _SKILLS_ROOT is None:
    raise RuntimeError("Cannot locate zenrows-api foundation")

import importlib.util


def _load_module(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_name} from {file_path}")
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(Path(file_path).parent))
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


_zr_client_mod = _load_module("zr_client", _SKILLS_ROOT / "zenrows-api" / "client.py")
ZenRowsClient = _zr_client_mod.ZenRowsClient
ZenRowsError = _zr_client_mod.ZenRowsError


# Matches https://www.linkedin.com/in/<slug>/?... and grabs just the canonical
# /in/slug part. The slug rules per LinkedIn allow alphanumerics, hyphens, and
# (rarely) percent-encoded unicode. We accept those plus a trailing slash.
_LINKEDIN_RE = re.compile(
    r"https?://(?:[a-z]{2,3}\.)?linkedin\.com/in/([A-Za-z0-9\-_%\.]+)(?:/|\?|$)",
    re.IGNORECASE,
)


def _normalize_linkedin_url(raw: str) -> str:
    """Strip tracking params, lower-case host, drop trailing slash."""
    m = _LINKEDIN_RE.search(raw)
    if not m:
        return ""
    slug = m.group(1).rstrip("/")
    return f"https://www.linkedin.com/in/{slug}"


def _extract_linkedin_urls_from_ddg(html: str) -> list:
    """DuckDuckGo's HTML SERP wraps target URLs in redirect links like
    /l/?uddg=ENCODED_URL. We pull from both the redirect-encoded form AND
    any raw linkedin.com URLs in the page."""
    urls = []
    # 1. DDG redirect form: /l/?...&uddg=ENCODED&...
    for match in re.finditer(r"/l/\?[^\"']*?uddg=([^&\"']+)", html):
        decoded = unquote(match.group(1))
        norm = _normalize_linkedin_url(decoded)
        if norm and norm not in urls:
            urls.append(norm)
    # 2. Raw linkedin.com matches anywhere in the HTML (fallback)
    for match in _LINKEDIN_RE.finditer(html):
        norm = _normalize_linkedin_url(match.group(0))
        if norm and norm not in urls:
            urls.append(norm)
    return urls


def _extract_linkedin_urls_from_google(html: str) -> list:
    """Google embeds results inside <a href="..."> tags. We bypass that and
    just grep raw linkedin.com URLs anywhere in the response."""
    urls = []
    for match in _LINKEDIN_RE.finditer(html):
        norm = _normalize_linkedin_url(match.group(0))
        if norm and norm not in urls:
            urls.append(norm)
    return urls


def find_linkedin_url(*, name: str, company: str = "", domain: str = "") -> Optional[str]:
    """Search for the prospect's LinkedIn URL and return the first plausible
    /in/ match. Returns None if nothing found.

    Strategy:
      1. Try DuckDuckGo HTML SERP (ZenRows basic — cheap, works most of the time).
      2. If DDG misses, try Google (ZenRows premium — more expensive but
         catches profiles DDG doesn't surface).

    The caller (poll_and_brief.py) should then pass the URL to
    research.scrape_linkedin() to actually pull profile content.
    """
    if not name:
        return None

    # Build the query: more relaxed than a strict site: filter — DDG often
    # returns ZERO results to `site:linkedin.com/in "Foo" "Bar"` even when
    # there's an obvious match, because the strict combo is rarely an exact
    # token-sequence on any indexed page. Quoting NAME (so DDG doesn't tokenize
    # it) and appending the keyword "linkedin" works much better.
    company_term = company or (domain.split(".")[0] if domain else "")
    query = f'"{name}" linkedin'
    if company_term:
        query = f'"{name}" "{company_term}" linkedin'

    try:
        client = ZenRowsClient()
    except Exception:
        return None

    # --- Step 1: DuckDuckGo (basic ZenRows, cheap) ---
    ddg_url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
    try:
        html = client.scrape(ddg_url, js_render=False, premium_proxy=False)
    except (ZenRowsError, Exception):
        # Transient network failures shouldn't crash the orchestrator —
        # the brief generator handles missing LinkedIn data gracefully.
        html = ""
    candidates = _extract_linkedin_urls_from_ddg(html) if html else []
    if candidates:
        return candidates[0]

    # --- Step 2: Google fallback (premium proxy required) ---
    google_url = f"https://www.google.com/search?q={quote_plus(query)}&num=10"
    try:
        html = client.scrape(google_url, js_render=False, premium_proxy=True)
    except (ZenRowsError, Exception):
        return None
    candidates = _extract_linkedin_urls_from_google(html) if html else []
    if candidates:
        return candidates[0]
    return None
