#!/usr/bin/env python3
"""
Sales-brief doctor — diagnoses every credential + every API connection.

Run me whenever something's broken or on first-time setup. I'll tell you
exactly what's missing and the exact command to fix it.

Also: if you pass a Calendly event URL like `https://calendly.com/bryan/sales-call`,
I'll resolve the user_uri and event_type_uri you need to put in ~/.olympolabs/calendly.json.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

CREDS_DIR = Path.home() / ".olympolabs"


def _color(s: str, code: str) -> str:
    if not sys.stdout.isatty():
        return s
    return f"\033[{code}m{s}\033[0m"


def ok(msg: str):   print(_color("  [OK]  ", "32") + msg)
def warn(msg: str): print(_color("  [!]   ", "33") + msg)
def err(msg: str):  print(_color("  [X]   ", "31") + msg)
def head(msg: str): print("\n" + _color(f"==> {msg}", "34"))


def _load_json_if_exists(path: Path):
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as exc:
        err(f"{path} is malformed JSON: {exc}")
        return False


def check_creds_dir():
    head("Credentials directory")
    if not CREDS_DIR.exists():
        warn(f"{CREDS_DIR} doesn't exist. Creating it (mode 700).")
        CREDS_DIR.mkdir(parents=True, exist_ok=True)
        os.chmod(CREDS_DIR, 0o700)
    ok(f"{CREDS_DIR} exists")


def check_calendly():
    head("Calendly")
    path = CREDS_DIR / "calendly.json"
    creds = _load_json_if_exists(path)
    if creds is None:
        err(f"{path} not found. Get a Personal Access Token at https://calendly.com/integrations/api_webhooks and save:")
        print(f"     cat > {path} <<'EOF'")
        print(f"     {{")
        print(f'       "api_token": "eyJ...",')
        print(f'       "event_type_uri": "https://api.calendly.com/event_types/<UUID>",')
        print(f'       "user_uri": "https://api.calendly.com/users/<UUID>"')
        print(f"     }}")
        print(f"     EOF")
        return False
    if creds is False:
        return False
    for k in ("api_token", "user_uri"):
        if not creds.get(k):
            err(f"{path} missing required key: {k}")
            return False
    if not creds.get("event_type_uri"):
        warn(f"{path} has no 'event_type_uri' — all event types will trigger briefs (probably not what you want).")
    # Connectivity
    try:
        from calendly_client import CalendlyClient, CalendlyError
        c = CalendlyClient()
        me = c.whoami()
        ok(f"Calendly auth OK: {me.get('name')} ({me.get('email')})")
        evts = c.list_event_types()
        ok(f"Found {len(evts)} active event types on this account")
        configured_etype = creds.get("event_type_uri")
        if configured_etype:
            matched = [e for e in evts if e.get("uri") == configured_etype]
            if matched:
                ok(f"Configured event_type_uri matches: {matched[0].get('name')}")
            else:
                err(f"Configured event_type_uri NOT FOUND on this account: {configured_etype}")
                print("     Available event types (use one of these URIs):")
                for e in evts:
                    print(f"       {e.get('name'):30s}  {e.get('uri')}")
                return False
        return True
    except Exception as exc:
        err(f"Calendly connectivity failed: {exc}")
        return False


def check_enrichment():
    head("Enrichment providers")
    found = []
    for name in ("leadmagic", "blitz", "icypeas"):
        path = CREDS_DIR / f"{name}.json"
        creds = _load_json_if_exists(path)
        if creds is None:
            warn(f"{path} not found (provider will be skipped)")
        elif creds is False:
            continue
        elif not (creds.get("api_key") or creds.get("token")):
            err(f"{path} missing 'api_key'")
        else:
            ok(f"{name}: credentials present")
            found.append(name)
    if not found:
        err("No enrichment providers configured. Drop a key in at least one of:")
        for name in ("leadmagic", "blitz", "icypeas"):
            print(f"     {CREDS_DIR}/{name}.json   {{\"api_key\": \"...\"}}")
        return False
    return True


def check_zenrows():
    head("ZenRows (used for company + LinkedIn scrape)")
    path = CREDS_DIR / "zenrows.json"
    creds = _load_json_if_exists(path)
    if creds is None:
        err(f"{path} not found. Get a key at https://app.zenrows.com/users/api-keys")
        return False
    if not creds.get("api_key"):
        err(f"{path} missing 'api_key'")
        return False
    ok("ZenRows credentials present")
    return True


def check_openrouter():
    head("OpenRouter (used for brief synthesis with Sonnet)")
    path = CREDS_DIR / "openrouter.json"
    creds = _load_json_if_exists(path)
    if creds is None:
        err(f"{path} not found. Get a key at https://openrouter.ai/keys")
        return False
    if not creds.get("api_key"):
        err(f"{path} missing 'api_key'")
        return False
    ok("OpenRouter credentials present")
    return True


def check_slack():
    head("Slack incoming webhook")
    path = CREDS_DIR / "slack_webhook.json"
    creds = _load_json_if_exists(path)
    if creds is None:
        err(f"{path} not found.")
        print("     Create a Slack app + webhook (see references/slack-webhook-setup.md), then:")
        print(f"     cat > {path} <<'EOF'")
        print(f'     {{"url": "https://hooks.slack.com/services/T.../B.../..."}}')
        print(f"     EOF")
        return False
    if not creds.get("url"):
        err(f"{path} missing 'url'")
        return False
    ok("Slack webhook URL present")
    return True


def check_state():
    head("State file")
    state_path = CREDS_DIR / "sales-brief-state.json"
    if not state_path.exists():
        warn(f"{state_path} doesn't exist yet — will be created on first poll.")
    else:
        try:
            with state_path.open("r", encoding="utf-8") as f:
                s = json.load(f)
            ok(f"{len(s.get('processed_booking_uuids', []))} bookings tracked  ·  last poll: {s.get('last_poll_at') or 'never'}")
        except json.JSONDecodeError as exc:
            err(f"{state_path} is corrupt: {exc}. Delete it to start fresh.")
            return False
    return True


def resolve_calendly_url(public_url: str):
    """Given e.g. https://calendly.com/bryan/sales-call, print the matching
    event_type_uri to drop into calendly.json. Requires Calendly creds with
    api_token + user_uri already configured."""
    head(f"Resolving Calendly URL: {public_url}")
    try:
        from calendly_client import CalendlyClient
        c = CalendlyClient()
        evts = c.list_event_types()
        # Calendly event_type has a "scheduling_url" field with the public link.
        match = next((e for e in evts if (e.get("scheduling_url") or "").rstrip("/") == public_url.rstrip("/")), None)
        if not match:
            err(f"No event type matched scheduling_url={public_url}")
            print("     Available scheduling URLs on this account:")
            for e in evts:
                print(f"       {e.get('scheduling_url')}")
            return False
        ok(f"Matched event type: {match.get('name')}")
        print(f"     event_type_uri: {match.get('uri')}")
        print(f"     Update {CREDS_DIR/'calendly.json'} so 'event_type_uri' equals the line above.")
        return True
    except Exception as exc:
        err(f"Couldn't resolve: {exc}")
        return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--resolve-url", help="Resolve a public Calendly URL to its event_type_uri")
    args = parser.parse_args()

    check_creds_dir()
    cal_ok    = check_calendly()
    enr_ok    = check_enrichment()
    zr_ok     = check_zenrows()
    or_ok     = check_openrouter()
    slack_ok  = check_slack()
    state_ok  = check_state()

    if args.resolve_url:
        resolve_calendly_url(args.resolve_url)

    head("Summary")
    blockers = []
    if not cal_ok:    blockers.append("calendly")
    if not enr_ok:    blockers.append("enrichment")
    if not zr_ok:     blockers.append("zenrows")
    if not or_ok:     blockers.append("openrouter")
    if not slack_ok:  blockers.append("slack")
    if blockers:
        err(f"Not ready to run. Missing/broken: {', '.join(blockers)}")
        return 1
    ok("All systems go. Run:  python3 scripts/poll_and_brief.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
