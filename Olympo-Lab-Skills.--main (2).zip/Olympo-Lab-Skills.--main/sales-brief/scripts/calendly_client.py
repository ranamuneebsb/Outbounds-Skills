"""
Calendly v2 API client.

Auth: Bearer token (Personal Access Token from calendly.com/integrations/api_webhooks).
Endpoints we use:
  GET /scheduled_events   - list events, filter by event_type + time window
  GET /scheduled_events/{uuid}/invitees   - get invitee details (email, name, custom Q&A)

Bookings are returned newest-first. The orchestrator filters out already-processed
UUIDs via the state file.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests


CALENDLY_API = "https://api.calendly.com"
CREDS_PATH = Path.home() / ".olympolabs" / "calendly.json"


class CalendlyError(Exception):
    pass


class CalendlyClient:
    def __init__(self, creds_path: Optional[Path] = None):
        path = creds_path or CREDS_PATH
        if not path.exists():
            raise CalendlyError(
                f"Calendly credentials not found at {path}. "
                "Get a Personal Access Token at https://calendly.com/integrations/api_webhooks "
                f"and save as {path} with keys 'api_token', 'event_type_uri', 'user_uri'."
            )
        try:
            with path.open("r", encoding="utf-8") as f:
                creds = json.load(f)
        except json.JSONDecodeError as exc:
            raise CalendlyError(f"calendly.json malformed: {exc}") from exc
        self._token = creds.get("api_token") or creds.get("token")
        self._event_type_uri = creds.get("event_type_uri")
        self._user_uri = creds.get("user_uri")
        if not self._token:
            raise CalendlyError(f"{path} missing 'api_token'")
        if not self._user_uri:
            raise CalendlyError(f"{path} missing 'user_uri'. Use doctor.py to discover it from your Calendly URL.")
        # event_type_uri is optional (None = all event types for the user)
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
        })

    def whoami(self) -> Dict[str, Any]:
        """GET /users/me - cheap connectivity + auth check."""
        r = self._session.get(f"{CALENDLY_API}/users/me", timeout=20)
        if r.status_code != 200:
            raise CalendlyError(f"GET /users/me returned {r.status_code}: {r.text[:200]}")
        return r.json().get("resource", {})

    def list_event_types(self) -> List[Dict[str, Any]]:
        """Return all event types for the configured user (handy for discovery)."""
        r = self._session.get(
            f"{CALENDLY_API}/event_types",
            params={"user": self._user_uri, "active": "true"},
            timeout=20,
        )
        if r.status_code != 200:
            raise CalendlyError(f"GET /event_types returned {r.status_code}: {r.text[:200]}")
        return r.json().get("collection", [])

    def list_recent_scheduled_events(
        self,
        *,
        hours_back: int = 24,
        status: str = "active",
    ) -> List[Dict[str, Any]]:
        """List scheduled events (bookings) created in the last `hours_back` hours.

        Filters by event_type if event_type_uri is configured.
        status='active' excludes cancellations; pass 'canceled' or None for all.
        """
        now = datetime.now(timezone.utc)
        min_start = now - timedelta(hours=hours_back)
        params: Dict[str, Any] = {
            "user": self._user_uri,
            "min_start_time": min_start.isoformat(),
            "count": 100,
            "sort": "start_time:asc",
        }
        if status:
            params["status"] = status
        if self._event_type_uri:
            params["event_type"] = self._event_type_uri

        events: List[Dict[str, Any]] = []
        url = f"{CALENDLY_API}/scheduled_events"
        while url:
            r = self._session.get(url, params=params if events == [] else None, timeout=30)
            if r.status_code != 200:
                raise CalendlyError(f"GET /scheduled_events returned {r.status_code}: {r.text[:300]}")
            body = r.json()
            events.extend(body.get("collection", []))
            next_page = body.get("pagination", {}).get("next_page")
            url = next_page
        return events

    def list_invitees(self, event_uuid: str) -> List[Dict[str, Any]]:
        """Each scheduled event can have 1+ invitees. For 1-on-1 calls it's
        always one. Returns the full invitee object including email, name,
        and any custom intake-form Q&A."""
        url = f"{CALENDLY_API}/scheduled_events/{event_uuid}/invitees"
        r = self._session.get(url, timeout=20)
        if r.status_code != 200:
            raise CalendlyError(f"GET invitees for {event_uuid} returned {r.status_code}: {r.text[:200]}")
        return r.json().get("collection", [])


def extract_uuid_from_uri(uri: str) -> str:
    """Calendly URIs look like https://api.calendly.com/scheduled_events/<UUID>.
    Returns just the UUID."""
    return uri.rstrip("/").split("/")[-1]
