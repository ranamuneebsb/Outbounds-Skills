"""
Brief generator: turns (booking + enriched profile + scrapes) into a
structured markdown brief, then formats it as Slack Block Kit blocks.

Uses Claude Sonnet 4.6 via OpenRouter — the synthesis is judgment-heavy
(deciding which company facts matter, what talking points actually leverage
well) and Sonnet earns its cost on this step.

The brief has four named sections:
  1. Header (prospect name, title, company, scheduled time)
  2. Company snapshot (industry / size / products / recent news)
  3. Prospect dossier (background / role / public signals)
  4. Talking points & leverage (3-5 specific angles)

All sections gracefully handle missing data — if the LinkedIn scrape failed,
the prospect section says so explicitly rather than fabricating.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# Locate the shared openrouter foundation
_SKILLS_ROOT_CANDIDATES = [
    Path(__file__).resolve().parent.parent.parent,
    Path.home() / "Desktop" / "OlympoLabs-Skills",
]
_SKILLS_ROOT = next(
    (p for p in _SKILLS_ROOT_CANDIDATES if (p / "openrouter-api" / "client.py").exists()),
    None,
)
if _SKILLS_ROOT is None:
    raise RuntimeError("Cannot locate openrouter-api foundation")

import importlib.util


def _load_module(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {module_name} from {file_path}")
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(Path(file_path).parent))
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


_or_client_mod = _load_module("or_client", _SKILLS_ROOT / "openrouter-api" / "client.py")
OpenRouterClient = _or_client_mod.OpenRouterClient
OpenRouterError = _or_client_mod.OpenRouterError


BRIEF_MODEL = "anthropic/claude-sonnet-4.6"


SYSTEM_PROMPT = """\
You write structured pre-call sales briefings for OlympoLabs. The user is the
sales rep who will take the call. Your output is the ONLY context they will
have going in — be specific, sourced, and skim-friendly.

INPUTS YOU RECEIVE
==================
- Booking metadata (prospect name, company, scheduled time, intake-form Q&A)
- Enriched prospect profile (title, work history, LinkedIn URL, bio) when available
- Scraped company website text (trafilatura output)
- Scraped LinkedIn profile text (when scrape succeeded)

OUTPUT FORMAT
=============
Return ONLY a JSON object with this exact shape:

{
  "company_snapshot": "<3-6 short bullet points, markdown '- ' prefix, one fact per line>",
  "prospect_dossier": "<4-7 bullet points covering: WHERE THEY'RE BASED (location/city), CAREER TRAJECTORY (current role + tenure, notable prior roles), and SIGNIFICANT POSTS / PUBLIC ACTIVITY (anything they've publicly written, spoken at, launched, raised, hired for — anything the sales rep can specifically remark on). One fact per bullet. Skip the bullet entirely if you don't have evidence for it — don't pad.>",
  "talking_points": [
    {"hook": "<one-line opener or angle>", "evidence": "<the company / prospect fact that justifies it>"},
    {"hook": "...", "evidence": "..."},
    {"hook": "...", "evidence": "..."}
  ],
  "missing_data": "<one short note IF significant data was missing (e.g. 'LinkedIn scrape failed — prospect bullets are from enrichment only'). Otherwise empty string.>"
}

PROSPECT DOSSIER — what to put in each bullet
=============================================
The user (sales rep) specifically wants three things they can leverage on the call:
1. **Where they're based** — city / region / country (lead with this if you have it)
2. **Career info** — current title + tenure at current company, previous role(s) if notable, founder/operator history, any meaningful career pattern (e.g. "joined Anthropic from Stripe in 2024", "founded 2 companies before this one")
3. **Significant public posts / activity** — recent LinkedIn posts, talks they gave, podcasts they appeared on, products they launched, fundraises they led, hires they announced. Quote the substance briefly so the rep can reference it specifically ("their March 2026 post on agent latency", not just "active on LinkedIn"). If the LinkedIn scrape surfaced specific post content, quote a short phrase from it.

If you genuinely don't have evidence for one of those buckets, OMIT that bullet rather than filling with generic filler. Better 3 specific bullets than 6 vague ones.

RULES
=====
- BULLETS MUST BE SPECIFIC. "Recently raised $30M Series B" beats "Recently raised funding".
- NEVER FABRICATE. If the scrape is thin or missing, say so in `missing_data` and keep bullets shorter.
- TALKING POINTS MUST LADDER TO EVIDENCE. The `evidence` field is what convinces the rep this hook is real, not invented.
- 3-5 talking points. Quality over quantity. If you only have 3 strong ones, return 3.
- TONE: tight, factual, sales-rep-friendly. No marketing fluff. No "leverage this" / "synergy". Concrete only.
- NEVER include the booking metadata in your output (the orchestrator adds the header separately).
- NEVER use markdown headers (# / ##) in the bullet strings — just plain `- ` bullets, one per line.
"""


def _user_message(
    booking: Dict[str, Any],
    profile: Optional[Dict[str, Any]],
    company_scrape: str,
    linkedin_scrape: str,
) -> str:
    payload = {
        "booking": {
            "prospect_email":   booking.get("email", ""),
            "prospect_name":    booking.get("name", ""),
            "company_guess":    booking.get("company", ""),
            "scheduled_time":   booking.get("scheduled_time", ""),
            "form_responses":   booking.get("questions_and_answers", []),
        },
        "enriched_profile": profile or {"note": "No enrichment match — providers returned no result"},
        "company_scrape":    company_scrape or "(empty - scrape failed or site blocked)",
        "linkedin_scrape":   linkedin_scrape or "(empty - LinkedIn scrape failed or no URL)",
    }
    return (
        "Generate the sales brief for the booking below. Return JSON only per the format spec.\n\n"
        + json.dumps(payload, ensure_ascii=False, indent=2)
    )


def generate_brief(
    *,
    booking: Dict[str, Any],
    profile: Optional[Dict[str, Any]],
    company_scrape: str,
    linkedin_scrape: str,
    model: str = BRIEF_MODEL,
) -> Dict[str, Any]:
    """Returns the parsed JSON dict from the LLM. Raises OpenRouterError on
    auth / network / parse failure (caller decides whether to retry or post
    a degraded brief)."""
    client = OpenRouterClient()
    resp = client.chat(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": _user_message(booking, profile, company_scrape, linkedin_scrape)},
        ],
        json_mode=True,
        temperature=0.2,
        # 4000 is the upper bound a Sonnet brief needs even for content-heavy companies.
        # 2000 was occasionally truncating mid-JSON on rich scrapes (e.g. Madaket Health),
        # producing unparseable output that fell through to the degraded-brief path.
        max_tokens=4000,
    )
    parsed = client.parse_json_content(resp)
    # Defensive normalization
    parsed.setdefault("company_snapshot", "")
    parsed.setdefault("prospect_dossier", "")
    parsed.setdefault("talking_points", [])
    parsed.setdefault("missing_data", "")
    return parsed


# ---- Slack Block Kit formatting ----

def format_slack_blocks(
    *,
    booking: Dict[str, Any],
    profile: Optional[Dict[str, Any]],
    brief: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Render the brief as Slack Block Kit. Keep blocks under Slack's 50-block
    limit (we use ~7) and 3000-char-per-text-field limit (we cap)."""
    name        = booking.get("name", "(unknown invitee)")
    company     = (profile or {}).get("company_name") or booking.get("company", "(unknown company)")
    title       = (profile or {}).get("title", "")
    when        = _format_when(booking.get("scheduled_time", ""))
    linkedin    = (profile or {}).get("linkedin_url", "")

    header_line = f"🔔 *Sales Call · {name} · {company}*"
    subtitle_parts = []
    if title:
        subtitle_parts.append(title)
    if when:
        subtitle_parts.append(when)
    subtitle = " · ".join(subtitle_parts)

    blocks: List[Dict[str, Any]] = [
        {"type": "section", "text": {"type": "mrkdwn", "text": header_line}},
    ]
    if subtitle:
        blocks.append({"type": "context", "elements": [{"type": "mrkdwn", "text": subtitle}]})
    if linkedin:
        blocks.append({"type": "context", "elements": [{"type": "mrkdwn", "text": f"<{linkedin}|LinkedIn profile>"}]})

    blocks.append({"type": "divider"})

    if brief.get("company_snapshot"):
        blocks.append({"type": "section", "text": {"type": "mrkdwn",
                       "text": f"*📋 Company snapshot*\n{_truncate(brief['company_snapshot'], 2800)}"}})
    if brief.get("prospect_dossier"):
        blocks.append({"type": "section", "text": {"type": "mrkdwn",
                       "text": f"*👤 Prospect dossier*\n{_truncate(brief['prospect_dossier'], 2800)}"}})

    talking_points = brief.get("talking_points") or []
    if talking_points:
        tp_lines = []
        for i, tp in enumerate(talking_points, 1):
            hook = (tp.get("hook") or "").strip()
            evidence = (tp.get("evidence") or "").strip()
            if hook:
                line = f"*{i}.* {hook}"
                if evidence:
                    line += f"\n     _{evidence}_"
                tp_lines.append(line)
        if tp_lines:
            blocks.append({"type": "section", "text": {"type": "mrkdwn",
                           "text": f"*🎯 Talking points & leverage*\n" + "\n".join(tp_lines)[:2800]}})

    form_qa = booking.get("questions_and_answers") or []
    if form_qa:
        qa_lines = [f"*Q:* {qa.get('question', '')}\n*A:* {qa.get('answer', '')}" for qa in form_qa if qa.get('question')]
        if qa_lines:
            blocks.append({"type": "section", "text": {"type": "mrkdwn",
                           "text": f"*📝 From the booking form*\n" + "\n\n".join(qa_lines)[:2800]}})

    if brief.get("missing_data"):
        blocks.append({"type": "context", "elements": [{"type": "mrkdwn", "text": f"_⚠ {brief['missing_data']}_"}]})

    return blocks


def fallback_text(booking: Dict[str, Any]) -> str:
    """Notification preview text — what shows on mobile push, etc."""
    name = booking.get("name", "(unknown)")
    company = booking.get("company", "")
    return f"Sales brief · {name}" + (f" · {company}" if company else "")


def _format_when(iso_ts: str) -> str:
    if not iso_ts:
        return ""
    try:
        dt = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
        return dt.strftime("%a %b %-d, %Y · %-I:%M %p UTC")
    except (ValueError, AttributeError):
        return iso_ts


def _truncate(text: str, n: int) -> str:
    if not text:
        return ""
    return text if len(text) <= n else text[:n - 3] + "..."
