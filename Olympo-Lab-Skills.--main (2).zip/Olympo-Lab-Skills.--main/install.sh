#!/usr/bin/env bash
#
# OlympoLabs Skills - one-command install
#
# Run this after cloning the repo. Re-runnable safely (idempotent).
# Installs all .skill files at the repo root into ~/.claude/skills/ and prints next
# steps for credentials + gcloud + the Copywriter knowledge-base doc.
#
# Usage:
#   ./install.sh
#

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_DIR="$HOME/.claude/skills"
OLYMPO_DIR="$HOME/.olympolabs"

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # no color

step() { echo -e "\n${BLUE}==> $1${NC}"; }
ok()   { echo -e "${GREEN}    ✓ $1${NC}"; }
warn() { echo -e "${YELLOW}    ! $1${NC}"; }
err()  { echo -e "${RED}    ✗ $1${NC}"; }

# ----------------------------------------------------------------------------
step "Verifying prerequisites"

if ! command -v python3 >/dev/null 2>&1; then
  err "python3 not found. Install Python 3.9+ first."
  exit 1
fi
ok "python3 is installed ($(python3 --version))"

if ! command -v gcloud >/dev/null 2>&1; then
  warn "gcloud CLI not found - required for the company-scoring skill (Google Sheets write access)."
  warn "Install via: brew install --cask google-cloud-sdk"
  warn "You can finish the install now and add gcloud later."
else
  ok "gcloud is installed"
fi

if ! command -v unzip >/dev/null 2>&1; then
  err "unzip not found. (It should be on macOS by default.)"
  exit 1
fi

# Check Python deps - install missing ones with --user
echo
echo "    Checking Python dependencies..."
PYTHON_DEPS=(
  "requests"
  "google.oauth2.service_account"
  "googleapiclient.discovery"
  "trafilatura"
)
MISSING_DEPS=()
for mod in "${PYTHON_DEPS[@]}"; do
  if ! python3 -c "import $mod" >/dev/null 2>&1; then
    MISSING_DEPS+=("$mod")
  fi
done
if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
  warn "Missing Python modules: ${MISSING_DEPS[*]}"
  echo "    Installing them now (pip3 install --user)..."
  pip3 install --user --quiet \
    requests \
    google-api-python-client \
    google-auth \
    google-auth-oauthlib \
    trafilatura \
    || { err "pip install failed - install manually and re-run."; exit 1; }
  ok "Python deps installed"
else
  ok "All Python deps present"
fi

# ----------------------------------------------------------------------------
step "Creating directories"

mkdir -p "$SKILLS_DIR"
ok "$SKILLS_DIR"

mkdir -p "$OLYMPO_DIR/icp-profiles"
chmod 700 "$OLYMPO_DIR"
ok "$OLYMPO_DIR (mode 700)"

# ----------------------------------------------------------------------------
step "Vendoring foundations into self-contained skills"

# Some skills (e.g. company-scoring) bundle the shared foundation packages under
# their OWN scripts/lib/ so they run standalone with zero path dependence - no
# more "Claude rebuilds the scripts because the repo isn't where it expected".
# Each such skill lists the packages it needs in scripts/lib/.foundations. We
# re-sync those from the repo root (the single source of truth) and then rebuild
# that skill's .skill bundle so the vendored copies actually ship. Idempotent.
if command -v zip >/dev/null 2>&1; then
  for marker in "$REPO_DIR"/*/scripts/lib/.foundations; do
    [ -e "$marker" ] || continue
    skill_dir="$(cd "$(dirname "$marker")/../.." && pwd)"
    skill_name="$(basename "$skill_dir")"
    libdir="$skill_dir/scripts/lib"
    while IFS= read -r pkg || [ -n "$pkg" ]; do
      [ -z "$pkg" ] && continue
      if [ -d "$REPO_DIR/$pkg" ]; then
        rm -rf "${libdir:?}/$pkg"
        cp -R "$REPO_DIR/$pkg" "$libdir/$pkg"
        rm -rf "$libdir/$pkg/__pycache__" "$libdir/$pkg/ping.py"
        ok "vendored $pkg -> $skill_name/scripts/lib/"
      else
        warn "foundation package '$pkg' not found at repo root (needed by $skill_name)"
      fi
    done < "$marker"
    ( cd "$REPO_DIR" && rm -f "$skill_name.skill" \
        && zip -rqX "$skill_name.skill" "$skill_name" \
             -x "*/__pycache__/*" "*.pyc" "*/.DS_Store" )
    ok "rebuilt $skill_name.skill (self-contained)"
  done
else
  warn "zip not found - skipping bundle rebuild; install will use existing .skill files."
fi

# ----------------------------------------------------------------------------
step "Installing skills"

# The .skill files live at the repo root. Unzip each into ~/.claude/skills/.
# unzip -o overwrites without prompting; we rm -rf first to clean stale files
# from previous installs.
shopt -s nullglob
skills=("$REPO_DIR"/*.skill)
shopt -u nullglob

if [ ${#skills[@]} -eq 0 ]; then
  err "No .skill files found at the repo root. Did you clone the right repo?"
  exit 1
fi

for skill_file in "${skills[@]}"; do
  skill_name="$(basename "$skill_file" .skill)"
  target="$SKILLS_DIR/$skill_name"
  rm -rf "$target"
  unzip -oq "$skill_file" -d "$SKILLS_DIR/"
  ok "Installed: $skill_name"
done

# ----------------------------------------------------------------------------
step "Next steps (one-time, ~5 minutes)"

cat <<EOF

The skills are installed. Three things still need to happen:

${BLUE}1. Set up your API keys${NC}

   ${YELLOW}Each teammate uses their OWN OpenRouter and ZenRows keys.${NC}
   ${YELLOW}PlusVibe is one team-shared key - ask team lead.${NC}

   # OpenRouter: get a key from https://openrouter.ai/keys
   echo '{"api_key": "sk-or-v1-..."}' > ~/.olympolabs/openrouter.json
   chmod 600 ~/.olympolabs/openrouter.json

   # ZenRows: get a key from https://app.zenrows.com/users/api-keys
   echo '{"api_key": "your-zenrows-key"}' > ~/.olympolabs/zenrows.json
   chmod 600 ~/.olympolabs/zenrows.json

   # PlusVibe: ask team lead for the team's shared key
   echo '{"api_key": "the-team-plusvibe-key"}' > ~/.olympolabs/plusvibe.json
   chmod 600 ~/.olympolabs/plusvibe.json

${BLUE}2. Set up gcloud Application Default Credentials${NC} (required for the
   company-scoring skill - it needs WRITE access to your Google Sheets)

   If gcloud isn't installed:
     brew install --cask google-cloud-sdk

   Then run (this opens your browser):
     gcloud auth login
     gcloud auth application-default login \\
       --client-id-file=$REPO_DIR/shared-config/gcloud-oauth-client.json \\
       --scopes=openid,email,https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/spreadsheets
     gcloud auth application-default set-quota-project olympolabs-copywriter

   See docs/setup-gcloud-adc.md for screenshots and troubleshooting.

${BLUE}3. Copywriter knowledge-base doc${NC} (only needed if you'll use the
   copywriter skill)

   The copywriter reads from a markdown file of OlympoLabs's winning cold
   email scripts. Ask team lead for the Google Doc URL, then:

     File → Download → Markdown (.md)
     mv ~/Downloads/<file>.md ~/.olympolabs/copywriter-kb.md

   Add this to your shell profile so the skill can find it:
     echo 'export COPYWRITER_KB_FILE="\$HOME/.olympolabs/copywriter-kb.md"' >> ~/.zshrc
     source ~/.zshrc

${BLUE}Finally:${NC} restart Claude Code. The five skills will auto-load.

${GREEN}Read docs/ for per-skill setup details, common workflows, and troubleshooting.${NC}

EOF
