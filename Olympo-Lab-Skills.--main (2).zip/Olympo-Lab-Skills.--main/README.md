# OlympoLabs Skills

Internal Claude Code skills for OlympoLabs's cold outbound pipeline. Private — do not share outside the team.

## What's included

| Skill | What it does |
|---|---|
| **copywriter** | Generate cold email scripts from the agency's winning-scripts KB, grounded in 6 mentor frameworks. Outputs 10-20 framework-labeled pairs (first-touch + follow-up) ready for spintax. |
| **plusvibe-spintax** | Heavy spintax + spam-word audit. Reads a Copywriter `draft.md`, outputs both `spintaxed.md` (audit trail) and `final.md` (editable). Auto-opens `final.md` in Cursor. |
| **plusvibe-campaign-manager** | Take a finished `final.md` and upload it to PlusVibe via API as a configured campaign (sequences, variations, accounts, schedule). Leaves campaign in DRAFT — user activates manually after review. |
| **company-scoring** | Score Google Sheets of companies 1-10 for ICP fit. Interactive: asks the user for run mode (conventional/hybrid vs force-scrape), runs a 20-row scrape pilot for ICP calibration, lets the user iterate on the ICP before scaling, then runs the full sheet. Concurrent (30 parallel workers), resume-safe, cost-logged. |
| **name-normalizer** | Normalize first-name and company-name columns in a Google Sheet or local CSV so they read naturally as cold-email merge tags. Strips legal suffixes (LLC, Inc., Corp), titles (Dr., Mr., PhD), trailing region/city qualifiers (Motorola San Diego → Motorola), generic filler (Industries, Ventures), Title-Cases ALL-CAPS junk while preserving real acronyms (IBM, IKEA, GEICO), recovers over-Title-Cased acronyms (Tmg → TMG), preserves diacritics. Overwrites in place. Gemini 2.5 Flash at ~$0.15 per 1,000 rows. |
| **personalization** | Generate per-row cold-email personalization snippets from the Scrape Content column written by company-scoring. User supplies a directive (literal phrase, sentence template, or topic) plus a fallback string for rows where the directive can't be applied authentically. Writes a new `Personalization` column. Iterative preview-and-tweak loop (`--preview 20`). Dedupes by domain — one LLM call per unique company, propagated to all contacts. Supports Sheets + CSV. Claude Sonnet 4.6 at ~$3 per 1,000 rows. |
| **icp-keywords** | Conversational skill that turns a campaign strategy + ICP description into three comma-separated, copy-pasteable lists: INCLUDE keywords, EXCLUDE keywords, and DECISION-MAKER TITLES (ranked, with one-line rationale per title). Tuned for Apollo / ZoomInfo / Clay / LinkedIn Sales Navigator. No scripts, no files written — pure markdown output. |

Plus four shared Python API foundations used by the skills:

- `plusvibe-api/` — PlusVibe REST API client
- `openrouter-api/` — OpenRouter LLM client (handles auth, retries, prompt caching, JSON parsing)
- `zenrows-api/` — ZenRows scraper client + trafilatura text extractor
- `google-sheets-api/` — Google Sheets read/write via ADC

## First-time setup (~10 minutes)

```bash
git clone <repo-url>
cd OlympoLabs-Skills
./install.sh
```

Follow the on-screen instructions for credentials + gcloud + the Copywriter KB. Then restart Claude Code.

See `docs/setup-api-keys.md` and `docs/setup-gcloud-adc.md` for full walkthroughs.

## Daily use

Just talk to Claude Code naturally — skills auto-trigger from their descriptions:

| You say | Skill that triggers |
|---|---|
| "Score this sheet for SaaS firms in the US: `<URL>`" | company-scoring |
| "Normalize the names + companies in this sheet: `<URL>`" | name-normalizer |
| "We have a new client signing today, let me give you the brief" | copywriter |
| "Spintax the draft at `<path>/draft.md`" | plusvibe-spintax |
| "Upload `<path>/final.md` to PlusVibe in the GLOBALTIZE workspace" | plusvibe-campaign-manager |

## Updating to the latest version

```bash
cd OlympoLabs-Skills
git pull origin main
./install.sh        # idempotent - safe to re-run
```

Restart Claude Code if the SKILL.md descriptions or scripts changed.

## What stays private (per user, NOT in the repo)

| File | Why |
|---|---|
| `~/.olympolabs/openrouter.json` | Each person's OpenRouter API key (billed separately) |
| `~/.olympolabs/zenrows.json` | Each person's ZenRows API key |
| `~/.olympolabs/plusvibe.json` | Team-shared PlusVibe key — get from team lead, don't commit |
| `~/.olympolabs/copywriter-kb.md` | Local markdown copy of the team's winning-scripts Doc |
| `~/.olympolabs/icp-profiles/*.md` | Per-engagement ICP profiles (may contain client-specific detail) |
| `~/.olympolabs/scoring-costs.log` | Your personal per-run spend log |
| `~/.config/gcloud/...` | gcloud ADC tokens (Google manages this for you) |

## What's safe to share via the repo

| File | Why |
|---|---|
| `*.skill` files | The skill code itself. Designed to be distributed. |
| `*-api/` foundations | Python source for the shared API clients. |
| `shared-config/gcloud-oauth-client.json` | Desktop-app OAuth client tied to the team's GCP project (`olympolabs-copywriter`). Designed by Google to be distributed with the app. Doesn't grant access on its own — each user still has to OAuth-grant their own Google account during `gcloud auth application-default login`. |
| `templates/*.md` | Blank ICP / brief templates to copy and customize. |
| `docs/*.md` | Documentation. |

## Workflows at a glance

### New client onboarding (full pipeline)

```
1. Get a list of leads (Clay/Apollo) into a Google Sheet
2. company-scoring → filter to qualified (score ≥ 7)
3. name-normalizer → clean {{first_name}} + {{company}} merge tags
4. copywriter → draft.md (10-20 framework-labeled pairs)
5. Trim to keepers in Cursor → save draft.md
6. plusvibe-spintax → final.md (heavy spintax + spam audit)
7. Run final.md through external spam tool → edit final.md
8. plusvibe-campaign-manager → campaign in PlusVibe (DRAFT)
9. Add the qualified leads in PlusVibe UI, activate campaign
```

### Just scoring a list

```
1. Run company-scoring on the sheet
2. Mode question: conventional (hybrid) or force-scrape?
3. 20-row pilot → review → sign off or refine ICP
4. Full-sheet run in chosen mode
5. (If hybrid only) Targeted 6-7 rescue
6. Filter Sheet for ICP Verdict = Qualified → outreach pool
```

## Daily-use how-to guides

These walk through what to type, what to expect, and what artifacts come out — for each step of the pipeline.

| Doc | When to read |
|---|---|
| [`docs/the-full-pipeline.md`](docs/the-full-pipeline.md) | Start here. End-to-end walkthrough for onboarding a new client. |
| [`docs/how-to-score-a-list.md`](docs/how-to-score-a-list.md) | Whenever you score a Google Sheet against an ICP |
| [`docs/how-to-generate-cold-email-scripts.md`](docs/how-to-generate-cold-email-scripts.md) | Whenever a new client needs scripts |
| [`docs/how-to-spintax-and-spam-check.md`](docs/how-to-spintax-and-spam-check.md) | After Copywriter — before upload |
| [`docs/how-to-upload-a-campaign-to-plusvibe.md`](docs/how-to-upload-a-campaign-to-plusvibe.md) | After Spintax — uploading to PlusVibe |
| [`docs/working-with-icp-profiles.md`](docs/working-with-icp-profiles.md) | Writing or refining an ICP file |

## Troubleshooting

See `docs/troubleshooting.md`. Common issues:

- "API key rejected" → check your `~/.olympolabs/*.json` keys, mode 600
- "Cannot locate plusvibe-api foundation" → the repo should be at `~/Desktop/OlympoLabs-Skills/`; re-clone or re-symlink
- "Sheets API permission denied" → re-run `gcloud auth application-default login` with the spreadsheets scope
- Skills don't show up after install → restart Claude Code (new skill directories need a fresh session)

## Repo conventions

- One commit per change, descriptive messages.
- New skills go in their own folder + corresponding packaged `.skill` at repo root.
- New API foundations follow the `<name>-api/` pattern with `auth.py` + `client.py` + `__init__.py`.
- Bump `install.sh` if a new install step is needed.
- Update `README.md` if behavior or setup changes.

---

*Maintained by the OlympoLabs team.*
