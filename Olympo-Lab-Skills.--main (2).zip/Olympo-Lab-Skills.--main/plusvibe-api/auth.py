"""
PlusVibe API authentication.

Loads the API key (and optional default workspace_id) from one of two places,
in order of precedence:

  1. Environment variables:
       PLUSVIBE_API_KEY
       PLUSVIBE_WORKSPACE_ID   (optional; used as the default for endpoints
                                that require it)
  2. ~/.olympolabs/plusvibe.json — a JSON file with shape:
       {
         "api_key": "...",
         "default_workspace_id": "..."   // optional
       }
     File mode should be 0600 (owner read/write only). The loader does NOT
     enforce this; the user creates the file with `chmod 600` per the install
     instructions.

If neither source supplies a key, raises MissingCredentials. The error message
points at the exact remediation (the URL to fetch a fresh key + the env var or
file path to set).
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


DEFAULT_CONFIG_PATH = Path.home() / ".olympolabs" / "plusvibe.json"
SETTINGS_URL = "https://app.plusvibe.ai/v2/settings/api-access/"


class MissingCredentials(Exception):
    """Raised when no API key is configured."""


@dataclass(frozen=True)
class Credentials:
    api_key: str
    default_workspace_id: Optional[str] = None


def load_credentials(config_path: Optional[Path] = None) -> Credentials:
    """Resolve credentials, preferring env vars over the config file.

    Args:
        config_path: Override the default config file location. Mostly useful
            for tests.

    Returns:
        Credentials with at least an api_key set.

    Raises:
        MissingCredentials: if neither source supplies a key.
    """
    env_key = os.environ.get("PLUSVIBE_API_KEY")
    env_ws = os.environ.get("PLUSVIBE_WORKSPACE_ID")
    if env_key:
        return Credentials(api_key=env_key, default_workspace_id=env_ws)

    path = config_path or DEFAULT_CONFIG_PATH
    if path.exists():
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            raise MissingCredentials(
                f"PlusVibe config at {path} is not valid JSON: {exc}\n"
                f"Fix or recreate the file with:\n"
                f'  {{"api_key": "...", "default_workspace_id": "..."}}'
            ) from exc
        api_key = data.get("api_key")
        if api_key:
            return Credentials(
                api_key=api_key,
                default_workspace_id=data.get("default_workspace_id") or env_ws,
            )

    raise MissingCredentials(
        "No PlusVibe API key configured. Set one of:\n"
        f"  1. ENV: export PLUSVIBE_API_KEY=...\n"
        f"  2. FILE: {DEFAULT_CONFIG_PATH} containing "
        f'{{"api_key": "..."}}'
        f" (chmod 600)\n"
        f"Get a key at: {SETTINGS_URL}"
    )
