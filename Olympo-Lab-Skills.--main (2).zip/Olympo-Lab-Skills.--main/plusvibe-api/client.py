"""
PlusVibe API client.

Thin Python wrapper over the PlusVibe REST API at https://api.plusvibe.ai/api/v1.
Designed for use by OlympoLabs Claude skills (plusvibe-campaign-manager,
plusvibe-health-monitor, plusvibe-reply-handler, etc.) so each skill doesn't
reimplement auth, rate limiting, and error handling.

Endpoint path conventions (these are not standard REST — they were probed
against the live API; the docs at developer.plusvibe.ai use the exact same
shapes):

- Resources are singular: `/campaign/...`, `/lead/...`, `/account/...`, not
  `/campaigns/...`.
- Action verbs live in the path: `/campaign/add/campaign`, `/campaign/launch`,
  `/campaign/pause`, `/lead/add`, `/lead/count/lead-status`.
- GET requests carry `workspace_id` as a query parameter.
- POST / PATCH requests carry `workspace_id` (and other IDs) in the JSON body.
- The exception is the `/workspaces` endpoint, which is plural-no-action — it's
  the key-test endpoint that lists workspaces accessible to the API key.

Design choices:

- Auth via `x-api-key` header (per CORS preflight + the docs).
- Base URL hard-coded to `https://api.plusvibe.ai/api/v1`.
- Rate limiting: PlusVibe enforces 5 requests/second per API key. The client
  enforces 4 RPS internally with a tiny serialization to stay safely under the
  cap.
- workspace_id: most endpoints require it. The client accepts a default
  workspace_id from credentials and lets callers override per-request.
- Errors: structured exceptions (PlusVibeAuthError, PlusVibeNotFoundError, etc.)
  rather than generic HTTPError - lets skills handle each case appropriately
  (e.g. AuthError should always surface the regenerate-key + base-URL message
  to the user).

Usage:

    from client import PlusVibeClient

    client = PlusVibeClient()                  # uses ~/.olympolabs/plusvibe.json
    workspaces = client.list_workspaces()      # sanity-check the key
    campaigns = client.list_campaigns(workspace_id="6a09...")
    accounts = client.list_email_accounts(workspace_id="6a09...")

The `Any`-typed returns are intentional: PlusVibe's response shapes evolve and
callers (skills) inspect dicts by key name. Adding strict types here would
break the moment PlusVibe adds a field.
"""

from __future__ import annotations

import time
import warnings
from typing import Any, Iterable, Mapping, Optional

# Silence the urllib3 / LibreSSL warning that's noise on macOS Python 3.9
warnings.filterwarnings("ignore", message=".*OpenSSL.*", module=r"urllib3.*")

import requests

from auth import Credentials, MissingCredentials, load_credentials  # noqa: E402
from exceptions import (  # noqa: E402
    PlusVibeAuthError,
    PlusVibeError,
    PlusVibeNotFoundError,
    PlusVibeRateLimitError,
    PlusVibeRequestError,
    PlusVibeServerError,
)


BASE_URL = "https://api.plusvibe.ai/api/v1"
# PlusVibe enforces 5 req/sec. We aim for 4 to leave headroom for clock skew
# and the occasional retry. Minimum interval between requests is 1/4 sec.
MIN_INTERVAL_SECONDS = 0.25
DEFAULT_TIMEOUT = 30.0


class PlusVibeClient:
    """Synchronous PlusVibe API client.

    Not thread-safe; create one per thread/process if you need parallelism
    (the 5-rps limit is per API key anyway, so parallelism doesn't actually
    buy throughput).
    """

    def __init__(
        self,
        credentials: Optional[Credentials] = None,
        base_url: str = BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        session: Optional[requests.Session] = None,
    ):
        self._creds = credentials or load_credentials()
        self._base = base_url.rstrip("/")
        self._timeout = timeout
        self._session = session or requests.Session()
        self._last_call_at = 0.0

    # ---- core HTTP ------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Mapping[str, Any]] = None,
        json_body: Optional[Any] = None,
    ) -> Any:
        """Send a request, throttling to stay under PlusVibe's rate limit."""
        self._throttle()
        url = f"{self._base}/{path.lstrip('/')}"
        headers = {
            "x-api-key": self._creds.api_key,
            "Accept": "application/json",
        }
        if json_body is not None:
            headers["Content-Type"] = "application/json"

        resp = self._session.request(
            method=method,
            url=url,
            params=params,
            json=json_body,
            headers=headers,
            timeout=self._timeout,
        )
        return self._handle_response(resp)

    def _throttle(self) -> None:
        """Sleep just enough to keep us under MIN_INTERVAL_SECONDS between calls."""
        now = time.monotonic()
        elapsed = now - self._last_call_at
        if elapsed < MIN_INTERVAL_SECONDS:
            time.sleep(MIN_INTERVAL_SECONDS - elapsed)
        self._last_call_at = time.monotonic()

    def _handle_response(self, resp: requests.Response) -> Any:
        status = resp.status_code

        # Try to decode JSON, but don't blow up on empty / malformed bodies
        try:
            payload = resp.json() if resp.content else {}
        except ValueError:
            payload = {"raw": resp.text}

        if 200 <= status < 300:
            # PlusVibe wraps SOME successful responses in {code, message, data}.
            # Others (like /workspaces, /campaign/list-all) return a bare array
            # or bare object. Unwrap only when the wrapper is present.
            if (
                isinstance(payload, dict)
                and set(payload.keys()) >= {"code", "message"}
                and "data" in payload
            ):
                return payload["data"]
            return payload

        message = ""
        if isinstance(payload, dict):
            message = payload.get("message") or payload.get("error") or ""
            # PlusVibe validation errors put the actionable details in `errors`
            # (list of strings). Append them so the caller sees the actual
            # field-level problem instead of just "Validation error".
            errs = payload.get("errors")
            if isinstance(errs, list) and errs:
                detail = "; ".join(str(e) for e in errs)
                message = f"{message}: {detail}" if message else detail
        if not message:
            message = f"HTTP {status}: {resp.text[:200]}"

        if status == 401:
            raise PlusVibeAuthError(
                f"API key rejected ({message}). Two things to check:\n"
                f"  1. Is the base URL correct? It is "
                f"https://api.plusvibe.ai/api/v1 (note the /api/ segment).\n"
                f"  2. Regenerate the key at "
                f"https://app.plusvibe.ai/v2/settings/api-access/ and update "
                f"~/.olympolabs/plusvibe.json or PLUSVIBE_API_KEY.",
                status_code=status,
                payload=payload if isinstance(payload, dict) else None,
            )
        if status == 404:
            raise PlusVibeNotFoundError(
                f"Not found: {resp.request.method} {resp.request.url} ({message})",
                status_code=status,
                payload=payload if isinstance(payload, dict) else None,
            )
        if status == 429:
            raise PlusVibeRateLimitError(
                f"Rate limited (5 req/sec cap). Back off and retry. ({message})",
                status_code=status,
                payload=payload if isinstance(payload, dict) else None,
            )
        if 400 <= status < 500:
            raise PlusVibeRequestError(
                f"Bad request ({status}): {message}",
                status_code=status,
                payload=payload if isinstance(payload, dict) else None,
            )
        if 500 <= status < 600:
            raise PlusVibeServerError(
                f"PlusVibe server error ({status}): {message}",
                status_code=status,
                payload=payload if isinstance(payload, dict) else None,
            )
        raise PlusVibeError(
            f"Unexpected status {status}: {message}",
            status_code=status,
            payload=payload if isinstance(payload, dict) else None,
        )

    def _workspace(self, workspace_id: Optional[str]) -> str:
        """Resolve a workspace_id, falling back to the default from credentials."""
        ws = workspace_id or self._creds.default_workspace_id
        if not ws:
            raise PlusVibeRequestError(
                "workspace_id is required. Pass it explicitly or set "
                "default_workspace_id in ~/.olympolabs/plusvibe.json."
            )
        return ws

    # ---- workspaces -----------------------------------------------------

    def list_workspaces(self) -> Any:
        """GET /workspaces — verify the API key + list accessible workspaces.

        Returns a bare list of `{id, name}` dicts. This is the canonical
        health-check call: a 200 here means the key works and the user has at
        least one workspace.
        """
        return self._request("GET", "/workspaces")

    # ---- campaigns ------------------------------------------------------

    def list_campaigns(
        self,
        *,
        workspace_id: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        status: Optional[str] = None,
    ) -> Any:
        """GET /campaign/list-all — paginated list of campaigns in a workspace.

        Returns a list of campaign dicts. Each one includes at minimum:
            camp_name, organization_id, workspace_id, parent_camp_id,
            email_accounts (list of account IDs)
        (Other fields vary by campaign type.)
        """
        params: dict = {"workspace_id": self._workspace(workspace_id)}
        if status is not None:
            params["status"] = status
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        return self._request("GET", "/campaign/list-all", params=params)

    def create_campaign_stub(
        self,
        *,
        name: str,
        workspace_id: Optional[str] = None,
    ) -> Any:
        """POST /campaign/add/campaign — create a campaign shell.

        IMPORTANT: PlusVibe's campaign creation is a TWO-STEP flow. This call
        creates just the shell (workspace_id + camp_name) and returns the new
        campaign's `id`. To set schedule, sequence, email accounts, and all
        other config, follow up with `update_campaign()`.

        Most callers should use `create_and_configure_campaign()` instead,
        which orchestrates both calls.

        Returns: {"status": "success", "id": "<new_campaign_id>"} or similar.
        """
        body = {
            "workspace_id": self._workspace(workspace_id),
            "camp_name": name,
        }
        return self._request("POST", "/campaign/add/campaign", json_body=body)

    def update_campaign(
        self,
        campaign_id: str,
        *,
        workspace_id: Optional[str] = None,
        name: Optional[str] = None,
        status: Optional[str] = None,
        schedules: Optional[Mapping[str, Any]] = None,
        sequences: Optional[Iterable[Mapping[str, Any]]] = None,
        email_accounts: Optional[Iterable[str]] = None,
        first_wait_time: Optional[int] = None,
        extra: Optional[Mapping[str, Any]] = None,
    ) -> Any:
        """PATCH /campaign/update/campaign - full or partial config update.

        Path verified live against PlusVibe API May 2026. The field names are
        pluralized: `schedules` (singular `schedule` is wrong) and `sequences`
        (singular `sequence` is wrong). `first_wait_time` is REQUIRED by the
        API even on patch-style calls.

        Args:
            campaign_id: The campaign to update.
            workspace_id: Workspace; falls back to credentials default.
            name: New campaign name (maps to `camp_name`).
            status: e.g. "PAUSED", "ACTIVE", "DRAFT". Usually managed via
                activate_campaign / pause_campaign instead.
            schedules: Schedule object. Shape:
                {
                    "daily_limit": 1000,
                    "daily_limit_new_lead": 500,
                    "start_date": "YYYY-MM-DD",
                    "end_date": "",  // empty string = no end
                    "days": {"1": true, "2": true, ...},  // Mon=1
                    "timezone": "America/New_York",
                    "timing": {"from": "09:00", "to": "18:00"}
                }
            sequences: List of step dicts. Each step:
                {
                    "step": 1,
                    "wait_time": 1,  // days before THIS step (step 1 uses first_wait_time)
                    "variations": [
                        {"variation": "A", "subject": "...", "name": "", "body": "<div>...</div>"},
                        {"variation": "B", "subject": "...", "name": "", "body": "<div>...</div>"}
                    ]
                }
                Multiple variations = A/B test. Empty `subject` on follow-up steps
                = reply in thread.
            email_accounts: List of email_account_ids that send for this campaign.
            first_wait_time: Minutes to wait before sending the very first email
                (applies to step 1).
            extra: Any other fields (bounce_rate_limit, stop_on_lead_replied,
                is_emailopened_tracking, var_sel_type, etc.). Merged last.
        """
        body: dict = {
            "workspace_id": self._workspace(workspace_id),
            "campaign_id": campaign_id,
        }
        if name is not None:
            body["camp_name"] = name
        if status is not None:
            body["status"] = status
        if schedules is not None:
            # PlusVibe's API expects `schedules` as a JSON ARRAY (an array of
            # schedule objects), even though the docs example shows a single
            # object inline. The API rejects a bare object with
            # `"schedules" must be an array`. Accept either shape from callers
            # and normalize.
            if isinstance(schedules, dict):
                body["schedules"] = [dict(schedules)]
            else:
                body["schedules"] = list(schedules)
        if sequences is not None:
            body["sequences"] = list(sequences)
        if email_accounts is not None:
            body["email_accounts"] = list(email_accounts)
        if first_wait_time is not None:
            body["first_wait_time"] = first_wait_time
        if extra:
            body.update(dict(extra))
        return self._request("PATCH", "/campaign/update/campaign", json_body=body)

    def create_and_configure_campaign(
        self,
        *,
        name: str,
        workspace_id: Optional[str] = None,
        email_accounts: Optional[Iterable[str]] = None,
        schedules: Optional[Mapping[str, Any]] = None,
        sequences: Optional[Iterable[Mapping[str, Any]]] = None,
        first_wait_time: Optional[int] = None,
        extra: Optional[Mapping[str, Any]] = None,
    ) -> Any:
        """Convenience: create a campaign shell + immediately configure it.

        Wraps the two-step PlusVibe flow (POST /campaign/add/campaign followed
        by POST /campaign/update) so callers don't have to manage the in-between
        ID handoff.

        Returns the full update response, which includes the campaign ID in
        the body as `campaign_id` or similar.
        """
        stub = self.create_campaign_stub(name=name, workspace_id=workspace_id)
        new_id = (
            stub.get("id")
            or stub.get("campaign_id")
            or (stub.get("data", {}) or {}).get("id")
        )
        if not new_id:
            raise PlusVibeError(
                f"create_campaign_stub did not return a campaign id; got: {stub!r}"
            )
        update_resp = self.update_campaign(
            campaign_id=new_id,
            workspace_id=workspace_id,
            email_accounts=email_accounts,
            schedules=schedules,
            sequences=sequences,
            first_wait_time=first_wait_time,
            extra=extra,
        )
        # PlusVibe's PATCH /campaign/update/campaign returns just {"status":
        # "success"} without the campaign_id, so callers (the launcher script
        # in particular) would lose track of which campaign they just made.
        # Merge the stub's id into the response shape so they don't have to.
        merged = dict(update_resp) if isinstance(update_resp, dict) else {"raw": update_resp}
        merged.setdefault("campaign_id", new_id)
        return merged

    def activate_campaign(
        self, campaign_id: str, *, workspace_id: Optional[str] = None
    ) -> Any:
        """POST /campaign/launch — start sending."""
        body = {
            "workspace_id": self._workspace(workspace_id),
            "campaign_id": campaign_id,
        }
        return self._request("POST", "/campaign/launch", json_body=body)

    def pause_campaign(
        self, campaign_id: str, *, workspace_id: Optional[str] = None
    ) -> Any:
        """POST /campaign/pause — pause an active campaign."""
        body = {
            "workspace_id": self._workspace(workspace_id),
            "campaign_id": campaign_id,
        }
        return self._request("POST", "/campaign/pause", json_body=body)

    def get_campaign_status(
        self, campaign_id: str, *, workspace_id: Optional[str] = None
    ) -> Any:
        """GET /campaign/get/status — campaign run status."""
        params = {
            "workspace_id": self._workspace(workspace_id),
            "campaign_id": campaign_id,
        }
        return self._request("GET", "/campaign/get/status", params=params)

    def get_campaign_variation_stats(
        self, campaign_id: str, *, workspace_id: Optional[str] = None
    ) -> Any:
        """GET /campaign/get/variation-stats — per-variation perf for each step.

        This is THE endpoint that makes uploading 5 scripts as variations of
        step 1 valuable — it tells you which variation is winning so you can
        prune the losers later.
        """
        params = {
            "workspace_id": self._workspace(workspace_id),
            "campaign_id": campaign_id,
        }
        return self._request("GET", "/campaign/get/variation-stats", params=params)

    # ---- leads ----------------------------------------------------------

    def add_leads_to_campaign(
        self,
        campaign_id: str,
        leads: Iterable[Mapping[str, Any]],
        *,
        workspace_id: Optional[str] = None,
    ) -> Any:
        """POST /lead/add — upload a batch of leads to a campaign.

        Each lead is a dict with at minimum `email`. PlusVibe accepts arbitrary
        custom variables like first_name, company_name, custom_growth_idea, etc.
        """
        leads_list = list(leads)
        if not leads_list:
            raise PlusVibeRequestError("add_leads_to_campaign called with empty leads list")
        body = {
            "workspace_id": self._workspace(workspace_id),
            "campaign_id": campaign_id,
            "leads": leads_list,
        }
        return self._request("POST", "/lead/add", json_body=body)

    def lead_counts(
        self,
        *,
        workspace_id: Optional[str] = None,
        campaign_id: Optional[str] = None,
    ) -> Any:
        """GET /lead/count/lead-status — totals by lead status.

        Returns a list of `{status, count}` dicts. Statuses observed in the
        wild include: NOT_CONTACTED, CONTACTED, COMPLETED, REPLIED,
        RESCHEDULED, UNSUBSCRIBED, BOUNCED, SKIPPED.
        """
        params: dict = {"workspace_id": self._workspace(workspace_id)}
        if campaign_id is not None:
            params["campaign_id"] = campaign_id
        return self._request("GET", "/lead/count/lead-status", params=params)

    # ---- email accounts -------------------------------------------------

    def list_email_accounts(
        self,
        *,
        workspace_id: Optional[str] = None,
        tags: Optional[Iterable[str]] = None,
    ) -> Any:
        """GET /account/list — inboxes available in the workspace.

        Returns an object like `{"accounts": [...]}` where each account has
        id, email, status, warmup_status, provider, and a nested `payload`
        with daily_limit, sending_gap, signature, tags, cmps (campaigns it's
        attached to), and analytics (health_scores, reply_rates, daily_counters).

        Useful before campaign creation: which inboxes can we attach? Also the
        backbone of any future Health Monitor skill.
        """
        params: dict = {"workspace_id": self._workspace(workspace_id)}
        if tags is not None:
            params["tags"] = ",".join(tags)
        return self._request("GET", "/account/list", params=params)
