#!/usr/bin/env python3
"""
Sanity-check the PlusVibe API key.

Calls GET /workspaces and prints the result. Exits 0 on success with the
workspace list (one per line) and the resolved default workspace_id, if any.
Exits non-zero with a clear stderr message on auth failure or other issues.

Use this:
  - When you've just pasted a new API key, to confirm it works before building
    anything else.
  - When a skill fails with PlusVibeAuthError and you want to test the key in
    isolation.

  python3 plusvibe-api/ping.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

# When run directly (not imported), make sibling modules importable.
sys.path.insert(0, str(Path(__file__).parent))

from auth import DEFAULT_CONFIG_PATH, MissingCredentials, load_credentials  # noqa: E402
from client import PlusVibeClient  # noqa: E402
from exceptions import PlusVibeAuthError, PlusVibeError  # noqa: E402


def main() -> int:
    try:
        creds = load_credentials()
    except MissingCredentials as exc:
        sys.stderr.write(f"{exc}\n")
        return 2

    print(f"Credentials source: {DEFAULT_CONFIG_PATH if not _env_key() else 'env var PLUSVIBE_API_KEY'}")
    print(f"API key (first 8): {creds.api_key[:8]}...")
    print(f"Default workspace_id: {creds.default_workspace_id or '(not set)'}")
    print()

    client = PlusVibeClient(credentials=creds)
    try:
        result = client.list_workspaces()
    except PlusVibeAuthError as exc:
        sys.stderr.write(f"AUTH FAILED: {exc}\n")
        return 3
    except PlusVibeError as exc:
        sys.stderr.write(f"API ERROR: {exc}\n")
        return 4

    print("OK — API key works.")
    print("Workspaces:")
    print(json.dumps(result, indent=2))
    return 0


def _env_key() -> bool:
    import os
    return bool(os.environ.get("PLUSVIBE_API_KEY"))


if __name__ == "__main__":
    sys.exit(main())
