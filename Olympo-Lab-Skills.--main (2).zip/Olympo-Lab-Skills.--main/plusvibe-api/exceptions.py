"""Custom exceptions raised by the PlusVibe API client."""

from __future__ import annotations


class PlusVibeError(Exception):
    """Base for all PlusVibe API errors."""

    def __init__(self, message: str, status_code: int | None = None, payload: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload or {}


class PlusVibeAuthError(PlusVibeError):
    """401 - API key invalid, expired, or revoked.

    The API returns this with payload like {"authtoken_expired": 1}. The fix
    is always on the user side: regenerate or re-paste the API key.
    """


class PlusVibeNotFoundError(PlusVibeError):
    """404 - resource (campaign, lead, account, workspace) does not exist."""


class PlusVibeRateLimitError(PlusVibeError):
    """429 / rate-limit response. Caller should back off and retry."""


class PlusVibeServerError(PlusVibeError):
    """5xx - PlusVibe-side problem. Retry-able but not always."""


class PlusVibeRequestError(PlusVibeError):
    """4xx other than 401/404 - malformed request, validation failure, etc.

    Inspect `payload` for the API's structured error info.
    """
