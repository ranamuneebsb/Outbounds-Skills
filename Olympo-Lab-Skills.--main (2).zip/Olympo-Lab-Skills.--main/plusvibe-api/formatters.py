"""
Format conversions for moving content between OlympoLabs file formats and
PlusVibe API shapes.

PlusVibe stores email bodies as HTML (typically per-line/per-paragraph `<div>`s,
matching what Gmail's compose produces). OlympoLabs's Copywriter + Spintax
pipeline produces markdown-ish plain text (with `{{token}}` merge tags and
`{{random|a|b}}` spintax). The bridge between them lives here.

Conventions:
- Each non-empty paragraph in the source becomes one `<div>` block.
- Single line-breaks inside a paragraph become `<br>`.
- Blank lines between paragraphs become `<div><br></div>` separators (matches
  Gmail/Outlook compose output - PlusVibe tolerates this and inboxes render it
  correctly).
- `{{first_name}}`, `{{company_name}}`, `{{sender_signature}}`,
  `{{custom_*}}`, and `{{random|...|...}}` spintax blocks are PASSED THROUGH
  UNCHANGED. They are not HTML-escaped because PlusVibe needs them literal.
- Plain `<` and `>` (extremely rare in OlympoLabs cold emails) get HTML-escaped
  to avoid breaking the document, while leaving the braces alone.
"""

from __future__ import annotations

import re
from typing import List


def body_to_plusvibe_html(body: str) -> str:
    """Convert a plain-text / markdown body to PlusVibe's per-paragraph div HTML.

    Args:
        body: The plain-text body as written by Copywriter/Spintax. May include
            personalization tokens (`{{first_name}}` etc) and spintax
            (`{{random|a|b}}`). Must not include real HTML — if you pass HTML
            it will get escaped.

    Returns:
        An HTML string of one or more concatenated `<div>...</div>` blocks
        ready to drop into a PlusVibe sequence variation's `body` field.

    Example:
        >>> body_to_plusvibe_html("Hi {{first_name}},\\n\\nQuick question.")
        '<div>Hi {{first_name}},</div><div><br></div><div>Quick question.</div>'
    """
    text = body.strip("\n")
    if not text:
        return "<div><br></div>"

    # Split into paragraphs on blank lines (one or more empty lines)
    paragraphs = re.split(r"\n\s*\n", text)

    out: List[str] = []
    for i, para in enumerate(paragraphs):
        if i > 0:
            # Empty-div separator between paragraphs
            out.append("<div><br></div>")

        lines = para.splitlines()
        # Within a paragraph: single newlines become <br>
        escaped_lines = [_escape_non_token_html(line) for line in lines if line.strip() or len(lines) == 1]
        if not escaped_lines:
            out.append("<div><br></div>")
            continue
        out.append("<div>" + "<br>".join(escaped_lines) + "</div>")

    return "".join(out)


# Match a {{...}} block (token or spintax) - greedy is fine since braces don't nest.
_TOKEN_RE = re.compile(r"\{\{[^{}]*\}\}")


def _escape_non_token_html(line: str) -> str:
    """HTML-escape a line of text WITHOUT touching `{{token}}` content.

    PlusVibe merge tags and spintax must reach the server literal. Plain `<`,
    `>`, `&` characters elsewhere in the line get escaped so PlusVibe / Gmail
    don't interpret them as HTML.
    """
    parts: List[str] = []
    cursor = 0
    for match in _TOKEN_RE.finditer(line):
        # Escape the gap before this token
        gap = line[cursor:match.start()]
        parts.append(_escape_html(gap))
        # Pass the token through verbatim
        parts.append(match.group(0))
        cursor = match.end()
    # Trailing gap after the last token (or the whole line if no tokens)
    parts.append(_escape_html(line[cursor:]))
    return "".join(parts)


def _escape_html(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
