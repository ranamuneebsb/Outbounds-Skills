"""PlusVibe API shared client for OlympoLabs skills.

This is a thin Python wrapper used by every skill that talks to PlusVibe:

  - plusvibe-campaign-manager
  - plusvibe-health-monitor (future)
  - plusvibe-reply-handler (future)
  - plusvibe-placement-tester (future)
  - plusvibe-client-dashboard (future)
  - plusvibe-learning-loop (future)

Skills that need it import via:

    import sys
    sys.path.insert(0, "/Users/bryanlopez/Desktop/OlympoLabs-Skills/plusvibe-api")
    from client import PlusVibeClient

(See each skill's scripts/ folder for a small bootstrap helper.)

Auth lives in ~/.olympolabs/plusvibe.json (mode 0600). See auth.py.

The base URL `https://api.plusvibe.ai/v1` and header `x-api-key` are hard-coded
in client.py because they came from probing the live API; the public docs at
developer.plusvibe.ai don't state them explicitly. If PlusVibe ever migrates
hosts, update BASE_URL in client.py.
"""

from auth import Credentials, MissingCredentials, load_credentials
from client import PlusVibeClient
from exceptions import (
    PlusVibeAuthError,
    PlusVibeError,
    PlusVibeNotFoundError,
    PlusVibeRateLimitError,
    PlusVibeRequestError,
    PlusVibeServerError,
)

__all__ = [
    "Credentials",
    "MissingCredentials",
    "PlusVibeAuthError",
    "PlusVibeClient",
    "PlusVibeError",
    "PlusVibeNotFoundError",
    "PlusVibeRateLimitError",
    "PlusVibeRequestError",
    "PlusVibeServerError",
    "load_credentials",
]
