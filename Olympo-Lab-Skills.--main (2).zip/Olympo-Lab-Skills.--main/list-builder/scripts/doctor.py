#!/usr/bin/env python3
"""
list-builder doctor — verify the skill can run before a real pull.

Checks, in order:
  1. The modern-TLS venv exists and has requests + google libs.
  2. AI Ark key present + live credits ping (proves auth + TLS).
  3. Google ADC ready (so the new sheet can be created/written).

Run:  python3 scripts/doctor.py
Exits non-zero if anything needs fixing, printing the exact remediation.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

_VENV = Path.home() / ".olympolabs" / "venv"
_VENV_PY = _VENV / "bin" / "python"
if _VENV_PY.exists() and Path(sys.executable).resolve() != _VENV_PY.resolve():
    os.execv(str(_VENV_PY), [str(_VENV_PY)] + sys.argv)

import json  # noqa: E402

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE / "lib" / "google-sheets-api"))

OK, FIX = "OK  ", "FIX "
problems = 0


def line(status: str, msg: str) -> None:
    global problems
    if status == FIX:
        problems += 1
    print(f"[{status}] {msg}")


# 1. venv + deps + TLS
if not _VENV_PY.exists():
    line(FIX, f"venv missing at {_VENV}. Create it:\n"
              f"       /opt/homebrew/bin/python3.13 -m venv {_VENV}\n"
              f"       {_VENV}/bin/pip install requests google-api-python-client "
              f"google-auth google-auth-oauthlib google-auth-httplib2")
    print("\nCannot continue without the venv.")
    raise SystemExit(1)

import ssl  # noqa: E402
line(OK, f"venv python {sys.version.split()[0]} (OpenSSL {ssl.OPENSSL_VERSION.split()[1]})")

missing = []
for mod in ("requests", "googleapiclient", "google.auth"):
    try:
        __import__(mod)
    except Exception:
        missing.append(mod)
if missing:
    line(FIX, f"venv missing modules {missing}. Run: {_VENV}/bin/pip install requests "
              f"google-api-python-client google-auth google-auth-oauthlib google-auth-httplib2")
else:
    line(OK, "venv has requests + Google Sheets libs")

# 2. AI Ark key + live ping
try:
    import aiark_search as ark
    key = ark.load_key()
    bal = ark.get_credits(key)
    if bal is None:
        line(FIX, "AI Ark key loaded but the credits ping failed (auth or network). "
                  "Verify the key at https://app.ai-ark.com/settings")
    elif bal <= 0:
        line(FIX, "AI Ark account is OUT OF CREDITS (balance 0). Builds will come back "
                  "empty via HTTP 402 — top up at https://app.ai-ark.com before building.")
    elif bal < 200:
        line(OK, f"AI Ark reachable — {bal:,.1f} credits remaining "
                 "(LOW: ~0.1 cr/company, covers only a small pull — consider topping up)")
    else:
        line(OK, f"AI Ark reachable — {bal:,.1f} credits remaining")
except Exception as e:
    line(FIX, f"AI Ark key problem: {e}")

# 3. Google ADC — load AND actually refresh the token (a bare default() load
#    succeeds even when the session has expired and needs reauth).
try:
    from google.auth import default as _adc
    from google.auth.transport.requests import Request as _Req
    creds, proj = _adc(scopes=["https://www.googleapis.com/auth/spreadsheets"])
    creds.refresh(_Req())  # triggers RefreshError if reauth is actually needed
    line(OK, f"Google ADC ready + token refreshes (quota project: {proj})")
except Exception as e:
    hint = ("Run: gcloud auth application-default login "
            "--scopes=openid,email,https://www.googleapis.com/auth/spreadsheets")
    if "Reauthentication is needed" in str(e) or "RefreshError" in type(e).__name__:
        line(FIX, f"Google ADC session expired — reauth needed. {hint}")
    else:
        line(FIX, f"Google ADC not configured. {hint}\n"
                  "       then: gcloud auth application-default set-quota-project <project-id>\n"
                  f"       (underlying: {str(e)[:120]})")

print()
if problems:
    print(f"{problems} thing(s) to fix above.")
    raise SystemExit(1)
print("All green — ready to build lists.")
raise SystemExit(0)
