"""
AI Ark Company Search client + query builder + row mapper.

This is the search backend that replaces Clay's "pull a company list" step.
It turns an OlympoLabs targeting brief (industry classification + include/exclude
keywords + a few structured filters) into an AI Ark Company Search request,
paginates the results, and maps each company onto the exact column schema the
`company-scoring` skill auto-detects.

The authoritative API contract and the full filter/enum reference live in
`references/aiark-api.md`; the build strategy (precision-first doctrine, the
volume-expansion ladder, intent signals) lives in `references/list-building-playbook.md`.
Read those before changing targeting behavior.

API contract (verified live 2026-06-19):

  Base    https://api.ai-ark.com/api/developer-portal/v1
  Auth    header  X-TOKEN: <api_key>   (key file ~/.olympolabs/aiark.json)
  Credits GET  /payments/credits            -> {"total": <float>}   (free)
  Search  POST /companies                   -> paginated {"content": [...], ...}
          (POST /company  -- singular -- 401s; always use the plural path)
          body: {account:{...filters...}, lookalikeDomains:[max 5], lists:{...},
                 page:<0-based int>, size:<1-100, default 10>}

  Cost    ~0.1 credit per company RETURNED (billed per result, even size=1).
          NOT free. A full size=100 page ~= 10 credits. Under the 10k cap cost
          ~= universe*0.1; over it, banding adds a little (~x0.1-0.13).
  Errors  402 = OUT OF CREDITS (not "no results"); 401 = wrong path/key;
          404 = genuinely empty; 400 "pagination limit" = past the 10k cap.
  Limits  5 req/s, 300/min, 18,000/hr; 10,000 results max per single query.
"""

from __future__ import annotations

import datetime
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

CREDS = Path.home() / ".olympolabs" / "aiark.json"
BASE = "https://api.ai-ark.com/api/developer-portal/v1"
TIMEOUT = 30
MAX_PAGE_SIZE = 100
PAGINATION_CAP = 10000  # AI Ark caps a single query at 10k results, regardless of universe

# Keyword sources AI Ark can match an include/exclude term against. We default
# to the four that matter for B2B targeting; SEO is available but noisier.
DEFAULT_KEYWORD_SOURCES = ["NAME", "KEYWORD", "DESCRIPTION", "INDUSTRY"]
ALL_KEYWORD_SOURCES = ["NAME", "KEYWORD", "DESCRIPTION", "INDUSTRY", "SEO"]
MATCH_MODES = ["SMART", "WORD", "STRICT"]

# Company type enum (account.type.any.include).
COMPANY_TYPES = [
    "PRIVATELY_HELD", "SELF_OWNED", "SELF_EMPLOYED", "PARTNERSHIP",
    "PUBLIC_COMPANY", "NON_PROFIT", "EDUCATIONAL", "GOVERNMENT_AGENCY",
]

# Funding stage enum (account.funding.type) — an INTENT signal, opt-in only.
FUNDING_TYPES = [
    "PRE_SEED", "SEED", "SERIES_A", "SERIES_B", "SERIES_C", "SERIES_D",
    "SERIES_E", "SERIES_F", "SERIES_G", "SERIES_H", "SERIES_I", "SERIES_J",
    "VENTURE_ROUND", "ANGEL", "PRIVATE_EQUITY", "DEBT_FINANCING",
    "CONVERTIBLE_NOTE", "GRANT", "CORPORATE_ROUND", "EQUITY_CROWDFUNDING",
    "PRODUCT_CROWDFUNDING", "SECONDARY_MARKET", "POST_IPO_EQUITY",
    "POST_IPO_DEBT", "POST_IPO_SECONDARY", "NON_EQUITY_ASSISTANCE",
    "INITIAL_COIN_OFFERING", "UNDISCLOSED", "SERIES_UNKNOWN", "FUNDING_ROUND",
]

# Department functions for the growth/employee metric (account.metric) — opt-in.
METRIC_DEPARTMENTS = [
    "program_and_project_management", "education", "purchasing", "accounting",
    "sales", "research", "operations", "customer_success_and_support", "legal",
    "product_management", "media_and_communication", "real_estate",
    "quality_assurance", "consulting", "arts_and_design", "healthcare_services",
    "entrepreneurship", "engineering", "community_and_social_services",
    "marketing", "information_technology", "business_development",
    "administrative", "military_and_protective_services", "finance",
    "human_resources", "support",
]
METRIC_TIMEFRAMES = ["ONE", "THREE", "SIX", "TWELVE", "TWENTY_FOUR"]  # months

# The valid `industries` enum — the precision lever. Pass values EXACTLY (lowercase).
# This is the LinkedIn industry taxonomy AI Ark exposes (~150 values, 2026-06-19).
# A company carries several of these; union a small set with industries.any.include.
# Full list + guidance: references/aiark-api.md (kept in sync).
INDUSTRIES = (
    "accounting", "administration of justice", "advertising services",
    "airlines and aviation", "alternative dispute resolution", "alternative medicine",
    "animation and post-production",
    "appliances, electrical, and electronics manufacturing",
    "architecture and planning", "armed forces", "artists and writers",
    "automation machinery manufacturing",
    "aviation and aerospace component manufacturing", "banking",
    "beverage manufacturing", "biotechnology research",
    "book and periodical publishing", "broadcast media production and distribution",
    "business consulting and services", "capital markets", "chemical manufacturing",
    "civic and social organizations", "civil engineering",
    "computer and network security", "computer games",
    "computer hardware manufacturing", "computer networking products",
    "computers and electronics manufacturing", "construction", "consumer services",
    "dairy product manufacturing", "defense and space manufacturing",
    "design services", "e-commerce", "education administration programs",
    "e-learning providers", "entertainment providers", "environmental services",
    "events services", "executive offices", "facilities services", "farming",
    "financial services", "fisheries", "food and beverage manufacturing",
    "food and beverage services", "freight and package transportation",
    "fundraising", "furniture and home furnishings manufacturing",
    "gambling facilities and casinos",
    "glass, ceramics and concrete manufacturing", "government administration",
    "government relations services", "graphic design", "higher education",
    "hospitality", "hospitals and health care", "human resources services",
    "individual and family services", "industrial machinery manufacturing",
    "information services", "insurance", "international affairs",
    "international trade and development", "investment banking",
    "investment management", "it services and it consulting", "law enforcement",
    "law practice", "leasing non-residential real estate", "legal services",
    "legislative offices", "libraries", "machinery manufacturing", "manufacturing",
    "maritime transportation", "market research", "marketing", "media production",
    "medical equipment manufacturing", "medical practices", "mental health care",
    "mining", "mobile gaming apps", "motor vehicle manufacturing",
    "movies, videos, and sound", "museums, historical sites, and zoos", "musicians",
    "nanotechnology research", "newspaper publishing", "non-profit organizations",
    "oil and gas", "online audio and video media",
    "outsourcing and offshoring consulting",
    "packaging and containers manufacturing",
    "paper and forest product manufacturing", "performing arts",
    "personal care product manufacturing", "pharmaceutical manufacturing",
    "philanthropic fundraising services", "photography", "plastics manufacturing",
    "political organizations", "primary and secondary education",
    "printing services", "professional training and coaching",
    "public policy offices", "public relations and communications services",
    "public safety", "railroad equipment manufacturing", "ranching", "real estate",
    "recreational facilities", "religious institutions",
    "renewable energy semiconductor manufacturing", "research services",
    "restaurants", "retail", "retail apparel and fashion", "retail art supplies",
    "retail groceries", "retail luxury goods and jewelry", "retail office equipment",
    "security and investigations", "semiconductor manufacturing", "shipbuilding",
    "software development", "spectator sports", "sporting goods manufacturing",
    "staffing and recruiting", "strategic management services",
    "technology, information and internet", "telecommunications",
    "textile manufacturing", "think tanks", "tobacco manufacturing",
    "translation and localization",
    "transportation, logistics, supply chain and storage", "travel arrangements",
    "truck transportation", "utilities",
    "venture capital and private equity principals", "veterinary services",
    "warehousing and storage", "wellness and fitness services", "wholesale",
    "wholesale building materials", "wholesale import and export",
    "wireless services", "writing and editing",
)
_INDUSTRY_SET = frozenset(INDUSTRIES)


def validate_industries(values: List[str]) -> List[str]:
    """Return the subset of `values` NOT in the known enum (likely typos / free
    text that will match almost nothing). Empty list == all good. The enum can
    grow on AI Ark's side, so this WARNS (caller decides), it does not block."""
    return [v for v in values if v.strip().lower() not in _INDUSTRY_SET]


# The output column schema. Order matters: the first four headers are exactly
# what company-scoring's column_detect.py auto-detects (company / domain /
# description / industry) with zero --*-col overrides. The rest are carry-along
# context. "AI Ark Company ID" is the join key People Search uses to pull
# decision-makers for each company (dm-enrichment).
OUTPUT_HEADERS = [
    "Company Name",
    "Website",
    "Description",
    "Industry",
    "Location",
    "Employees",
    "Founded",
    "LinkedIn",
    "AI Ark Company ID",
]

DESCRIPTION_CAP = 2000


class AiArkError(Exception):
    pass


class OutOfCreditsError(AiArkError):
    """Raised on HTTP 402 — the AI Ark account has no credits left. This is NOT
    an empty result; the build must stop and the account must be topped up."""


def load_key() -> str:
    if not CREDS.exists():
        raise AiArkError(
            f"Missing {CREDS}. Create it with: "
            f'echo \'{{"api_key": "<YOUR_AIARK_KEY>"}}\' > {CREDS} && chmod 600 {CREDS}'
        )
    try:
        d = json.loads(CREDS.read_text())
    except (json.JSONDecodeError, OSError) as e:
        raise AiArkError(f"Could not read {CREDS}: {e}") from e
    key = d.get("api_key") or d.get("token")
    if not key:
        raise AiArkError(f"{CREDS} has no 'api_key' field.")
    return key


def _headers(key: str) -> Dict[str, str]:
    return {"X-TOKEN": key, "Content-Type": "application/json"}


def get_credits(key: str) -> Optional[float]:
    """Return remaining credit balance, or None if the call fails."""
    try:
        r = requests.get(f"{BASE}/payments/credits", headers=_headers(key), timeout=TIMEOUT)
        if r.status_code == 200:
            return float(r.json().get("total"))
    except (requests.RequestException, ValueError, TypeError):
        pass
    return None


# ---- query builder -------------------------------------------------------

def _kw_block(content: List[str], sources: List[str]) -> Dict[str, Any]:
    return {
        "sources": [{"mode": "SMART", "source": s} for s in sources],
        "content": content,
    }


def _months_ago_ms(months: int) -> int:
    """Epoch-ms `months` before now — for the funding recency window."""
    now = datetime.datetime.now(datetime.timezone.utc)
    past = now - datetime.timedelta(days=int(months) * 30)
    return int(past.timestamp() * 1000)


def _now_ms() -> int:
    return int(datetime.datetime.now(datetime.timezone.utc).timestamp() * 1000)


def build_account(
    *,
    include: List[str],
    exclude: List[str],
    locations: List[str],
    employee_min: Optional[int] = None,
    employee_max: Optional[int] = None,
    revenue_min: Optional[int] = None,
    revenue_max: Optional[int] = None,
    company_types: Optional[List[str]] = None,
    founded_min: Optional[int] = None,
    founded_max: Optional[int] = None,
    industries: Optional[List[str]] = None,
    naics: Optional[List[str]] = None,
    technologies: Optional[List[str]] = None,
    products: Optional[List[str]] = None,
    languages: Optional[List[str]] = None,
    exclude_domains: Optional[List[str]] = None,
    geo_lat: Optional[float] = None,
    geo_lng: Optional[float] = None,
    geo_radius: Optional[float] = None,
    geo_unit: str = "mi",
    funding_stages: Optional[List[str]] = None,
    funding_recent_months: Optional[int] = None,
    growth_dept: Optional[str] = None,
    growth_min_pct: Optional[float] = None,
    growth_months: Optional[str] = None,
    keyword_sources: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Map an OlympoLabs targeting brief onto AI Ark's `account` filter object.

    PRECISION-FIRST (validated 2026-06-09, see list-building-playbook.md):
    lead with the INDUSTRY CLASSIFICATION, then refine with keywords, then
    constrain with geo + headcount, then trim with excludes. Optional intent
    signals (funding, growth) are OPT-IN — the operator asks the user first.

    industries (CLASSIFICATION) -> account.industries.any.include (WORD)  <- precision lever
    naics codes                 -> account.naics.any.include              (matches ANY secondary code; pair with industries+keyword)
    products                    -> account.productAndServices.any.include (WORD) — what they sell
    INCLUDE keywords (REFINE)    -> account.keyword.any.include  (sources NAME/KEYWORD/DESCRIPTION/INDUSTRY)
    EXCLUDE keywords             -> account.keyword.any.exclude  (blunt; prefer firmographic precision)
    locations                    -> account.location.any.include
    employee range               -> account.employeeSize (RANGE)
    technologies                 -> account.technologies.any.include (WORD)
    company_types / founded / languages / geo-radius -> respective filters
    funding_* / growth_*         -> account.funding / account.metric (INTENT signals, opt-in)
    revenue                      -> BANNED by policy; callers should not pass it
    """
    sources = keyword_sources or DEFAULT_KEYWORD_SOURCES
    account: Dict[str, Any] = {}

    kw: Dict[str, Any] = {}
    if include:
        kw["include"] = _kw_block(include, sources)
    if exclude:
        kw["exclude"] = _kw_block(exclude, sources)
    if kw:
        account["keyword"] = {"any": kw}

    if locations:
        account["location"] = {"any": {"include": locations}}

    if employee_min is not None or employee_max is not None:
        account["employeeSize"] = {
            "type": "RANGE",
            "range": [{"start": employee_min or 0, "end": employee_max or 1_000_000}],
        }

    if revenue_min is not None or revenue_max is not None:
        # Kept for compatibility; OlympoLabs policy is to NEVER use it. build_list
        # does not pass it. Headcount is the size proxy.
        account["revenue"] = {
            "type": "RANGE",
            "range": [{"start": revenue_min or 0, "end": revenue_max or 1_000_000_000_000}],
        }

    if industries:
        account["industries"] = {"any": {"include": {"mode": "WORD", "content": industries}}}

    if naics:
        account["naics"] = {"any": {"include": naics}}

    if products:
        account["productAndServices"] = {"any": {"include": {"mode": "WORD", "content": products}}}

    if company_types:
        account["type"] = {"any": {"include": company_types}}

    if founded_min is not None or founded_max is not None:
        account["foundedYear"] = {
            "type": "RANGE",
            "range": {"start": founded_min or 1800, "end": founded_max or 2100},
        }

    if technologies:
        account["technologies"] = {"any": {"include": {"mode": "WORD", "content": technologies}}}

    if languages:
        account["language"] = {"any": {"include": languages}}

    if exclude_domains:
        account["domain"] = {"any": {"exclude": exclude_domains}}

    if geo_lat is not None and geo_lng is not None and geo_radius is not None:
        account["geoLocation"] = {
            "position": {"lat": geo_lat, "lng": geo_lng},
            "radius": geo_radius,
            "unit": "km" if str(geo_unit).lower().startswith("k") else "mi",
        }

    # ---- INTENT signals (opt-in) ----
    if funding_stages or funding_recent_months:
        funding: Dict[str, Any] = {}
        if funding_stages:
            funding["type"] = funding_stages
        if funding_recent_months:
            funding["duration"] = {"start": _months_ago_ms(funding_recent_months), "end": _now_ms()}
        account["funding"] = funding

    if growth_dept and growth_min_pct is not None:
        account["metric"] = {
            "growth": [{
                "function": growth_dept,
                "start": growth_min_pct,
                "end": 100000,
                "timeFrame": (growth_months or "SIX"),
            }]
        }

    return account


def search_page(
    key: str,
    account: Dict[str, Any],
    *,
    page: int,
    size: int,
    lookalike: Optional[List[str]] = None,
    exclude_company_ids: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """One Company Search page. Returns the parsed response dict.

    Raises OutOfCreditsError on HTTP 402 (account empty — must stop + top up).
    Treats 404 and the 10k-pagination 400 as a clean empty page so pagination
    terminates. Raises AiArkError on any other non-200.
    """
    body: Dict[str, Any] = {"account": account, "page": page, "size": min(size, MAX_PAGE_SIZE)}
    if lookalike:
        body["lookalikeDomains"] = lookalike[:5]
    if exclude_company_ids:
        body["lists"] = {"company_id": {"exclude": exclude_company_ids}}
    try:
        r = requests.post(f"{BASE}/companies", headers=_headers(key), json=body, timeout=TIMEOUT)
    except requests.RequestException as e:
        raise AiArkError(f"AI Ark request failed: {e}") from e
    if r.status_code == 402:
        raise OutOfCreditsError(
            "AI Ark returned HTTP 402 — the account is OUT OF CREDITS. "
            "Top up at https://app.ai-ark.com before building."
        )
    if r.status_code == 404:
        return {"content": [], "totalElements": 0, "totalPages": 0, "numberOfElements": 0, "last": True}
    if r.status_code == 400 and "pagination limit" in r.text.lower():
        # AI Ark caps pagination at 10,000 results per query — treat as a clean
        # end-of-results so the caller stops paging this band instead of crashing.
        return {"content": [], "totalElements": 0, "totalPages": 0, "numberOfElements": 0, "last": True}
    if r.status_code == 401:
        raise AiArkError(
            f"AI Ark returned HTTP 401 (unauthorized). Check the key, and confirm the "
            f"path is /companies (plural) — /company singular 401s. Body: {r.text[:200]}"
        )
    if r.status_code != 200:
        raise AiArkError(f"AI Ark returned HTTP {r.status_code}: {r.text[:300]}")
    try:
        return r.json()
    except ValueError as e:
        raise AiArkError(f"AI Ark returned non-JSON: {r.text[:200]}") from e


def inspect_domain(key: str, domain: str) -> Dict[str, Any]:
    """Fetch one company by domain so you can see how AI Ark ACTUALLY tags a
    known-good target (industries / naics / sic / primary industry) and pick
    real filter values off it. Returns {} if no match. Costs ~0.1 credit."""
    resp = search_page(
        key, {"domain": {"any": {"include": [_clean_domain(domain)]}}}, page=0, size=1,
    )
    content = resp.get("content") or []
    return content[0] if content else {}


# ---- response mapping ----------------------------------------------------

def _clean_domain(raw: str) -> str:
    """Normalize a domain/URL to a bare host: https://www.Jet.com/x -> jet.com."""
    if not raw:
        return ""
    d = str(raw).strip().lower()
    for pre in ("https://", "http://"):
        if d.startswith(pre):
            d = d[len(pre):]
    if d.startswith("www."):
        d = d[4:]
    d = d.split("/")[0].split("?")[0].strip()
    return d


def _collapse(text: str, cap: int = DESCRIPTION_CAP) -> str:
    if not text:
        return ""
    out = " ".join(str(text).split())
    return out[:cap]


def _location(company: Dict[str, Any]) -> str:
    hq = ((company.get("location") or {}).get("headquarter")) or {}
    parts = [hq.get("city"), hq.get("state"), hq.get("country")]
    seen, clean = set(), []
    for p in parts:
        if p and str(p).strip() and str(p).strip().lower() not in seen:
            seen.add(str(p).strip().lower())
            clean.append(str(p).strip())
    return ", ".join(clean)


def _employees(summary: Dict[str, Any]) -> str:
    staff = summary.get("staff") or {}
    if staff.get("total"):
        return str(staff["total"])
    rng = staff.get("range") or {}
    if rng.get("start") or rng.get("end"):
        return f"{rng.get('start', '')}-{rng.get('end', '')}".strip("-")
    return ""


def company_to_row(company: Dict[str, Any]) -> Dict[str, Any]:
    """Map one AI Ark company object -> the OUTPUT_HEADERS row dict."""
    summary = company.get("summary") or {}
    link = company.get("link") or {}
    website = _clean_domain(link.get("domain") or link.get("website") or "")
    description = _collapse(summary.get("description") or summary.get("overview") or "")
    return {
        "Company Name": summary.get("name") or "",
        "Website": website,
        "Description": description,
        "Industry": summary.get("industry") or "",
        "Location": _location(company),
        "Employees": _employees(summary),
        "Founded": summary.get("founded_year") or "",
        "LinkedIn": link.get("linkedin") or "",
        "AI Ark Company ID": company.get("id") or "",
    }


def dedupe_key(row: Dict[str, Any]) -> str:
    """Stable identity for a company row: prefer domain, fall back to id/name."""
    return (
        row.get("Website")
        or row.get("AI Ark Company ID")
        or row.get("Company Name", "").strip().lower()
    )
