#!/usr/bin/env python3
"""
list-builder — build a company list from scratch via AI Ark Company Search.

This is the front end of the OlympoLabs fulfillment pipeline: the Clay-search
replacement. It takes the INCLUDE / EXCLUDE keyword lists from the icp-keywords
skill plus a few structured filters, queries AI Ark's 70M-company database,
dedupes, and writes a fresh, scoring-ready Google Sheet (or CSV). The output
columns are exactly what company-scoring auto-detects, so the next step is a
zero-config hand-off:

    icp-keywords  ->  list-builder  ->  company-scoring  ->  (filter Qualified)  -> ...

Workflow (mirrors company-scoring's pilot-then-run):
    1. PREVIEW  — see the universe size + a sample + credit estimate, write nothing
    2. RUN      — paginate, dedupe, write the sheet

Runs under ~/.olympolabs/venv (modern TLS — AI Ark requires TLS 1.2+, which the
system python's old LibreSSL can't negotiate). This script auto-relaunches under
that venv if it exists, so `python3 build_list.py ...` just works.
"""

from __future__ import annotations

# --- venv bootstrap: re-exec under the modern-TLS venv before heavy imports ---
import os
import sys
from pathlib import Path

_VENV_PY = Path.home() / ".olympolabs" / "venv" / "bin" / "python"
if _VENV_PY.exists() and Path(sys.executable).resolve() != _VENV_PY.resolve():
    os.execv(str(_VENV_PY), [str(_VENV_PY)] + sys.argv)

import argparse
import csv
import datetime
import json
import time
from typing import List, Optional

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE / "lib" / "google-sheets-api"))

import aiark_search as ark  # noqa: E402

COST_LOG = Path.home() / ".olympolabs" / "list-builder-costs.log"
RATE_SLEEP = 0.25  # AI Ark allows 5 req/s; stay well under
SHEET_WRITE_CHUNK = 2000  # keep each values.update request well under the size limit (rich descriptions)


# ---- helpers -------------------------------------------------------------

def _split(s: Optional[str]) -> "list[str]":
    if not s:
        return []
    return [x.strip() for x in s.split(",") if x.strip()]


def _print_query(account: dict, lookalike: List[str]) -> None:
    body = {"account": account}
    if lookalike:
        body["lookalikeDomains"] = lookalike
    print("--- AI Ark query (account filter) ---")
    print(json.dumps(body, indent=2))
    print("-------------------------------------")


def _sample_table(rows: List[dict], n: int) -> None:
    print(f"\n{'#':>3}  {'Company':28s}  {'Website':26s}  {'Industry':24s}  {'Emp':>5}  Location")
    for i, r in enumerate(rows[:n], 1):
        print(
            f"{i:>3}  {r['Company Name'][:28]:28s}  {r['Website'][:26]:26s}  "
            f"{r['Industry'][:24]:24s}  {str(r['Employees'])[:5]:>5}  {r['Location'][:30]}"
        )


# ---- writers -------------------------------------------------------------

def _values(rows: List[dict]) -> List[List]:
    return [ark.OUTPUT_HEADERS] + [[r[h] for h in ark.OUTPUT_HEADERS] for r in rows]


def write_csv(path: str, rows: List[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        for row in _values(rows):
            w.writerow(row)


def _row_values(rows: List[dict]) -> List[List]:
    return [[r[h] for h in ark.OUTPUT_HEADERS] for r in rows]


# Durable, streaming writers. The target (sheet/tab) is CREATED FIRST with just
# the header row, then each pulled batch is APPENDED as it arrives — so an
# approved pull is never lost if the run dies mid-stream (the credits already
# spent stay on the sheet). RAW so descriptions starting with '=' or '+' aren't
# parsed as formulas. append() auto-grows the grid, so a small initial rowCount
# is fine.

def create_new_sheet(title: str):
    """Create a fresh spreadsheet with the header row. Returns (service, sid, tab, url)."""
    from sheets_auth import get_sheets_service
    service = get_sheets_service()
    created = service.spreadsheets().create(
        body={
            "properties": {"title": title},
            "sheets": [{"properties": {
                "title": "Companies",
                "gridProperties": {"rowCount": 2000, "columnCount": max(26, len(ark.OUTPUT_HEADERS))},
            }}],
        },
        fields="spreadsheetId,spreadsheetUrl",
    ).execute()
    sid = created["spreadsheetId"]
    service.spreadsheets().values().update(
        spreadsheetId=sid, range="Companies!A1", valueInputOption="RAW",
        body={"values": [ark.OUTPUT_HEADERS]},
    ).execute()
    return service, sid, "Companies", created["spreadsheetUrl"]


def create_existing_tab(sheet_url: str, tab: str):
    """Add a header-only tab to an existing spreadsheet (suffixing if it exists).
    Returns (service, sid, tab, url)."""
    from client import extract_sheet_id
    from sheets_auth import get_sheets_service
    service = get_sheets_service()
    sid = extract_sheet_id(sheet_url)
    base, n = tab, 2
    while True:
        try:
            service.spreadsheets().batchUpdate(
                spreadsheetId=sid,
                body={"requests": [{"addSheet": {"properties": {
                    "title": tab,
                    "gridProperties": {"rowCount": 2000, "columnCount": max(26, len(ark.OUTPUT_HEADERS))},
                }}}]},
            ).execute()
            break
        except Exception as e:
            if "already exists" in str(e):
                tab = f"{base} {n}"
                n += 1
                continue
            raise
    service.spreadsheets().values().update(
        spreadsheetId=sid, range=f"{tab}!A1", valueInputOption="RAW",
        body={"values": [ark.OUTPUT_HEADERS]},
    ).execute()
    return service, sid, tab, f"https://docs.google.com/spreadsheets/d/{sid}/edit  (tab: {tab})"


def append_batch(service, sid: str, tab: str, rows: List[dict]) -> None:
    """Append one batch of pulled rows to the live sheet."""
    service.spreadsheets().values().append(
        spreadsheetId=sid, range=f"{tab}!A1", valueInputOption="RAW",
        insertDataOption="INSERT_ROWS", body={"values": _row_values(rows)},
    ).execute()


# ---- run -----------------------------------------------------------------

PAGINATION_CAP = 10000  # AI Ark caps a single query at 10k results, regardless of universe


def _ensure_spend_approved(confirm_flag: bool, est_text: str) -> bool:
    """HARD CREDIT GATE. The list-builder must NEVER spend a single AI Ark credit
    without explicit user approval (building lists / pulling companies / contacts).

    Returns True only when approved:
      - --confirm-spend was passed (the operator passes it ONLY after the user
        explicitly OK'd the spend), or
      - a human at a TTY answered y/N.
    Otherwise it prints how to approve and returns False — so an agent-driven
    (non-TTY) run cannot spend anything unless --confirm-spend is present.
    """
    if confirm_flag:
        return True
    if sys.stdin.isatty():
        try:
            ans = input(f"\nThis will SPEND AI Ark credits ({est_text}). Proceed? [y/N] ").strip().lower()
        except EOFError:
            ans = ""
        if ans in ("y", "yes"):
            return True
        print("Not approved — nothing was spent.")
        return False
    print(f"\n⛔ CREDIT SPEND BLOCKED — this would spend AI Ark credits ({est_text}).", file=sys.stderr)
    print("   list-builder never spends credits without explicit user approval.", file=sys.stderr)
    print("   Get the user's OK, then re-run the SAME command with --confirm-spend.", file=sys.stderr)
    return False


def pull_streaming(key, make_account, emp_lo: int, emp_hi: int, lookalike: List[str],
                   max_companies: int, page_size: int, on_batch) -> "tuple[int, int, int]":
    """Pull up to max_companies deduped companies, auto-splitting by HEADCOUNT band
    whenever a band's universe exceeds the 10k pagination cap (recursive bisection
    of [emp_lo, emp_hi]). Each page's NET-NEW rows are handed to on_batch(rows)
    immediately (durable write) rather than buffered to the end. Only dedupe keys
    are held in memory. Returns (written_count, universe, bands)."""
    seen: "set[str]" = set()
    bands = [0]
    count = [0]

    def ingest(resp) -> None:
        new = []
        for c in resp.get("content") or []:
            if count[0] + len(new) >= max_companies:  # honor the cap precisely
                break
            row = ark.company_to_row(c)
            k = ark.dedupe_key(row)
            if k and k not in seen:
                seen.add(k)
                new.append(row)
        if new:
            on_batch(new)            # flush this batch to the durable target NOW
            count[0] += len(new)

    universe = int(ark.search_page(key, make_account(emp_lo, emp_hi), page=0, size=1,
                                   lookalike=lookalike).get("totalElements") or 0)

    def pull_band(lo: int, hi: int, depth: int) -> None:
        if count[0] >= max_companies:
            return
        account = make_account(lo, hi)
        # Cheap size=1 probe just to read THIS band's universe and decide whether
        # to bisect — NOT a full page. (Fetching size=page_size at every internal
        # node of the bisection tree wastes ~10 credits per node on rows that get
        # thrown away. Probe is ~0.1 credit.)
        u = int(ark.search_page(key, account, page=0, size=1, lookalike=lookalike)
                .get("totalElements") or 0)
        if u == 0:
            return
        if u > PAGINATION_CAP and hi > lo and depth < 16:
            mid = (lo + hi) // 2
            pull_band(lo, mid, depth + 1)
            pull_band(mid + 1, hi, depth + 1)
            return
        # Leaf band: page through it, requesting only as many as we still want.
        bands[0] += 1
        max_page = (PAGINATION_CAP // page_size) - 1  # keep page*size < 10k
        page = 0
        while page <= max_page and count[0] < max_companies:
            want = min(page_size, max_companies - count[0])
            resp = ark.search_page(key, account, page=page, size=want, lookalike=lookalike)
            if not (resp.get("content")):
                break
            ingest(resp)
            page += 1
            if count[0] < max_companies:
                time.sleep(RATE_SLEEP)

    pull_band(emp_lo, emp_hi, 0)
    return count[0], universe, bands[0]


def main() -> int:
    p = argparse.ArgumentParser(
        description="Build a scoring-ready company list from AI Ark Company Search.",
    )
    # Targeting — PRECISION-FIRST: lead with --industries, refine with --include,
    # constrain with --location/--employee, trim with --exclude. See references/.
    p.add_argument("--industries", help="Industry CLASSIFICATION (WORD match) — the PRECISION LEVER; LEAD WITH THIS. Comma-separated enum values, e.g. 'advertising services, marketing'. See --industries-list for valid values.")
    p.add_argument("--include", help="INCLUDE keywords to REFINE within the industry, comma-separated (icp-keywords output).")
    p.add_argument("--exclude", help="EXCLUDE keywords, comma-separated (blunt — prefer firmographic precision).")
    p.add_argument("--location", help="Locations, comma-separated (e.g. 'United States, Canada').")
    p.add_argument("--employee-min", type=int, help="Headcount floor — the SIZE proxy (never a revenue filter).")
    p.add_argument("--employee-max", type=int)
    p.add_argument("--naics", help="NAICS codes, comma-separated. Precise but matches any secondary code; pair with --industries/--include, never alone.")
    p.add_argument("--product", help="productAndServices terms (WORD) — what the company sells. Comma-separated.")
    p.add_argument("--technology", help="Tech-stack terms (WORD), comma-separated.")
    p.add_argument("--company-type", help="e.g. PRIVATELY_HELD,PUBLIC_COMPANY. Comma-separated. See aiark-api.md for the enum.")
    p.add_argument("--founded-min", type=int)
    p.add_argument("--founded-max", type=int)
    p.add_argument("--language", help="Site/profile language(s), comma-separated (e.g. 'english').")
    p.add_argument("--lookalike", help="Seed domains/LinkedIn company URLs (max 5), comma-separated → similar companies.")
    p.add_argument("--exclude-domains", help="Domains to exclude, comma-separated.")
    p.add_argument("--keyword-sources", help=f"Override keyword sources. Default: {','.join(ark.DEFAULT_KEYWORD_SOURCES)}.")
    # Geo-radius targeting (all three required together)
    p.add_argument("--geo-lat", type=float, help="Latitude for radius targeting (needs --geo-lng + --geo-radius).")
    p.add_argument("--geo-lng", type=float, help="Longitude for radius targeting.")
    p.add_argument("--geo-radius", type=float, help="Radius around (lat,lng).")
    p.add_argument("--geo-unit", default="mi", help="Radius unit: mi (default) or km.")
    # INTENT signals — OPT-IN. Ask the user before applying; they narrow volume.
    p.add_argument("--funding-stage", help="[INTENT — ask first] Funding stage(s), comma-separated (e.g. 'SEED,SERIES_A'). See --funding-list.")
    p.add_argument("--funding-recent-months", type=int, help="[INTENT — ask first] Only companies funded within the last N months.")
    p.add_argument("--growth-dept", help="[INTENT — ask first] Department whose headcount grew (e.g. 'sales'). Needs --growth-min-pct.")
    p.add_argument("--growth-min-pct", type=float, help="[INTENT — ask first] Minimum growth %% for --growth-dept.")
    p.add_argument("--growth-months", help="[INTENT — ask first] Growth window: ONE/THREE/SIX/TWELVE/TWENTY_FOUR (default SIX).")
    # Volume
    p.add_argument("--max-companies", type=int, default=None, help="Cap deduped count. DEFAULT: pull the FULL universe (preview shows it). Only set this to throttle a pull on purpose.")
    p.add_argument("--page-size", type=int, default=100, help="Results per AI Ark page (max 100).")
    # Credit gate — REQUIRED to spend anything. Pass ONLY after the user approves.
    p.add_argument("--confirm-spend", action="store_true",
                   help="Authorize AI Ark credit spend for this run. WITHOUT it, every credit-spending "
                        "operation (inspect / preview / build) is BLOCKED. Pass it only after the user OKs the spend.")
    # Modes (no build)
    p.add_argument("--preview", nargs="?", type=int, const=10, default=None,
                   metavar="N", help="Preview N companies (default 10) + universe size + credit estimate + ignored-filter guard. Small credit spend — still gated by --confirm-spend.")
    p.add_argument("--inspect", help="Comma-separated KNOWN-GOOD domains: print how AI Ark tags them (industries/naics/sic) so you can pick real filters. No build.")
    p.add_argument("--industries-list", action="store_true", help="Print the valid industry enum values the code knows, then exit.")
    p.add_argument("--funding-list", action="store_true", help="Print the valid funding-stage enum values, then exit.")
    # Output
    p.add_argument("--title", help="Title for the new spreadsheet (default: derived from --industries/--include).")
    p.add_argument("--sheet-url", help="Write into a NEW tab of this existing spreadsheet instead of creating one.")
    p.add_argument("--csv-path", help="Write to a local CSV instead of Google Sheets.")
    args = p.parse_args()

    # ---- enum-list modes (no key needed) ----
    if args.industries_list:
        print("Valid AI Ark industry enum values (pass to --industries, exactly as shown):\n")
        for v in ark.INDUSTRIES:
            print(f"  {v}")
        return 0
    if args.funding_list:
        print("Valid AI Ark funding-stage enum values (pass to --funding-stage):\n")
        print("  " + ", ".join(ark.FUNDING_TYPES))
        return 0

    try:
        key = ark.load_key()
    except ark.AiArkError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    # ---- INSPECT mode: how does AI Ark tag known-good companies? ----
    if args.inspect:
        _domains = _split(args.inspect)
        if not _ensure_spend_approved(args.confirm_spend,
                                      f"~{0.1 * len(_domains):.1f} credits — {len(_domains)} domain lookup(s)"):
            return 5
        print("INSPECT — how AI Ark tags these companies (pick real filters off this):\n")
        for d in _domains:
            try:
                c = ark.inspect_domain(key, d)
            except ark.OutOfCreditsError as e:
                print(f"ERROR: {e}", file=sys.stderr)
                return 4
            except ark.AiArkError as e:
                print(f"  {d}: lookup failed — {e}")
                continue
            if not c:
                print(f"  {d}: (no match)")
                continue
            s = c.get("summary") or {}
            print(f"  {d}")
            print(f"    primary industry: {s.get('industry')!r}")
            print(f"    industries: {c.get('industries')}")
            print(f"    naics: {c.get('naics')}   sic: {c.get('sic')}")
            time.sleep(RATE_SLEEP)
        return 0

    include = _split(args.include)
    exclude = _split(args.exclude)
    locations = _split(args.location)
    industries = _split(args.industries)
    funding_stages = _split(args.funding_stage)
    if not industries and not include and not args.naics and not args.product and not args.lookalike:
        p.error("Provide --industries (the precision lever; lead with this), and/or --include keywords, --product, --naics, or --lookalike.")

    # Warn (don't block) on industry values that aren't in the known enum — these
    # almost always match nothing (free-text instead of an enum value).
    if industries:
        unknown = ark.validate_industries(industries)
        if unknown:
            print(f"⚠️  These --industries are NOT in the known enum and will likely match nothing: {unknown}",
                  file=sys.stderr)
            print("    Run --industries-list for valid values, or --inspect a known-good domain to find the right tags.",
                  file=sys.stderr)

    emp_lo = args.employee_min if args.employee_min is not None else 1
    emp_hi = args.employee_max if args.employee_max is not None else 1_000_000

    def make_account(lo: int, hi: int) -> dict:
        return ark.build_account(
            include=include, exclude=exclude, locations=locations,
            employee_min=lo, employee_max=hi,
            company_types=_split(args.company_type) or None,
            founded_min=args.founded_min, founded_max=args.founded_max,
            industries=industries or None,
            naics=_split(args.naics) or None,
            products=_split(args.product) or None,
            technologies=_split(args.technology) or None,
            languages=_split(args.language) or None,
            exclude_domains=_split(args.exclude_domains) or None,
            geo_lat=args.geo_lat, geo_lng=args.geo_lng,
            geo_radius=args.geo_radius, geo_unit=args.geo_unit,
            funding_stages=funding_stages or None,
            funding_recent_months=args.funding_recent_months,
            growth_dept=args.growth_dept, growth_min_pct=args.growth_min_pct,
            growth_months=args.growth_months,
            keyword_sources=_split(args.keyword_sources) or None,
        )

    account = make_account(emp_lo, emp_hi)
    lookalike = _split(args.lookalike)[:5]

    balance = ark.get_credits(key)
    if balance is not None:
        print(f"AI Ark credit balance: {balance:,.1f}")
        if balance <= 0:
            print("\nERROR: AI Ark account has 0 credits — top up at https://app.ai-ark.com "
                  "before building. (Searches return HTTP 402 when empty.)", file=sys.stderr)
            return 4

    # ---- PREVIEW ----
    if args.preview is not None:
        n = args.preview
        if not _ensure_spend_approved(args.confirm_spend,
                                      f"~{0.1 * (n + 1):.1f}–1 credit — small universe-size probe"):
            return 5
        try:
            resp = ark.search_page(key, account, page=0, size=min(n, ark.MAX_PAGE_SIZE), lookalike=lookalike)
        except ark.OutOfCreditsError as e:
            print(f"\nERROR: {e}", file=sys.stderr)
            return 4
        universe = int(resp.get("totalElements") or 0)
        rows = [ark.company_to_row(c) for c in (resp.get("content") or [])]
        _print_query(account, lookalike)
        print(f"\nUNIVERSE: {universe:,} companies match this query.")

        # Ignored-filter guard: if the universe ~= the location+employee-only
        # baseline, a precision filter (industries/keyword/naics/...) is being
        # SILENTLY IGNORED (usually a value/syntax issue) — you'd pull the whole DB.
        precision_keys = {k for k in account if k not in ("location", "employeeSize")}
        if precision_keys:
            base_account = {k: v for k, v in account.items() if k in ("location", "employeeSize")}
            try:
                base_u = int(ark.search_page(key, base_account, page=0, size=1, lookalike=lookalike)
                             .get("totalElements") or 0)
            except ark.OutOfCreditsError:
                base_u = 0
            if base_u and universe >= base_u * 0.95:
                print(f"\n⚠️  IGNORED-FILTER WARNING: universe ({universe:,}) ≈ the location+employee-only "
                      f"baseline ({base_u:,}). A precision filter {sorted(precision_keys)} is being IGNORED "
                      f"(likely a bad value). Fix it — do NOT build this (it's ~the whole database).")

        target = universe if args.max_companies is None else min(args.max_companies, universe)
        cap_note = "the FULL universe" if args.max_companies is None else f"{target:,} (capped by --max-companies)"
        # Cost is billed per company RETURNED (~0.1 each), not per unique match.
        # A pull that fits under the 10k cap is ONE clean paginated pull → cost is
        # essentially target * 0.1 (dedup loss within a single band is negligible).
        # Only when banding kicks in (universe > 10k) do cross-band overlap +
        # per-band probes add a modest overhead, so widen the estimate then.
        # Cost depends on (a) whether banding happens — universe > 10k forces the
        # headcount bisection — and (b) whether we're CAPPING below the universe.
        # Measured rates (list-builder-costs.log, 13 runs): full pulls ≈ 0.1/co
        # regardless of banding; a CAPPED pull from a >10k universe runs ~0.2–0.3/co
        # because banding fetches overlapping headcount bands you pay for but dedupe
        # away — and capping keeps fewer of them. So pulling the full universe is
        # cheaper PER company than a small sample of it.
        capped = target < universe
        banding = universe > PAGINATION_CAP
        if capped:
            # Measured: CAPPED/sample pulls cost ~0.17-0.25/company — about 2x a full
            # pull — at ANY universe size (a 993-row cap from a 7,633 universe still
            # ran 0.18/co). It's the capping, not banding: AI Ark's partial-query
            # billing runs higher and isn't cleanly predictable. Small caps worse.
            print(f"Pulling {cap_note} ≈ {target * 0.17:,.0f}–{target * 0.25:,.0f} credits "
                  f"(~0.17–0.25/company — CAPPED/sample pulls cost ~2x per company vs a full "
                  f"pull, at ANY universe size; very small caps run higher. The FULL "
                  f"{universe:,} universe would be ~{universe * 0.1:,.0f} cr at ~0.1/company — "
                  f"cheaper per head.)")
        elif not banding:
            print(f"Pulling the FULL universe ≈ {target * 0.1:,.0f} credits "
                  f"(~0.1/company; universe under the 10k cap = one clean pull).")
        else:
            print(f"Pulling the FULL universe ≈ {target * 0.1:,.0f}–{target * 0.13:,.0f} credits "
                  f"(~0.1/company + light banding overhead; full universe over the 10k cap).")
        _sample_table(rows, n)
        if rows:
            print(f"\nSample description [{rows[0]['Company Name']}]:")
            print("  " + (rows[0]["Description"][:240] or "(none)"))
        print("\nLooks right? Re-run WITHOUT --preview to build the full universe "
              "(or add --max-companies N to throttle on purpose).")
        return 0

    # ---- RUN ----
    # CREDIT GATE: never pull (spend) without explicit approval.
    if args.max_companies is None:
        spend_est = "the FULL universe at ~0.1 credit/company (a little more if it exceeds the 10k cap) — run --preview first to see the exact count + cost"
    else:
        spend_est = (f"~{args.max_companies * 0.17:,.0f}–{args.max_companies * 0.25:,.0f} credits "
                     f"for up to {args.max_companies:,} companies (capped/sample pulls run ~0.17–0.25/company "
                     f"— about 2x a full pull, at ANY universe size; small caps higher. A full-universe "
                     f"pull is ~0.1/company — cheaper per head.)")
    if not _ensure_spend_approved(args.confirm_spend, spend_est):
        return 5

    # Discover the universe (first spend) so the full-universe default knows how
    # many to pull and we can report it.
    try:
        uni0 = int(ark.search_page(key, account, page=0, size=1, lookalike=lookalike)
                   .get("totalElements") or 0)
    except ark.OutOfCreditsError as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        return 4
    if uni0 == 0:
        print("No companies match this query. Loosen the filters or check it with --preview.")
        return 1
    if args.max_companies is None:
        max_companies = uni0
        print(f"Approved. Pulling the FULL universe (~{uni0:,} companies, page size {args.page_size})...")
    else:
        max_companies = args.max_companies
        print(f"Approved. Pulling up to {max_companies:,} of ~{uni0:,} (page size {args.page_size})...")

    # Set up the DURABLE writer FIRST, then stream each batch into it as it's
    # pulled — so an approved pull is NEVER lost if the run dies mid-stream.
    csv_file = None
    try:
        if args.csv_path:
            csv_file = open(args.csv_path, "w", newline="", encoding="utf-8")
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow(ark.OUTPUT_HEADERS)
            csv_file.flush()
            target_desc = f"CSV: {args.csv_path}"
            print(f"Writing live to {args.csv_path} (data is safe even if the run dies).")

            def on_batch(rows):
                for r in rows:
                    csv_writer.writerow([r[h] for h in ark.OUTPUT_HEADERS])
                csv_file.flush()
        elif args.sheet_url:
            service, sid, tab, loc = create_existing_tab(args.sheet_url, args.title or "AI Ark Companies")
            target_desc = loc
            print(f"Writing live to {loc}\n  (data is safe even if the run dies).")

            def on_batch(rows):
                append_batch(service, sid, tab, rows)
        else:
            _seed = (industries or include or _split(args.product) or ["companies"])[0]
            title = args.title or f"List Builder — {_seed}"
            service, sid, _tab, url = create_new_sheet(title)
            target_desc = url
            print(f"Created sheet '{title}' — writing live (data is safe even if the run dies):\n  {url}")

            def on_batch(rows):
                append_batch(service, sid, "Companies", rows)
    except Exception as e:
        expired = "Reauthentication is needed" in str(e) or "RefreshError" in type(e).__name__
        print(f"\nERROR: could not create the output target: {e}", file=sys.stderr)
        if expired:
            print("  Cause: Google ADC session expired. Reauth:\n"
                  "    gcloud auth application-default login "
                  "--scopes=openid,email,https://www.googleapis.com/auth/spreadsheets", file=sys.stderr)
        return 3

    # Stream the pull into the durable writer.
    count = 0
    try:
        count, universe, bands = pull_streaming(
            key, make_account, emp_lo, emp_hi, lookalike, max_companies,
            min(args.page_size, ark.MAX_PAGE_SIZE), on_batch,
        )
    except ark.OutOfCreditsError as e:
        if csv_file:
            csv_file.flush(); csv_file.close()
        print(f"\nERROR: {e}", file=sys.stderr)
        print(f"  The companies pulled before running out are already saved at: {target_desc}", file=sys.stderr)
        return 4
    except Exception as e:
        if csv_file:
            csv_file.flush(); csv_file.close()
        print(f"\nERROR mid-pull: {e}", file=sys.stderr)
        print(f"  The companies pulled so far are already saved at: {target_desc} (not lost).", file=sys.stderr)
        return 3
    if csv_file:
        csv_file.flush(); csv_file.close()

    split_note = f" (auto-split into {bands} headcount bands to clear the 10k cap)" if bands > 1 else ""
    print(f"\nUniverse was {universe:,}; wrote {count:,} unique companies{split_note} ->\n  {target_desc}")
    if count == 0:
        print("No companies returned. Loosen the filters or check the query with --preview.")

    # Credit accounting + cost log
    after = ark.get_credits(key)
    used = (balance - after) if (balance is not None and after is not None) else None
    if used is not None:
        print(f"Credits used: {used:,.1f}  (balance now {after:,.1f})")
    try:
        with COST_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps({
                "ts": datetime.datetime.now().isoformat(timespec="seconds"),
                "industries": industries, "include": include, "exclude": exclude,
                "location": locations, "funding_stages": funding_stages,
                "count": count, "universe": universe,
                "credits_used": used, "target": target_desc,
            }) + "\n")
    except OSError:
        pass

    print("\nNext: score it ->  company-scoring on the sheet/CSV above, then filter ICP Verdict = Qualified.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
