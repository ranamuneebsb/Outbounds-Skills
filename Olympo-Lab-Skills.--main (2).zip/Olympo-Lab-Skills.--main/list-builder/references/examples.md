# list-builder — worked examples

Precision-first: lead with `--industries`, refine with `--include`, constrain with
geo + headcount. Preview first; build the full universe by default.

## Example 0: Validate the data model first (inspect known-good companies)

```
python3 scripts/build_list.py --inspect drhorton.com,hines.com,pulte.com
```

Prints each company's primary industry + `industries` / `naics` / `sic` tags so you
pick real filter values instead of guessing. (~0.1 credit/domain.)

## Example 1: LeadGen agencies, US

```
python3 scripts/build_list.py \
  --industries "advertising services, marketing" \
  --include "lead generation, appointment setting, cold email, demand generation, outbound sales, SDR, B2B lead gen" \
  --exclude "recruiting, staffing, real estate, insurance, mortgage" \
  --location "United States" \
  --employee-min 2 --employee-max 200 \
  --preview 10
```

Preview prints the universe, a sample, the credit estimate, and the ignored-filter
guard. If the sample looks on-target, drop `--preview` (pulls the full universe)
and add `--title "Client — LeadGen US"`.

## Example 2: Property management, US

```
python3 scripts/build_list.py \
  --industries "real estate, leasing non-residential real estate" \
  --include "property management, HOA management, community association management, rental management" \
  --exclude "real estate brokerage, mortgage, title insurance, vacation rental" \
  --location "United States" \
  --employee-min 5 --employee-max 500 \
  --title "Property Management US"
```

## Example 3: Lookalike expansion (find companies like a seed set)

When you have a few ideal-customer domains and want more like them:

```
python3 scripts/build_list.py \
  --industries "marketing, advertising services" \
  --lookalike "https://linkedin.com/company/some-great-customer, anotherideal.com" \
  --location "United States, Canada" \
  --preview 10
```

## Example 4: Intent signal — recently funded B2B SaaS (ASK THE USER FIRST)

Only add a funding/growth signal after confirming with the user — it narrows volume.

```
python3 scripts/build_list.py \
  --industries "software development, technology, information and internet" \
  --include "B2B SaaS, platform, software" \
  --location "United States" --employee-min 11 --employee-max 200 \
  --funding-stage "SEED,SERIES_A" --funding-recent-months 12 \
  --preview 10
```

Growth-signal variant — companies whose sales team grew ≥25% in 6 months:

```
  --growth-dept sales --growth-min-pct 25 --growth-months SIX
```

## Example 5: Offline / no Google auth (CSV)

```
python3 scripts/build_list.py \
  --industries "individual and family services, hospitals and health care" \
  --include "home care, assisted living, senior care, geriatric care" \
  --location "United States" --employee-min 10 \
  --csv-path ~/Desktop/senior-care-us.csv
```

## Enum helpers (no credits, no key)

```
python3 scripts/build_list.py --industries-list   # valid industry values
python3 scripts/build_list.py --funding-list       # valid funding stages
```

---

## AI Ark Company Search response → output column mapping

A company object from `POST /companies` `content[]`:

```json
{
  "id": "5f187d88-901c-0f78-48d5-91e2ab1ccab7",          // -> AI Ark Company ID
  "summary": {
    "name": "Act-On Software",                            // -> Company Name
    "description": "Act-On Software provides ...",         // -> Description
    "industry": "software development",                   // -> Industry (single primary label)
    "founded_year": 2008,                                 // -> Founded
    "staff": { "total": 200, "range": {"start":..,"end":..} }  // -> Employees
  },
  "link": {
    "domain": "act-on.com",                               // -> Website (preferred)
    "website": "https://www.act-on.com",                  // -> Website (fallback)
    "linkedin": "https://www.linkedin.com/company/act-on-software"  // -> LinkedIn
  },
  "location": { "headquarter": { "city": "...", "state": "...", "country": "..." } },  // -> Location
  "industries": ["mobile payments","software development","saas"],  // multi-tag (for --inspect)
  "naics": ["541511","522320"], "sic": ["7389"]
}
```

Pagination: `totalElements` (universe), `totalPages`, `last`. We page with
`size=100`, sleep 0.25s between pages (limit 5 req/s), dedupe by domain, and
auto-split the headcount range into bands to clear the 10k-results-per-query cap.

## The decision-maker phase (built — see dm-enrichment)

`People Search` (`POST /people`) is the decision-maker enrichment step, handled by
the **dm-enrichment** skill. It takes the same `account` company filters PLUS a
`contact` object (`experience.current.title`, `seniority`, `departmentAndFunction`,
tenure, hiring badges) and can scope to specific companies via
`contact.company.current.any.include` using the **AI Ark Company ID** this skill
persists — which is why that column is carried through. Full contact-filter surface
in `aiark-api.md §7`.
