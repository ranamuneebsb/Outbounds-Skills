# ICP Discovery Interview — run this BEFORE building any list

A list is only as good as its targeting. So **never go straight to
`build_list.py`** — first ask three objective questions, then synthesize the
filters and **get the user to confirm (or correct) before spending credits.**
(AI Ark Company Search costs ~0.1 credit/company returned — see `aiark-api.md`.)

## The three questions (ask these, nothing more)

1. **What is the offer?**
   What are we selling, and to whom? The offer defines who we target — infer the
   buyer from it. (e.g. "done-for-you cold email lead gen for B2B SaaS companies".)

2. **What headcount are we going for?**
   Company size, as an employee range (min–max). If unsure, offer bands:
   1–10 / 11–50 / 51–200 / 201–500 / 500+.

3. **What countries — and anything else you want to add?**
   The geographies to target. The open "anything else" lets the user pin extra
   constraints (sub-niches to include, business models to exclude, signals, etc.)
   without being interrogated for them.

That's the whole interview. Don't pile on more questions — keep it objective.
(Don't ask for example companies; if the user happens to name a few, you can
`build_list.py --inspect <domains>` to see how AI Ark tags them and pick filters
off real tags — but don't make it a required question.)

## Synthesize → propose the targeting (precision-first)

From those answers, produce the targeting brief. Lead with the industry
classification, then refine — this is the validated doctrine (see
`list-building-playbook.md`):

- **Industry classification** — map the ICP to 1–4 values from AI Ark's
  `industries` enum (`build_list.py --industries-list`). This is the precision
  lever; lead with it.
- **INCLUDE keywords** — the terms the target uses for itself, to refine *within*
  the industry. (Use the **icp-keywords** skill to generate these from the offer.)
- **EXCLUDE keywords** — adjacent / wrong-fit terms that would pollute the search
  (blunt on AI Ark — prefer firmographic precision over heavy excludes).
- **Geographies** — the country list.
- **Headcount** — min–max employees (the size proxy; never a revenue filter).

### Intent signals — ask, don't assume
If the offer implies a timing/intent angle — e.g. "they just raised money", "teams
that are scaling/hiring", "recently funded startups" — **ASK the user whether to
add an intent signal** (funding stage/recency, or department employee-growth).
These narrow the universe, so they are opt-in. If the user wants one, add it and
show the volume impact in `--preview`. Never apply an intent signal silently.

## Confirm + correct (the loop)

Show the targeting back and ask:

> "Here's how I'd target it — INDUSTRIES: …, INCLUDE: …, EXCLUDE: …, in
> [countries], [min]–[max] employees[, intent signal: …]. Anything to add, drop,
> or tighten before I pull?"

- If the user corrects → adjust and re-show. Loop until "yes".
- **Targeting approval is NOT spend approval.** Before running the preview (which
  costs ~1 credit), say so and get the user's OK, then run `--preview --confirm-spend`.
  The preview shows the *universe size* + the full-build credit estimate + a sample,
  and runs the ignored-filter guard:
  - a few hundred → too narrow (loosen industries/includes, widen headcount/geo)
  - millions → too broad (lead with the industry filter, sharpen includes, add excludes)
- Then **state the full-build credit cost and get explicit approval again** before
  building. Only then run the build with `--confirm-spend`. It pulls the **full
  universe** (don't sample) and writes live to the sheet. Hand the sheet to
  **company-scoring** — that's where the real qualification happens. Keep the AI
  Ark net broad-but-on-target; let scoring filter.

> **The hard rule (see SKILL.md):** the skill never spends a single credit without
> the user's explicit per-run approval. Inspect, preview, and build are all gated
> behind `--confirm-spend`; never add that flag without asking first.

## Why precision-first (and not keyword-only)

OlympoLabs used to build keyword-only with **no industry filter**. That was
reversed on 2026-06-09 after a live A/B: keyword-only returned ~26% qualified on an
easy ICP (US Google-Ads agencies) and forced wasteful scoring of ~8k companies;
**leading with the industry classification returned ~65% qualified** at a fraction
of the time/cost. So: lead with `--industries`, refine with keywords, and let
`company-scoring` make the final fit call. Breadth in, qualified-only out.
