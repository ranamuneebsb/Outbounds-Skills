# List-building playbook — how to build an accurate list and how to find more

The strategy layer on top of the raw API contract (`aiark-api.md`). This is the
"understand the ICP and the AI Ark algorithm so you can always find us more
accurate contacts" doctrine. Read both.

---

## 0. The mental model: breadth at the search, precision at the score

AI Ark is a **recall instrument with noisy, multi-label tagging.** Every company
carries several `industries`/`naics` tags, and the tagging is inconsistent. So:

- The search's job is to assemble the **right addressable universe** —
  precise enough to be mostly on-target, broad enough to not drop good-fit
  companies that are tagged oddly.
- **`company-scoring` is the precision instrument.** It reads each company and
  qualifies it 1–10 against the real ICP. That's where fit is decided.

**Breadth in, qualified-only out.** Don't try to make the search perfect — make it
*accurate enough that scoring isn't wading through junk*, then let scoring do the
fit call.

---

## 1. The precision-first doctrine (supersedes the old "no industry filter" rule)

> **Historical note:** earlier versions of this skill said "never use the industry
> filter — keywords only." That was **reversed on 2026-06-09 after a live A/B** and
> the reversal is now permanent. Keyword-only produced garbage: ~26% qualified on
> an *easy* ICP (US Google-Ads agencies), forcing wasteful scoring of ~8k
> companies. Leading with the industry classification produced ~65% qualified at a
> fraction of the scoring cost/time. The SKILL.md prose that still said "no
> industry filter, by design" was stale — ignore any lingering copy of it.

**The validated recipe — layer filters in this order:**

1. **Lead with `industries`** (the AI Ark classification, `any.include`, mode
   `WORD`). Map the ICP to 1–4 values from the enum in `aiark-api.md §6`. This is
   the precision lever — it does ~80% of the targeting.
2. **Refine with `--include` keywords** (sources NAME/KEYWORD/DESCRIPTION/INDUSTRY,
   SMART) — the terms the target uses for itself, to sharpen within the industry.
3. **Constrain with geography + headcount** (employee band = the size proxy).
4. **Trim with `--exclude` keywords** for adjacent wrong-fit terms — but excludes
   are *blunt* on AI Ark (they also catch client-vertical mentions in
   descriptions); prefer firmographic precision over heavy excludes.
5. **(Optional, ask first) intent signals** — see §5.

Then **let scoring qualify.** Aim for a universe that scores **≥ ~50% qualified**.
If a preview suggests it'll be much lower, tighten step 1–2; much higher and tiny,
loosen them.

### NAICS is a supporting actor, not the lead
NAICS (`--naics`) is precise per-code but **`any`-matches secondary codes**, so on
its own it's noisy (Stripe carries 3 NAICS). Use it to *catch companies the
industry tag misses* (union it in), paired with `industries`/keyword — never alone.

---

## 2. Validate the data model BEFORE choosing filters — don't guess

Two cheap moves that prevent building the wrong list:

1. **`build_list.py --inspect drhorton.com,hines.com,<known-good>`** — prints how
   AI Ark actually tags companies you *know* fit (their `industries` / `naics` /
   `sic` / primary industry). Pick your filter values off those real tags instead
   of guessing enum strings. (Costs ~0.1 cr/domain.)
2. **`--preview`** — prints the exact query, the **universe size**, a **credit
   estimate**, and a sample. It also runs the **ignored-filter guard**: if the
   filtered universe ≈ the location+employee-only baseline, a filter is being
   **silently ignored** (almost always a syntax issue) and you'd be pulling the
   whole DB. Never trust a suspiciously huge or round universe.

Reading the universe number:
- a few hundred → too narrow (loosen industries/keywords or widen bands)
- millions → too broad (add the industry lead, sharpen includes, add excludes)
- "multiple thousands, mostly on-target in the sample" → right.

---

## 3. Revenue → employees (hard rule)

**Never use the `revenue` filter.** AI Ark's revenue data is unreliable and
revenue is irrelevant to OlympoLabs targeting. This holds **even if the
client/intake explicitly asks to filter by revenue.** Translate the revenue
target into a **headcount floor** by reasoning about revenue-per-employee for the
vertical, and use `--employee-min`:

- asset-heavy / labor-light (real-estate developers ~ $1M rev/employee): $10M ≈ 10+
- typical B2B services/SaaS (~$150–250k rev/employee): $3M ≈ 15–20+

And the scorer must judge **fit only** — never re-impose a revenue threshold in the
rubric (a revenue clause once wrongly dropped ~1,118 real developers).

---

## 4. Pull the FULL universe, not a sample

After preview shows the universe (say 31,051), **build all of it** — set
`--max-companies` at/above the universe, or omit it (the default now pulls the full
universe). Do **not** leave it at a small sample. OlympoLabs wants the full
addressable market; scoring filters it down afterward.

The script auto-bisects the **headcount** range into sub-bands to clear AI Ark's
**10,000-results-per-query cap**, so large pulls complete. Cost is billed per
company *returned*, in two regimes (measured, 14 runs):
- **FULL pull:** ≈ `count × 0.10` (0.10–0.13 once universe > 10k → banding). Reliable.
- **CAPPED / sample pull (`--max-companies`):** ≈ `cap × 0.17–0.25` — **~2× the full
  rate, at ANY universe size** (a 993-cap from a 7.6k universe still ran ~0.18/co;
  small caps higher). Partial-query billing is pricier and not cleanly predictable.

**Takeaway: a sample is the *most expensive* way to buy companies per head — and the
least predictable.** Pull the full universe unless the user explicitly wants a capped
sample. `--preview` prints the exact figure for whichever regime applies.

---

## 5. Intent / signal filters — powerful, but OPT-IN (always ask)

These narrow the universe to *higher-intent* companies. They can sharpen a list or
surface net-new high-propensity accounts — **but they also cut volume**, so they
are **never applied by default. Ask the user whether they're relevant** before
adding them, and show the volume impact in preview.

- **Funding** (`--funding-stage`, `--funding-recent-months`): e.g. recently raised
  Seed/Series-A → budget + growth motion. Good for "companies that just got money
  to spend." Cuts to funded companies only — verify there's still enough volume.
- **Employee growth** (`--growth-dept sales --growth-min-pct 20 --growth-months SIX`):
  companies whose *sales* (or any department) headcount grew ≥20% in 6 months →
  scaling GTM, hiring, likely buying. Excellent intent signal; small universe.
- **Hiring badges / job-change** (People side, dm-enrichment): `HIRING`,
  new-in-role contacts — timing signals for outreach.

Rule of thumb: build the **firmographic** list first (industries + keywords + geo +
headcount). Layer an intent signal only when the user wants a tighter, higher-intent
cut **and** the preview shows the funded/growing universe is still big enough to be
worth a campaign.

---

## 6. The volume-expansion ladder — "always find us more"

When a build (or the qualified-after-scoring list) is **too thin**, climb this
ladder. Each rung adds reach while protecting quality. **Always: dedupe net-new
first, re-score any net-new companies through the same rubric, and stop a rung the
moment net-new yield drops (don't bleed credits on a dud).**

| # | Rung | What it does | When |
|---|---|---|---|
| 1 | **Broaden the industry union** | add adjacent enum values (`--inspect` more known-good companies to discover the tags they carry) | first move — cheapest reach, same ICP |
| 2 | **Add product/keyword angles** | union `--product` + more `--include` synonyms the target uses | the segment uses varied self-descriptions |
| 3 | **Relax bands** | widen headcount / add geographies | the ICP genuinely spans more |
| 4 | **Headcount-band stratification** | (automatic) bisect employeeSize to pull > 10k universes | universe exceeds the 10k cap |
| 5 | **NAICS / industry stratification** | run the query per-NAICS / per-industry slice and union | a single band still > 10k, or to catch mis-tags |
| 6 | **Lookalike seeds** | `--lookalike <best-converter domains>` (max 5) → companies similar to proven winners | you have a few ideal customers and want more like them |
| 7 | **People-by-account (no domain)** | People Search by industry+size+geo + DM titles, *no domain* → same-ICP contacts at companies that never made the company list | (dm-enrichment) company list is maxed but you need more *contacts* |
| 8 | **Widen titles** | broaden the DM title/seniority/department filter on already-qualified companies → more relevant seats per company | (dm-enrichment) cheapest contacts — companies already passed the ICP gate |

Rungs 1–6 are list-builder (more companies). Rungs 7–8 are dm-enrichment (more
contacts). Use `lists` exclusion (`aiark-api.md §8`) across re-pulls so you never
re-pay for companies/people you already have.

**Yield discipline (the point of the ladder):** after a small probe window, if
net-new-per-result falls below a floor (~15%), stop that rung and report — don't
spend the budget padding the list with near-duplicates or off-ICP companies.

---

## 7. Cost & quality guardrails (always on)

- **Check credits first.** A 402 mid-run = out of credits (not "no results").
  Top up before building; the script aborts clearly on 402.
- **Preview before every full build** — it's the cost gate and the
  ignored-filter guard.
- **Dedupe by domain** (built in) and across re-pulls (via `lists`).
- **Re-score net-new** companies — never auto-trust expansion pulls.
- **Never the revenue filter.** Headcount is the size proxy.
- **Don't over-tighten** at search time — a slightly loose list scores fine; a
  too-tight list misses good accounts you can't get back.
