# AI Ark API — the authoritative reference

Everything the list-builder (and any AI-Ark skill) needs to know about the API.
Sourced from the official docs (`docs.ai-ark.com`, machine index at `/llms.txt`)
**and verified live against the real endpoint on 2026-06-19.** Where the docs and
live behavior disagree, the live-verified value wins and is marked **[verified]**.

For *how to build a list well* (strategy, the precision-first doctrine, the
volume-expansion ladder), see **`list-building-playbook.md`**. This file is the
raw API contract.

---

## 1. Base, auth, endpoints

- **Base URL:** `https://api.ai-ark.com/api/developer-portal/v1`
- **Auth:** header `X-TOKEN: <api_key>` — **no `Bearer` prefix.** [verified]
  (The marketing "first-steps" page mentions `Authorization: Bearer`; that is
  wrong for the developer-portal API. Use `X-TOKEN`.)
- **Key file:** `~/.olympolabs/aiark.json` → `{"api_key": "..."}`
- **Header:** `Content-Type: application/json` required on every POST.
- **TLS:** AI Ark requires TLS 1.2+. The macOS system python (LibreSSL) **cannot**
  reach it — always run under `~/.olympolabs/venv` (OpenSSL 3.x). Scripts auto
  re-exec under the venv.

| Endpoint | Method | Path | Purpose |
|---|---|---|---|
| Credits | GET | `/payments/credits` | `{"total": N}` remaining balance. **Free.** |
| **Company Search** | POST | **`/companies`** | Search 70M+ companies. ← list-builder's engine |
| People Search | POST | `/people` | Search 400M+ people (account and/or contact filters). |
| Export single + email | POST | `/people/export/single` | One person → full profile + BounceBan-verified email (real-time). |
| Export bulk + email | POST | `/people/export` | Up to 10,000 people → emails, async (webhook + poll). |
| Export results (poll) | GET | `/people/export/{trackId}/inquiries` | Paginated results of a bulk export. |
| Email finder (by trackId) | POST | `/people/email-finder` | Cheaper bulk emails: enrich a People-Search `trackId`. |
| Mobile phone finder | POST | `/people/mobile-phone-finder` | LinkedIn or domain+name → mobile number. |
| Reverse lookup | POST | `/people/reverse-lookup` | Email/phone → full person profile. |
| Personality analysis | POST | `/people/analysis` | LinkedIn URL → OCEAN/DISC + comms style. |
| Lists | POST | `/lists` | Create/update a reusable exclude list (people_id/company_id). |

### Endpoint gotcha — `/companies`, NOT `/company`
**Company Search is `POST /companies` (plural).** `POST /company` (singular)
returns **HTTP 401**. [verified] Any code still calling `/company` is silently
broken (it will look like an auth failure). People Search is `/people`.

### Error codes (what they actually mean) [verified]
| Code | Meaning | Action |
|---|---|---|
| 200 | OK | parse `content[]` |
| 400 | Bad request — incl. `"pagination limit exceeded"` past the 10k cap | stop paging this band |
| 401 | Unauthorized — **or you hit the wrong path** (`/company`) | check path + key |
| **402** | **Payment Required = out of credits** | **stop and top up.** Do NOT treat as "no results." |
| 404 | `"data not found"` — genuinely empty result | treat as empty page |
| 409 | bulk export still processing | retry/poll later |
| 429 | rate limited | back off (limits below) |
| 501 | unsupported (e.g. non-LinkedIn `socialMediaFollower`) | drop that filter |

> **402 is the trap.** When the account runs out of credits, searches return 402,
> which old code mistook for "no match." The list comes back empty and the
> targeting gets blamed. Check the balance first (`GET /payments/credits`); if a
> search 402s mid-run, abort with a clear "top up credits" message.

---

## 2. Cost model & rate limits

Credit costs are **not published in the docs** — these are measured live.

| Operation | Cost | Notes |
|---|---|---|
| `GET /payments/credits` | **0** | free balance check |
| **Company Search** | **billed per result *returned*** [verified, 14 runs] | not per unique match. **Not free.** Two regimes: **FULL pull** ≈ `count × 0.10` (0.10–0.13 once universe > 10k → banding); **CAPPED/sample pull** ≈ `cap × 0.17–0.25` — **~2× the full rate at ANY universe size** (a 993-cap from a 7.6k universe ran ~0.18/co), small caps higher. Partial-query billing is pricier + not cleanly predictable → a sample is the most expensive way to buy companies per head; prefer full pulls. (A one-off ~0.9/co was a since-fixed banding bug.) |
| People Search | ~0.5 credit per person *returned* | bills on results, not matches. Server has no name-exclusion, so use `lists` to avoid re-paying for people you already have. |
| Export single + email | **1 credit** (0.5 profile + 0.5 BounceBan email); **0 if no valid email found** | [docs] real-time, slow per-person — don't use at scale. |
| Email finder / bulk export | per email found (BounceBan-verified) | the scalable email path; prefer over export-single. |

> **The "Company Search is free" claim in old `_pipeline/AIARK_LIST_BUILDING.md`
> is FALSE.** It costs ~0.1/company. Treat every pull as real spend and always
> `--preview` (which prints the credit estimate) before a full build.

**Rate limits** (global, all endpoints): **5 req/s · 300/min · 18,000/hr**;
resets every 60s; over-limit → 429. Stay ≤ ~4.5/s (the scripts sleep 0.25s/page).

---

## 3. The data model (why union-of-signals + scoring works)

A company object carries **multiple** classification tags, not one. Live example
(`stripe.com`):

```
industries: ["mobile payments", "software development", "saas", "fintech", "finance"]
naics:      ["522320", "541511", "523940"]
sic:        ["7389"]
summary.industry: "software development"   ← single "primary" label
```

Consequences that drive the whole strategy:
- **`industries.any.include` matches if ANY of a company's tags match** → good
  recall. `all` requires every listed tag → high precision, low recall.
- A company is reachable under several industry tags, so a single tag never
  captures a segment cleanly → **union a few precise tags, then let scoring
  filter.** (See playbook.)
- **NAICS `any` matches secondary codes too** (Stripe carries 3) → NAICS alone is
  noisy; pair it with `industries` + keyword.
- **`sic` is present in the data but is NOT a request-time filter** — you can read
  it (via `--inspect`) but can't search on it.

---

## 4. Company Search — full request schema

```json
{
  "lookalikeDomains": ["domain-or-linkedin-url", "... max 5"],
  "account": { ...filters... },
  "lists": { "company_id": { "exclude": ["uuid", "..."] } },
  "page": 0,            // 0-based
  "size": 100           // 1–100, default 10
}
```

### `account` filters

Every text filter takes `{any|all: {include: {...}, exclude: {...}}}`.
`any` = OR (match ≥1), `all` = AND (match all). Most filters take a
`{mode, content}` block; a few take plain string arrays.

| Filter | Shape | Use |
|---|---|---|
| `industries` | `{any:{include:{mode,content:[...]}, exclude:{mode,content:[...]}}}` | **the precision lever.** mode `WORD`. Values from the enum in §6. |
| `keyword` | `{any:{include:{sources:[{mode,source}],content:[...]}, exclude:{...}}}` | free-text refine across chosen sources. See §5. |
| `location` | `{any:{include:["United States",...], exclude:[...]}}` | plain strings (country/state/city). |
| `employeeSize` | `{type:"RANGE", range:[{start,end}]}` | **array** of ranges (multi-band ok). Headcount = size proxy. |
| `naics` | `{any:{include:["541810",...], exclude:[...]}}` | plain code arrays. `any` matches secondary codes. |
| `productAndServices` | `{any:{include:{mode,content:[...]}}}` | what the company sells — strong ICP signal, underused. |
| `technologies` | `{any:{include:{mode,content:["salesforce",...]}}}` | tech-stack (mode WORD). |
| `type` | `{any:{include:[ENUM,...]}}` | company type enum (§6). |
| `foundedYear` | `{type:"RANGE", range:{start,end}}` | single range (object, not array). |
| `revenue` | `{type:"RANGE"|"ALL"|"NONE", range:[{start,end}]}` | **BANNED by OlympoLabs policy — never use.** Translate to headcount. |
| `language` | `{any:{include:[ENUM,...]}, range:{start,end}}` | site/profile language. |
| `geoLocation` | `{position:{lat,lng}, radius:N, unit:"km"|"mi"}` | radius targeting around a point. |
| `funding` | `{type:[ENUM,...], totalAmount:{start,end}, lastAmount:{start,end}, duration:{start,end}}` | funding stage/size/recency (ms timestamps). **Intent signal — opt-in.** |
| `metric` | `{employee:[{function,start,end,timeFrame}], growth:[{function,start,end,timeFrame}]}` | headcount/**growth by department** over a window. **Intent signal — opt-in.** |
| `domain` / `linkedin` / `url` / `name` | include/exclude (domain/linkedin = arrays; url/name = `{mode,content}`) | target/exclude specific companies. |
| `socialMedia` | `{any:{include:[FACEBOOK|INSTAGRAM|TWITTER|LINKEDIN]}}` | has-presence-on. |
| `socialMediaLink` / `phoneNumber` | include/exclude arrays | rarely needed. |
| `retailSize` | `{type:"RANGE", range:[{start,end}]}` | store count (retail). |

### `lists` (server-side exclusion)
`{"company_id": {"exclude": [uuid,...]}}` — up to 10 lists/request, 10k items
each. Create lists via `POST /lists` (see §8). Use this to skip companies you've
already pulled/contacted **without re-paying** for them.

### Response (the fields the skill maps)
```
content[]:
  id                                   → AI Ark Company ID (join key for People Search)
  summary.{name, legal_name, description, founded_year, type, industry,
           staff.total, staff.range.{start,end}, logo}
  link.{website, domain, linkedin, twitter, crunchbase}
  location.headquarter.{city, state, country, ...}
  industries[], keywords[], naics[], sic[], technologies[], languages[]
  financial.funding.{type, total_amount, rounds[...]}
pagination: totalElements (universe), totalPages, last, numberOfElements, number
```

---

## 5. Keyword sources & match modes

`keyword` searches free text across one or more **sources**, each with a **mode**:

- **Sources** (`KeywordSource`): `NAME`, `KEYWORD`, `DESCRIPTION`, `INDUSTRY`, `SEO`.
  Default for list-builder: `NAME, KEYWORD, DESCRIPTION, INDUSTRY` (SEO is noisier).
- **Modes** (`SearchMatchMode`): `SMART` (intelligent/stemmed match — default),
  `WORD` (word-boundary), `STRICT` (exact).

`industries`, `technologies`, `productAndServices`, `name`, `url` also take a
`mode`. For `industries`, use **`WORD`** (the enum values are multi-word phrases
like `advertising services`; WORD matches the phrase cleanly).

People Search `keyword` uses different sources: `ORGANIZATION`, `SUMMARY`, `HEADLINE`.

---

## 6. Enumerations

### Company `type`
`PRIVATELY_HELD`, `SELF_OWNED`, `SELF_EMPLOYED`, `PARTNERSHIP`, `PUBLIC_COMPANY`,
`NON_PROFIT`, `EDUCATIONAL`, `GOVERNMENT_AGENCY`

### Funding `type` (intent signal)
`PRE_SEED`, `SEED`, `SERIES_A`…`SERIES_J`, `VENTURE_ROUND`, `ANGEL`,
`PRIVATE_EQUITY`, `DEBT_FINANCING`, `CONVERTIBLE_NOTE`, `GRANT`, `CORPORATE_ROUND`,
`EQUITY_CROWDFUNDING`, `PRODUCT_CROWDFUNDING`, `SECONDARY_MARKET`, `POST_IPO_EQUITY`,
`POST_IPO_DEBT`, `POST_IPO_SECONDARY`, `NON_EQUITY_ASSISTANCE`,
`INITIAL_COIN_OFFERING`, `UNDISCLOSED`, `SERIES_UNKNOWN`, `FUNDING_ROUND`

### `metric` department functions (for employee count / growth)
`program_and_project_management`, `education`, `purchasing`, `accounting`, `sales`,
`research`, `operations`, `customer_success_and_support`, `legal`,
`product_management`, `media_and_communication`, `real_estate`, `quality_assurance`,
`consulting`, `arts_and_design`, `healthcare_services`, `entrepreneurship`,
`engineering`, `community_and_social_services`, `marketing`,
`information_technology`, `business_development`, `administrative`,
`military_and_protective_services`, `finance`, `human_resources`, `support`

### `metric` timeFrame
`ONE`, `THREE`, `SIX`, `TWELVE`, `TWENTY_FOUR` (months)

### `industries` — the full valid enum (LinkedIn industry taxonomy)
**This is the precision lever.** Pass values **exactly** as below (lowercase).
Free-text phrases that are not in this list (e.g. `"real estate developer"`)
match almost nothing — map the ICP to the closest enum value(s) instead. A
company carries several of these; `any.include` a small union.

```
accounting
administration of justice
advertising services
airlines and aviation
alternative dispute resolution
alternative medicine
animation and post-production
appliances, electrical, and electronics manufacturing
architecture and planning
armed forces
artists and writers
automation machinery manufacturing
aviation and aerospace component manufacturing
banking
beverage manufacturing
biotechnology research
book and periodical publishing
broadcast media production and distribution
business consulting and services
capital markets
chemical manufacturing
civic and social organizations
civil engineering
computer and network security
computer games
computer hardware manufacturing
computer networking products
computers and electronics manufacturing
construction
consumer services
dairy product manufacturing
defense and space manufacturing
design services
e-commerce
education administration programs
e-learning providers
entertainment providers
environmental services
events services
executive offices
facilities services
farming
financial services
fisheries
food and beverage manufacturing
food and beverage services
freight and package transportation
fundraising
furniture and home furnishings manufacturing
gambling facilities and casinos
glass, ceramics and concrete manufacturing
government administration
government relations services
graphic design
higher education
hospitality
hospitals and health care
human resources services
individual and family services
industrial machinery manufacturing
information services
insurance
international affairs
international trade and development
investment banking
investment management
it services and it consulting
law enforcement
law practice
leasing non-residential real estate
legal services
legislative offices
libraries
machinery manufacturing
manufacturing
maritime transportation
market research
marketing
media production
medical equipment manufacturing
medical practices
mental health care
mining
mobile gaming apps
motor vehicle manufacturing
movies, videos, and sound
museums, historical sites, and zoos
musicians
nanotechnology research
newspaper publishing
non-profit organizations
oil and gas
online audio and video media
outsourcing and offshoring consulting
packaging and containers manufacturing
paper and forest product manufacturing
performing arts
personal care product manufacturing
pharmaceutical manufacturing
philanthropic fundraising services
photography
plastics manufacturing
political organizations
primary and secondary education
printing services
professional training and coaching
public policy offices
public relations and communications services
public safety
railroad equipment manufacturing
ranching
real estate
recreational facilities
religious institutions
renewable energy semiconductor manufacturing
research services
restaurants
retail
retail apparel and fashion
retail art supplies
retail groceries
retail luxury goods and jewelry
retail office equipment
security and investigations
semiconductor manufacturing
shipbuilding
software development
spectator sports
sporting goods manufacturing
staffing and recruiting
strategic management services
technology, information and internet
telecommunications
textile manufacturing
think tanks
tobacco manufacturing
translation and localization
transportation, logistics, supply chain and storage
travel arrangements
truck transportation
utilities
venture capital and private equity principals
veterinary services
warehousing and storage
wellness and fitness services
wholesale
wholesale building materials
wholesale import and export
wireless services
writing and editing
```

> This list is the ~150 values exposed by the schema as of 2026-06-19. It tracks
> the LinkedIn industry taxonomy; AI Ark may add values. If an `--inspect` of a
> known-good company shows an industry tag not listed here, it is still valid —
> add it. Run `build_list.py --industries-list` to print the enum the code knows.

---

## 7. People Search — contact filters (for dm-enrichment)

People Search (`POST /people`) takes the **same `account` filters as Company
Search** PLUS a `contact` object — so you can find people by company firmographics
**without any domain**, or scope to specific company UUIDs.

Key `contact` filters:
- `experience.current.title` / `.latest.` / `.previous.` — `{any:{include:{mode,content:[titles]}}}`
- `experience.current.duration` — tenure ranges (`currentJob`/`currentCompany`/`total`
  min/max in years+months) → **job-change signal** (e.g. in role < 12 months).
- `seniority` — enum include/exclude (`founder`, `head`, `senior`, …).
  **Unreliable** (CEOs tagged "intern", AMs tagged "founder") → rank on TITLE, not seniority.
- `departmentAndFunction` — enum (`executive`, `marketing`, `sales`, `product_management`,
  `accounting`, `design`, …).
- `company.{current|latest|previous}` — `{any:{include:[company UUIDs]}}` → filter
  people by the **AI Ark Company IDs** the list-builder persists.
- `keyword` — sources `ORGANIZATION`, `SUMMARY`, `HEADLINE`.
- `profileBadge` — `HIRING`, `OPEN_TO_WORK`, `CREATOR`, `INFLUENCER`, `VERIFIED`,
  `PAID_SOCIAL_MEMBERS` (intent/timing signals).
- `education` (school/degree/fieldOfStudy/date), `skill`, `certification`,
  `socialMediaFollower.linkedin` (followers/connections range; LinkedIn only).
- `lists.people_id.exclude` — server-side dedup of already-contacted people.

People response carries `trackId` (feed it to `/people/email-finder`), full
profile, and `company` firmographics. ~0.5 credit/person returned.

---

## 8. Lists, lookalike, MCP

- **Lists** (`POST /lists`): a reusable set of `company_id` or `people_id` UUIDs
  for **exclusion**. Body `{type, values:[uuid], mode:"APPEND"|"REPLACE", id?}`.
  Max 50 lists/day, 10k items each, **auto-expire after 24h.** Reference them in
  search via `lists.{company_id|people_id}.exclude`. This is how you avoid
  re-pulling and re-paying for companies/people you already have.
- **Lookalike:** NOT a separate endpoint — it's the top-level `lookalikeDomains`
  field on Company Search (seed up to 5 of your best-fit domains / LinkedIn
  company URLs). No people-lookalike in the API.
- **MCP server (optional):** AI Ark exposes a remote MCP server at
  `https://api.ai-ark.com/v1/mcp?token=<API-KEY>` (company search, people search,
  enrichment, doc search). The skills use the direct REST API for control + cost
  accounting; the MCP server is an alternative for ad-hoc agent use.

---

## 9. Pagination & the 10k cap

- `size` ≤ 100 per page; `page` is 0-based; `totalElements` = the universe.
- **Hard cap: a single query returns at most 10,000 results.** Past
  `page*size = 10,000` you get `400 "pagination limit exceeded"`.
- To pull a universe larger than 10k, **stratify** the query into sub-bands whose
  individual universes are each < 10k and union the results (dedupe by domain).
  The list-builder auto-bisects the **headcount** range; for very large segments
  also stratify by NAICS / industry / geography. See the playbook.
