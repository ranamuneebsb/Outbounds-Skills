---
name: list-builder
description: Build a B2B lead list FROM SCRATCH and deliver the DECISION-MAKERS — the full front end of the OlympoLabs pipeline in one skill, end to end: (1) ICP discovery interview, (2) pull companies via AI Ark Company Search, (3) score them for ICP fit, (4) pull the decision-makers via AI Ark People Search. The skill ENDS at the decision-maker list and NEVER runs email enrichment or any email/verification waterfall — emails, name-normalizer, personalization, and PlusVibe are separate downstream steps the user owns. ALWAYS starts with an ICP discovery interview (offer, who we target, headcount, geographies, exclusions) — never builds from a vague request, and lets the user correct the narrowing before pulling. Targeting is PRECISION-FIRST: lead with AI Ark's industry classification, refine with include/exclude keywords, constrain with geography + headcount; optional intent signals (funding, employee growth) are opt-in (ask first). Trigger when the user wants to "build a list", "pull companies for [ICP]", "get a list of companies/leads in [geo]", "replace Clay", "find companies matching these keywords", "build the prospect list", "get me the decision-makers for [ICP]", or starts a new campaign and needs the lead list. Provider: AI Ark Company + People Search. Runs under ~/.olympolabs/venv.
---

# list-builder

Builds a B2B lead list from scratch and delivers the **decision-makers** — the
front end of the OlympoLabs pipeline, end to end in one skill. It pulls companies
from **AI Ark Company Search** (70M+ companies), scores them for ICP fit, then
pulls the decision-makers from **AI Ark People Search**. This is the work
Clay/Apollo used to do by hand — now it's a few API calls.

```
1. Define the ICP  →  2. Pull companies (AI Ark)  →  3. Score the companies  →  4. Pull the decision-makers  →  deliver the DM list   ⛔ ENDS HERE
```

The deliverable is the **decision-maker list** (name, title, LinkedIn, AI Ark
IDs — NO emails). Email enrichment, name-normalizer, personalization, copywriting,
and PlusVibe are separate downstream steps the user owns, **outside** this skill.

## ⛔ Scope & hard stop — NO email enrichment, NO waterfalls

This skill **ends at the decision-maker list.** Its only deliverable is the
contacts CSV (name, title, seniority, department, LinkedIn, AI Ark Company ID,
AI Ark Person ID — **no email addresses**).

It **NEVER**:
- runs an email-finding / email-verification waterfall (no `enrich_waterfall.py`,
  no Blitz, no email provider),
- exports emails from AI Ark People Search (`/people/export/single` is never called),
- runs name-normalizer, personalization, copywriting, or PlusVibe upload.

Those are deliberate downstream steps the user owns. When Step 4 finishes, hand
over the DM list and **stop** — do not offer to "also find the emails" or chain
into a waterfall.

## ⛔ Credit approval — NON-NEGOTIABLE

**The skill must NEVER spend a single AI Ark credit without the user's explicit,
per-run approval — for inspecting, previewing, building lists, or pulling any
companies/contacts.** This is enforced two ways:

1. **In code:** every credit-spending operation is hard-gated behind
   `--confirm-spend`. Without that flag, an agent-driven (non-TTY) run is
   **BLOCKED** (exits without spending). Never add `--confirm-spend` to a command
   on your own initiative.
2. **In behavior (you):** before running ANY command that spends credits, **state
   the estimated credit cost and ask the user to approve it.** Only after the user
   says yes do you re-run the same command with `--confirm-spend`. Each run needs
   its own approval — approval for a preview is NOT approval for the build.

The free, ungated calls are: the credit-balance check, `--industries-list`, and
`--funding-list`. Everything that hits company/people search spends and is gated.

**Durable writes:** once a build is approved, the script **creates the sheet/CSV
first and writes every batch as it's pulled** — so if the run dies mid-stream, the
companies already pulled (and paid for) are safe on the sheet and the URL was
already printed. Never buffer-then-write.

## The two reference docs — read them before non-trivial builds

- **`references/aiark-api.md`** — the authoritative AI Ark API contract: every
  endpoint, the full Company-Search filter schema, the complete `industries`
  enum, the verified cost model, error codes, the People-Search surface, and the
  10k-pagination cap. This is "how AI Ark actually works."
- **`references/list-building-playbook.md`** — how to build accurately and how to
  **find more**: the precision-first doctrine, the union-of-signals + scoring
  model, the volume-expansion ladder, intent signals, and the cost/quality
  guardrails. This is "how we build."

## Targeting model — precision-first (this is the doctrine)

AI Ark is a recall instrument with noisy, multi-label tagging. The search's job is
to assemble the **right addressable universe**; `company-scoring` is the precision
instrument that decides fit. **Breadth in, qualified-only out.** Layer filters in
this order:

1. **Lead with `--industries`** — AI Ark's industry classification (the precision
   lever; mode WORD, `any`-match a small union). Map the ICP to 1–4 values from
   the enum (`build_list.py --industries-list`, or `--inspect` a known-good domain
   to see real tags). This does ~80% of the targeting.
2. **Refine with `--include`** keywords (from the **icp-keywords** skill) to sharpen
   within the industry.
3. **Constrain with `--location` + `--employee-min/max`** (headcount = the size proxy).
4. **Trim with `--exclude`** keywords for adjacent wrong-fit terms (blunt on AI Ark
   — prefer firmographic precision over heavy excludes).
5. **(Optional) intent signals** — funding stage/recency, employee growth. **These
   narrow volume, so they are OPT-IN: ASK THE USER whether they're relevant before
   applying them**, and show the volume impact in `--preview`.

> **Doctrine note (don't regress):** an earlier version of this skill said "no
> industry filter, by design — keywords only." That was **reversed and is now
> permanent.** Keyword-only produced ~26% qualified on an easy ICP and forced
> wasteful scoring; leading with the industry classification produced ~65%
> qualified at a fraction of the cost. Lead with `--industries`.

> **Never the revenue filter.** AI Ark's revenue data is unreliable and revenue is
> irrelevant to OlympoLabs — *even if the intake explicitly asks for a revenue
> band.* Translate the revenue target into a headcount floor (`--employee-min`).
> The flag has been removed from this script.

> ⚠️ **Runs under `~/.olympolabs/venv`, not the system python.** AI Ark requires
> TLS 1.2+, which the system python's old LibreSSL can't negotiate. The scripts
> **auto-relaunch under the venv** if it exists, so `python3 scripts/build_list.py …`
> just works. If the venv is missing, `doctor.py` prints the one-line fix.

## Prerequisites (run the doctor first)

```
python3 scripts/doctor.py
```

Checks everything and prints the exact fix for anything red:
1. **venv** at `~/.olympolabs/venv` with `requests` + Google Sheets libs.
2. **AI Ark key** at `~/.olympolabs/aiark.json` → `{"api_key": "..."}` (header `X-TOKEN`)
   **plus a live credits ping** — if the balance is **0 you cannot build** (searches
   return HTTP 402, which looks like "no results"). Top up at https://app.ai-ark.com.
3. **Google ADC** (only for Sheets output, not CSV) — the doctor refreshes the token
   so it catches an expired session. Shared with the scoring/normalize/personalize skills.

## Workflow

### 0. ICP Discovery Interview — ALWAYS run this first

**Never build from a vague ask.** Ask three objective questions (full detail in
**`references/icp-intake.md`**):

1. **What is the offer?** What we're selling and to whom — infer the target from it.
2. **What headcount are we going for?** Employee range (bands if unsure:
   1–10 / 11–50 / 51–200 / 201–500 / 500+).
3. **What countries — and anything else to add?** Geographies + an open slot for
   extra constraints (sub-niches, business models to exclude, signals).

Then **synthesize and confirm**: propose the targeting — **industry
classification + INCLUDE keywords + EXCLUDE keywords + geographies + headcount**
(use the **icp-keywords** skill for the keyword lists; map the ICP to industry
enum values). If the offer suggests an intent angle (e.g. "they just raised" or
"scaling teams"), **ask whether to add a funding/growth signal** — don't apply it
silently. Show it back, allow corrections, loop until approved, then preview.

### 1. Inspect (optional, ~0.1 cr/domain) — validate the data model

If you have a few known-good example companies, see how AI Ark actually tags them
so you pick real filter values instead of guessing. **Spends ~0.1 cr/domain — ask
the user first, then add `--confirm-spend`:**

```
python3 scripts/build_list.py --inspect drhorton.com,hines.com,pulte.com --confirm-spend
```

### 2. Preview (small spend) — the cost + sanity gate

Tell the user "checking the universe size costs about 1 credit — OK?" then:

```
python3 scripts/build_list.py \
  --industries "advertising services, marketing" \
  --include "lead generation, appointment setting, cold email, demand generation" \
  --exclude "recruiting, staffing, real estate, insurance" \
  --location "United States" --employee-min 2 --employee-max 200 \
  --preview 8 --confirm-spend
```

Prints the **exact AI Ark query**, the **universe size**, a **credit estimate for
the full build**, a **sample table**, and runs the **ignored-filter guard** (warns
if a precision filter is being silently ignored — i.e. the universe ≈ the whole
DB). Reading the universe: a few hundred = too narrow; millions = too broad;
"thousands, on-target sample" = right.

### 3. Build — pulls the FULL universe by default (writes live)

Now you know the universe + cost from preview. **Tell the user the credit cost and
get explicit approval**, then run with `--confirm-spend`. **By default it pulls the
entire matching universe** (OlympoLabs wants the full addressable market; scoring
filters it down) and **writes each batch to the sheet as it's pulled** — so nothing
is lost if the run dies. The script auto-splits the headcount range into bands to
clear AI Ark's 10k-results-per-query cap.

```
python3 scripts/build_list.py \
  --industries "advertising services, marketing" \
  --include "lead generation, appointment setting, cold email, demand generation" \
  --exclude "recruiting, staffing, real estate, insurance" \
  --location "United States" --employee-min 2 --employee-max 200 \
  --title "Acme — LeadGen Agencies US" \
  --confirm-spend
```

Use `--max-companies N` **only to throttle on purpose** (e.g. a quick test pull —
it requests only N and honors the cap precisely). Prints the sheet/CSV path up
front, then the deduped count and credits used. That completes **Step 2 (pull
companies)** — go straight to Step 3.

### 4. Score the companies (keep Qualified)

Score the pulled list for ICP fit and keep only `Qualified` (score ≥ 7). Run the
**company-scoring** orchestrator against the list you just built and the ICP from
Step 0 (save it to `~/.olympolabs/icp-profiles/<slug>.md` first):

```
python3 ~/.claude/skills/company-scoring/scripts/score_sheet.py \
  --csv-path "<list.csv>"  --icp-file ~/.olympolabs/icp-profiles/<slug>.md \
  --no-escalation --concurrency 30
```

(Swap `--csv-path` for `--sheet-url` on Sheets.) It writes the five scoring
columns back; the rows with `ICP Verdict == Qualified` are the input to Step 4.
This spends OpenRouter/ZenRows, **not** AI Ark. On AI-Ark-sourced lists, **skip
the 6–7 scrape-rescue** (low yield). Pilot 20 rows, get sign-off on the ICP, then
run the full list.

### 5. Pull the decision-makers (AI Ark People Search ONLY) → deliver, then STOP

Pull the decision-makers for the Qualified companies with the campaign's DM
titles, using **dm-enrichment's `find_contacts.py`** — which is **People Search
only, with NO email export**:

```
python3 ~/Desktop/OlympoLabs-Skills/dm-enrichment/scripts/find_contacts.py \
  --source-sheet "<sheet-url>" --min-score 7 \
  --search-titles "<DM titles>" --keep-titles "<...>" --exclude-titles "<...>" \
  --tier1-titles "<...>" --tier2-titles "<...>" \
  --search-size 8 --max-per-company 25 --csv-path "<dm-list.csv>"
```

- People Search bills **~0.5 cr per contact RETURNED** (`--search-size` is the
  cost lever) — so **estimate + get explicit approval before pulling**, and pilot
  ~20 companies first to validate the titles and price the rate (it can settle
  ~2× the immediate read).
- **Override every title list per campaign.** The script's built-in defaults
  target print/events buyers and EXCLUDE sales/marketing/product — wrong for most
  campaigns.

⚠️ **`find_contacts.py` reads its company list from a Google Sheet only.** When
Sheets/ADC is unavailable (CSV pipeline), drive its engine from the scored CSV:
run under `~/.olympolabs/venv/bin/python`, `import find_contacts`, build company
dicts `{company, website, aiark_id, score}` from the CSV, and thread
`find_contacts.enrich_company`. For a contacts-only pull, set
`find_contacts.mail_blocked = lambda p: False` so no company is dropped for an
email gateway. (Full pattern: the `csv-pipeline-find-contacts-gotchas` memory.)

When the DM list is written, **hand it to the user and STOP.** Do not run a
waterfall, do not find emails, do not chain into name-normalizer / personalization
/ PlusVibe — those are the user's separate downstream steps.

## "We need more leads" — the volume-expansion ladder

When a build (or the qualified-after-scoring list) is too thin, climb the ladder
in `list-building-playbook.md §6`. In short, in order of preference:

1. **Broaden the industry union** (`--inspect` more known-good companies → add the tags they carry).
2. **Add product/keyword angles** (`--product`, more `--include` synonyms).
3. **Relax bands** (widen `--employee` / add geographies).
4. **Headcount-band stratification** — automatic (clears the 10k cap).
5. **NAICS / industry stratification** for any single band still > 10k.
6. **Lookalike seeds** (`--lookalike <best-converter domains>`, max 5).
7–8. **People-by-account / widen-titles** — these add *contacts* at **Step 5 (the decision-maker pull)** via `find_contacts.py` (People Search only, no emails).

Always: dedupe net-new, re-score any net-new companies through the same rubric,
and stop a rung when net-new yield drops (don't burn credits padding the list).

## How targeting maps to AI Ark

**Core levers** (the normal flow):

| Flag | AI Ark `account` filter | Notes |
|---|---|---|
| `--industries` | `industries.any.include` (WORD) | **the precision lever — lead with it.** Enum values; `--industries-list` to print them. |
| `--include` | `keyword.any.include` (sources NAME/KEYWORD/DESCRIPTION/INDUSTRY, SMART) | OR across terms → refine within the industry. |
| `--exclude` | `keyword.any.exclude` | drops a company matching any exclude term (blunt). |
| `--location` | `location.any.include` | e.g. `"United States, Canada"`. |
| `--employee-min/max` | `employeeSize` RANGE | headcount = the size proxy (never revenue). |

**Additional firmographic levers** (use as the ICP needs):

| Flag | AI Ark filter | Notes |
|---|---|---|
| `--naics` | `naics.any.include` | precise but matches secondary codes — pair with industries/keyword, never alone. |
| `--product` | `productAndServices.any.include` (WORD) | what the company sells. |
| `--technology` | `technologies.any.include` (WORD) | tech-stack signal. |
| `--company-type` | `type.any.include` | `PRIVATELY_HELD,PUBLIC_COMPANY,…` (see aiark-api.md). |
| `--founded-min/max` | `foundedYear` RANGE | |
| `--language` | `language.any.include` | site/profile language. |
| `--geo-lat/--geo-lng/--geo-radius/--geo-unit` | `geoLocation` | radius targeting around a point. |
| `--lookalike` | top-level `lookalikeDomains` (max 5) | seed domains/LinkedIn URLs → similar companies. |
| `--exclude-domains` | `domain.any.exclude` | drop specific companies. |
| `--keyword-sources` | overrides include/exclude sources | default `NAME,KEYWORD,DESCRIPTION,INDUSTRY`. |

**Intent signals — OPT-IN, ASK THE USER FIRST** (they narrow volume):

| Flag | AI Ark filter | Notes |
|---|---|---|
| `--funding-stage` | `funding.type` | e.g. `SEED,SERIES_A` (`--funding-list` for values). |
| `--funding-recent-months` | `funding.duration` | funded within the last N months. |
| `--growth-dept` + `--growth-min-pct` + `--growth-months` | `metric.growth` | e.g. sales headcount grew ≥20% in 6 months (window ONE/THREE/SIX/TWELVE/TWENTY_FOUR). |

## Output columns (scoring-ready, zero mapping)

| Column | Source | Used by |
|---|---|---|
| `Company Name` | `summary.name` | scoring (company), merge tag |
| `Website` | `link.domain` (bare host) | **scoring REQUIRES this** |
| `Description` | `summary.description` | scoring's cheap description path |
| `Industry` | `summary.industry` | context |
| `Location` | HQ city/state/country | context |
| `Employees` | `summary.staff.total` | context |
| `Founded` | `summary.founded_year` | context |
| `LinkedIn` | `link.linkedin` | context |
| `AI Ark Company ID` | `id` | **join key** for Step 5's People Search (the decision-maker pull) — keep this column. |

One company per row, deduped by domain. Rich AI Ark descriptions mean most rows
score on the cheap description path (no ZenRows scrape needed).

## Output targets

- **(default)** new Google Sheet — `--title "..."` sets the name; prints the URL.
- `--sheet-url <url>` — writes into a **new tab** of an existing spreadsheet.
- `--csv-path out.csv` — local CSV (no Google auth needed).

If a Sheets write fails on an expired ADC session, the pulled rows are rescued to
`/tmp/list-builder-rescue.csv` so the AI Ark credits aren't wasted.

## Cost

Billed per *result handed back*, not per unique match. Two regimes (measured across
14 real runs in `list-builder-costs.log`):
- **FULL pull:** ≈ `count × 0.10` (0.10–0.13 once the universe is > 10k and banding
  kicks in). Reliable + predictable. A 9.5k full pull ≈ ~950 cr; a 31k ≈ ~3,100–3,900.
- **CAPPED / sample pull (`--max-companies`):** ≈ `cap × 0.17–0.25` — **about 2× the
  full-pull rate, at ANY universe size** (a 993-row cap from a 7.6k universe still ran
  ~0.18/co; very small caps run higher). AI Ark's partial-query billing is pricier and
  not cleanly predictable, so **a sample is the most expensive way to buy companies per
  head.**

> **Estimating discipline:** always quote from `--preview` (it applies the right
> regime). NEVER eyeball `cap × 0.1` for a capped pull — it under-quotes ~2× (it bit us
> twice in testing: a 1k sample quoted ~100 actually cost 245, and another cost 176).
> **Prefer full-universe pulls** — cheaper per company *and* predictable. (A one-off
> ~0.9/company was a since-fixed banding bug.)

`--preview` prints the exact estimate; **nothing spends without `--confirm-spend` +
your explicit approval**. **Company Search is NOT free** (an old doc claimed it was
— wrong). Free calls: the balance check, `--industries-list`, `--funding-list`.
Every run logs to `~/.olympolabs/list-builder-costs.log`.

## Gotchas

- **Never spend without approval.** Every credit-spending run is gated by
  `--confirm-spend`; you must ask the user (with the cost estimate) before adding
  it. Each run needs its own approval.
- **Writes are live + durable.** The sheet/CSV is created first and filled batch by
  batch as the pull runs — a mid-run crash never loses pulled-and-paid-for rows.
- **Check credits first.** Balance 0 → builds come back empty via HTTP 402, which
  is *out of credits*, not bad targeting. The script aborts clearly on 402.
- **Always `--preview` first** — it's the cost gate and the ignored-filter guard.
- **`/companies` plural, not `/company`** — the singular path 401s. (The script
  uses the right one; flagged here because old `_pipeline` code didn't.)
- **Lead with `--industries`; don't over-tighten.** A slightly loose list scores
  fine; a too-tight list misses good accounts. Let scoring do the qualifying.
- **`Website` is mandatory downstream.** Rows without a domain are written (blank
  Website) but scoring skips them — fine.
- **Keep `AI Ark Company ID`** — it's the chain key for Step 5's decision-maker pull (People Search); don't delete it.
- **Pull the full universe**, not a sample — omit `--max-companies` unless you mean
  to throttle.
