# [ICP NAME] ICP

## Who counts as a fit

Describe the core ICP in 2-3 sentences. Be specific:
- Geography (country, region, state if relevant)
- Industry / category
- Company size band (employees / revenue)
- Business model

## Positive signals (any of these = higher score, multiple = 8-10)

- Self-describes as "..."
- Mentions services like ...
- Industry tag is ...
- Based in ...
- Other concrete signals you'd recognize as a strong fit

## Negative signals (score under 5 or Disqualified)

- **Adjacent industries that look similar but aren't:** ...
- **Subsegments you DON'T want:** ...
- **Companies that share a keyword but are different:** ...
- **Geographic mismatches:** ...
- **Size mismatches:** ...

## Edge cases - how to handle

Describe ambiguous cases and what to do:
- "Design-build" hybrid -> FIT/NOT FIT because ...
- Multi-trade firms doing core service + adjacent -> ...
- Small specialty offshoots of larger firms -> ...

## Use of metadata

If the sheet has industry/category columns that are unreliable, note that here:

> The `main_category` column in this list comes from [SOURCE] and is OFTEN
> WRONG. Use it as one signal, but override based on the description / scrape
> content when they disagree.

---

# How to use this template

1. Copy this file to `~/.olympolabs/icp-profiles/<slug>.md` (e.g. `dental-offices-texas.md`).
2. Fill in the bracketed sections with the client's actual ICP.
3. Be concrete and specific. The LLM follows what's written here literally - vague rules produce inconsistent scoring.
4. List 5-10 positive signals and 5-10 negative signals minimum.
5. Use the 20-row calibration pilot to find the gaps and refine the file.

The skill auto-edits the file when you give feedback during the pilot sign-off
loop ("X should be Qualified because ..." → it adds that pattern as a positive
signal). So you don't have to write a perfect ICP up front — start sensible,
let the calibration loop sharpen it.
