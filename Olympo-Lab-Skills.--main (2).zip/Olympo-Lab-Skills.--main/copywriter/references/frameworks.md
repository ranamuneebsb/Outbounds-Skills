# Best Cold Email Frameworks

These six frameworks are the canonical set for the Copywriter skill. They come from the user's mentor and have produced every one of the user's most successful cold email scripts. **Use these as the primary framework set when generating a batch.** Supplement with patterns from the live KB (Google Doc), but lead with these.

Each framework below is shown as a template. When generating a real email:

- Personalization tokens like `{{first_name}}`, `{{company_name}}`, `{{sender_signature}}` stay as PlusVibe merge tags in the final output (they get replaced at send time).
- Template placeholders like `{{Lead Magnet}}`, `{{Mechanism Strategy}}`, `{{Client Name}}`, `{{Result}}` are **slots to fill** with concrete content from the client brief - they do not appear in the final output.
- If the brief doesn't supply content for a placeholder a framework requires, either choose a different framework or restructure - do not invent the missing content.
- Always use plain ASCII hyphens `-`. Never use the typographic em dash (Unicode U+2014) or en dash (Unicode U+2013). Where you'd reach for an em dash, use space-hyphen-space instead.

---

## Framework #1 - Lead-magnet + industry-peer case-study

```
{{first_name}} - created a {{Lead Magnet}} for {{company_name}} covering the {{Mechanism Strategy}} we implemented to help {{Client Descriptor from same Industry}} generate {{Result}} within the last {{Timeframe}} - {{CTA}}?
```

One dense sentence. Requires: a lead magnet, an industry-peer client (described, not necessarily named), a specific result, a timeframe, and a CTA. Skip this framework if the brief doesn't supply an industry-peer reference and a concrete result.

**Client naming - apply the recognizability test (see SKILL.md "Naming clients").** The `{{Client Descriptor}}` slot should be an industry/role/segment descriptor by default ("a recruitment agency client of ours", "a Series C SaaS client", "a fitness coaching client we work with"). Drop the literal client name only when the brand passes the cold-prospect recognizability test - meaning a stranger in the target ICP would already know the name without context. "Mechanic Plug" or "SanterMedia" or "Joe's agency" do NOT pass; "Salesforce" or "HubSpot" do. When in doubt, descriptor wins.

---

## Framework #2 - Frontend free-work offer (one sentence + P.S.)

```
{{first_name}} - interested in {{Free Work/Frontend Offer}} for {{company_name}}?

{{sender_signature}}

P.S. {{Social proof}}
```

**This is literally the full email - one sentence plus a P.S. line.** Devastatingly short. Requires: a concrete frontend offer (audit, teardown, sample, etc.) and a piece of social proof. Use the P.S. block for the proof - never inline.

---

## Framework #3 - Mechanism + guarantee / risk reversal

```
{{first_name}} - interested in generating {{Dream Result}} with {{Mechanism}} for {{company_name}} in the next {{Timeframe}}?

Asking since our {{Mechanism}} guarantees {{Dream Result}} in {{Timeframe}} for your company or {{Risk Reversal}} - {{CTA}}?
```

Two short blocks. The risk reversal (e.g., "you don't pay", "money back", "we work for free until X") is the engine of this framework. Skip if the client's offer doesn't actually have a risk-reversal mechanism - don't fake one. The CTA at the end can be a lead magnet ("want the case study?") or a meeting ask.

Avoid the literal word "guarantees" if the client's tone notes ban it - rephrase to "delivers", "produces", "drives" while keeping the same structural commitment.

---

## Framework #4 - Pain-point question + solution + interest CTA + P.S. proof

```
{{first_name}} - {{Relevant question around pain point}}?

Our {{solution}} offers {{how to fix problem}} to {{achieve end result of solution}}

{{Interest-based CTA}}

{{sender_signature}}

P.S. {{Social proof}}
```

Four short blocks. The first line is a sharp question about the prospect's pain. The middle block is a single sentence describing the solution and outcome. CTA is interest-based ("interested in...?", "want to see...?"). Social proof in the P.S. - not inline.

---

## Framework #5 - Touchpoint + diagnosis + quick-solution CTA

```
{{first_name}} - {{Relevant Touchpoint}}

Noticed {{Relevant Pain Point}}

Interested in {{Quick Solution to Pain Point}}?
```

Three short lines. The touchpoint is something specific about the prospect or their company (a recent move, a public post, an observable detail). Diagnosis names the pain. CTA offers a small, fast solution. This framework is the shortest of the diagnosis style - if there's no real observable touchpoint, use Framework #4 instead.

---

## Framework #6 - Question + unique market insight + insight-implementation CTA

```
{{first_name}} - {{Question around relevant touchpoint}}

{{Unique Market Insight Relevant to Initial Touchpoint Questions}}

{{CTA around offering implementing Unique Market Insight}}
```

Three short blocks. The middle block is the workhorse - a piece of insight the prospect probably doesn't already know but would want to (a stat, a counterintuitive observation, a trend they're inside of but can't see). The CTA offers to help them act on that insight.

This framework requires the most upstream work - if there's no genuine insight to share, fall back to Framework #4 or #5.

---

## Framework selection guidance

When generating a batch of 10-20 first emails, distribute across these 6 frameworks. Some frameworks fit some clients better than others - pick honestly:

- **Framework #1** needs a named peer client with a concrete result. Skip if the brief doesn't supply one.
- **Framework #2** needs a real frontend offer (audit, teardown, sample). Skip if the client only sells the main offer.
- **Framework #3** needs a real risk-reversal mechanism. Skip if there isn't one in the offer.
- **Framework #4 and #5** are the most universally applicable - lean on these when others don't fit.
- **Framework #6** is the highest-quality but hardest - only use when you have a genuine market insight to deliver.

A typical balanced batch of 15 first emails might look like: #1 (×2), #2 (×2), #3 (×2), #4 (×4), #5 (×3), #6 (×2). Adjust based on what the brief actually supports.

The live KB (Google Doc) supplies additional variations and proof of what works. Read it AFTER you've planned the framework distribution - it shows how these frameworks get expressed in the agency's voice, not new framework shapes to use instead.
