#!/usr/bin/env python3
"""
Fetch the Copywriter knowledge base from Google Docs and print it as markdown
to stdout, with each winning script delimited by a heading.

Reads:
  COPYWRITER_DOC_ID  (required)     -- the Google Doc ID containing the winning scripts
  GOOGLE_APPLICATION_CREDENTIALS    -- optional; service account JSON path
  COPYWRITER_KB_FILE                -- optional; local markdown file (test mode)

Auth: prefers Application Default Credentials. Set up once with
  gcloud auth application-default login \\
    --scopes=openid,email,https://www.googleapis.com/auth/documents.readonly
The user just needs read access to the doc — since they own it, that's automatic.
Service account JSON is supported as a fallback for headless / CI use cases via
GOOGLE_APPLICATION_CREDENTIALS, but most local users won't need it.

Output format (markdown):
  ## <heading text>
  <body paragraphs>

  ## <next heading text>
  ...

Headings in the source doc (HEADING_1 or HEADING_2) delimit individual scripts.
Anything before the first heading is treated as preamble and skipped (likely a
title or table of contents).

Usage:
  python fetch_kb.py            # print KB to stdout
  python fetch_kb.py --json     # print parsed scripts as JSON (for tooling)

Exits non-zero on configuration or API errors with a clear stderr message.
"""

import argparse
import json
import os
import sys
import warnings
from typing import Any, Dict, List, Optional

# Silence the Python 3.9 EOL FutureWarnings emitted by google-auth / google-api-core
# on import. They're informational, not actionable here, and they pollute stderr
# for any caller (including the Copywriter skill) that reads from this script.
warnings.filterwarnings("ignore", category=FutureWarning, module=r"google\..*")

try:
    from google.oauth2 import service_account
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
except ImportError as exc:
    sys.stderr.write(
        "ERROR: missing Google API libraries. Install with:\n"
        "  pip install --user google-api-python-client google-auth\n"
        f"Original import error: {exc}\n"
    )
    sys.exit(2)


SCOPES = ["https://www.googleapis.com/auth/documents.readonly"]
HEADING_STYLES = {"HEADING_1", "HEADING_2"}


def env_or_die(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        sys.stderr.write(
            f"ERROR: environment variable {name} is not set.\n"
            "Set it before running the Copywriter skill. For example:\n"
            f"  export {name}=...\n"
        )
        sys.exit(2)
    return value


def get_docs_service():
    """Build a Docs API client, preferring ADC and falling back to service account.

    Many Google Cloud organizations block service-account JSON key creation under
    the `iam.disableServiceAccountKeyCreation` org policy (Secure by Default).
    For a local desktop tool that the user runs themselves, the recommended
    pattern is Application Default Credentials via `gcloud auth
    application-default login` — the user authenticates as themselves, no
    long-lived keys are produced, and the doc just needs to be accessible to
    that user (which it already is, since they own it).

    Resolution order:
      1. If GOOGLE_APPLICATION_CREDENTIALS is set, use that as a service
         account JSON path (useful for headless / server scenarios where the
         org policy allows keys).
      2. Otherwise, use `google.auth.default()` to pick up ADC.
    """
    creds_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if creds_path:
        if not os.path.exists(creds_path):
            sys.stderr.write(
                f"ERROR: service account JSON not found at {creds_path}\n"
                "Either unset GOOGLE_APPLICATION_CREDENTIALS to use ADC, or\n"
                "point it at the correct path.\n"
            )
            sys.exit(2)
        creds = service_account.Credentials.from_service_account_file(
            creds_path, scopes=SCOPES
        )
    else:
        try:
            from google.auth import default as default_creds
            creds, _project = default_creds(scopes=SCOPES)
        except Exception as exc:
            sys.stderr.write(
                "ERROR: no Google credentials found. Run one of:\n"
                "  gcloud auth application-default login \\\n"
                "    --scopes=openid,email,https://www.googleapis.com/auth/documents.readonly\n"
                "or set GOOGLE_APPLICATION_CREDENTIALS to a service account JSON path.\n"
                f"Underlying error: {exc}\n"
            )
            sys.exit(2)
    # cache_discovery=False keeps things quiet on Python 3.9
    return build("docs", "v1", credentials=creds, cache_discovery=False)


def extract_text(elements: List[Dict[str, Any]]) -> str:
    """Concatenate the text from a list of paragraph/text elements."""
    out: List[str] = []
    for el in elements:
        text_run = el.get("textRun")
        if text_run:
            out.append(text_run.get("content", ""))
    return "".join(out)


def parse_doc(doc: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    Walk the document body and split into scripts by heading.

    Returns a list of {"title": str, "body": str} dicts in document order.
    """
    body = doc.get("body", {}).get("content", [])

    scripts: List[Dict[str, str]] = []
    current_title: Optional[str] = None
    current_body: List[str] = []

    def flush() -> None:
        nonlocal current_title, current_body
        if current_title is None:
            return
        body_text = "".join(current_body).strip("\n")
        scripts.append({"title": current_title.strip(), "body": body_text})
        current_title = None
        current_body = []

    for el in body:
        paragraph = el.get("paragraph")
        if not paragraph:
            # tables, section breaks, etc. — skip for v1
            continue
        style = paragraph.get("paragraphStyle", {}).get("namedStyleType", "")
        text = extract_text(paragraph.get("elements", []))

        if style in HEADING_STYLES:
            # heading → start a new script
            flush()
            current_title = text.strip() or "(untitled)"
        else:
            if current_title is None:
                # preamble before the first heading — skip
                continue
            current_body.append(text)

    flush()
    return scripts


def _split_markdown_by_h2(content: str) -> List[Dict[str, str]]:
    """Lightweight reverse parser used by the --json flag in test mode.

    Splits a markdown KB file (the same shape render_markdown produces) back
    into per-script dicts by H2 headings. The H1 title at the top, if any,
    is dropped — only the per-script H2 sections become entries.
    """
    scripts: List[Dict[str, str]] = []
    current_title: Optional[str] = None
    current_body: List[str] = []

    def flush() -> None:
        nonlocal current_title, current_body
        if current_title is None:
            return
        scripts.append({"title": current_title.strip(), "body": "".join(current_body).strip("\n")})
        current_title = None
        current_body = []

    for line in content.splitlines(keepends=True):
        if line.startswith("## "):
            flush()
            current_title = line[3:].rstrip()
        elif line.startswith("# "):
            # top-level title — skip
            continue
        else:
            if current_title is not None:
                current_body.append(line)
    flush()
    return scripts


def render_markdown(scripts: List[Dict[str, str]]) -> str:
    lines: List[str] = []
    lines.append(f"# Copywriter knowledge base ({len(scripts)} winning scripts)")
    lines.append("")
    for s in scripts:
        lines.append(f"## {s['title']}")
        lines.append("")
        lines.append(s["body"].rstrip())
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch Copywriter KB from Google Docs.")
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit parsed scripts as JSON instead of markdown.",
    )
    args = parser.parse_args()

    # Testing override: if COPYWRITER_KB_FILE is set, read the KB from a local
    # markdown file instead of hitting Google. The file's content is passed
    # through unchanged in markdown mode, or parsed back into scripts via
    # heading splits for --json. This makes the skill testable without the
    # one-time Google Cloud setup, while production stays on the real fetch.
    kb_file = os.environ.get("COPYWRITER_KB_FILE")
    if kb_file:
        if not os.path.exists(kb_file):
            sys.stderr.write(
                f"ERROR: COPYWRITER_KB_FILE is set to {kb_file} but the file does not exist.\n"
            )
            return 2
        with open(kb_file, "r", encoding="utf-8") as fh:
            content = fh.read()
        if args.json:
            scripts = _split_markdown_by_h2(content)
            json.dump(
                {"source": kb_file, "scripts": scripts},
                sys.stdout,
                indent=2,
                ensure_ascii=False,
            )
            sys.stdout.write("\n")
        else:
            sys.stdout.write(content if content.endswith("\n") else content + "\n")
        return 0

    doc_id = env_or_die("COPYWRITER_DOC_ID")
    service = get_docs_service()
    try:
        doc = service.documents().get(documentId=doc_id).execute()
    except HttpError as exc:
        sys.stderr.write(
            f"ERROR: Google Docs API call failed ({exc.resp.status}): {exc}\n"
            "Common causes:\n"
            "  - The doc ID is wrong (check COPYWRITER_DOC_ID).\n"
            "  - The doc is not shared with the service account's email.\n"
            "    Open the doc, click Share, paste the service account email\n"
            "    (looks like xxx@yyy.iam.gserviceaccount.com), set to Viewer.\n"
        )
        return 3

    scripts = parse_doc(doc)
    if not scripts:
        sys.stderr.write(
            "ERROR: no scripts parsed. The doc must contain Heading 1 or\n"
            "Heading 2 styled lines to delimit each winning script.\n"
        )
        return 4

    if args.json:
        json.dump(
            {"doc_id": doc_id, "title": doc.get("title", ""), "scripts": scripts},
            sys.stdout,
            indent=2,
            ensure_ascii=False,
        )
        sys.stdout.write("\n")
    else:
        sys.stdout.write(render_markdown(scripts))

    return 0


if __name__ == "__main__":
    sys.exit(main())
