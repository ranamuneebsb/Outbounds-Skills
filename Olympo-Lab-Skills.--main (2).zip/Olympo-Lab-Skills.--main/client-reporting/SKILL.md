---
name: client-reporting
description: Run the bi-weekly (fortnightly) client report refresh. Pulls each active client's last completed 14-day window from PlusVibe, upserts it into the reporting database, and drafts a client-ready report email per client. Trigger when the user asks to "run biweekly reports", "run the fortnightly reports", "refresh client reporting", "draft the client reports", or "pull this period's client numbers". Drafts ONLY — nothing sends. DB writes are upserts (safe to re-run). Phase 1 — single owner dashboard, no client logins.
---

# Client Bi-Weekly Reporting

Collapses the manual reporting loop (log into PlusVibe → eyeball per-client stats →
hunt last period → hand-write the email) into one command, plus a live hosted
dashboard.

## When to run
The user asks to run bi-weekly / fortnightly client reports, refresh the
reporting data, or draft this period's client report emails.

## What it does (per run)
For **every client in `config.json` where `active: true`**, in a loop:
1. **pull_stats** — `fetch_campaign_stats()` pulls the last completed 14-day window
   (two full Mon–Sun weeks ending the most recent Sunday) from PlusVibe's
   `/campaign/get/stats`, aggregating all of the client's campaigns into the
   normalized dict.
2. **update_db** — upserts one record per `(client, period_start)`. Re-running a
   stored period UPDATES the API metrics and PRESERVES operator-owned fields
   (`meetings`, `decision`, `notes`). Never duplicates.
3. **draft_report** — reads this period + the prior 1–2 periods and drafts a
   client-ready email (subject + body) in house voice.

## How to run it
```bash
cd <repo>/client-reporting
./.venv/bin/python scripts/run_reports.py            # all active clients, today's window
./.venv/bin/python scripts/run_reports.py --client "EMC Financial"   # one client
./.venv/bin/python scripts/run_reports.py --run-date 2026-06-13      # pin the run date
```
Requires env: `PLUSVIBE_API_KEY` (or `~/.olympolabs/plusvibe.json`) and
`DATABASE_URL` (point it at the Railway Postgres so local runs write to the
hosted store; unset → local sqlite dev file).

Before the first run, lock the client→campaign mapping:
```bash
./.venv/bin/python scripts/discover_clients.py          # review the name-match groupings
./.venv/bin/python scripts/discover_clients.py --write  # write campaign_ids into config.json
```
Until campaign_ids are locked, the pull falls back to name-matching campaigns and
flags each such client in the output.

Rates match PlusVibe's own UI exactly: **bounce** = bounces/sent, **reply rate
(incl. OOO)** = (replies+ooo)/contacted, **positive reply rate** = positive/replies.
Stats are stored at two grains: the client rollup AND per-campaign, so the
dashboard can segment a client's individual campaigns.

## End-of-run summary (always print)
- Which clients refreshed + drafted successfully (`N/total`).
- Any **API failures** (client + error).
- Any client **breaching a threshold** (bounce > 3%, or positive yield < 0.5%
  where yield = positive/sent), flagged for attention.
- The **dashboard URL** (`DASHBOARD_URL` env, set after deploy).

## Hard rules
- **Drafts only.** Nothing sends. The owner copies drafts into their mail client
  (printed in the run output and viewable in the dashboard).
- **Upserts.** DB writes are idempotent — safe to re-run a period.
- **Phase 1 only.** Single owner login on the dashboard. Do NOT build client
  logins, access control, auto-send, or campaign-level drill-down — those are
  Phase 2 and explicitly out of scope.
- **Meetings are operator-owned.** PlusVibe has no meetings metric; the number
  comes from the operator (editable in the dashboard) and is preserved on re-run.
