# Deploy & day-to-day use

## How the system is wired

Two pieces share **one Postgres database**:

1. **Dashboard** (Streamlit) — lives on a public link. Reads the database, and makes
   a few *live* PlusVibe calls (call attribution, the Scheduling "Refresh live"
   button, the debug tool).
2. **Data refresh** (`scripts/run_reports.py`) — pulls from PlusVibe and writes the
   weekly / fortnight / runway numbers into the database. Run it on a cadence.

Locally you've been using a SQLite file. To live on a link, the database must be
**hosted Postgres** so both the link and your laptop reach the same data.

```
 PlusVibe API ──run_reports.py (your laptop or a cron)──► Postgres ◄──reads── Streamlit dashboard (the link)
```

---

## Deploy on Railway (all-in-one, ~$5/mo) — recommended

You'll do the browser login + secrets; everything else is copy-paste.

### 1. Install the CLI and log in
```bash
npm install -g @railway/cli        # or use `npx @railway/cli ...` below
railway login                      # opens your browser
```

### 2. Create the project + Postgres
```bash
cd ~/Desktop/OlympoLabs-Skills/client-reporting
railway init                       # name it e.g. "client-reporting"
railway add --database postgres    # provisions managed Postgres
```

### 3. Deploy the dashboard
```bash
railway up                         # builds from Procfile + requirements.txt
railway domain                     # generates the public https link
```

### 4. Set the dashboard's environment variables
In the Railway dashboard → your service → **Variables**:
- `PLUSVIBE_API_KEY` = your PlusVibe key (needed for live attribution/refresh)
- `DASH_USER` = a username  ← **set these two to lock the public link**
- `DASH_PASS` = a strong password
- `DATABASE_URL` — Railway injects this automatically from the Postgres plugin.
  (If not auto-linked, add a reference variable to the Postgres `DATABASE_URL`.)

Redeploy after setting vars (`railway up` again, or it redeploys on save).

### 5. Populate the hosted database (one time + each refresh)
The hosted Postgres starts empty. Fill it from your laptop:
```bash
cd ~/Desktop/OlympoLabs-Skills/client-reporting
# Use the Postgres PUBLIC url from Railway (Postgres service → Connect →
# "Public Network"), NOT the internal one:
export DATABASE_URL="postgresql://...public-url-from-railway..."
# backfill ~2 months for all clients (same script we used):
./.venv/bin/python scripts/run_reports.py --run-date $(date +%F) --no-drafts
./.venv/bin/python scripts/run_reports.py --run-date <today-14> --no-drafts --no-weekly --no-runway
./.venv/bin/python scripts/run_reports.py --run-date <today-28> --no-drafts --no-weekly --no-runway
./.venv/bin/python scripts/run_reports.py --run-date <today-42> --no-drafts --no-weekly --no-runway
```
Open your `railway domain` link — the data is there.

---

## Day-to-day

- **View:** bookmark the Railway link. Open it anytime — overview with the date-range
  picker, per-client tabs (Summary / Trends / Campaigns / Calls / Email report),
  Scheduling board. Log booked calls in the Calls tab; copy email reports from the
  Email tab.
- **Refresh the numbers:** run the pull so trends/fortnights/runway update. With
  `DATABASE_URL` pointed at the Railway Postgres:
  ```bash
  ./.venv/bin/python scripts/run_reports.py
  ```
  Run it weekly (captures the new completed week) — takes a few minutes.
- **Live bits need no refresh:** call attribution and the Scheduling "Refresh live"
  button hit PlusVibe directly when you use them.

### Optional: fully hands-off refresh (Railway cron)
Add a second Railway service from the same repo with:
- Start command: `python scripts/run_reports.py --no-drafts`
- A **cron schedule** (Railway service settings), e.g. `0 13 * * 1` (Mondays).
- Same `PLUSVIBE_API_KEY` + `DATABASE_URL` variables.
Then you never run the pull by hand.

---

## Free alternative: Streamlit Community Cloud + Neon Postgres
- Push this folder to a GitHub repo.
- Create a free Postgres at neon.tech → copy its connection string.
- streamlit.io/cloud → "New app" → point at `dashboard/app.py` → add
  `DATABASE_URL`, `PLUSVIBE_API_KEY`, `DASH_USER`, `DASH_PASS` in the app's Secrets.
- Run the local backfill against the Neon `DATABASE_URL` (as in step 5).
Free, but two platforms instead of one.

---

## Security note
On a public link, **set `DASH_USER` + `DASH_PASS`** — otherwise anyone with the URL
sees all client data. (Locally, login stays off automatically when they're unset.)
