"""Rate formulas, matching PlusVibe's own UI stats EXACTLY.

Derived by reconciling PlusVibe's header rates against its raw counts across
multiple live campaigns (June 2026). Reply rates use CONTACTED (unique leads
reached) as the denominator, NOT sent (total emails). Positive-reply rate is
positive / replies (i.e. "of replies, how many were labelled interested").

    bounce_rate          = bounces / sent
    reply_rate           = replies / contacted
    reply_rate_with_ooo  = (replies + ooo_replies) / contacted   <- the report's "reply rate"
    pos_reply_rate       = positive_replies / replies            <- the report's "positive rate"

Computing from summed raw counts (rather than averaging per-campaign
percentages) keeps a client's multi-campaign rate volume-weighted and identical
to what PlusVibe would show for the same set.
"""
from __future__ import annotations

from typing import Mapping

# The raw count keys every stats record carries.
COUNT_KEYS = ("sent", "replies", "ooo_replies", "positive_replies", "bounces",
              "contacted", "completed")


def _rate(num: int, denom: int) -> float:
    return round(num / denom, 4) if denom else 0.0


def compute_rates(counts: Mapping[str, int]) -> dict[str, float]:
    """Return PlusVibe-matching rates from a dict of raw counts (as fractions,
    e.g. 0.022 == 2.2%)."""
    sent = counts.get("sent", 0) or 0
    replies = counts.get("replies", 0) or 0
    ooo = counts.get("ooo_replies", 0) or 0
    positive = counts.get("positive_replies", 0) or 0
    bounces = counts.get("bounces", 0) or 0
    contacted = counts.get("contacted", 0) or 0
    return {
        "bounce_rate": _rate(bounces, sent),
        "reply_rate": _rate(replies, contacted),
        "reply_rate_with_ooo": _rate(replies + ooo, contacted),
        "pos_reply_rate": _rate(positive, replies),
    }


def sum_counts(records) -> dict[str, int]:
    """Sum the raw count keys across an iterable of records (campaigns)."""
    return {k: sum(int(r.get(k, 0) or 0) for r in records) for k in COUNT_KEYS}


def positive_yield(rec) -> float:
    """positive_replies / sent — the volume-health view of positives (distinct
    from the displayed pos_reply_rate = positive/replies). This is what the
    positive_floor threshold guards."""
    sent = rec.get("sent", 0) or 0
    return _rate(rec.get("positive_replies", 0) or 0, sent)


def flags(rec, thresholds) -> list[str]:
    """Threshold breaches for a record (campaign or client rollup).
      - bounce: PlusVibe bounce_rate (bounce/sent) over bounce_warn
      - positive: low positive YIELD (positive/sent) under positive_floor
    Skips records with no volume."""
    out = []
    if (rec.get("sent", 0) or 0) <= 0:
        return out
    bounce_warn = thresholds.get("bounce_warn", 0.03)
    pos_floor = thresholds.get("positive_floor", 0.005)
    if (rec.get("bounce_rate", 0) or 0) > bounce_warn:
        out.append(f"bounce {(rec['bounce_rate'] or 0)*100:.1f}% > {bounce_warn*100:.0f}%")
    py = positive_yield(rec)
    if py < pos_floor:
        out.append(f"positive yield {py*100:.2f}% < {pos_floor*100:.1f}% (pos/sent)")
    return out
