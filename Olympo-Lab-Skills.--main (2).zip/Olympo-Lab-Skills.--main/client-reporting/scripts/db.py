"""Database layer (SQLAlchemy Core). Works on managed Postgres in prod (Railway)
and a local sqlite file for offline dev — same code, dialect-aware upsert.

Two grains:
  - period_stats   : one row per (client, period)  — the client rollup
  - campaign_stats : one row per (client, campaign, period) — the segmentation

Rates are PlusVibe-matching (see rates.py): bounce/sent, reply/contacted,
(reply+ooo)/contacted, positive/replies.

The per-client structure is deliberate: it's what lets a future client-login
layer bolt on without a migration rewrite.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any, Optional

from sqlalchemy import (
    Boolean, Column, Date, DateTime, Float, ForeignKey, Integer, MetaData,
    String, Table, UniqueConstraint, create_engine, select, func, inspect, text,
)
from sqlalchemy.engine import Engine

try:
    from .config import database_url, load_config
    from .rates import compute_rates, COUNT_KEYS
except ImportError:
    from config import database_url, load_config
    from rates import compute_rates, COUNT_KEYS

metadata = MetaData()

# Count + rate columns shared by both grains.
_COUNT_COLS = ("sent", "replies", "ooo_replies", "positive_replies", "bounces",
               "contacted", "completed")
_RATE_COLS = ("bounce_rate", "reply_rate", "reply_rate_with_ooo", "pos_reply_rate")


def _count_columns():
    return [Column(c, Integer, nullable=False, default=0) for c in _COUNT_COLS]


def _rate_columns():
    return [Column(c, Float, nullable=False, default=0.0) for c in _RATE_COLS]


client = Table(
    "client", metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String, nullable=False, unique=True),
    Column("contact_name", String),
    Column("active", Boolean, nullable=False, default=True),
)

period_stats = Table(
    "period_stats", metadata,
    Column("id", Integer, primary_key=True),
    Column("client_id", Integer, ForeignKey("client.id", ondelete="CASCADE"), nullable=False),
    Column("period_start", Date, nullable=False),
    Column("period_end", Date, nullable=False),
    *_count_columns(),
    *_rate_columns(),
    # operator-owned (preserved across upserts)
    Column("meetings", Integer, nullable=False, default=0),
    Column("decision", String),
    Column("notes", String),
    Column("refreshed_at", DateTime(timezone=True), nullable=False,
           default=lambda: datetime.now(timezone.utc)),
    UniqueConstraint("client_id", "period_start", name="uq_client_period"),
)

campaign_stats = Table(
    "campaign_stats", metadata,
    Column("id", Integer, primary_key=True),
    Column("client_id", Integer, ForeignKey("client.id", ondelete="CASCADE"), nullable=False),
    Column("platform_campaign_id", String, nullable=False),
    Column("campaign_name", String),
    Column("period_start", Date, nullable=False),
    Column("period_end", Date, nullable=False),
    *_count_columns(),
    *_rate_columns(),
    Column("refreshed_at", DateTime(timezone=True), nullable=False,
           default=lambda: datetime.now(timezone.utc)),
    UniqueConstraint("client_id", "platform_campaign_id", "period_start",
                     name="uq_client_campaign_period"),
)

# Individual meetings booked, logged by the operator (date + email). The count
# "for a period" = meetings whose meeting_date falls inside the period window.
meeting = Table(
    "meeting", metadata,
    Column("id", Integer, primary_key=True),
    Column("client_id", Integer, ForeignKey("client.id", ondelete="CASCADE"), nullable=False),
    Column("meeting_date", Date, nullable=False),
    Column("email", String, nullable=False),
    Column("note", String),
    # Attribution: which campaign contacted this prospect (resolved via the API).
    Column("attributed_campaign_id", String),
    Column("attributed_campaign_name", String),
    Column("attribution_status", String),   # matched | unmatched | ambiguous | pending
    Column("created_at", DateTime(timezone=True), nullable=False,
           default=lambda: datetime.now(timezone.utc)),
)

# Weekly (7-day, Mon-Sun) per-campaign stats — the granular series that drives
# the trend charts. NON-cumulative: each row is that week's activity only.
# Built from PlusVibe's daily `chart` array. The rollup cards + report email
# stay on the fortnightly period_stats; these are for week-by-week visualization.
weekly_stats = Table(
    "weekly_stats", metadata,
    Column("id", Integer, primary_key=True),
    Column("client_id", Integer, ForeignKey("client.id", ondelete="CASCADE"), nullable=False),
    Column("platform_campaign_id", String, nullable=False),
    Column("campaign_name", String),
    Column("week_start", Date, nullable=False),   # Monday
    Column("week_end", Date, nullable=False),     # Sunday
    *_count_columns(),
    *_rate_columns(),
    Column("refreshed_at", DateTime(timezone=True), nullable=False,
           default=lambda: datetime.now(timezone.utc)),
    UniqueConstraint("client_id", "platform_campaign_id", "week_start",
                     name="uq_client_campaign_week"),
)

# Lead-runway snapshot per ACTIVE campaign — when it runs out of fresh leads.
# leads_remaining = NOT_CONTACTED (real, from lead-status). daily_rate = recent
# avg new leads contacted per sending day. run_out_date projected over the
# campaign's real sending weekdays. One current snapshot per campaign.
campaign_runway = Table(
    "campaign_runway", metadata,
    Column("id", Integer, primary_key=True),
    Column("client_id", Integer, ForeignKey("client.id", ondelete="CASCADE"), nullable=False),
    Column("platform_campaign_id", String, nullable=False),
    Column("campaign_name", String),
    Column("status", String),
    Column("leads_total", Integer, nullable=False, default=0),
    Column("leads_remaining", Integer, nullable=False, default=0),
    Column("daily_rate", Integer, nullable=False, default=0),
    Column("sending_days_left", Integer),          # nullable: unknown when stalled
    Column("run_out_date", Date),                  # nullable: out now / unknown
    Column("schedule_days", String),               # e.g. "Mon,Tue,Wed,Thu,Fri"
    Column("refreshed_at", DateTime(timezone=True), nullable=False,
           default=lambda: datetime.now(timezone.utc)),
    UniqueConstraint("client_id", "platform_campaign_id", name="uq_runway_campaign"),
)

# Campaigns the GTM engineer plans to launch (manual scheduling).
planned_campaign = Table(
    "planned_campaign", metadata,
    Column("id", Integer, primary_key=True),
    Column("client_id", Integer, ForeignKey("client.id", ondelete="CASCADE"), nullable=False),
    Column("name", String, nullable=False),
    Column("planned_start_date", Date, nullable=False),
    Column("est_sending_days", Integer),
    Column("note", String),
    Column("created_at", DateTime(timezone=True), nullable=False,
           default=lambda: datetime.now(timezone.utc)),
)


_engine: Optional[Engine] = None


def get_engine(cfg: Optional[dict] = None) -> Engine:
    global _engine
    if _engine is None:
        cfg = cfg or load_config()
        _engine = create_engine(database_url(cfg), future=True)
    return _engine


def init_db(engine: Optional[Engine] = None) -> None:
    engine = engine or get_engine()
    metadata.create_all(engine)
    _ensure_columns(engine)


def _ensure_columns(engine: Engine) -> None:
    """Lightweight additive migration: ALTER existing tables to add any columns
    present in the model but missing in the DB (e.g. meeting attribution cols
    added after rows already existed). Add-only — never drops or retypes."""
    insp = inspect(engine)
    existing_tables = set(insp.get_table_names())
    for table in metadata.tables.values():
        if table.name not in existing_tables:
            continue
        have = {c["name"] for c in insp.get_columns(table.name)}
        for col in table.columns:
            if col.name in have:
                continue
            ddl_type = col.type.compile(dialect=engine.dialect)
            with engine.begin() as conn:
                conn.execute(text(
                    f'ALTER TABLE {table.name} ADD COLUMN {col.name} {ddl_type}'))


def _as_date(d: Any) -> date:
    if isinstance(d, date):
        return d
    return datetime.strptime(str(d), "%Y-%m-%d").date()


def get_or_create_client(conn, name: str, contact_name: str = "", active: bool = True) -> int:
    row = conn.execute(select(client.c.id).where(client.c.name == name)).first()
    if row:
        conn.execute(client.update().where(client.c.id == row[0]).values(
            contact_name=contact_name or None, active=active))
        return row[0]
    res = conn.execute(client.insert().values(
        name=name, contact_name=contact_name or None, active=active))
    return int(res.inserted_primary_key[0])


def _metric_values(stats: dict) -> dict[str, Any]:
    vals = {c: stats.get(c, 0) or 0 for c in _COUNT_COLS}
    vals.update({c: stats.get(c, 0.0) or 0.0 for c in _RATE_COLS})
    vals["period_end"] = _as_date(stats["period_end"])
    vals["refreshed_at"] = datetime.now(timezone.utc)
    return vals


def _upsert(conn, table, insert_values: dict, update_values: dict, constraint: str,
            index_elements: list[str]) -> None:
    dialect = conn.engine.dialect.name
    if dialect == "postgresql":
        from sqlalchemy.dialects.postgresql import insert as pg_insert
        stmt = pg_insert(table).values(**insert_values).on_conflict_do_update(
            constraint=constraint, set_=update_values)
        conn.execute(stmt)
    elif dialect == "sqlite":
        from sqlalchemy.dialects.sqlite import insert as sqlite_insert
        stmt = sqlite_insert(table).values(**insert_values).on_conflict_do_update(
            index_elements=index_elements, set_=update_values)
        conn.execute(stmt)
    else:
        where = None
        for col in index_elements:
            cond = table.c[col] == insert_values[col]
            where = cond if where is None else (where & cond)
        existing = conn.execute(select(table.c.id).where(where)).first()
        if existing:
            conn.execute(table.update().where(table.c.id == existing[0]).values(**update_values))
        else:
            conn.execute(table.insert().values(**insert_values))


def upsert_period_stats(conn, client_id: int, stats: dict[str, Any]) -> None:
    """Upsert the client rollup. Only API metrics overwrite on conflict;
    meetings/decision/notes are operator-owned and never clobbered."""
    metrics = _metric_values(stats)
    insert_values = {"client_id": client_id, "period_start": _as_date(stats["period_start"]),
                     "meetings": stats.get("meetings", 0) or 0, **metrics}
    _upsert(conn, period_stats, insert_values, metrics,
            constraint="uq_client_period", index_elements=["client_id", "period_start"])


def upsert_campaign_stats(conn, client_id: int, camp: dict[str, Any],
                          period_start: Any, period_end: Any) -> None:
    """Upsert one campaign's row for a period. Pure API data — fully refreshed."""
    metrics = _metric_values({**camp, "period_end": period_end})
    insert_values = {
        "client_id": client_id,
        "platform_campaign_id": camp["campaign_id"],
        "campaign_name": camp.get("campaign_name"),
        "period_start": _as_date(period_start),
        **metrics,
    }
    update_values = {**metrics, "campaign_name": camp.get("campaign_name")}
    _upsert(conn, campaign_stats, insert_values, update_values,
            constraint="uq_client_campaign_period",
            index_elements=["client_id", "platform_campaign_id", "period_start"])


# ---- read helpers ------------------------------------------------------

def fetch_clients(conn, active_only: bool = False) -> list[dict]:
    q = select(client)
    if active_only:
        q = q.where(client.c.active.is_(True))
    return [dict(r._mapping) for r in conn.execute(q.order_by(client.c.name))]


def fetch_periods(conn, client_id: int) -> list[dict]:
    q = select(period_stats).where(period_stats.c.client_id == client_id).order_by(
        period_stats.c.period_start)
    return [dict(r._mapping) for r in conn.execute(q)]


def fetch_latest_period(conn, client_id: int) -> Optional[dict]:
    q = select(period_stats).where(period_stats.c.client_id == client_id).order_by(
        period_stats.c.period_start.desc()).limit(1)
    r = conn.execute(q).first()
    return dict(r._mapping) if r else None


def fetch_campaigns_for_period(conn, client_id: int, period_start: Any) -> list[dict]:
    q = select(campaign_stats).where(
        (campaign_stats.c.client_id == client_id)
        & (campaign_stats.c.period_start == _as_date(period_start))
    ).order_by(campaign_stats.c.sent.desc())
    return [dict(r._mapping) for r in conn.execute(q)]


def fetch_campaign_series(conn, client_id: int, platform_campaign_id: str) -> list[dict]:
    q = select(campaign_stats).where(
        (campaign_stats.c.client_id == client_id)
        & (campaign_stats.c.platform_campaign_id == platform_campaign_id)
    ).order_by(campaign_stats.c.period_start)
    return [dict(r._mapping) for r in conn.execute(q)]


def fetch_client_campaigns(conn, client_id: int) -> list[dict]:
    """Distinct campaigns seen for a client (latest name wins)."""
    q = select(campaign_stats.c.platform_campaign_id, campaign_stats.c.campaign_name,
               func.max(campaign_stats.c.period_start)).where(
        campaign_stats.c.client_id == client_id).group_by(
        campaign_stats.c.platform_campaign_id, campaign_stats.c.campaign_name)
    seen: dict[str, str] = {}
    for cid, name, _ in conn.execute(q):
        seen[cid] = name
    return [{"platform_campaign_id": k, "campaign_name": v} for k, v in seen.items()]


def update_operator_fields(conn, period_id: int, *, decision: Optional[str] = None,
                           notes: Optional[str] = None) -> None:
    """Save the per-period decision/notes. (Meetings now live in the `meeting`
    table, not here.)"""
    vals: dict[str, Any] = {}
    if decision is not None:
        vals["decision"] = decision
    if notes is not None:
        vals["notes"] = notes
    if vals:
        conn.execute(period_stats.update().where(period_stats.c.id == period_id).values(**vals))


# ---- meetings ----------------------------------------------------------

def add_meeting(conn, client_id: int, meeting_date: Any, email: str, note: str = "") -> int:
    res = conn.execute(meeting.insert().values(
        client_id=client_id, meeting_date=_as_date(meeting_date),
        email=email.strip(), note=(note or None), attribution_status="pending"))
    return int(res.inserted_primary_key[0])


def set_meeting_attribution(conn, meeting_id: int, campaign_id: Optional[str],
                            campaign_name: Optional[str], status: str) -> None:
    conn.execute(meeting.update().where(meeting.c.id == meeting_id).values(
        attributed_campaign_id=campaign_id, attributed_campaign_name=campaign_name,
        attribution_status=status))


def count_calls_by_campaign(conn, client_id: int) -> dict[str, int]:
    """{platform_campaign_id: booked-call count} — counts auto-matched AND
    manually-attributed meetings."""
    q = select(meeting.c.attributed_campaign_id, func.count()).where(
        (meeting.c.client_id == client_id)
        & (meeting.c.attribution_status.in_(("matched", "manual")))
        & (meeting.c.attributed_campaign_id.isnot(None))
    ).group_by(meeting.c.attributed_campaign_id)
    return {cid: int(n) for cid, n in conn.execute(q)}


def delete_meeting(conn, meeting_id: int) -> None:
    conn.execute(meeting.delete().where(meeting.c.id == meeting_id))


def fetch_meetings(conn, client_id: int, start: Any = None, end: Any = None) -> list[dict]:
    """Meetings for a client, optionally restricted to a [start, end] date window."""
    q = select(meeting).where(meeting.c.client_id == client_id)
    if start is not None and end is not None:
        q = q.where(meeting.c.meeting_date >= _as_date(start)).where(
            meeting.c.meeting_date <= _as_date(end))
    return [dict(r._mapping) for r in conn.execute(q.order_by(meeting.c.meeting_date.desc()))]


def count_meetings(conn, client_id: int, start: Any, end: Any) -> int:
    return int(conn.execute(
        select(func.count()).select_from(meeting).where(
            (meeting.c.client_id == client_id)
            & (meeting.c.meeting_date >= _as_date(start))
            & (meeting.c.meeting_date <= _as_date(end)))).scalar() or 0)


# ---- weekly stats ------------------------------------------------------

def upsert_weekly_stats(conn, client_id: int, rec: dict) -> None:
    """Upsert one campaign's weekly row. Pure derived data — fully refreshed."""
    metrics = {c: rec.get(c, 0) or 0 for c in _COUNT_COLS}
    metrics.update({c: rec.get(c, 0.0) or 0.0 for c in _RATE_COLS})
    metrics["week_end"] = _as_date(rec["week_end"])
    metrics["refreshed_at"] = datetime.now(timezone.utc)
    insert_values = {
        "client_id": client_id,
        "platform_campaign_id": rec["campaign_id"],
        "campaign_name": rec.get("campaign_name"),
        "week_start": _as_date(rec["week_start"]),
        **metrics,
    }
    update_values = {**metrics, "campaign_name": rec.get("campaign_name")}
    _upsert(conn, weekly_stats, insert_values, update_values,
            constraint="uq_client_campaign_week",
            index_elements=["client_id", "platform_campaign_id", "week_start"])


def fetch_weekly_campaigns_for_week(conn, client_id: int, week_start: Any) -> list[dict]:
    """Per-campaign weekly rows for one week (the weekly-grain campaign breakdown)."""
    q = select(weekly_stats).where(
        (weekly_stats.c.client_id == client_id)
        & (weekly_stats.c.week_start == _as_date(week_start))
    ).order_by(weekly_stats.c.sent.desc())
    return [dict(r._mapping) for r in conn.execute(q)]


def fetch_weekly_campaign_series(conn, client_id: int, platform_campaign_id: str) -> list[dict]:
    q = select(weekly_stats).where(
        (weekly_stats.c.client_id == client_id)
        & (weekly_stats.c.platform_campaign_id == platform_campaign_id)
    ).order_by(weekly_stats.c.week_start)
    return [dict(r._mapping) for r in conn.execute(q)]


def fetch_weekly_client_series(conn, client_id: int) -> list[dict]:
    """Weekly client totals: sum campaigns per week, recompute rates. Returned
    with a `period_start` key (= week_start) so the chart renderer can reuse it."""
    q = select(weekly_stats).where(weekly_stats.c.client_id == client_id).order_by(
        weekly_stats.c.week_start)
    by_week: dict[Any, dict] = {}
    for r in conn.execute(q):
        row = dict(r._mapping)
        wk = row["week_start"]
        agg = by_week.setdefault(wk, {"week_start": wk, "week_end": row["week_end"],
                                      **{k: 0 for k in COUNT_KEYS}})
        for k in COUNT_KEYS:
            agg[k] += int(row.get(k, 0) or 0)
    out = []
    for wk in sorted(by_week):
        agg = by_week[wk]
        agg.update(compute_rates(agg))
        agg["period_start"] = agg["week_start"]  # chart renderer expects this key
        out.append(agg)
    return out


def fetch_client_campaigns_weekly(conn, client_id: int) -> list[dict]:
    """Distinct campaigns that have any weekly rows (for the weekly drill-down)."""
    q = select(weekly_stats.c.platform_campaign_id, weekly_stats.c.campaign_name).where(
        weekly_stats.c.client_id == client_id).group_by(
        weekly_stats.c.platform_campaign_id, weekly_stats.c.campaign_name)
    seen: dict[str, str] = {}
    for cid, name in conn.execute(q):
        seen[cid] = name
    return [{"platform_campaign_id": k, "campaign_name": v} for k, v in seen.items()]


# ---- runway -----------------------------------------------------------

def upsert_runway(conn, client_id: int, rec: dict) -> None:
    vals = {
        "campaign_name": rec.get("campaign_name"),
        "status": rec.get("status"),
        "leads_total": rec.get("leads_total", 0) or 0,
        "leads_remaining": rec.get("leads_remaining", 0) or 0,
        "daily_rate": rec.get("daily_rate", 0) or 0,
        "sending_days_left": rec.get("sending_days_left"),
        "run_out_date": _as_date(rec["run_out_date"]) if rec.get("run_out_date") else None,
        "schedule_days": rec.get("schedule_days"),
        "refreshed_at": datetime.now(timezone.utc),
    }
    insert_values = {"client_id": client_id,
                     "platform_campaign_id": rec["campaign_id"], **vals}
    _upsert(conn, campaign_runway, insert_values, vals,
            constraint="uq_runway_campaign",
            index_elements=["client_id", "platform_campaign_id"])


def clear_runway(conn, client_id: int) -> None:
    """Drop a client's runway snapshot before re-writing (so closed campaigns
    don't linger)."""
    conn.execute(campaign_runway.delete().where(campaign_runway.c.client_id == client_id))


def fetch_runway(conn, client_id: int) -> list[dict]:
    q = select(campaign_runway).where(campaign_runway.c.client_id == client_id).order_by(
        campaign_runway.c.run_out_date.asc().nulls_first())
    return [dict(r._mapping) for r in conn.execute(q)]


def fetch_all_runway(conn) -> list[dict]:
    q = select(campaign_runway).order_by(campaign_runway.c.run_out_date.asc().nulls_first())
    return [dict(r._mapping) for r in conn.execute(q)]


# ---- planned campaigns -------------------------------------------------

def add_planned_campaign(conn, client_id: int, name: str, planned_start_date: Any,
                         est_sending_days: Optional[int] = None, note: str = "") -> None:
    conn.execute(planned_campaign.insert().values(
        client_id=client_id, name=name.strip(),
        planned_start_date=_as_date(planned_start_date),
        est_sending_days=est_sending_days, note=(note or None)))


def delete_planned_campaign(conn, planned_id: int) -> None:
    conn.execute(planned_campaign.delete().where(planned_campaign.c.id == planned_id))


def fetch_planned_campaigns(conn, client_id: Optional[int] = None) -> list[dict]:
    q = select(planned_campaign)
    if client_id is not None:
        q = q.where(planned_campaign.c.client_id == client_id)
    return [dict(r._mapping) for r in conn.execute(q.order_by(planned_campaign.c.planned_start_date))]
