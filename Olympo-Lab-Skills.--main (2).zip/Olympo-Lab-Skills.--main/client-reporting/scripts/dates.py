"""Reporting-window date math. Isolated and pure so it can be unit-tested
without touching the API or DB.

The reporting period is a 14-day window: two FULL completed Mon-Sun weeks ending
on the most recent Sunday strictly before the run date. A run on any day of week
yields the same window for that week.

Example: run on Sat 2026-06-13. Most recent completed Sunday is 2026-06-07.
The 14-day window is Mon 2026-05-25 .. Sun 2026-06-07.
"""
from __future__ import annotations

from datetime import date, timedelta


def last_completed_sunday(run_date: date) -> date:
    """The most recent Sunday that is strictly in the past relative to run_date.

    weekday(): Mon=0 .. Sun=6. If run_date is itself a Sunday, that week is not
    yet complete, so we take the PREVIOUS Sunday.
    """
    # Days since the most recent Sunday (0 if run_date is Sunday).
    days_since_sunday = (run_date.weekday() + 1) % 7
    this_or_last_sunday = run_date - timedelta(days=days_since_sunday)
    if this_or_last_sunday >= run_date:
        # run_date is a Sunday; that week isn't complete yet.
        return this_or_last_sunday - timedelta(days=7)
    return this_or_last_sunday


def biweekly_window(run_date: date) -> tuple[date, date]:
    """Return (period_start, period_end) for the last completed 14-day window.

    period_start is a Monday; period_end is the Sunday 13 days later.
    Both bounds are INCLUSIVE (PlusVibe's stats endpoint treats start/end as
    inclusive).
    """
    period_end = last_completed_sunday(run_date)      # a Sunday
    period_start = period_end - timedelta(days=13)    # the Monday two weeks back
    return period_start, period_end


def iso(d: date) -> str:
    return d.isoformat()


def week_start(d: date) -> date:
    """The Monday of d's week (Mon=0)."""
    return d - timedelta(days=d.weekday())


def weekly_pull_range(run_date: date, weeks_back: int = 12,
                      include_wtd: bool = True) -> tuple[date, date]:
    """Date range for weekly bucketing. Starts on the Monday `weeks_back` weeks
    back. Ends today (run_date) when include_wtd so the current partial week is
    captured (week-to-date); otherwise on the last completed Sunday."""
    end = run_date if include_wtd else last_completed_sunday(run_date)
    start = week_start(run_date) - timedelta(days=(weeks_back - 1) * 7)
    return start, end


def project_runout(remaining: int, daily_rate: float, sending_weekdays: set[int],
                   start_date: date, max_days: int = 120):
    """Project when a campaign runs out of fresh leads.

    Steps forward from the day after start_date, decrementing `remaining` by
    `daily_rate` on each scheduled sending weekday (Mon=0..Sun=6). Returns
    (run_out_date, sending_days_left). (start_date, 0) if already out;
    (None, None) if it can't be projected (no rate / no schedule / beyond
    horizon)."""
    if remaining <= 0:
        return start_date, 0
    if daily_rate <= 0 or not sending_weekdays:
        return None, None
    rem = remaining
    sdays = 0
    d = start_date
    for _ in range(max_days):
        d = d + timedelta(days=1)
        if d.weekday() in sending_weekdays:
            rem -= daily_rate
            sdays += 1
            if rem <= 0:
                return d, sdays
    return None, None
