"""Config + environment loading. No secrets live in config.json — only env var
names. This module resolves those names to actual values at runtime."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional

try:
    from dotenv import load_dotenv  # type: ignore
    load_dotenv()  # load .env if present (local dev); no-op in prod
except Exception:
    pass

REPO_ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = REPO_ROOT / "config.json"


def load_config(path: Optional[Path] = None) -> dict[str, Any]:
    return json.loads((path or CONFIG_PATH).read_text())


def active_clients(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    return [c for c in cfg.get("clients", []) if c.get("active")]


def env(name: str, default: Optional[str] = None, required: bool = False) -> Optional[str]:
    val = os.environ.get(name, default)
    if required and not val:
        raise RuntimeError(
            f"Required environment variable {name!r} is not set. "
            f"See .env.example for the full list."
        )
    return val


def database_url(cfg: dict[str, Any]) -> str:
    """Resolve DATABASE_URL. Falls back to a local sqlite dev file when unset so
    the pipeline is testable offline; production (Railway) always sets it to
    managed Postgres."""
    var = cfg["database"]["url_env_var"]
    url = os.environ.get(var)
    if not url:
        dev = REPO_ROOT / "local.db"
        return f"sqlite:///{dev}"
    # Railway/Heroku hand out "postgres://"; SQLAlchemy needs "postgresql://".
    if url.startswith("postgres://"):
        url = url.replace("postgres://", "postgresql://", 1)
    return url
