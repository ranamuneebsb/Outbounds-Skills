"""Auto-discover which PlusVibe campaigns belong to which client (by name-match),
so you can confirm the mapping once and lock campaign_ids into config.json.

Usage:
    python scripts/discover_clients.py            # human-readable report
    python scripts/discover_clients.py --json      # machine-readable
    python scripts/discover_clients.py --write      # patch config.json campaign_ids

Run this after adding/renaming clients in config.json. Locking campaign_ids makes
`run biweekly reports` deterministic (no fuzzy re-matching each run).
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import load_config, CONFIG_PATH            # noqa: E402
from pull_stats import discover_campaigns_for_clients   # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--write", action="store_true",
                    help="Write resolved campaign_ids back into config.json.")
    args = ap.parse_args()

    cfg = load_config()
    result = discover_campaigns_for_clients(cfg)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"\nShared workspace id: {result['shared_workspace_id']}\n")
        for c in result["clients"]:
            flag = "" if c["active"] else "  (inactive)"
            print(f"● {c['client']}  [match: {c['name_match']!r}]  "
                  f"{c['matched_count']} campaigns{flag}")
            for m in c["matches"]:
                print(f"    - {m['camp_name']}  ({m['status']})  id={m['campaign_id']}")
            print()

    if args.write:
        by_name = {c["client"]: c for c in result["clients"]}
        for client_obj in cfg["clients"]:
            match = by_name.get(client_obj["name"])
            if match:
                client_obj["campaign_ids"] = [m["campaign_id"] for m in match["matches"]]
        cfg.pop("_shared_ws_id", None)  # don't persist the runtime cache
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2) + "\n")
        print(f"Wrote resolved campaign_ids into {CONFIG_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
