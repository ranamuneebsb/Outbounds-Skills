"""Pull campaign stats from PlusVibe and normalize them.

ALL platform-specific logic lives in this file. Everything downstream (DB,
dashboard, drafts) consumes the normalized structure below, so swapping platforms
later touches only this file.

fetch_campaign_stats() returns a client ROLLUP plus a per-CAMPAIGN breakdown:

    {
      "client": str,
      "period_start": "YYYY-MM-DD", "period_end": "YYYY-MM-DD",
      # rollup raw counts (summed across the client's campaigns)
      "sent","replies","ooo_replies","positive_replies","bounces","contacted","completed": int,
      # rollup rates — PlusVibe-matching (see rates.py)
      "bounce_rate","reply_rate","reply_rate_with_ooo","pos_reply_rate": float,
      "meetings": 0,                 # operator-owned; PlusVibe has no meetings metric
      "campaigns": [                 # one entry per campaign
        {"campaign_id","campaign_name", <same counts>, <same rates>}, ...
      ],
      "_meta": {...},
    }
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any, Optional, Union

try:
    from .config import load_config
    from .plusvibe_client import PlusVibeClient
    from .rates import compute_rates, sum_counts, COUNT_KEYS
    from .dates import week_start, weekly_pull_range, project_runout
except ImportError:
    from config import load_config
    from plusvibe_client import PlusVibeClient
    from rates import compute_rates, sum_counts, COUNT_KEYS
    from dates import week_start, weekly_pull_range, project_runout

# Full weekday name -> Python weekday int (Mon=0). PlusVibe schedule.days uses
# full names ("Monday", ...).
_DOW = {"Monday": 0, "Tuesday": 1, "Wednesday": 2, "Thursday": 3,
        "Friday": 4, "Saturday": 5, "Sunday": 6}
_DOW_ABBR = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

DateLike = Union[str, date]


def _d(x: DateLike) -> str:
    return x.isoformat() if isinstance(x, date) else str(x)


def _shared_workspace_id(cfg: dict, pv: PlusVibeClient) -> Optional[str]:
    if "_shared_ws_id" in cfg:
        return cfg["_shared_ws_id"]
    target = (cfg.get("api", {}).get("shared_workspace_name") or "").strip().lower()
    ws_id = None
    for w in pv.list_workspaces():
        if (w.get("name") or "").strip().lower() == target:
            ws_id = w.get("id") or w.get("_id")
            break
    cfg["_shared_ws_id"] = ws_id
    return ws_id


def _campaign_id(c: dict) -> Optional[str]:
    return c.get("id") or c.get("_id")


def _workspace_campaigns(cfg: dict, pv: PlusVibeClient, workspace_id: str) -> list[dict]:
    """List (and cache on cfg) the campaigns in a workspace, for id->name lookup
    and name-match resolution."""
    cache = cfg.setdefault("_ws_campaigns", {})
    if workspace_id not in cache:
        cache[workspace_id] = pv.list_campaigns(workspace_id) if workspace_id else []
    return cache[workspace_id]


def _client_workspaces(client_obj: dict, cfg: dict, pv: PlusVibeClient) -> list[str]:
    """Workspace ids this client may have campaigns in: its own workspace and/or
    the match workspace (default shared)."""
    wss = []
    if client_obj.get("workspace_id"):
        wss.append(client_obj["workspace_id"])
    if client_obj.get("name_match"):
        mws = client_obj.get("match_workspace_id") or _shared_workspace_id(cfg, pv)
        if mws and mws not in wss:
            wss.append(mws)
    return wss


def resolve_campaigns(client_obj: dict, cfg: dict, pv: PlusVibeClient) -> list[dict]:
    """Return the client's campaigns as full campaign dicts, each augmented with
    `_ws` (its workspace id). A client can draw from two sources, deduped by id:
      - workspace_id  : ALL campaigns in that (own) workspace — covers campaigns
                        whose names don't contain the brand token.
      - name_match    : campaigns in match_workspace_id (default the shared
                        'Clients Workspace') whose name contains the token.
    This supports clients that span workspaces (e.g. Olympo Labs)."""
    out: dict[str, dict] = {}
    own = client_obj.get("workspace_id")
    if own:
        for c in _workspace_campaigns(cfg, pv, own):
            cid = _campaign_id(c)
            if cid:
                c = dict(c); c["_ws"] = own; out[cid] = c
    nm = (client_obj.get("name_match") or "").strip().lower()
    if nm:
        mws = client_obj.get("match_workspace_id") or _shared_workspace_id(cfg, pv)
        if mws:
            for c in _workspace_campaigns(cfg, pv, mws):
                if nm in (c.get("camp_name") or "").lower():
                    cid = _campaign_id(c)
                    if cid and cid not in out:
                        c = dict(c); c["_ws"] = mws; out[cid] = c
    return list(out.values())


def _counts_from_header(header: dict) -> dict[str, int]:
    return {
        "sent": int(header.get("total_sent_count") or 0),
        "replies": int(header.get("total_reply_count") or 0),
        "ooo_replies": int(header.get("total_ooo_reply_count") or 0),
        "positive_replies": int(header.get("total_pos_reply_count") or 0),
        "bounces": int(header.get("total_bounce_count") or 0),
        "contacted": int(header.get("total_contacted_count") or 0),
        "completed": int(header.get("total_completed_count") or 0),
    }


def fetch_campaign_stats(
    client_obj: dict,
    period_start: DateLike,
    period_end: DateLike,
    cfg: Optional[dict] = None,
    pv: Optional[PlusVibeClient] = None,
) -> dict[str, Any]:
    cfg = cfg or load_config()
    pv = pv or PlusVibeClient()
    start, end = _d(period_start), _d(period_end)

    campaigns = resolve_campaigns(client_obj, cfg, pv)

    per_campaign: list[dict] = []
    for c in campaigns:
        cid = _campaign_id(c)
        header = (pv.get_campaign_stats(c["_ws"], cid, start, end) or {}).get("header", {})
        counts = _counts_from_header(header)
        per_campaign.append({
            "campaign_id": cid,
            "campaign_name": c.get("camp_name") or cid,
            **counts,
            **compute_rates(counts),
        })

    rollup_counts = sum_counts(per_campaign)
    return {
        "client": client_obj["name"],
        "period_start": start,
        "period_end": end,
        **rollup_counts,
        **compute_rates(rollup_counts),
        "meetings": 0,  # operator-owned
        "campaigns": per_campaign,
        "_meta": {"campaign_count": len(per_campaign)},
    }


def _counts_from_chart_row(row: dict) -> dict[str, int]:
    return {
        "sent": int(row.get("total_sent_count") or 0),
        "replies": int(row.get("total_reply_count") or 0),
        "ooo_replies": int(row.get("total_ooo_reply_count") or 0),
        "positive_replies": int(row.get("total_pos_reply_count") or 0),
        "bounces": int(row.get("total_bounce_count") or 0),
        "contacted": int(row.get("total_contacted_count") or 0),
        "completed": int(row.get("total_completed_count") or 0),
    }


def fetch_weekly_buckets(client_obj: dict, run_date: date, weeks_back: int = 12,
                         cfg: Optional[dict] = None,
                         pv: Optional[PlusVibeClient] = None) -> list[dict]:
    """Per-campaign WEEKLY (Mon-Sun) records over the last `weeks_back` weeks,
    built from PlusVibe's daily `chart` array. Non-cumulative — each record is
    that week's activity only. One API call per campaign (wide range)."""
    cfg = cfg or load_config()
    pv = pv or PlusVibeClient()
    start, end = weekly_pull_range(run_date, weeks_back)
    campaigns = resolve_campaigns(client_obj, cfg, pv)

    out: list[dict] = []
    for c in campaigns:
        cid = _campaign_id(c)
        chart = (pv.get_campaign_stats(c["_ws"], cid,
                                       start.isoformat(), end.isoformat()) or {}).get("chart", [])
        weeks: dict[date, dict[str, int]] = {}
        for row in chart:
            d = row.get("date")
            if not d:
                continue
            day = datetime.strptime(d, "%Y-%m-%d").date()
            wk = week_start(day)
            acc = weeks.setdefault(wk, {k: 0 for k in COUNT_KEYS})
            for k, v in _counts_from_chart_row(row).items():
                acc[k] += v
        for wk in sorted(weeks):
            counts = weeks[wk]
            out.append({
                "campaign_id": cid,
                "campaign_name": c.get("camp_name") or cid,
                "week_start": wk.isoformat(),
                "week_end": (wk + timedelta(days=6)).isoformat(),
                **counts,
                **compute_rates(counts),
            })
    return out


def compute_runway(client_obj: dict, run_date: date, cfg: Optional[dict] = None,
                   pv: Optional[PlusVibeClient] = None) -> list[dict]:
    """Lead-runway for each ACTIVE campaign of a client, from real API data.

    leads_remaining = NOT_CONTACTED (lead-status). daily_rate = avg new leads
    contacted per active sending day over the last 28 days (daily chart).
    run_out_date projected over the campaign's real sending weekdays.
    """
    cfg = cfg or load_config()
    pv = pv or PlusVibeClient()
    campaigns = resolve_campaigns(client_obj, cfg, pv)
    recent_start = (run_date - timedelta(days=27)).isoformat()
    recent_end = run_date.isoformat()

    out: list[dict] = []
    for cm in campaigns:
        if cm.get("status") != "ACTIVE":
            continue
        ws = cm["_ws"]
        cid = _campaign_id(cm)
        ls = pv.lead_status_counts(ws, cid)
        remaining = int(ls.get("NOT_CONTACTED") or 0)

        chart = (pv.get_campaign_stats(ws, cid, recent_start, recent_end)
                 or {}).get("chart", [])
        active = [int(d.get("total_contacted_count") or 0) for d in chart
                  if (d.get("total_contacted_count") or 0) > 0]
        daily_rate = round(sum(active) / len(active)) if active else 0

        sch = cm.get("schedule") or {}
        day_names = sch.get("days") or []
        weekdays = {_DOW[n] for n in day_names if n in _DOW}
        run_out, sdays = project_runout(remaining, daily_rate, weekdays, run_date)

        out.append({
            "campaign_id": cid,
            "campaign_name": cm.get("camp_name"),
            "status": cm.get("status"),
            "leads_total": int(cm.get("lead_count") or 0),
            "leads_remaining": remaining,
            "daily_rate": daily_rate,
            "sending_days_left": sdays,
            "run_out_date": run_out.isoformat() if run_out else None,
            "schedule_days": ",".join(_DOW_ABBR[i] for i in sorted(weekdays)) or None,
        })
    return out


def _lookup_lead(pv: PlusVibeClient, workspace_id: str, email: str) -> list[dict]:
    """find_lead with a case-insensitive retry (PlusVibe stores contacts lower-cased)."""
    recs = pv.find_lead(workspace_id, email)
    if not recs and email != email.lower():
        recs = pv.find_lead(workspace_id, email.lower())
    return recs


def attribute_email(client_obj: dict, email: str, cfg: Optional[dict] = None,
                    pv: Optional[PlusVibeClient] = None) -> dict:
    """Resolve which campaign contacted a prospect email and credit the booked
    call to it. Attributes to the campaign the lead is ACTUALLY in (PlusVibe),
    not a name-matched guess.

    status: matched (one campaign, or the one that got the reply) |
            ambiguous (several campaigns) | unmatched (email never contacted).

    Searches the client's workspace first, then falls back to every workspace
    (handles clients whose campaigns live in their own workspace or are not yet
    mapped in config). The reply flag wins ties: the campaign the prospect
    replied to is the one that booked the call.
    """
    cfg = cfg or load_config()
    pv = pv or PlusVibeClient()
    email = (email or "").strip()
    # Search the client's own workspaces first, then fall back to all workspaces.
    primary = _client_workspaces(client_obj, cfg, pv)
    searched = set()
    recs = []
    for wid in primary:
        searched.add(wid)
        recs = _lookup_lead(pv, wid, email)
        if recs:
            break
    if not recs:
        for w in pv.list_workspaces():
            wid = w.get("id") or w.get("_id")
            if not wid or wid in searched:
                continue
            recs = _lookup_lead(pv, wid, email)
            if recs:
                break

    def res(r, status, candidates=None):
        return {"campaign_id": r.get("campaign") if r else None,
                "campaign_name": r.get("campaign_name") if r else None,
                "status": status, "candidates": candidates or []}

    if not recs:
        return res(None, "unmatched")
    if len(recs) == 1:
        return res(recs[0], "matched")
    replied = [r for r in recs if r.get("email_replied")]
    names = [r.get("campaign_name") for r in recs]
    if len(replied) == 1:
        return res(replied[0], "matched", names)        # the campaign that got the reply
    return res(replied[0] if replied else recs[0], "ambiguous", names)


# ---- discovery (unchanged behaviour) ----------------------------------------

def discover_campaigns_for_clients(cfg: Optional[dict] = None,
                                   pv: Optional[PlusVibeClient] = None) -> dict[str, Any]:
    cfg = cfg or load_config()
    pv = pv or PlusVibeClient()
    workspaces = pv.list_workspaces()
    shared_id = _shared_workspace_id(cfg, pv)
    ws_campaigns = {(_cid := (w.get("id") or w.get("_id"))): pv.list_campaigns(_cid)
                    for w in workspaces if (w.get("id") or w.get("_id"))}

    out = []
    for client_obj in cfg.get("clients", []):
        needle = (client_obj.get("name_match") or client_obj.get("name") or "").strip().lower()
        search_ws = [client_obj["workspace_id"]] if client_obj.get("workspace_id") else (
            [shared_id] if shared_id else list(ws_campaigns))
        matches = []
        for wid in search_ws:
            for c in ws_campaigns.get(wid, []):
                if needle and needle in (c.get("camp_name") or "").lower():
                    matches.append({"campaign_id": _campaign_id(c), "camp_name": c.get("camp_name"),
                                    "status": c.get("status"), "workspace_id": wid})
        out.append({"client": client_obj["name"], "name_match": client_obj.get("name_match"),
                    "active": client_obj.get("active"), "matched_count": len(matches),
                    "matches": matches})
    return {"shared_workspace_id": shared_id, "clients": out}
