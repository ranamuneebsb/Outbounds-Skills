"""Persist a normalized stats structure into the database (upsert, never
duplicate). Stores the client rollup AND each campaign's row.

Re-running a stored period UPDATES the API metrics; the client rollup's
operator-owned fields (meetings/decision/notes) are left intact. Safe to re-run.
"""
from __future__ import annotations

from typing import Any, Optional

from sqlalchemy.engine import Engine

try:
    from .db import (get_engine, init_db, get_or_create_client,
                     upsert_period_stats, upsert_campaign_stats, upsert_weekly_stats,
                     clear_runway, upsert_runway)
except ImportError:
    from db import (get_engine, init_db, get_or_create_client,
                    upsert_period_stats, upsert_campaign_stats, upsert_weekly_stats,
                    clear_runway, upsert_runway)


def store_stats(stats: dict[str, Any], contact_name: str = "", active: bool = True,
                engine: Optional[Engine] = None) -> None:
    engine = engine or get_engine()
    init_db(engine)
    with engine.begin() as conn:
        client_id = get_or_create_client(
            conn, name=stats["client"], contact_name=contact_name, active=active)
        upsert_period_stats(conn, client_id, stats)
        for camp in stats.get("campaigns", []):
            upsert_campaign_stats(conn, client_id, camp,
                                  stats["period_start"], stats["period_end"])


def store_weekly(client_name: str, weekly_records: list[dict], contact_name: str = "",
                 active: bool = True, engine: Optional[Engine] = None) -> None:
    """Upsert a client's per-campaign weekly rows (the trend-chart series)."""
    engine = engine or get_engine()
    init_db(engine)
    with engine.begin() as conn:
        client_id = get_or_create_client(conn, name=client_name,
                                         contact_name=contact_name, active=active)
        for rec in weekly_records:
            upsert_weekly_stats(conn, client_id, rec)


def store_runway(client_name: str, runway_records: list[dict], contact_name: str = "",
                 active: bool = True, engine: Optional[Engine] = None) -> None:
    """Replace a client's runway snapshot (clear + write, so deactivated
    campaigns drop off the board)."""
    engine = engine or get_engine()
    init_db(engine)
    with engine.begin() as conn:
        client_id = get_or_create_client(conn, name=client_name,
                                         contact_name=contact_name, active=active)
        clear_runway(conn, client_id)
        for rec in runway_records:
            upsert_runway(conn, client_id, rec)
