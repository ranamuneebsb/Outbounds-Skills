"""Minimal, self-contained PlusVibe API client for the reporting pull.

Vendored (not imported from the OlympoLabs-Skills/plusvibe-api skill) so this
repo deploys standalone. Only the three calls the reporting pull needs:
list_workspaces, list_campaigns, get_campaign_stats.

Auth: x-api-key header. Key from PLUSVIBE_API_KEY env var, falling back to
~/.olympolabs/plusvibe.json (local convenience). Base URL hard-coded.
Rate limit: PlusVibe caps 5 req/sec/key; we throttle to 4.
"""
from __future__ import annotations

import json
import os
import time
import warnings
from pathlib import Path
from typing import Any, Optional

warnings.filterwarnings("ignore", message=".*OpenSSL.*", module=r"urllib3.*")
import requests  # noqa: E402

BASE_URL = "https://api.plusvibe.ai/api/v1"
MIN_INTERVAL_SECONDS = 0.25
DEFAULT_TIMEOUT = 30.0
_CREDS_FILE = Path.home() / ".olympolabs" / "plusvibe.json"
_SETTINGS_URL = "https://app.plusvibe.ai/v2/settings/api-access/"


class PlusVibeError(RuntimeError):
    pass


def _load_api_key() -> str:
    key = os.environ.get("PLUSVIBE_API_KEY")
    if key:
        return key
    if _CREDS_FILE.exists():
        try:
            data = json.loads(_CREDS_FILE.read_text())
            if data.get("api_key"):
                return data["api_key"]
        except json.JSONDecodeError:
            pass
    raise PlusVibeError(
        "No PlusVibe API key. Set PLUSVIBE_API_KEY or create "
        f"{_CREDS_FILE} with {{\"api_key\": \"...\"}}. Get one at {_SETTINGS_URL}"
    )


class PlusVibeClient:
    def __init__(self, api_key: Optional[str] = None, base_url: str = BASE_URL,
                 timeout: float = DEFAULT_TIMEOUT):
        self._key = api_key or _load_api_key()
        self._base = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._last_call = 0.0

    def _throttle(self) -> None:
        elapsed = time.monotonic() - self._last_call
        if elapsed < MIN_INTERVAL_SECONDS:
            time.sleep(MIN_INTERVAL_SECONDS - elapsed)
        self._last_call = time.monotonic()

    def _get(self, path: str, params: dict[str, Any]) -> Any:
        self._throttle()
        url = f"{self._base}/{path.lstrip('/')}"
        resp = self._session.get(
            url, params=params,
            headers={"x-api-key": self._key, "Accept": "application/json"},
            timeout=self._timeout,
        )
        try:
            payload = resp.json() if resp.content else {}
        except ValueError:
            payload = {"raw": resp.text}
        if 200 <= resp.status_code < 300:
            # Unwrap {code,message,data} envelope when present.
            if (isinstance(payload, dict) and {"code", "message"} <= set(payload)
                    and "data" in payload):
                return payload["data"]
            return payload
        msg = ""
        if isinstance(payload, dict):
            msg = payload.get("message") or payload.get("error") or ""
        if resp.status_code == 401:
            raise PlusVibeError(
                f"API key rejected ({msg}). Regenerate at {_SETTINGS_URL} and "
                "update PLUSVIBE_API_KEY."
            )
        raise PlusVibeError(f"HTTP {resp.status_code} on {path}: {msg or resp.text[:200]}")

    # ---- the three calls the reporting pull needs ----------------------

    def list_workspaces(self) -> list[dict]:
        """GET /workspaces -> [{id, name}, ...]. Also the key health-check."""
        return self._get("/workspaces", {})

    def list_campaigns(self, workspace_id: str) -> list[dict]:
        """GET /campaign/list-all -> [{camp_name, id, status, ...}, ...]."""
        r = self._get("/campaign/list-all", {"workspace_id": workspace_id})
        if isinstance(r, dict):
            return r.get("data", []) or []
        return r or []

    def find_lead(self, workspace_id: str, email: str) -> list[dict]:
        """GET /lead/get?workspace_id&email — find a lead by email across the
        workspace. Returns a list of records (one per campaign the email is in),
        each with `campaign` (id), `campaign_name`, `status`, `email_replied`.
        Empty list if the email was never contacted."""
        r = self._get("/lead/get", {"workspace_id": workspace_id, "email": email.strip()})
        return r if isinstance(r, list) else (r.get("data", []) if isinstance(r, dict) else [])

    def lead_status_counts(self, workspace_id: str, campaign_id: str) -> dict[str, int]:
        """GET /lead/count/lead-status -> {STATUS: count}. NOT_CONTACTED is the
        authoritative count of fresh leads not yet emailed (= the runway pool)."""
        r = self._get("/lead/count/lead-status",
                      {"workspace_id": workspace_id, "campaign_id": campaign_id})
        if isinstance(r, list):
            return {d.get("status"): int(d.get("count") or 0) for d in r}
        return {}

    def get_campaign_stats(self, workspace_id: str, campaign_id: str,
                           start_date: str, end_date: str) -> dict:
        """GET /campaign/get/stats for ONE campaign over an inclusive date window.

        Returns {"header": {...windowed totals...}, "chart": [...daily...]}.
        Header carries total_sent_count, total_reply_count, total_pos_reply_count,
        total_bounce_count, etc. NOTE: PlusVibe's pre-computed *rates* in the
        header use non-/sent denominators — callers must recompute rates from the
        raw counts. (See memory: plusvibe-stats-endpoint.)
        """
        return self._get("/campaign/get/stats", {
            "workspace_id": workspace_id,
            "campaign_id": campaign_id,
            "start_date": start_date,
            "end_date": end_date,
        })
