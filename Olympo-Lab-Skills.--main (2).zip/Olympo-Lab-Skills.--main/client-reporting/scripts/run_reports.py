"""Orchestrator for `run biweekly reports`.

For every active client: pull the last completed 14-day window from PlusVibe ->
upsert into the DB -> draft the report email. Prints a summary: who refreshed +
drafted, any API failures, any threshold breaches, and the dashboard URL.

DRAFTS ONLY — nothing sends. DB writes are upserts — safe to re-run.
"""
from __future__ import annotations

import argparse
import os
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import load_config, active_clients          # noqa: E402
from dates import biweekly_window                        # noqa: E402
from plusvibe_client import PlusVibeClient, PlusVibeError  # noqa: E402
from pull_stats import (fetch_campaign_stats, fetch_weekly_buckets,  # noqa: E402
                        compute_runway)
from update_db import store_stats, store_weekly, store_runway  # noqa: E402
from db import get_engine, fetch_clients                 # noqa: E402
from draft_report import draft_for_client                # noqa: E402
from rates import flags as _breaches                     # noqa: E402


def run(run_date: date, only_client: str | None = None, show_drafts: bool = True,
        do_weekly: bool = True, do_runway: bool = True) -> int:
    cfg = load_config()
    thresholds = cfg.get("thresholds", {})
    start, end = biweekly_window(run_date)
    clients = active_clients(cfg)
    if only_client:
        clients = [c for c in clients if c["name"].lower() == only_client.lower()]

    print(f"\n{'='*72}")
    print(f"BI-WEEKLY REPORT RUN — window {start} .. {end}  (run date {run_date})")
    print(f"{'='*72}\n")

    pv = PlusVibeClient()
    engine = get_engine()

    refreshed: list[str] = []
    failures: list[tuple[str, str]] = []
    flagged: list[tuple[str, list[str]]] = []

    for c in clients:
        name = c["name"]
        try:
            stats = fetch_campaign_stats(c, start, end, cfg=cfg, pv=pv)
            store_stats(stats, contact_name=c.get("contact_name", ""),
                        active=c.get("active", True), engine=engine)
            if do_weekly:
                # Weekly trend series (non-cumulative, for the dashboard charts).
                weekly = fetch_weekly_buckets(c, run_date, weeks_back=12, cfg=cfg, pv=pv)
                store_weekly(name, weekly, contact_name=c.get("contact_name", ""),
                             active=c.get("active", True), engine=engine)
            if do_runway:
                # Lead-runway snapshot (when active campaigns run out of leads).
                runway = compute_runway(c, run_date, cfg=cfg, pv=pv)
                store_runway(name, runway, contact_name=c.get("contact_name", ""),
                             active=c.get("active", True), engine=engine)
            refreshed.append(name)
            meta = stats.get("_meta", {})
            print(f"  ✓ {name}: {stats['sent']:,} sent, {stats['replies']} replies, "
                  f"{stats['positive_replies']} positive, {stats['bounces']} bounces "
                  f"({meta.get('campaign_count', 0)} campaigns)")
            br = _breaches(stats, thresholds)
            if br:
                flagged.append((name, br))
        except PlusVibeError as e:
            failures.append((name, str(e)))
            print(f"  ✗ {name}: API ERROR — {e}")
        except Exception as e:  # noqa: BLE001
            failures.append((name, f"{type(e).__name__}: {e}"))
            print(f"  ✗ {name}: ERROR — {type(e).__name__}: {e}")

    # Drafts (read back from DB so they include any operator fields / meetings).
    drafts: list[tuple[str, dict]] = []
    with engine.begin() as conn:
        client_ids = {row["name"]: row["id"] for row in fetch_clients(conn)}
    for name in refreshed:
        cid = client_ids.get(name)
        if cid is None:
            continue
        drafts.append((name, draft_for_client(cid, engine=engine, cfg=cfg)))

    if show_drafts:
        for name, d in drafts:
            print(f"\n{'-'*72}\nDRAFT — {name}\n{'-'*72}")
            print(f"Subject: {d['subject']}\n")
            print(d["body"])

    # Summary
    dash_url = os.environ.get("DASHBOARD_URL", "(set DASHBOARD_URL after deploy)")
    print(f"\n{'='*72}\nSUMMARY\n{'='*72}")
    print(f"  Refreshed + drafted : {len(refreshed)}/{len(clients)}  "
          f"({', '.join(refreshed) if refreshed else 'none'})")
    if failures:
        print(f"  API failures        : {len(failures)}")
        for n, e in failures:
            print(f"      - {n}: {e[:120]}")
    else:
        print("  API failures        : none")
    if flagged:
        print(f"  ⚠ Threshold flags   : {len(flagged)}")
        for n, br in flagged:
            print(f"      - {n}: {', '.join(br)}")
    else:
        print("  Threshold flags     : none")
    print(f"  Dashboard           : {dash_url}")
    print(f"\n  Drafts only — nothing was sent. DB writes were upserts (safe to re-run).\n")
    return 0 if not failures else 1


def main() -> int:
    p = argparse.ArgumentParser(description="Run bi-weekly client reports.")
    p.add_argument("--run-date", help="YYYY-MM-DD; defaults to today.")
    p.add_argument("--client", help="Only this client (by display name).")
    p.add_argument("--no-drafts", action="store_true", help="Skip printing drafts.")
    p.add_argument("--no-weekly", action="store_true", help="Skip the weekly trend pull.")
    p.add_argument("--no-runway", action="store_true", help="Skip the lead-runway pull.")
    args = p.parse_args()
    rd = date.fromisoformat(args.run_date) if args.run_date else date.today()
    return run(rd, only_client=args.client, show_drafts=not args.no_drafts,
               do_weekly=not args.no_weekly, do_runway=not args.no_runway)


if __name__ == "__main__":
    raise SystemExit(main())
