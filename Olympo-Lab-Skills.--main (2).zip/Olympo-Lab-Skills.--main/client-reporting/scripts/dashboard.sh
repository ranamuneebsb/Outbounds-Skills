#!/bin/zsh
# Local launcher for the client-reporting dashboard.
#   dashboard.sh start     start it (if not already up) and open the browser
#   dashboard.sh stop      stop it
#   dashboard.sh status    is it running?
#   dashboard.sh restart   stop + start (reload code changes)
#   dashboard.sh refresh   pull fresh PlusVibe data, then ensure it's up
# URL: http://localhost:8501
set -u
REPO="$HOME/Desktop/OlympoLabs-Skills/client-reporting"
PORT=8501
URL="http://localhost:$PORT"
PY="$REPO/.venv/bin/python"
ST="$REPO/.venv/bin/streamlit"
LOG="/tmp/client-reporting-dashboard.log"
cd "$REPO" || { echo "repo not found: $REPO"; exit 1; }

is_up() { curl -s -o /dev/null --max-time 3 "$URL/" 2>/dev/null; }

start() {
  if is_up; then echo "Already running → $URL"; return 0; fi
  echo "Starting dashboard…"
  nohup "$ST" run dashboard/app.py --server.port "$PORT" --server.address 127.0.0.1 \
    --server.headless true > "$LOG" 2>&1 &
  disown
  for _ in $(seq 1 40); do is_up && break; sleep 0.5; done
  if is_up; then
    echo "Up → $URL"
    command -v open >/dev/null && open "$URL" 2>/dev/null || true
  else
    echo "Failed to start — last log lines:"; tail -8 "$LOG"
    return 1
  fi
}

stop() { pkill -f "streamlit run dashboard/app.py" 2>/dev/null && echo "Stopped." || echo "Was not running."; }

case "${1:-start}" in
  start)   start ;;
  stop)    stop ;;
  status)  if is_up; then echo "Running → $URL"; else echo "Not running."; fi ;;
  restart) stop; sleep 1; start ;;
  refresh)
    echo "Pulling fresh PlusVibe data (a few minutes for all clients)…"
    "$PY" scripts/run_reports.py --no-drafts
    start ;;
  *) echo "usage: dashboard.sh [start|stop|status|restart|refresh]"; exit 1 ;;
esac
