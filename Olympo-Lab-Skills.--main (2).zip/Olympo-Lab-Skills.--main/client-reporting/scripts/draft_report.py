"""Draft a client-ready report email — clean, copy-paste-ready plain text.

No markdown tables, pipes, or asterisks (they distort when pasted into Gmail /
Outlook). Just labelled lines and short paragraphs that paste unchanged.

Standardized four-part structure:
    The numbers  — this period vs the prior period
    What happened — the activity, in plain language
    What it means — deliverability / relevance / offer-fit read
    What we're doing from here — the decision / next move

Rates (PlusVibe definitions) and what each one tells us:
    reply rate incl. OOO  = (replies+ooo)/contacted  -> deliverability proxy
    reply rate            = replies/contacted         -> relevance proxy
    positive reply rate   = positive/replies          -> offer-fit proxy
    bounce rate           = bounces/sent
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

try:
    from .config import load_config
    from .db import (get_engine, fetch_periods, fetch_clients, count_meetings,
                     fetch_campaigns_for_period)
    from .rates import positive_yield
except ImportError:
    from config import load_config
    from db import (get_engine, fetch_periods, fetch_clients, count_meetings,
                    fetch_campaigns_for_period)
    from rates import positive_yield


def _pct(x: Optional[float], dp: int = 1) -> str:
    return f"{(x or 0) * 100:.{dp}f}%"


def _fmt_date(d: Any) -> str:
    if not isinstance(d, date):
        d = datetime.strptime(str(d), "%Y-%m-%d").date()
    return d.strftime("%b %-d")


def _delta(now: float, prior: Optional[float], dp: int = 1, as_pct: bool = False) -> str:
    if prior is None:
        return "no prior period"
    fmt = (lambda v: _pct(v, dp)) if as_pct else (lambda v: f"{v:,}")
    return f"prior: {fmt(prior)}"


def _headline(name: str, this: dict, meetings: int, thresholds: dict) -> str:
    bounce_warn = thresholds.get("bounce_warn", 0.03)
    if (this.get("bounce_rate") or 0) > bounce_warn:
        return f"deliverability flag, bounce {_pct(this['bounce_rate'])}"
    if meetings > 0:
        return f"{meetings} meeting{'s' if meetings != 1 else ''} booked"
    pos = this.get("positive_replies") or 0
    if pos > 0:
        return f"{pos} positive repl{'ies' if pos != 1 else 'y'}"
    return f"{this.get('sent', 0):,} sent, {this.get('replies', 0)} replies"


def _campaigns_running(campaigns: list[dict]) -> str:
    """Plain bulleted list of the campaigns that actually sent this period."""
    active = sorted([c for c in (campaigns or []) if (c.get("sent") or 0) > 0],
                    key=lambda c: c.get("sent", 0), reverse=True)
    if not active:
        return "No campaigns sent during this period."
    lines = []
    for c in active:
        pos = c.get("positive_replies", 0) or 0
        pos_txt = f", {pos} positive" if pos else ""
        lines.append(f"- {c.get('campaign_name','(unnamed)')}: "
                     f"{c.get('sent',0):,} sent, {c.get('replies',0)} replies{pos_txt}")
    return "\n".join(lines)


def _whats_working(this: dict, last: Optional[dict], meetings: int, thresholds: dict) -> str:
    bounce_warn = thresholds.get("bounce_warn", 0.03)
    bits = []
    if meetings > 0:
        bits.append(f"We booked {meetings} meeting{'s' if meetings != 1 else ''} — the pipeline "
                    f"is converting.")
    if (this.get("bounce_rate") or 0) <= bounce_warn:
        bits.append(f"Deliverability is solid (bounce {_pct(this['bounce_rate'])}, reply-incl-OOO "
                    f"{_pct(this.get('reply_rate_with_ooo'), 2)}), so the sends are landing.")
    rr, pr = this.get("reply_rate") or 0, (last or {}).get("reply_rate")
    if pr is not None and round(rr, 4) > round(pr, 4):
        bits.append(f"Relevance is climbing — reply rate up to {_pct(rr, 2)} from {_pct(pr, 2)}, "
                    f"so the targeting and messaging are connecting better.")
    pos, pos_prev = this.get("positive_replies", 0) or 0, (last or {}).get("positive_replies", 0) or 0
    if pos and last is not None and pos > pos_prev:
        bits.append(f"Positive replies rose to {pos} from {pos_prev} — the offer is resonating "
                    f"with more of the right people.")
    elif pos and (this.get("pos_reply_rate") or 0) >= 0.10:
        bits.append(f"Of everyone who replied, {_pct(this.get('pos_reply_rate'))} were positive — "
                    f"strong offer fit.")
    if not bits:
        bits.append("Volume held steady and deliverability stayed in range; no standout win to "
                    "call out yet.")
    return " ".join(bits[:3])


def _whats_not_working(this: dict, last: Optional[dict], thresholds: dict) -> str:
    bounce_warn = thresholds.get("bounce_warn", 0.03)
    pos_floor = thresholds.get("positive_floor", 0.005)
    bits = []
    if (this.get("bounce_rate") or 0) > bounce_warn:
        bits.append(f"Bounce is {_pct(this['bounce_rate'])}, above our {_pct(bounce_warn, 0)} "
                    f"line — list quality needs tightening before we scale.")
    rr, pr = this.get("reply_rate") or 0, (last or {}).get("reply_rate")
    if pr is not None and round(rr, 4) < round(pr, 4):
        bits.append(f"Relevance softened — reply rate fell to {_pct(rr, 2)} from {_pct(pr, 2)}, "
                    f"a sign the current angle is tiring.")
    if positive_yield(this) < pos_floor and (this.get("sent") or 0) > 0:
        bits.append(f"Positives are thin for the volume ({this.get('positive_replies',0)} on "
                    f"{this.get('sent',0):,} sent) — the offer isn't converting replies into "
                    f"interest yet.")
    if not bits:
        bits.append("Nothing is materially underperforming this period.")
    return " ".join(bits[:3])


def _what_now(this: dict, last: Optional[dict], decision: str, thresholds: dict) -> str:
    if decision.strip():
        return decision.strip()
    bounce_warn = thresholds.get("bounce_warn", 0.03)
    pos_floor = thresholds.get("positive_floor", 0.005)
    if (this.get("bounce_rate") or 0) > bounce_warn:
        return ("Tightening list verification and pausing the weakest inboxes to bring bounce "
                "back under control before we push more volume.")
    if positive_yield(this) < pos_floor:
        return ("Testing a fresh angle on the offer next period to lift positive replies, while "
                "holding volume steady.")
    pos = this.get("positive_replies", 0) or 0
    pos_prev = (last or {}).get("positive_replies", 0) or 0
    if last is not None and pos > pos_prev:
        return ("Doubling down on the current angle, which is producing more positives, and "
                "scaling volume where deliverability allows.")
    return ("Holding the current approach steady and watching next period's numbers before "
            "making a change.")


def build_draft(client_row: dict, this_period: Optional[dict], last_period: Optional[dict],
                meetings_this: int = 0, meetings_last: int = 0,
                campaigns: Optional[list[dict]] = None,
                cfg: Optional[dict] = None, period_phrase: Optional[str] = None,
                period_start: Any = None, period_end: Any = None) -> dict[str, str]:
    """Return {'subject','body'} for one client + period. Plain text, paste-ready.

    Auto-filled from data: numbers + campaigns running. The three analysis
    sections (what's working / not working / changing next week) are left BLANK
    for the operator to type directly in the editable draft."""
    cfg = cfg or load_config()
    thresholds = cfg.get("thresholds", {})
    name = client_row["name"]
    contact = (client_row.get("contact_name") or "").strip() or "team"

    if not this_period:
        return {"subject": f"{name} — no data yet",
                "body": f"Hi {contact},\n\nNo campaign data is recorded for this period yet.\n"}

    this, last = this_period, last_period
    ps = period_start if period_start is not None else this.get("period_start") or this.get("week_start")
    pe = period_end if period_end is not None else this.get("period_end") or this.get("week_end")
    rng = f"{_fmt_date(ps)}–{_fmt_date(pe)}"
    phrase = period_phrase or f"the last two weeks ({rng})"
    headline = _headline(name, this, meetings_this, thresholds)

    def line(label, now, prior, as_pct=False, dp=1):
        val = _pct(now, dp) if as_pct else f"{now:,}"
        if prior is None:
            return f"{label}: {val}"
        pv = _pct(prior, dp) if as_pct else f"{prior:,}"
        return f"{label}: {val}  (prior: {pv})"

    lp = last or {}
    numbers = "\n".join([
        line("Emails sent", this.get("sent", 0), lp.get("sent") if last else None),
        line("Contacts reached", this.get("contacted", 0), lp.get("contacted") if last else None),
        line("Replies", this.get("replies", 0), lp.get("replies") if last else None),
        line("Positive replies", this.get("positive_replies", 0),
             lp.get("positive_replies") if last else None),
        line("Meetings booked", meetings_this, meetings_last if last else None),
        "",
        line("Reply rate incl. out-of-office (deliverability)", this.get("reply_rate_with_ooo", 0),
             lp.get("reply_rate_with_ooo") if last else None, as_pct=True, dp=2),
        line("Reply rate (relevance)", this.get("reply_rate", 0),
             lp.get("reply_rate") if last else None, as_pct=True, dp=2),
        line("Positive reply rate (offer fit)", this.get("pos_reply_rate", 0),
             lp.get("pos_reply_rate") if last else None, as_pct=True, dp=1),
        line("Bounce rate", this.get("bounce_rate", 0),
             lp.get("bounce_rate") if last else None, as_pct=True, dp=1),
    ])

    prior_phrase = "against the prior period" if last else "(first recorded period)"
    body = (
        f"Hi {contact},\n\n"
        f"Here's where {name} landed over {phrase}, {prior_phrase}.\n\n"
        f"The numbers:\n{numbers}\n\n"
        f"Campaigns running this period:\n{_campaigns_running(campaigns)}\n\n"
        f"What's working:\n\n\n"
        f"What's not working:\n\n\n"
        f"What we're changing or adding next week:\n\n\n"
        f"Best,\nBryan\n"
    )
    subject = f"{name} — {rng}: {headline}"
    return {"subject": subject, "body": body}


def draft_for_client(client_id: int, period_start: Any = None, engine=None,
                     cfg: Optional[dict] = None) -> dict[str, str]:
    """Build the draft for a client's selected period (default: latest)."""
    engine = engine or get_engine()
    cfg = cfg or load_config()
    with engine.begin() as conn:
        rows = [c for c in fetch_clients(conn) if c["id"] == client_id]
        if not rows:
            raise ValueError(f"No client with id {client_id}")
        periods = fetch_periods(conn, client_id)
        if not periods:
            return build_draft(rows[0], None, None, cfg=cfg)
        idx = len(periods) - 1
        if period_start is not None:
            for i, p in enumerate(periods):
                if str(p["period_start"]) == str(period_start):
                    idx = i
                    break
        this = periods[idx]
        last = periods[idx - 1] if idx > 0 else None
        m_this = count_meetings(conn, client_id, this["period_start"], this["period_end"])
        m_last = count_meetings(conn, client_id, last["period_start"], last["period_end"]) if last else 0
        campaigns = fetch_campaigns_for_period(conn, client_id, this["period_start"])
    return build_draft(rows[0], this, last, m_this, m_last, campaigns, cfg)
