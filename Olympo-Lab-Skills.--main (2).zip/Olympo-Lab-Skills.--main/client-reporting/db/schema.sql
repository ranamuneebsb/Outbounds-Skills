-- Canonical Postgres schema for the client bi-weekly reporting store.
-- Source of truth for production (Railway) Postgres. scripts/db.py builds the
-- equivalent tables via SQLAlchemy so the same code runs on a local sqlite dev
-- file too, but THIS is what prod looks like.
--
-- Two grains:
--   client        : one row per client
--   period_stats  : one row per (client, period)            — the rollup
--   campaign_stats: one row per (client, campaign, period)  — the segmentation
--
-- Rates match PlusVibe's UI: bounce=bounces/sent, reply=replies/contacted,
-- reply_with_ooo=(replies+ooo)/contacted, pos_reply=positive/replies.

CREATE TABLE IF NOT EXISTS client (
    id            SERIAL PRIMARY KEY,
    name          TEXT NOT NULL UNIQUE,
    contact_name  TEXT,
    active        BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS period_stats (
    id                   SERIAL PRIMARY KEY,
    client_id            INTEGER NOT NULL REFERENCES client(id) ON DELETE CASCADE,
    period_start         DATE NOT NULL,           -- Monday starting the 14-day window
    period_end           DATE NOT NULL,           -- Sunday ending it

    -- API counts (refreshed every run)
    sent                 INTEGER NOT NULL DEFAULT 0,
    replies              INTEGER NOT NULL DEFAULT 0,
    ooo_replies          INTEGER NOT NULL DEFAULT 0,
    positive_replies     INTEGER NOT NULL DEFAULT 0,
    bounces              INTEGER NOT NULL DEFAULT 0,
    contacted            INTEGER NOT NULL DEFAULT 0,   -- unique leads reached (rate denom)
    completed            INTEGER NOT NULL DEFAULT 0,

    -- PlusVibe-matching rates
    bounce_rate          DOUBLE PRECISION NOT NULL DEFAULT 0,
    reply_rate           DOUBLE PRECISION NOT NULL DEFAULT 0,
    reply_rate_with_ooo  DOUBLE PRECISION NOT NULL DEFAULT 0,
    pos_reply_rate       DOUBLE PRECISION NOT NULL DEFAULT 0,

    -- operator-owned (preserved across re-run upserts)
    meetings             INTEGER NOT NULL DEFAULT 0,
    decision             TEXT,
    notes                TEXT,

    refreshed_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_client_period UNIQUE (client_id, period_start)
);

CREATE TABLE IF NOT EXISTS campaign_stats (
    id                   SERIAL PRIMARY KEY,
    client_id            INTEGER NOT NULL REFERENCES client(id) ON DELETE CASCADE,
    platform_campaign_id TEXT NOT NULL,           -- PlusVibe campaign id
    campaign_name        TEXT,
    period_start         DATE NOT NULL,
    period_end           DATE NOT NULL,

    sent                 INTEGER NOT NULL DEFAULT 0,
    replies              INTEGER NOT NULL DEFAULT 0,
    ooo_replies          INTEGER NOT NULL DEFAULT 0,
    positive_replies     INTEGER NOT NULL DEFAULT 0,
    bounces              INTEGER NOT NULL DEFAULT 0,
    contacted            INTEGER NOT NULL DEFAULT 0,
    completed            INTEGER NOT NULL DEFAULT 0,

    bounce_rate          DOUBLE PRECISION NOT NULL DEFAULT 0,
    reply_rate           DOUBLE PRECISION NOT NULL DEFAULT 0,
    reply_rate_with_ooo  DOUBLE PRECISION NOT NULL DEFAULT 0,
    pos_reply_rate       DOUBLE PRECISION NOT NULL DEFAULT 0,

    refreshed_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_client_campaign_period UNIQUE (client_id, platform_campaign_id, period_start)
);

-- Meetings booked, logged individually by the operator (date + email).
-- A period's meeting count = meetings whose meeting_date falls in the window.
CREATE TABLE IF NOT EXISTS meeting (
    id            SERIAL PRIMARY KEY,
    client_id     INTEGER NOT NULL REFERENCES client(id) ON DELETE CASCADE,
    meeting_date  DATE NOT NULL,
    email         TEXT NOT NULL,
    note          TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_meeting_client        ON meeting (client_id);
CREATE INDEX IF NOT EXISTS ix_period_stats_client   ON period_stats (client_id);
CREATE INDEX IF NOT EXISTS ix_period_stats_period   ON period_stats (period_start);
CREATE INDEX IF NOT EXISTS ix_campaign_stats_client ON campaign_stats (client_id);
CREATE INDEX IF NOT EXISTS ix_campaign_stats_period ON campaign_stats (period_start);
