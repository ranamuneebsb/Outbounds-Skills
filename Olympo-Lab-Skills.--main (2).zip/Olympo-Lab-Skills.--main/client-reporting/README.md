# Client Bi-Weekly Reporting

One command refreshes every active client's last-completed 14-day window from
PlusVibe into a database and drafts their report email; a hosted dashboard shows
each client's numbers and trend lines over time.

**Phase 1 only:** single owner login, no client-facing surface. The data model is
per-client from day one so Phase 2 can bolt logins on without a rewrite — but auth,
multi-tenant access, client invites, auto-send, and campaign drill-down are NOT
built and are out of scope.

## Stack
- **Pull + drafts:** Python (`scripts/`), reusing a vendored minimal PlusVibe client.
- **Database:** Postgres in production (managed on Railway), keyed per client/period.
  Local dev falls back to a sqlite file when `DATABASE_URL` is unset.
- **Dashboard:** Streamlit (`dashboard/app.py`) — single env-var login, trend lines,
  all-clients overview, threshold flags.
- **Host:** Railway (Postgres + web service in one project).

## Layout
```
client-reporting/
├── SKILL.md                 # how Claude Code runs the bi-weekly loop
├── config.json              # clients, thresholds, env-var names (NO secrets)
├── scripts/
│   ├── pull_stats.py        # fetch_campaign_stats -> normalized dict (all PlusVibe logic)
│   ├── update_db.py         # upsert one client-period record
│   ├── draft_report.py      # build the email from current + prior periods
│   ├── run_reports.py       # `run biweekly reports` orchestrator
│   ├── discover_clients.py  # auto-map campaigns -> clients by name
│   ├── db.py / config.py / dates.py / plusvibe_client.py
├── dashboard/app.py         # the hosted dashboard
├── db/schema.sql            # canonical Postgres schema
└── tests/test_dates.py      # 14-day window logic
```

## Local setup
```bash
cd client-reporting
python3.13 -m venv .venv
./.venv/bin/pip install -r requirements.txt
cp .env.example .env          # fill in the values (this file is gitignored)
./.venv/bin/python tests/test_dates.py        # sanity-check the window math
```

### Environment variables (never commit these)
Set them in `.env` for local use, and in Railway's **Variables** tab for prod:

```bash
# PlusVibe API key — get/regenerate at https://app.plusvibe.ai/v2/settings/api-access/
export PLUSVIBE_API_KEY="pv_live_..."
# (Locally you can instead rely on ~/.olympolabs/plusvibe.json — env var wins.)

# Postgres connection string (Railway gives you this for its managed Postgres).
# Set it locally too, so `run biweekly reports` writes to the SAME hosted DB the
# dashboard reads. Unset locally -> a throwaway sqlite dev file.
export DATABASE_URL="postgresql://user:pass@host:5432/railway"

# Dashboard single login (Phase 1 — one set of creds, no user system).
export DASH_USER="owner"
export DASH_PASS="<something strong>"
```
To persist locally, add those `export` lines to `~/.zshrc` and `source ~/.zshrc`.

## First-run: lock the client → campaign mapping
Clients map to PlusVibe campaigns by name-match (the client name appears in the
campaign name). Confirm and lock the mapping so runs are deterministic:
```bash
./.venv/bin/python scripts/discover_clients.py          # review groupings
./.venv/bin/python scripts/discover_clients.py --write  # write campaign_ids into config.json
```
Edit `config.json` to add/remove clients, set `contact_name`, flip `active`, or set
an explicit `workspace_id` for clients that have their own PlusVibe workspace.

## Run the bi-weekly reports
```bash
./.venv/bin/python scripts/run_reports.py               # all active clients
./.venv/bin/python scripts/run_reports.py --client "EMC Financial"
```
Prints per-client pull results, the email drafts, and a summary (refreshed,
failures, threshold flags, dashboard URL). **Drafts only — nothing sends.**

## Run the dashboard locally
```bash
./.venv/bin/streamlit run dashboard/app.py
```
Open http://localhost:8501, sign in with `DASH_USER`/`DASH_PASS`.

## Deploy to Railway
1. `railway login` and `railway init` (or create the project in the Railway UI).
2. Add a **Postgres** plugin to the project — Railway injects `DATABASE_URL`.
3. Add the other variables in **Variables**: `PLUSVIBE_API_KEY`, `DASH_USER`,
   `DASH_PASS`. (Postgres is auto-injected.)
4. Deploy the repo. The `Procfile` starts Streamlit bound to `$PORT`. Railway
   builds from `requirements.txt` / `.python-version` via Nixpacks.
5. Open the generated URL, confirm the login gate, sign in.
6. Locally, set `DATABASE_URL` to the Railway Postgres string and run
   `run biweekly reports` — it populates the hosted DB the dashboard reads.
   Set `DASHBOARD_URL` locally so the run summary prints the live link.

The data pull stays a manual/local command in Phase 1 (the dashboard is the only
hosted piece). Scheduling the pull is Phase 2.
