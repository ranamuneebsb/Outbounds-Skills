"""Unit tests for the 14-day reporting-window logic. The spec flags this as the
single easiest thing to get subtly wrong, so we test every weekday + edges."""
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from dates import biweekly_window, last_completed_sunday  # noqa: E402


def test_window_is_always_14_days_monday_to_sunday():
    # Run on every day across a couple weeks; window must always be a
    # Mon..Sun span of exactly 14 days (13-day delta, inclusive).
    for offset in range(0, 21):
        run = date(2026, 6, 1) + __import__("datetime").timedelta(days=offset)
        start, end = biweekly_window(run)
        assert start.weekday() == 0, f"start not Monday for run {run}: {start}"
        assert end.weekday() == 6, f"end not Sunday for run {run}: {end}"
        assert (end - start).days == 13, f"window not 14 days for run {run}"
        assert end < run, f"window end {end} not before run {run}"


def test_saturday_run():
    # Sat 2026-06-13 -> last completed Sunday 2026-06-07 -> window 05-25..06-07
    start, end = biweekly_window(date(2026, 6, 13))
    assert end == date(2026, 6, 7)
    assert start == date(2026, 5, 25)


def test_sunday_run_uses_previous_completed_week():
    # On a Sunday, the current week is NOT complete -> go back to prior Sunday.
    run = date(2026, 6, 14)  # a Sunday
    assert run.weekday() == 6
    start, end = biweekly_window(run)
    assert end == date(2026, 6, 7)         # not 06-14
    assert start == date(2026, 5, 25)


def test_monday_run():
    # Mon 2026-06-08 -> last completed Sunday is the day before, 06-07.
    run = date(2026, 6, 8)
    assert run.weekday() == 0
    start, end = biweekly_window(run)
    assert end == date(2026, 6, 7)
    assert start == date(2026, 5, 25)


def test_last_completed_sunday_edges():
    assert last_completed_sunday(date(2026, 6, 7)) == date(2026, 5, 31)   # Sunday->prev Sunday
    assert last_completed_sunday(date(2026, 6, 8)) == date(2026, 6, 7)    # Monday
    assert last_completed_sunday(date(2026, 6, 13)) == date(2026, 6, 7)   # Saturday


if __name__ == "__main__":
    import traceback
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in fns:
        try:
            fn()
            print(f"PASS {fn.__name__}")
        except Exception:
            failed += 1
            print(f"FAIL {fn.__name__}")
            traceback.print_exc()
    print(f"\n{len(fns) - failed}/{len(fns)} passed")
    sys.exit(1 if failed else 0)
