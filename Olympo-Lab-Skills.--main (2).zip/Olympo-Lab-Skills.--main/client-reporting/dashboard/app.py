"""Bi-weekly client reporting dashboard.

Single owner login (env DASH_USER / DASH_PASS). Reads the database and shows,
per client: a PERIOD TOGGLE, the rollup numbers + three labelled rates,
redesigned per-metric trend charts, campaign-by-campaign segmentation, a
meetings log (date + email), persistent notes, and a copy-paste-ready draft.

The three rates and what each tells us (PlusVibe definitions):
  reply rate incl. OOO = (replies+ooo)/contacted -> DELIVERABILITY
  reply rate           = replies/contacted        -> RELEVANCE
  positive reply rate  = positive/replies          -> OFFER FIT
"""
from __future__ import annotations

import os
import sys
from datetime import date, timedelta
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from config import load_config                                  # noqa: E402
from db import (get_engine, fetch_clients, fetch_periods,        # noqa: E402
                fetch_campaigns_for_period, init_db,
                add_meeting, delete_meeting, fetch_meetings, count_meetings,
                fetch_weekly_client_series, fetch_weekly_campaign_series,
                fetch_weekly_campaigns_for_week, fetch_client_campaigns_weekly,
                set_meeting_attribution, count_calls_by_campaign,
                fetch_runway)
from draft_report import build_draft                            # noqa: E402
from rates import flags as breach_flags, compute_rates, sum_counts  # noqa: E402
from pull_stats import compute_runway, attribute_email          # noqa: E402
from update_db import store_runway                              # noqa: E402
from plusvibe_client import PlusVibeClient                      # noqa: E402


def _cfg_client(name: str):
    """The config.json client object (has name_match / workspace_id) for a
    client name — needed for API attribution."""
    return next((x for x in CFG.get("clients", []) if x["name"] == name), None)


def _attribute_and_store(client_name: str, meeting_id: int, email: str):
    """Resolve a meeting's email to a campaign via the API and persist it."""
    cobj = _cfg_client(client_name)
    if not cobj:
        with engine.begin() as conn:
            set_meeting_attribution(conn, meeting_id, None, None, "unmatched")
        return
    try:
        attr = attribute_email(cobj, email, CFG)
        with engine.begin() as conn:
            set_meeting_attribution(conn, meeting_id, attr["campaign_id"],
                                    attr["campaign_name"], attr["status"])
    except Exception:  # noqa: BLE001 — API hiccup shouldn't lose the meeting
        with engine.begin() as conn:
            set_meeting_attribution(conn, meeting_id, None, None, "error")


def _debug_attribution(client_name: str, email: str) -> dict:
    """Trace an email across every PlusVibe workspace — shows exactly where (if
    anywhere) the lead exists, to diagnose unmatched attributions."""
    cobj = _cfg_client(client_name)
    pv = PlusVibeClient()
    out = {"email": email, "verdict": attribute_email(cobj, email, CFG) if cobj else "no config client",
           "per_workspace": []}
    for w in pv.list_workspaces():
        wid = w.get("id") or w.get("_id")
        try:
            recs = pv.find_lead(wid, email) or pv.find_lead(wid, email.lower())
            matches = [{"campaign_name": r.get("campaign_name"), "status": r.get("status"),
                        "email_replied": r.get("email_replied"), "contact": r.get("contact")}
                       for r in recs]
        except Exception as e:  # noqa: BLE001
            matches = [{"error": str(e)[:100]}]
        out["per_workspace"].append({"workspace": w.get("name"), "found": len(matches), "matches": matches})
    return out

st.set_page_config(page_title="Client Reports", page_icon="📈", layout="wide")

# ---- Apple-inspired polish: system font, soft cards, generous whitespace ----
_APPLE_CSS = """
<style>
:root { --ink:#1d1d1f; --muted:#6e6e73; --line:#e8e8ed; --panel:#f5f5f7; --blue:#0071e3; }
html, body, [class*="css"], .stApp, button, input, textarea, select {
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text",
    "Helvetica Neue", Helvetica, Arial, sans-serif !important;
  -webkit-font-smoothing: antialiased;
}
.stApp { background: #ffffff; }
section.main > div.block-container { padding-top: 2.2rem; padding-bottom: 3rem; max-width: 1180px; }
h1, h2, h3, h4 { color: var(--ink) !important; font-weight: 600 !important; letter-spacing: -0.021em; }
h1 { font-size: 2.1rem !important; }
h2 { font-size: 1.5rem !important; }
h3 { font-size: 1.18rem !important; }
p, span, label, .stMarkdown { color: var(--ink); }
.stCaption, [data-testid="stCaptionContainer"] { color: var(--muted) !important; }

/* Metric cards */
div[data-testid="stMetric"] {
  background: #ffffff; border: 1px solid var(--line); border-radius: 16px;
  padding: 14px 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}
div[data-testid="stMetricLabel"] p { color: var(--muted) !important; font-weight: 500; font-size: 0.8rem; }
div[data-testid="stMetricValue"] { font-weight: 600 !important; color: var(--ink) !important; }

/* Sidebar */
section[data-testid="stSidebar"] { background: var(--panel); border-right: 1px solid var(--line); }
section[data-testid="stSidebar"] .block-container { padding-top: 1.5rem; }

/* Tabs — clean, pill-underline */
div[data-baseweb="tab-list"] { gap: 6px; border-bottom: 1px solid var(--line); }
button[data-baseweb="tab"] { font-weight: 500; color: var(--muted); padding: 8px 6px; }
button[data-baseweb="tab"][aria-selected="true"] { color: var(--ink); }
div[data-baseweb="tab-highlight"] { background: var(--blue); height: 2px; }

/* Buttons */
.stButton > button {
  border-radius: 980px; border: 1px solid var(--line); font-weight: 500;
  padding: 0.35rem 1.1rem; transition: all .15s ease;
}
.stButton > button:hover { border-color: var(--blue); color: var(--blue); }

/* Inputs / selects */
div[data-baseweb="select"] > div, .stTextInput input, .stTextArea textarea, .stDateInput input {
  border-radius: 10px !important; border-color: var(--line) !important;
}
.stTextArea textarea { font-family: ui-monospace, "SF Mono", Menlo, monospace !important; font-size: 0.86rem; }

/* Dataframe container */
div[data-testid="stDataFrame"] { border: 1px solid var(--line); border-radius: 14px; overflow: hidden; }

/* Alerts a touch softer */
div[data-testid="stAlert"] { border-radius: 12px; }
hr { border-color: var(--line); }
</style>
"""
st.markdown(_APPLE_CSS, unsafe_allow_html=True)

CFG = load_config()
THRESH = CFG.get("thresholds", {})
BOUNCE_WARN = THRESH.get("bounce_warn", 0.03)
POS_FLOOR = THRESH.get("positive_floor", 0.005)

# Rate metadata: key -> (label, meaning, color, decimals)
RATE_META = [
    ("reply_rate_with_ooo", "Reply rate (incl. OOO)", "Deliverability", "#2563eb", 2),
    ("reply_rate", "Reply rate", "Relevance", "#7c3aed", 2),
    ("pos_reply_rate", "Positive reply rate", "Offer fit", "#059669", 1),
    ("bounce_rate", "Bounce rate", "List quality", "#dc2626", 1),
]
COUNT_META = [
    ("sent", "Emails sent", "#2563eb"),
    ("replies", "Replies", "#7c3aed"),
    ("positive_replies", "Positive replies", "#059669"),
    ("meetings", "Meetings booked", "#d97706"),
]


def _check_login() -> bool:
    user = os.environ.get(CFG["dashboard"]["login_user_env_var"])
    pw = os.environ.get(CFG["dashboard"]["login_pass_env_var"])
    if not user or not pw:
        # No credentials configured -> open access (single-user / local use).
        # Set DASH_USER + DASH_PASS to re-enable the login gate (e.g. before
        # exposing the dashboard on a public URL).
        return True
    if st.session_state.get("authed"):
        return True
    st.title("📈 Client Reports")
    with st.form("login"):
        u = st.text_input("User")
        p = st.text_input("Password", type="password")
        if st.form_submit_button("Sign in"):
            if u == user and p == pw:
                st.session_state["authed"] = True
                st.rerun()
            else:
                st.error("Wrong credentials.")
    st.stop()


_check_login()
engine = get_engine(CFG)
init_db(engine)


def pct(x, dp=1):
    return f"{(x or 0)*100:.{dp}f}%"


def period_label(p: dict) -> str:
    s, e = p["period_start"], p["period_end"]
    s = s if isinstance(s, date) else date.fromisoformat(str(s))
    e = e if isinstance(e, date) else date.fromisoformat(str(e))
    return f"{s.strftime('%b %-d')} – {e.strftime('%b %-d, %Y')}"


def _as_d(x) -> date:
    return x if isinstance(x, date) else date.fromisoformat(str(x))


def _fmt(d) -> str:
    return _as_d(d).strftime("%b %-d")


# ---------- modern trend chart (one metric, own scale) ----------
def trend_chart(df: pd.DataFrame, field: str, title: str, subtitle: str,
                color: str, is_pct: bool):
    y_axis = alt.Axis(format="%" if is_pct else "~s", grid=True, gridOpacity=0.12,
                      labelFontSize=11, tickCount=4, domain=False, ticks=False)
    tip_fmt = ".2%" if is_pct else ","
    base = alt.Chart(df).encode(
        x=alt.X("period_start:T", title=None,
                axis=alt.Axis(format="%b %-d", labelFontSize=11, grid=False,
                              domain=False, ticks=False, labelAngle=0)),
        y=alt.Y(f"{field}:Q", title=None, axis=y_axis,
                scale=alt.Scale(zero=is_pct is False and field in ("sent",))),
    )
    area = base.mark_area(line=False, opacity=0.10, color=color)
    line = base.mark_line(color=color, strokeWidth=2.5, interpolate="monotone")
    pts = base.mark_point(color=color, filled=True, size=70, opacity=1).encode(
        tooltip=[alt.Tooltip("period_start:T", title="Week of", format="%b %-d"),
                 alt.Tooltip(f"{field}:Q", title=title, format=tip_fmt)])
    return (area + line + pts).properties(
        height=185,
        title=alt.TitleParams(title, subtitle=subtitle, fontSize=13,
                              subtitleFontSize=11, subtitleColor="#888",
                              anchor="start", color="#222"),
    ).configure_view(strokeWidth=0).configure_axis(labelColor="#666")


def render_trends(records: list[dict], meetings_series: dict | None = None):
    d = pd.DataFrame(records).copy()
    d["period_start"] = pd.to_datetime(d["period_start"])
    if meetings_series is not None:
        d["meetings"] = d["period_start"].dt.date.astype(str).map(
            lambda k: meetings_series.get(k, 0))
    elif "meetings" not in d:
        d["meetings"] = 0

    st.markdown("**Volume & engagement**")
    cols = st.columns(4)
    for (field, title, color), col in zip(COUNT_META, cols):
        col.altair_chart(trend_chart(d, field, title, "count", color, False),
                         width="stretch")

    st.markdown("**Performance rates** — each on its own scale")
    cols = st.columns(4)
    for (field, title, meaning, color, _dp), col in zip(RATE_META, cols):
        col.altair_chart(trend_chart(d, field, title, meaning, color, True),
                         width="stretch")


# ---------------- sidebar ----------------
st.sidebar.title("📈 Client Reports")
if st.sidebar.button("🔄 Refresh data"):
    st.rerun()
view = st.sidebar.radio("View", ["All clients", "Per client", "Scheduling"])
st.sidebar.caption(f"Flags: bounce > {pct(BOUNCE_WARN,0)} · positive yield < "
                   f"{pct(POS_FLOOR,1)} (pos/sent)")


def _rate_cols(rec: dict) -> dict:
    return {
        "Deliverability (reply+OOO)": round((rec.get("reply_rate_with_ooo") or 0)*100, 2),
        "Relevance (reply)": round((rec.get("reply_rate") or 0)*100, 2),
        "Offer fit (positive)": round((rec.get("pos_reply_rate") or 0)*100, 1),
        "Bounce %": round((rec.get("bounce_rate") or 0)*100, 1),
    }


# ---------------- data ----------------
with engine.begin() as conn:
    clients = fetch_clients(conn)
    periods_by_client = {c["id"]: fetch_periods(conn, c["id"]) for c in clients}


# ---------------- overview ----------------
def render_overview():
    st.header("All clients")
    active = [c for c in clients if c["active"]]
    if not active:
        st.info("No active clients with data yet. Run `run biweekly reports`.")
        return

    # ---- date-range control (presets + custom) ----
    today = date.today()
    _PRESETS = {"Last 2 weeks": 14, "Last 4 weeks": 28, "Last 8 weeks": 56, "Last 12 weeks": 84}
    choice = st.radio("Date range", list(_PRESETS) + ["Custom…"], index=2, horizontal=True,
                      key="ov_range_choice")
    if choice in _PRESETS:
        rstart, rend = today - timedelta(days=_PRESETS[choice] - 1), today
    else:
        dr = st.date_input("Custom range", value=(today - timedelta(days=55), today),
                           key="ov_custom_range")
        rstart, rend = dr if isinstance(dr, (tuple, list)) and len(dr) == 2 else \
            (today - timedelta(days=55), today)
    st.caption(f"Totals are summed over the weeks within **{rstart:%b %-d} – {rend:%b %-d, %Y}** "
               f"(weekly grain). Rates are recomputed from the summed counts.")

    rows = []
    with engine.begin() as conn:
        for c in active:
            wk = fetch_weekly_client_series(conn, c["id"])
            inrange = [w for w in wk if rstart <= _as_d(w["week_start"]) <= rend]
            agg = sum_counts(inrange)
            rec = {**agg, **compute_rates(agg)}
            m = count_meetings(conn, c["id"], rstart, rend)
            fl = breach_flags(rec, THRESH)
            rows.append({
                "Client": c["name"],
                "Sent": agg["sent"], "Contacted": agg["contacted"],
                "Replies": agg["replies"], "Positive": agg["positive_replies"],
                "Meetings": m, **_rate_cols(rec),
                "Flags": ", ".join(fl) if fl else "✓",
            })
    df = pd.DataFrame(rows).sort_values("Sent", ascending=False)
    sty = df.style.apply(lambda r: ["background-color:#b91c1c;color:#ffffff" if r["Flags"] != "✓" else ""
                                    for _ in r], axis=1)
    st.dataframe(sty, width="stretch", hide_index=True)
    tot = df[["Sent", "Contacted", "Replies", "Positive", "Meetings"]].sum()
    s = st.columns(5)
    s[0].metric("Total sent", f"{int(tot['Sent']):,}")
    s[1].metric("Contacted", f"{int(tot['Contacted']):,}")
    s[2].metric("Replies", f"{int(tot['Replies']):,}")
    s[3].metric("Positive", f"{int(tot['Positive']):,}")
    s[4].metric("Meetings", f"{int(tot['Meetings']):,}")


# ---------------- per client ----------------
def _build_period_options(cid: int):
    """Unified reporting periods: weekly (current = to-date) + fortnightly, newest
    first. Each carries its rollup row + same-grain prior + start/end + grain."""
    today = date.today()
    with engine.begin() as conn:
        weekly = fetch_weekly_client_series(conn, cid)
        forts = fetch_periods(conn, cid)
    opts = []
    wk = list(reversed(weekly))
    for i, w in enumerate(wk):
        s, e = _as_d(w["week_start"]), _as_d(w["week_end"])
        partial = e > today
        label = f"Week · {_fmt(s)}–{_fmt(e)}" + (" — to date" if partial else "")
        opts.append({"label": label, "grain": "week", "start": s, "end": e,
                     "row": w, "prior": wk[i + 1] if i + 1 < len(wk) else None})
    ft = list(reversed(forts))
    for i, p in enumerate(ft):
        s, e = _as_d(p["period_start"]), _as_d(p["period_end"])
        opts.append({"label": f"Fortnight · {_fmt(s)}–{_fmt(e)}", "grain": "fortnight",
                     "start": s, "end": e, "row": p,
                     "prior": ft[i + 1] if i + 1 < len(ft) else None})
    return opts


def _client_tab_summary(c, cid, this, last, grain, pstart, pend, sel, m_this, m_last):
    fl = breach_flags(this, THRESH)
    if fl:
        st.error("Threshold breach — " + " · ".join(fl))
    st.caption(f"Showing **{sel}**" + (" vs the prior period" if last else " (first period)"))
    m = st.columns(5)
    m[0].metric("Sent", f"{this['sent']:,}")
    m[1].metric("Contacted", f"{this['contacted']:,}")
    m[2].metric("Replies", f"{this['replies']:,}")
    m[3].metric("Positive replies", f"{this['positive_replies']:,}")
    m[4].metric("Meetings", f"{m_this}", delta=(m_this - m_last) if last else None)
    st.write("")
    r = st.columns(4)
    r[0].metric("Reply incl. OOO", pct(this["reply_rate_with_ooo"], 2), help="Deliverability")
    r[1].metric("Reply rate", pct(this["reply_rate"], 2), help="Relevance")
    r[2].metric("Positive reply rate", pct(this["pos_reply_rate"], 1), help="Offer fit")
    r[3].metric("Bounce rate", pct(this["bounce_rate"], 1), help="List quality")


def _client_tab_trends(cid):
    st.caption("Each point is one week's activity (Mon–Sun) — not cumulative. The latest point "
               "is the current week to date.")
    with engine.begin() as conn:
        weekly = fetch_weekly_client_series(conn, cid)
        mseries = {str(w["week_start"]): count_meetings(
            conn, cid, w["week_start"], w["week_end"]) for w in weekly}
    if weekly:
        render_trends(weekly, mseries)
    else:
        st.info("No weekly data yet — run `run biweekly reports`.")


def _client_tab_campaigns(cid, grain, pstart, sel):
    st.caption(f"Per-campaign performance for **{sel}**. 'Calls booked' is all-time.")
    with engine.begin() as conn:
        camps = (fetch_weekly_campaigns_for_week(conn, cid, pstart) if grain == "week"
                 else fetch_campaigns_for_period(conn, cid, pstart))
        calls = count_calls_by_campaign(conn, cid)
    if not camps:
        st.info("No per-campaign rows for this period.")
    else:
        crows = [{
            "Campaign": cs["campaign_name"], "Sent": cs["sent"], "Contacted": cs["contacted"],
            "Replies": cs["replies"], "OOO": cs["ooo_replies"], "Positive": cs["positive_replies"],
            "Calls booked": calls.get(cs["platform_campaign_id"], 0),
            "Bounces": cs["bounces"], **_rate_cols(cs),
            "Flags": ", ".join(breach_flags(cs, THRESH)) or "✓",
        } for cs in camps]
        st.dataframe(pd.DataFrame(crows).style.apply(
            lambda rr: ["background-color:#b91c1c;color:#ffffff" if rr["Flags"] != "✓" else ""
                        for _ in rr], axis=1), width="stretch", hide_index=True)
        booked = sorted(((calls.get(cs["platform_campaign_id"], 0), cs["campaign_name"])
                         for cs in camps), reverse=True)
        if any(n for n, _ in booked):
            st.markdown("###### Booked calls by campaign (all-time) — scale the top, kill the bottom")
            st.dataframe(pd.DataFrame([{"Campaign": nm, "Calls booked": n} for n, nm in booked]),
                         width="stretch", hide_index=True)
    st.divider()
    with engine.begin() as conn:
        all_camps = fetch_client_campaigns_weekly(conn, cid)
    if all_camps:
        st.markdown("###### Drill into one campaign's weekly trend")
        label_to_id = {a["campaign_name"]: a["platform_campaign_id"] for a in all_camps}
        csel = st.selectbox("Campaign", list(label_to_id), key=f"camp_{cid}")
        with engine.begin() as conn:
            series = fetch_weekly_campaign_series(conn, cid, label_to_id[csel])
        if series:
            for rr in series:
                rr["period_start"] = rr["week_start"]
            render_trends(series)


_ATTR_BADGE = {"matched": "✅", "ambiguous": "⚠️", "unmatched": "❓", "error": "⚠️",
               "pending": "…", "manual": "👤"}


def _client_tab_calls(c, cid, pend):
    st.caption("Log the prospect's email — the campaign that contacted them is resolved from "
               "PlusVibe and the booked call is credited to it.")
    with st.form(f"add_meeting_{cid}", clear_on_submit=True):
        mc = st.columns([1, 2, 2, 1])
        md = mc[0].date_input("Date", value=min(_as_d(pend), date.today()))
        me = mc[1].text_input("Prospect email")
        mn = mc[2].text_input("Note (optional)")
        if mc[3].form_submit_button("Add") and me.strip():
            with engine.begin() as conn:
                mid = add_meeting(conn, cid, md, me, mn)
            with st.spinner("Attributing to campaign…"):
                _attribute_and_store(c["name"], mid, me)
            st.rerun()

    with engine.begin() as conn:
        all_m = fetch_meetings(conn, cid)
    if all_m:
        unresolved = [m for m in all_m if (m.get("attribution_status") or "pending")
                      in ("pending", "unmatched", "error", None)]
        if unresolved and st.button(f"🔁 Re-attribute {len(unresolved)} unresolved", key=f"reattr_{cid}"):
            with st.spinner("Resolving campaigns from PlusVibe…"):
                for m in unresolved:
                    _attribute_and_store(c["name"], m["id"], m["email"])
            st.rerun()
        hdr = st.columns([1.1, 2.4, 2.6, 2.2, 0.7])
        for h, t in zip(hdr, ["Date", "Email", "Attributed campaign", "Note", ""]):
            h.markdown(f"**{t}**")
        for mm in all_m:
            cc = st.columns([1.1, 2.4, 2.6, 2.2, 0.7])
            cc[0].write(str(mm["meeting_date"]))
            cc[1].write(mm["email"])
            badge = _ATTR_BADGE.get(mm.get("attribution_status") or "pending", "…")
            camp = mm.get("attributed_campaign_name") or f"_{mm.get('attribution_status') or 'pending'}_"
            cc[2].write(f"{badge} {camp}")
            cc[3].write(mm.get("note") or "")
            if cc[4].button("🗑", key=f"del_{mm['id']}"):
                with engine.begin() as conn:
                    delete_meeting(conn, mm["id"])
                st.rerun()
        st.caption("✅ matched · 👤 manual · ⚠️ ambiguous (replied campaign preferred) · ❓ not found")

        # Manual attribution — for calls PlusVibe can't auto-resolve (the booker
        # replied from an alias/forward, was a referral, or the lead was uploaded
        # under a different email). Credit the call to the right campaign by hand.
        with engine.begin() as conn:
            client_camps = fetch_client_campaigns_weekly(conn, cid)
        if client_camps:
            with st.expander("✍️ Manually attribute a call (when auto can't find the email)"):
                m_by = {f"{m['meeting_date']} · {m['email']}": m["id"] for m in all_m}
                msel = st.selectbox("Booked call", list(m_by), key=f"man_m_{cid}")
                copts = {a["campaign_name"]: a["platform_campaign_id"] for a in client_camps}
                csel = st.selectbox("Attribute to campaign", list(copts), key=f"man_c_{cid}")
                if st.button("Assign", key=f"man_b_{cid}"):
                    with engine.begin() as conn:
                        set_meeting_attribution(conn, m_by[msel], copts[csel], csel, "manual")
                    st.rerun()
    else:
        st.caption("No meetings logged yet.")

    with st.expander("🔍 Debug attribution — trace an email across PlusVibe"):
        de = st.text_input("Prospect email to trace", key=f"dbg_{cid}")
        if st.button("Trace", key=f"dbgb_{cid}") and de.strip():
            with st.spinner("Searching every workspace…"):
                st.json(_debug_attribution(c["name"], de.strip()))


def _client_tab_email(c, cid):
    st.caption("The client report covers the **last two weeks** (a full fortnight). "
               "Numbers & campaigns are filled from live data; you type the three analysis "
               "sections, then copy.")
    with engine.begin() as conn:
        forts = fetch_periods(conn, cid)
    if not forts:
        st.info("No completed two-week period yet — run `run biweekly reports`.")
        return
    flabels = [f"{_fmt(p['period_start'])}–{_fmt(p['period_end'])}" for p in reversed(forts)]
    fsel = st.selectbox("Two-week period", flabels, index=0, key=f"fort_{cid}")
    fidx = len(forts) - 1 - flabels.index(fsel)
    fthis = forts[fidx]
    flast = forts[fidx - 1] if fidx > 0 else None
    with engine.begin() as conn:
        fcamps = fetch_campaigns_for_period(conn, cid, fthis["period_start"])
        fm_this = count_meetings(conn, cid, fthis["period_start"], fthis["period_end"])
        fm_last = (count_meetings(conn, cid, flast["period_start"], flast["period_end"])
                   if flast else 0)
    phrase = f"the last two weeks ({_fmt(fthis['period_start'])}–{_fmt(fthis['period_end'])})"
    draft = build_draft(c, fthis, flast, fm_this, fm_last, fcamps, CFG, period_phrase=phrase,
                        period_start=fthis["period_start"], period_end=fthis["period_end"])
    st.text_input("Subject", value=draft["subject"], key=f"subj_{cid}_{fsel}")
    st.text_area("Body — type What's working / not working / changing, then select-all & copy",
                 value=draft["body"], height=600, key=f"body_{cid}_{fsel}")


def render_client():
    name_to_client = {c["name"]: c for c in clients}
    pick = st.sidebar.selectbox("Client", list(name_to_client))
    c = name_to_client[pick]
    cid = c["id"]

    st.header(c["name"])
    st.caption(f"Contact: {c.get('contact_name') or '—'} · "
               f"{'Active' if c['active'] else 'Inactive'}")

    opts = _build_period_options(cid)
    if not opts:
        st.info("No data recorded yet. Run `run biweekly reports`.")
        return
    labels = [o["label"] for o in opts]
    sel = st.selectbox("Reporting period (drives Summary & Campaigns)", labels, index=0,
                       key=f"period_{cid}")
    opt = opts[labels.index(sel)]
    this, last, grain = opt["row"], opt["prior"], opt["grain"]
    pstart, pend = opt["start"], opt["end"]
    with engine.begin() as conn:
        m_this = count_meetings(conn, cid, pstart, pend)
        m_last = (count_meetings(conn, cid, _as_d(last["week_start" if grain == "week" else "period_start"]),
                                 _as_d(last["week_end" if grain == "week" else "period_end"]))
                  if last else 0)

    t_sum, t_tr, t_camp, t_calls, t_email = st.tabs(
        ["  Summary  ", "  Trends  ", "  Campaigns  ", "  Calls  ", "  Email report  "])
    with t_sum:
        _client_tab_summary(c, cid, this, last, grain, pstart, pend, sel, m_this, m_last)
    with t_tr:
        _client_tab_trends(cid)
    with t_camp:
        _client_tab_campaigns(cid, grain, pstart, sel)
    with t_calls:
        _client_tab_calls(c, cid, pend)
    with t_email:
        _client_tab_email(c, cid)


# ---------------- scheduling board ----------------
def _runway_status(row: dict, today: date) -> tuple[str, int]:
    rem = row.get("leads_remaining", 0) or 0
    ro = row.get("run_out_date")
    if rem <= 0:
        return "🔴 OUT", -1
    if not ro:
        return "⚪ stalled", 999
    days = (_as_d(ro) - today).days
    if days <= 7:
        return f"🔴 {days}d", days
    if days <= 14:
        return f"🟡 {days}d", days
    return f"🟢 {days}d", days


def _refresh_runway_live():
    """Recompute runway from PlusVibe for every active client and store the
    snapshot. Triggered by the refresh button (kept off the page-load path so a
    13-client board stays snappy)."""
    cfg = load_config()
    today = date.today()
    for c in cfg.get("clients", []):
        if c.get("active"):
            rw = compute_runway(c, today, cfg=cfg)
            store_runway(c["name"], rw, contact_name=c.get("contact_name", ""), active=True)


def render_scheduling():
    st.header("Scheduling — lead runway")
    today = date.today()
    cols = st.columns([1, 4])
    if cols[0].button("🔄 Refresh live"):
        with st.spinner("Reading live campaign state from PlusVibe…"):
            _refresh_runway_live()
        st.rerun()
    cols[1].caption("Leads left = NOT_CONTACTED, run-out projected over each campaign's real "
                    "sending days. Shows the last snapshot; hit Refresh live to re-pull from "
                    "PlusVibe (e.g. after starting a new campaign).")

    active = [x for x in clients if x["active"]]
    with engine.begin() as conn:
        runway = {x["name"]: fetch_runway(conn, x["id"]) for x in active}

    timeline = []
    for cname, rw in runway.items():
        st.markdown(f"### {cname}")
        if not rw:
            st.caption("No active campaigns.")
            continue
        outs = [r for r in rw if (r.get("leads_remaining", 0) or 0) <= 0]
        dated = [r for r in rw if r.get("run_out_date") and (r.get("leads_remaining", 0) or 0) > 0]
        if outs and not dated:
            st.error(f"⚠ All {len(rw)} active campaign(s) are OUT of fresh leads — "
                     f"load new campaigns now.")
        elif dated:
            earliest = min(_as_d(r["run_out_date"]) for r in dated)
            d = (earliest - today).days
            msg = (f"{len(outs)} campaign(s) OUT now; next runs out {earliest.strftime('%b %-d')} ({d}d)"
                   if outs else f"Earliest run-out: {earliest.strftime('%b %-d')} ({d}d)")
            (st.error if d <= 7 else st.info)(msg + " — set up the next campaign.")
        rows = []
        for r in rw:
            badge, _ = _runway_status(r, today)
            rows.append({
                "Campaign": r["campaign_name"], "Leads left": r["leads_remaining"],
                "Sends/day": r["daily_rate"], "Sending days left": r["sending_days_left"],
                "Run-out": r["run_out_date"] or "—",
                "Sends on": r["schedule_days"] or "—", "Status": badge,
            })
            ro = _as_d(r["run_out_date"]) if r["run_out_date"] else today
            timeline.append({"label": f"{cname[:12]}: {r['campaign_name'][:26]}",
                             "start": today, "end": max(ro, today + timedelta(days=1))})
        st.dataframe(pd.DataFrame(rows).style.apply(
            lambda rr: ["background-color:#b91c1c;color:#ffffff" if rr["Status"].startswith("🔴")
                        else "" for _ in rr], axis=1), width="stretch", hide_index=True)

    if timeline:
        st.subheader("Lead-coverage timeline")
        st.caption("Each bar = days of fresh leads a live campaign has left (today → run-out). "
                   "Dashed line = today. A short/absent bar means that campaign needs new leads.")
        tdf = pd.DataFrame(timeline)
        tdf["start"] = pd.to_datetime(tdf["start"])
        tdf["end"] = pd.to_datetime(tdf["end"])
        bars = alt.Chart(tdf).mark_bar(height=13, cornerRadius=3, color="#dc2626").encode(
            x=alt.X("start:T", title=None), x2="end:T",
            y=alt.Y("label:N", title=None, sort=None, axis=alt.Axis(labelFontSize=11)),
            tooltip=["label", alt.Tooltip("start:T", title="today", format="%b %-d"),
                     alt.Tooltip("end:T", title="runs out", format="%b %-d")])
        rule = alt.Chart(pd.DataFrame({"d": [pd.to_datetime(today)]})).mark_rule(
            color="#111", strokeDash=[4, 3]).encode(x="d:T")
        st.altair_chart((bars + rule).properties(height=max(140, 26 * len(tdf))
                                                 ).configure_view(strokeWidth=0), width="stretch")


if view == "All clients":
    render_overview()
elif view == "Scheduling":
    render_scheduling()
else:
    render_client()
