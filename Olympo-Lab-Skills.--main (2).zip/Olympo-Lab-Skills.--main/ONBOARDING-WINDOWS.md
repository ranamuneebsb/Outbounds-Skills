# Onboarding — OlympoLabs Skills (Windows)

Welcome. This is a private internal toolkit — never share the credentials or the repo URL outside the team. **Mac users: see [ONBOARDING.md](ONBOARDING.md). This file is Windows-specific.**

## What you'll need (15 min, one-time)

- **Windows 10 or 11**
- **Python 3.10+** — download from https://www.python.org/downloads/. ⚠️ During install, check the box **"Add python.exe to PATH"**.
- **Git for Windows** — https://git-scm.com/download/win (gives you `git` + Git Bash; we use plain PowerShell for everything else)
- **Claude Code** — install from claude.ai/code. Runs natively on Windows now (no WSL needed).
- **GitHub account** with access to this repo (DM Bryan your GitHub username)
- **Google Cloud SDK** — https://cloud.google.com/sdk/docs/install#windows, or run `winget install Google.CloudSDK` in PowerShell

You'll get three API keys via DM from Bryan (never commit these to git):
- **OpenRouter** (LLM provider)
- **ZenRows** (web scraping)
- **PlusVibe** (campaign sending)

## 1. Set up an SSH key for GitHub (3 min, one-time)

Open PowerShell and run:

```powershell
ssh-keygen -t ed25519 -C "your-email@whatever.com" -f "$env:USERPROFILE\.ssh\id_ed25519" -N '""'
Get-Content "$env:USERPROFILE\.ssh\id_ed25519.pub" | Set-Clipboard
```

The second line copies your public key to the clipboard. Now:

1. Open https://github.com/settings/keys
2. Click **New SSH key**
3. Title: "My Windows laptop"
4. Paste (Ctrl+V) and click **Add SSH key**

Verify it works:

```powershell
ssh -T git@github.com
```

You should see `Hi <your-username>! You've successfully authenticated...`

## 2. Clone the repo + run the installer

```powershell
cd $env:USERPROFILE
git clone git@github.com:bryanlopez-source/Olympo-Lab-Skills.-.git OlympoLabs-Skills
cd OlympoLabs-Skills
.\install.ps1
```

⚠️ If you get **"running scripts is disabled on this system"**, run this ONCE then re-run `.\install.ps1`:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

The installer:
- Verifies Python + pip + gcloud
- Installs missing Python packages (`pip install --user`)
- Creates `%USERPROFILE%\.claude\skills\` and unpacks the `.skill` bundles
- Creates `%USERPROFILE%\.olympolabs\` for your credentials
- Prints the next-step instructions

Re-running it is safe — idempotent.

## 3. Drop your credentials

Replace the placeholder values with the keys Bryan DMs you:

```powershell
'{"api_key": "sk-or-v1-..."}'               | Out-File -Encoding ascii "$env:USERPROFILE\.olympolabs\openrouter.json"
'{"api_key": "your-zenrows-key"}'           | Out-File -Encoding ascii "$env:USERPROFILE\.olympolabs\zenrows.json"
'{"api_key": "the-team-plusvibe-key"}'      | Out-File -Encoding ascii "$env:USERPROFILE\.olympolabs\plusvibe.json"
```

**Do not** put these keys anywhere in the repo.

## 4. Google Sheets auth (one-time)

```powershell
gcloud init                                 # pick your existing GCP project
gcloud services enable sheets.googleapis.com
gcloud auth application-default login `
  --client-id-file="$env:USERPROFILE\OlympoLabs-Skills\shared-config\gcloud-oauth-client.json" `
  --scopes=openid,email,https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/spreadsheets
gcloud auth application-default set-quota-project olympolabs-copywriter
```

The backtick (`) at the end of each line is PowerShell's line-continuation character — like `\` in bash. Keep them.

The skills authenticate AS you. Any Google Sheet you own or have edit access to is writable.

## 5. Restart Claude Code

That's it. The skills auto-trigger from their description text. Try one to verify:

> Score the qualified companies in this sheet against an ICP for SaaS founders: https://docs.google.com/spreadsheets/d/.../edit

If `company-scoring` fires, you're set up.

## What's in the box (7 skills)

Full descriptions in [README.md](README.md). Quick map:

| Skill | What it does |
|---|---|
| **copywriter** | Generate 10–20 cold email scripts from the winning-scripts knowledge base |
| **icp-keywords** | Generate INCLUDE / EXCLUDE / decision-maker title lists for Apollo, Clay, ZoomInfo, LinkedIn Sales Navigator |
| **company-scoring** | Score Google Sheets or CSVs of companies 1–10 for ICP fit; writes 5 columns including `Scrape Content` |
| **name-normalizer** | Clean up first-name and company columns for natural-reading merge tags |
| **personalization** | Per-row cold-email hooks generated from the `Scrape Content` column |
| **plusvibe-spintax** | Heavy spintax + spam-word audit on a finished script |
| **plusvibe-campaign-manager** | Upload finished spintaxed campaigns to PlusVibe via API |

Typical pipeline:

```
copywriter → plusvibe-spintax → plusvibe-campaign-manager
                                          ↑
company-scoring → name-normalizer → personalization
```

## Updating later

```powershell
cd $env:USERPROFILE\OlympoLabs-Skills
git pull
.\install.ps1        # idempotent
```

Restart Claude Code if any SKILL.md descriptions changed.

## When something breaks

1. **First, run the doctor:**
   ```powershell
   python $env:USERPROFILE\.claude\skills\company-scoring\scripts\doctor.py
   ```
   It checks credentials, dependencies, gcloud ADC, and prints the exact fix for anything missing.

2. **Check the docs:**
   - `docs\setup-api-keys.md`
   - `docs\setup-gcloud-adc.md`
   - `docs\troubleshooting.md`

3. **DM Bryan** if you're still stuck after the above.

## Hard rules

- **Never commit credentials.** The `.gitignore` blocks the obvious paths but stay vigilant.
- **Never share the repo URL or API keys outside the team.**
- **Don't push to `main` without a quick sanity check** — at minimum `.\install.ps1` should succeed after your changes.
- **Re-run `install.ps1` after pulling.** Skill updates ship as `.skill` bundles; the installer copies them into Claude Code's skills directory.

## Why two installers? (install.sh vs install.ps1)

`install.sh` is for Mac/Linux teammates; `install.ps1` is for Windows. They do the same thing. The PowerShell version uses native Windows tooling (Compress-Archive, winget, PowerShell paths) instead of bash + zip + brew.
