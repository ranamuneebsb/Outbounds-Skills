---
name: plusvibe-spintax
description: Add heavy spintax variations to cold email scripts using PlusVibe's `{{random|opt1|opt2|opt3}}` syntax for deliverability and inbox uniqueness, while scrubbing spam-trigger words and preserving tone and essence. Use whenever the user wants to spintax a cold email, prep for PlusVibe, add variations, spin a sequence, "make this unique", "add spintax", "spin this script", spintax a Copywriter draft file, or take an edited campaign draft to the spintax step — even without saying "spintax". Handles single emails, sequences, and Copywriter draft.md files (writes spintaxed.md as an immutable audit + final.md as the editable copy in the same campaign folder, auto-opens final.md in Cursor). Leaves personalization tokens and numerical values untouched, never spins subject lines, replaces spam-trigger words with safe synonyms, returns clean ready-to-paste spintaxed text with no commentary.
---

# PlusVibe Spintax

Add heavy, natural-sounding spintax variations to cold email body copy so that every send looks unique to spam filters and inbox providers, while preserving the original meaning, tone, and personalization tokens.

## The syntax

PlusVibe uses double-braced spintax with a `random` directive at the start:

```
{{random|option1|option2|option3}}
```

At send time PlusVibe picks one of the pipe-separated options. **Always include the literal `random` keyword as the first segment** — without it, PlusVibe won't recognize the spin.

Personalization tokens use the **same double-brace shape but with no `random` and no pipes**:

```
{{first_name}}    {{company_name}}    {{sender_signature}}    {{custom_growth_idea}}    {{custom_competitors}}
```

These are merge variables, not spins. Treat them as opaque — leave them exactly as written, never wrap them in `{{random|...}}`, never alter their casing, and never put options inside them.

## What to spin

Spin **heavily** — almost every meaningful clause gets a spin. The goal is maximum inbox-level uniqueness, not minimal change. Look for spin opportunities in:

- **Greetings**: `{{random|Hey|Hi|Hello|}}` (empty final option is fine — see "Empty options" below)
- **Verbs**: `{{random|booked|sent}}`, `{{random|generate|book|secure}}`, `{{random|reach|connect with|get in front of}}`
- **Noun synonyms**: `{{random|meetings|introductions}}`, `{{random|firm|shop}}`, `{{random|business owners|CFOs|operators}}`
- **Descriptor phrases**: `{{random|qualified|pre-qualified|high-intent}}`, `{{random|right-fit|quality}}`
- **Time / cadence phrases**: `{{random|each month|a month|every month}}`, `{{random|each week|a week|every week}}`
- **Transition / framing phrases**: `{{random|For context|Quick context on us|Bit about us}}`, `{{random|Quick idea -|Had an idea -|A quick thought -}}`
- **CTAs**: `{{random|Worth a quick chat?|Worth a quick conversation?|Worth 15 minutes?|Open to a quick chat?}}`
- **Equivalent restatements**: `{{random|Done-for-you.|We handle everything.|Fully done-for-you.}}` — these aren't strict synonyms but they make the same point with the same tone

Spin frequency target: **most clauses in the email should contain at least one spin point.** If a paragraph has no spins, something is off — look harder.

### Variation count per spin point

Target **2–5 options** per spin point. Pick the count that feels natural for that phrase:

- 2 options when there are only two good ways to say it (`{{random|booked|sent}}`)
- 3–4 options is the sweet spot for most phrases
- 5 options for high-value spin points like greetings and primary CTAs

Don't pad with weak options just to hit a number. Five strong variations beats five forced ones — but lean toward more, not fewer, when good options exist.

### Within-spin diversity — vary the shape, not just the words

**Important precondition: density still applies.** The heavy-density rule above (most clauses get at least one spin) is not optional. Within-spin diversity is an *additional* constraint, not a substitute. Do not respond to the diversity requirement by producing fewer, "deeper" spins — produce the same density AND make each spin structurally diverse. Both rules apply at once.

Inbox-level uniqueness comes from how *different* the rendered emails look, not from how many spin points you have. If every option in a spin is just a one-word swap, the rendered emails will be 95% identical and spam filters will catch on.

**Bad — minor word swaps, low diversity:**

```
{{random|Worth a chat?|Worth a quick chat?|Worth a brief chat?|Worth a short chat?}}
{{random|We help|We support|We assist|We aid}}
{{random|qualified meetings|qualified appointments|qualified calls|qualified intros}}
```

These technically have N options, but the rendered emails will read nearly identically every time. Whatever PlusVibe picks, the email reads as "[We help/support/assist/aid] [companies/clients/teams] [book/secure/land/lock] qualified [meetings/appointments/calls/intros]". The variation is at the level of synonyms, not structure.

**Good — varied syntactic shapes, same meaning:**

```
{{random|Worth a chat?|Curious to dig in?|15 min next week?|Would this be useful to talk through?}}
{{random|We help SaaS founders book demos|For SaaS founders, we deliver booked demos|SaaS founders use us to fill their demo calendar}}
{{random|qualified meetings|meetings we've already screened for fit|meetings where the buyer is already pre-qualified}}
```

Each option reshapes the sentence — different starting word, different grammatical structure, sometimes different length and rhythm. The *meaning* and *tone* are identical (which is still the law from the tone consistency section above), but the *surface form* is genuinely different.

**The two rules in tension:**

- Tone consistency (mandatory): all options must read like they came from one writer in one sitting.
- Within-spin diversity (also mandatory): options must vary structurally, not just lexically.

These aren't contradictions. A skilled writer can say the same thing in five structurally different ways while keeping a consistent voice. Aim for that. If your options all start with the same word, end with the same word, or have the same syllable rhythm, you're under-diversifying — rewrite at least one with a fundamentally different shape.

Quick diversity check before finalizing a spin:

1. Do the options start with at least 2 different first words?
2. Are at least two options noticeably different lengths?
3. Could a reader who saw all options side by side say "these are structurally different sentences" rather than "these are the same sentence with one word changed"?

If any answer is no, rewrite.

### Empty options

Allowed and useful, especially in greetings and short connector phrases. An empty trailing option means "sometimes this disappears entirely":

```
{{random|Hey|Hi|}} {{first_name}},
```

This sometimes renders as `Hey John,`, sometimes `Hi John,`, sometimes `John,`. Use empty options sparingly — only where dropping the phrase entirely still reads correctly.

## What to NOT spin

These must pass through untouched:

1. **Personalization tokens** — `{{first_name}}`, `{{company_name}}`, `{{sender_signature}}`, `{{custom_growth_idea}}`, `{{custom_competitors}}`, and any other `{{snake_case_var}}` pattern. If you're unsure whether something is a token, leave it alone.

2. **Specific numerical values, stats, offers, guarantees** — if the email says "4-8 meetings", the *value* 4-8 stays. You **may** spin the *formatting* of that value (`{{random|4-8|4 to 8}}`) because the meaning is identical, but never change 4-8 to 3-7 or 5-10. Same for percentages, pricing, guarantees, or any claim a prospect could hold them to.

3. **The subject line** — if the input includes a subject line (e.g., `Subject: ...` at the top), pass it through completely unchanged. Spintax goes in the body only.

4. **Existing spintax** — if part of the email is already spintaxed (input is partially spintaxed), preserve those spins exactly as written. Only add new spins to the unspun portions.

5. **Brand names, product names, proper nouns** — OlympoLabs, specific client names, named platforms, etc.

6. **URLs and link text** that points to specific destinations — don't spin a link's anchor text in a way that misrepresents where it goes.

## Preserve the email's essence, tone, and voice

This is the single most important rule of the skill. Spintax is supposed to be invisible to the reader — whichever option PlusVibe picks at send time, the resulting email should read like one coherent message written by one person in one sitting. Inconsistent tone across variations is worse than no spintax at all, because it makes the email feel machine-generated.

### Within a single spin point

All options inside one `{{random|...}}` block must be **interchangeable in register, formality, length, and meaning**. A reader who saw all options side by side should think "these are the same thing said slightly differently" — not "these are written by different people."

Concretely, never mix:

- **Formal with casual** within one spin. `{{random|Would you be amenable to a brief conversation?|wanna chat?|Worth a quick chat?}}` is broken — three different registers.
- **Long with short** to a jarring degree. `{{random|Worth a chat?|Would it be worth scheduling a quick call to explore whether there might be a mutually beneficial opportunity here?}}` reads weirdly because the email's pacing changes wildly depending on the pick.
- **Different meanings or claims**. `{{random|We help you book meetings|We can guarantee 10x ROI in 30 days}}` — these say different things. Variations are alternative *phrasings*, not alternative *promises*.
- **Smart with dumb**. Every option should sound like something a competent native speaker would write. No filler, no awkward synonyms, no padding to hit a count.

### Across the whole email

The email has a voice — casual, direct, lowercase sentence starts, em-dash heavy, sentence fragments, whatever it is. Every spin point must stay inside that voice. A casual email with `{{random|hey|hi|}}` openings shouldn't have `{{random|Furthermore|Additionally|Moreover}}` transitions buried in the body.

Read the input first, get a feel for its voice, and let that voice constrain every spin you write. When in doubt, pick the more conservative spin — fewer variations that all sound like the original beats more variations where one of them feels off.

### Preserve everything that isn't a word choice

- Match the original register: casual stays casual, formal stays formal, lowercase stays lowercase
- Don't add claims, numbers, urgency, or social proof that wasn't in the original
- Don't lose claims, numbers, urgency, or social proof that *was* in the original
- Keep paragraph breaks, line breaks, dashes, and punctuation exactly as written
- P.S. blocks, em-dashes, and stylistic choices (lowercase sentence starts, sentence fragments) are intentional — preserve them and spin within them

## Spam words — strict avoid and replace

Cold email deliverability lives and dies by what spam filters see. There is a long list of words and phrases that trigger spam filters on sight, and the skill must treat them as **strictly forbidden** in two ways:

1. **Never introduce a spam word in a variation.** When generating spin options, none of the options may contain a word from the spam list. If the natural-sounding synonym for a phrase is on the list, pick the second-most-natural option instead. This applies even if only one of three or four options contains the spam word — that single option taints the whole spin.

2. **Replace spam words present in the input.** If the user's input email contains a spam word, silently replace it with the closest non-spam synonym that preserves meaning and tone. Do not flag the replacement to the user, do not add commentary — just produce a clean spintaxed output with the replacements made.

The full categorized list of spam words lives in [references/spam-words.md](references/spam-words.md). Read that list before generating output, and re-scan against it before returning (see "Mandatory final-pass audit" at the end of this skill).

### Strict matching — no benign-context exception

Match the list **case-insensitively, as whole words/phrases, with no exception for "natural English" usage**. The user has explicitly chosen maximum safety over slightly more natural phrasing.

This means:

- `"Only"` is on the list. Replace it even in benign uses like `"you only paid if they showed up"` → `"you paid only if they showed up"` or restructure to drop the word.
- `"Call"` is on the list. Replace it even in `"intro call"`, `"discovery call"`, `"quick call"` → use `"chat"`, `"conversation"`, `"intro meeting"`, `"15 minutes"`.
- `"Extra"` is on the list. Replace it even in `"extra demos"`, `"no extra lift"` → use `"additional demos"`, `"no added work"`, `"without adding to your workload"`.
- `"Trial"` is on the list. Replace it even in `"1-week trial"` → use `"1-week pilot"`, `"1-week test run"`.
- `"Bank"`, `"Loans"`, `"Mortgage"`, `"Insurance"`, `"Earn"` — same treatment. See industry-context note below for the narrow exception.

There is **no general "natural English" exception**. If a word is on the list, replace it.

### Industry-context exception (narrow)

The only place a listed word may stay is when it is **literally describing the prospect's profession or industry** and no clean paraphrase exists. Examples:

- A prospect who runs a mortgage brokerage — referring to "mortgage brokers" as the audience is fine, but never say "mortgage rates" or "low mortgage rates".
- A prospect in insurance — "insurance agents" as the audience is fine, but never say "insurance quote" or "best insurance rates".
- A prospect in commercial lending — refer to "commercial financing" or "commercial funding" rather than "commercial loans". The word "Loans" is on the list and should always be replaced with `"financing"`, `"funding"`, or `"capital"` even when describing the lending industry.

When in doubt, replace. The goal is zero spam-list matches in the output.

### Replacement guidance for high-frequency offenders

These are the patterns that slip through most often. Internalize them:

| Spam word/phrase | Use instead |
|---|---|
| Loans | financing, funding, capital |
| Trial | pilot, test run |
| Free trial | pilot, no-cost pilot, complimentary pilot (avoid "free") |
| Free consultation | intro chat, discovery conversation, quick walkthrough |
| Click here | describe the link ("the case study", "the one-pager", "their site") |
| Limited time | drop entirely; let the offer stand on its own |
| Guarantee / Guaranteed | "what we typically see", "the kind of results we deliver", drop the guarantee framing |
| Earn $X / Earn money | "see X", "drive X in pipeline", "add X to revenue" |
| Risk-free | "no commitment", "low-stakes" |
| Buy now / Order now / Act now | "worth a chat?", drop the urgency |
| Best (deal/price/fit/etc.) | "right fit", "strongest fit", "ideal setup", "tight fit" — avoid "best" entirely |
| Call (noun, even "intro call") | chat, conversation, intro meeting, 15 minutes |
| Only (any context) | restructure to drop the word, or use "just", "simply" — but check those against list too |
| Extra | additional, more, added |
| Hurry up | "before X", "while there's still capacity" — but check those against list too |
| Last chance / Final call | "closing the loop", "final note from me", "one more before I let you go" |
| Supplies / Spots filling up | "calendar is filling", "intake is closing soon" — but check |
| Open / Open to | "Would you be interested in...?", "Interested in...?", "Up for...?", "Curious about...?" |
| Get (any form) | reshape to use specific verbs: "begin", "kick off", "launch", "reach", "connect with", "land in front of", "circle back", "schedule" |
| Get started | begin, kick off, launch |
| Get in front of | reach, connect with, land in front of |
| Get back to you | circle back, follow up, loop back |
| Performance / Performance-based | results-based, results-tied, pay-for-results, outcomes-tied |

### Common slip-through anti-patterns (from real failures)

These exact mistakes have happened before. Specifically avoid them:

**Anti-pattern 1: Synonym drift toward a spam word**

Input says "commercial financing". When generating variations, the natural synonym is "commercial loans" — but `"Loans"` is on the spam list. Do NOT include "loans" as one of the variation options. Stick with `"financing"`, `"funding"`, `"capital"`, `"lending partner"`.

**Anti-pattern 2: "The best ___" in a CTA or descriptor**

Generating `{{random|The strongest setup|The sharpest setup|The best fit}}` — the third option contains `"The best"` which is on the list. The whole spin is tainted. Replace `"The best fit"` with `"The ideal fit"`, `"The right fit"`, `"The tightest fit"`, etc.

**Anti-pattern 3: Preserving input spam words**

Input contains "no extra lift on your end" — `"Extra"` is on the list. Don't preserve this. Rewrite to `"no added work on your end"`, `"without adding to your workload"`, `"with no additional effort"`, etc.

**Anti-pattern 4: "Intro call" / "discovery call" / "quick call"**

`"Call"` is on the list as a urgency-tactic trigger. Replace `"intro call"` with `"intro chat"`, `"intro meeting"`, `"15-min intro"`, `"discovery conversation"`.

**Anti-pattern 5: "You only paid"**

`"Only"` is on the list. Restructure sentences to avoid it: `"you only paid if they showed up"` → `"you paid just if they showed up"` (check "just" — not on list, OK), or restructure: `"you paid solely on a per-show basis"`, or `"payment was contingent on show-ups"`.

**Anti-pattern 6: "Open to a chat?" / "Open to learning more?" CTAs**

`"Open"` and `"Open to"` are on the list. Replace these CTAs entirely: `"Open to a quick chat?"` → `"Would you be interested in a quick chat?"`, `"Up for a quick chat?"`, `"Interested in a quick chat?"`, `"Curious to dig in?"`. Same for variants like `"Opening up our calendar"` → `"Adding spots to our calendar"`.

**Anti-pattern 7: "Get" verbs**

`"Get"` is on the list in every form. Common slip-throughs and replacements:

- `"Get started"` → `"begin"`, `"kick off"`, `"launch"`
- `"Get in front of"` → `"reach"`, `"connect with"`, `"land in front of"`
- `"Get back to you"` → `"circle back"`, `"follow up"`, `"loop back"`
- `"Get a meeting"` → `"schedule a meeting"`, `"book a meeting"`
- `"You'll get X"` → `"You'll see X"`, `"You'll have X"`, `"You'll have access to X"`

**Anti-pattern 8: "Performance-based" model**

`"Performance"` and `"Performance-based"` are on the list. Replace with `"results-based"`, `"results-tied"`, `"pay-for-results"`, `"outcomes-tied"`. The phrase "we work on a performance-based model" should never appear in output.

## Input handling

The user may give you:

1. **A single plain email** — no spintax yet. Spin the body, return the spintaxed version.
2. **A sequence of plain emails** — multiple emails separated by blank lines, dividers (`---`, `===`), or just clearly delineated blocks. Spin each email separately and return them in the same order with the same separators.
3. **A partially spintaxed email** — some spins already in place. Preserve those, fill in spins where they're missing, return the fully-spintaxed version.
4. **A file path to a Copywriter draft** — e.g. `~/Desktop/OlympoLabs-Skills/copywriter-workspace/runs/2026-05-24-olympolabs/draft.md`. This is the handoff from the Copywriter skill after the user has trimmed the batch down to keepers and edited them in their text editor. See "Handling a Copywriter draft file" below for the file-mode flow.

Detect which case you're in by inspecting the input. If the input looks like a file path (starts with `~/`, `/`, `./`, or matches the Copywriter campaign-folder convention `.../copywriter-workspace/runs/<date>-<client>/draft.md`), use the file mode. Otherwise process the input as inline text. If there are multiple emails (sequence), treat each independently — don't share spin choices across emails.

### Handling a Copywriter draft file (file mode)

When the user passes a path to a draft file, treat the whole file as a sequence of emails and follow these steps:

1. **Read the file** with the Read tool.
2. **Parse the email pairs.** The Copywriter writes each pair under a heading like `## 1. Framework: ...` with `**Email 1**` and `**Email 2 (follow-up)**` subheadings. Each email body sits between its subheading and the next subheading or `---` separator. The file also contains a top-level header with framework distribution counts and (sometimes) a "Frameworks skipped" note — skip those, they're not emails. The trailing "Saved + opened:" / "Saved to:" line, if present, is also not an email.
3. **Spin each email body independently** per the rules above. Keep the heading structure (`## N. Framework:`, `**Email 1**`, `**Email 2 (follow-up)**`) intact — don't touch the structural markdown, only the prose inside each email body.
4. **Write TWO sibling files** in the same campaign folder:
   - `spintaxed.md` — the original spintaxed output. **Preserve this as an immutable audit trail.** Never edit it by hand; it represents what came out of the Spintax skill before any human cleanup.
   - `final.md` — an identical copy of `spintaxed.md`, but this is the editable file the user works on next. After they run the spintaxed copy through their external spam-check tool and identify words to fix, they edit `final.md` to apply those fixes, save it, and that's the version that ships to PlusVibe.
   Both files have the same content at write time; they diverge only when the user starts editing `final.md`.
5. **Auto-open `final.md` in Cursor** so the user can immediately begin the external spam-check + cleanup pass: run `open -a Cursor <full-path-to-final.md>` as a Bash command right after writing both files. The `open -a` flag uses macOS's app-launch mechanism, so no `cursor` CLI install is required.
6. **Render the full spintaxed batch in chat** as well, identical to the file contents — same headers, same separators — so the user can skim-review without opening the file. The chat render's only difference from the file is a final two-line pointer at the very end:
   ```
   Saved (audit): <path>/spintaxed.md
   Saved + opened (edit here): <path>/final.md
   ```

Importantly: do NOT modify the original `draft.md`. The user's selections/edits in that file are canonical input to this step. The spintaxed and final files are derived artifacts.

## Output format

Return **only the spintaxed email(s)**. No preamble, no summary, no "Here's your spintaxed version:", no count of spins added, no explanation. Just the raw text the user can paste directly into PlusVibe.

If the input was a sequence of N emails, the output is N spintaxed emails with the same separators the user used.

If a subject line was included, preserve it at the top of its email unchanged.

**If the input was a Copywriter draft file (file mode):** preserve the exact heading structure of the draft (`## N. Framework:`, `**Email 1**`, `**Email 2 (follow-up)**`, horizontal rules between pairs), spin only the email body prose, write TWO files to the same campaign folder — `spintaxed.md` (immutable audit trail) and `final.md` (identical copy, editable by the user after external spam-checking) — auto-open `final.md` in Cursor via `open -a Cursor`, render the same content in chat, and append two trailing pointer lines:

```
Saved (audit): <absolute path to spintaxed.md>
Saved + opened (edit here): <absolute path to final.md>
```

Those two trailing pointers are the only addition vs. the file contents.

## Examples

### Example 1: single short email

**Input:**

```
{{first_name}} - if we sent you a couple funding meetings every month with business owners looking for commercial financing for {{company_name}} - and you paid if they showed up - would that be worth a conversation?

P.S. Done-for-you. We do the work on the front end. You just show up and close.

{{sender_signature}}
```

**Output:**

```
{{first_name}} - if we {{random|booked|sent}} you a couple funding {{random|meetings|introductions}} {{random|every month|each month|monthly}} with {{random|business owners looking for commercial financing|business owners actively seeking commercial funding|owners exploring commercial loans}} for {{company_name}} - and you paid if they showed up - would that be {{random|worth a conversation|worth a quick chat|something you'd consider|worth exploring}}?

P.S. {{random|Done-for-you.|Fully done-for-you.|We handle everything.}} We do {{random|the work on the front end|everything on the front end|the heavy lifting up front}}.

You just {{random|show up and close|take the calls and close|close the deals}}.

{{sender_signature}}
```

Notice: `{{first_name}}`, `{{company_name}}`, `{{sender_signature}}` are untouched. The dash structure, P.S. block, and short paragraph rhythm are preserved. Heavy spin density — almost every meaningful phrase has options.

### Example 2: empty option in a greeting

**Input:**

```
Hey {{first_name}},

Quick idea - {{custom_growth_idea}}
```

**Output:**

```
{{random|Hey|Hi|Hello|}} {{first_name}},

{{random|Quick idea -|Had an idea -|A quick thought -|Quick thought -}} {{custom_growth_idea}}
```

The empty fourth option in the greeting means the email sometimes opens with just the name. `{{custom_growth_idea}}` is a token and stays untouched.

### Example 3: number formatting spin (value preserved)

**Input:**

```
We can help you land 4-8 conversations a month.
```

**Output:**

```
{{random|We can|Our team can}} help you {{random|land|book|secure}} {{random|4-8|4 to 8}} {{random|conversations|calls|introductions}} {{random|a month|each month|every month|monthly}}.
```

The numerical range `4-8` is preserved in both spin options — only the formatting varies (`4-8` vs `4 to 8`). Never change the underlying value.

## Common mistakes to avoid

- **Forgetting the `random` keyword**: `{{hey|hi|hello}}` won't work in PlusVibe. Always `{{random|hey|hi|hello}}`.
- **Spinning personalization tokens**: never wrap `{{first_name}}` in a spin or alter its insides.
- **Changing numerical values**: "4-8 meetings" stays "4-8". Spin format, not value.
- **Adding commentary in the output**: the user is going to paste this directly into a sending tool. They don't want "I've added 23 spin points across 3 paragraphs" — they want clean spintaxed text.
- **Light spin density**: if a paragraph has only one or two spins, it's probably under-spun. The point of the skill is *heavy* spintax — push for maximum surface variation while keeping meaning identical.
- **Synonym slop**: don't reach for awkward synonyms just to inflate variation count. "Worth a parley?" is not a CTA. Variations have to be things a real person would write.
- **Tone drift inside a spin**: mixing formal and casual options inside one `{{random|...}}` block. All options in a spin must be the same register.
- **Letting spam words through**: any word from [references/spam-words.md](references/spam-words.md) — either in the input or in your generated variations — must be replaced with a non-spam synonym.

## Mandatory final-pass audit

This is the last step before returning output. Skipping it is the single biggest source of skill failures.

### Step 1 — Run the programmatic spam audit (REQUIRED, no exceptions, no eyeball substitutes)

**Do not return any spintaxed output to the user until the audit script has exited 0.** This is a hard contract, not a suggestion.

Run:

```bash
python3 ~/Desktop/OlympoLabs-Skills/plusvibe-spintax/scripts/audit_spam_words.py <path-to-the-file-you-are-about-to-return>
```

In file mode, audit `final.md` (the editable copy). For inline mode where the user pasted text directly, write the spintaxed output to a temp file first and audit that.

The script loads the full [references/spam-words.md](references/spam-words.md) (~387 terms) and scans every email body line against every term using whole-word/whole-phrase, case-insensitive matching. It auto-skips structural lines (markdown headers, framework labels, `---` separators, `**Email N**` markers, top-of-file metadata) so only actual email body prose is audited. It strips HTML tags before matching so the same script also works on PlusVibe-formatted bodies fetched from the API.

**Exit codes:**
- `0` — clean. Proceed to step 2.
- `1` — hits found. The script prints every offending line, the spam term(s) on that line, and a snippet. Fix each hit in the file using the Replacement guidance table above. Then re-run the script. **Loop until exit 0.**
- `2` — usage error (file not found, reference missing). Surface the error to the user; don't try to bypass.

**Include the audit result in your final chat output** so the user has visible proof. Examples:

- Clean run: `audit: CLEAN (387 terms scanned, 0 hits)`
- After fixing hits: `audit: CLEAN after 2 iterations (initial: 32 hits across 11 lines; final: 0)`

### Why this is mechanical and not prose-driven

A previous run of this skill produced a campaign with 39 spam-word hits across 12 variations that almost shipped to production. The audit at the time was an LLM self-assessment using a hand-picked subset of ~25 terms from the 387-term reference. The model reported "clean" because the narrow subset missed `now`, `cost`, `no cost`, `today`, `deals`, `call`, and other high-frequency terms that were everywhere in the output.

The script removes the self-assessment failure mode. There is no "I scanned the list" — only "the script exited 0." If you find yourself about to claim the output is clean without having executed the script and seen exit 0, stop and run it. If you ran it once at the start and made any edits afterward, run it again — the relevant state is the file as it stands right now, not the file as it stood at first scan.

### Step 2 — File-mode check (only if input was a draft file)

If the user passed a path to a Copywriter draft file, verify all of the following before returning:

- `spintaxed.md` was written to the same campaign folder and contains the spintaxed content.
- `final.md` was written to the same campaign folder and is an identical copy of `spintaxed.md` at write time.
- `open -a Cursor <full-path-to-final.md>` was executed (exit 0).
- The chat output ends with the two pointer lines (`Saved (audit): ...` and `Saved + opened (edit here): ...`).
- The original `draft.md` was NOT modified — read it back to confirm if there's any doubt.

If any of these failed, fix and re-run before returning.

### Step 3 — Return the output

Only after step 1 exited 0 and step 2 checks pass, return the spintaxed text to the user along with the audit confirmation line.

This audit is not optional and not best-effort. The user has explicitly chosen maximum deliverability safety over slightly more natural phrasing. Every spam word that slips through is a failure of this audit, and the script makes "I forgot" or "I checked the common ones" impossible defenses.
