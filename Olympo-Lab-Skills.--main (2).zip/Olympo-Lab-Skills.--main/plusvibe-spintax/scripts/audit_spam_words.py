#!/usr/bin/env python3
"""
Audit a file (final.md, spintaxed.md, draft.md, or arbitrary text) against
the full PlusVibe-spintax spam-words reference.

This script exists because the audit step in the spintax skill historically
relied on the LLM eyeballing the spam-words list and grepping for a
hand-picked subset. That produced false negatives in real production
campaigns (39 spam-word hits across 12 variations almost shipped because
the model reported "clean" after checking only ~25 of the 387 terms).

The script removes the self-assessment failure mode. There is no
"I scanned the list" — only "the script exited 0."

USAGE
    python3 audit_spam_words.py <path>           # scan file, exit 0 if clean
    python3 audit_spam_words.py <path> --json    # machine-readable report
    python3 audit_spam_words.py <path> --quiet   # only print summary line

BEHAVIOR
- Loads every bullet-list term from references/spam-words.md (~387 terms).
- Walks the input file line by line.
- Skips structural markdown lines that aren't email body (markdown headers,
  framework labels, `---` separators, `**Email N**` markers, top-of-file
  metadata like `Target:`, `Offer:`, `Proof:`, `Saved (audit):` pointer
  lines from previous skill runs).
- Strips HTML tags before matching (so the same script works on raw HTML
  email bodies fetched from PlusVibe, not just markdown).
- Whole-word/whole-phrase, case-insensitive matching using lookarounds.
- Reports every offending line with the matched term(s) and a snippet.
- Exit code 0 if no hits; exit 1 if any hits found.

EXIT CODES
    0   clean - no spam-list terms found in email body content
    1   hits found (see stdout for details)
    2   usage error (file not found, etc.)

IMPORT API
    from audit_spam_words import audit_file, load_spam_terms
    hits = audit_file(Path('final.md'), load_spam_terms())
    if hits: ...
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import List, NamedTuple

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_SPAM_FILE = SCRIPT_DIR.parent / "references" / "spam-words.md"

# Lines starting with any of these prefixes are structural / metadata and
# never ship to the prospect's inbox, so they're excluded from the audit.
SKIP_PREFIXES = (
    "## ",          # markdown H2 (framework section headers)
    "# ",           # markdown H1 (document title)
    "---",          # horizontal rules
    "**Email ",     # Email 1 / Email 2 markers
    "**Framework",  # framework labels in copywriter format
    "- Framework",  # bullet list of frameworks at top of file
    "Target:",      # metadata header lines emitted by copywriter
    "Offer:",
    "Proof:",
    "Saved (audit):",       # spintax skill trailing pointers
    "Saved + opened",
    "Saved to:",
    "Saved:",
)


class Hit(NamedTuple):
    line_number: int      # 1-indexed line number in the source file
    term: str             # the matched spam term as it appears in spam-words.md
    count: int            # how many times the term appears on this line
    line_text: str        # the full line, untruncated


def load_spam_terms(spam_file: Path = DEFAULT_SPAM_FILE) -> List[str]:
    """Parse every bullet-list term from spam-words.md.

    The reference file is a markdown document with categorized sections;
    each spam term is a `- Term` bullet. Section headers and prose are
    ignored.
    """
    if not spam_file.exists():
        raise FileNotFoundError(
            f"spam-words reference not found: {spam_file}\n"
            "Expected at: <plusvibe-spintax>/references/spam-words.md"
        )
    terms: List[str] = []
    for line in spam_file.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^\s*-\s+(.+?)\s*$", line)
        if not m:
            continue
        term = m.group(1).strip()
        # Skip empty or markdown-formatted entries (rare; defensive)
        if term and not term.startswith("#"):
            terms.append(term)
    if not terms:
        raise ValueError(
            f"No terms parsed from {spam_file}. "
            "Check that the file uses `- Term` bullet format."
        )
    return terms


def _should_skip(line: str) -> bool:
    """True if this line is structural metadata and shouldn't be audited."""
    stripped = line.strip()
    if not stripped:
        return True
    return any(stripped.startswith(prefix) for prefix in SKIP_PREFIXES)


def audit_file(path: Path, terms: List[str]) -> List[Hit]:
    """Walk every line in path. Return Hit for every spam-term match in body."""
    if not path.exists():
        raise FileNotFoundError(f"file not found: {path}")
    hits: List[Hit] = []
    # Precompile patterns once. Using lookarounds (not \b) so that hyphens,
    # spintax pipes, and other non-word chars correctly act as boundaries —
    # e.g. "pre-call FAQ" should match `Call` because `-` is not \w.
    compiled = [(t, re.compile(r"(?<!\w)" + re.escape(t) + r"(?!\w)", re.IGNORECASE))
                for t in terms]

    for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if _should_skip(line):
            continue
        # Strip HTML tags so this works on PlusVibe-formatted bodies too.
        plain = re.sub(r"<[^>]+>", " ", line)
        for term, pattern in compiled:
            n = len(pattern.findall(plain))
            if n:
                hits.append(Hit(line_number=i, term=term, count=n, line_text=line))
    return hits


def _format_report(path: Path, terms: List[str], hits: List[Hit]) -> str:
    """Human-readable report. Always prints a summary; details only on hits."""
    out: List[str] = []
    out.append(f"Auditing {path}")
    out.append(f"  against {len(terms)} terms from {DEFAULT_SPAM_FILE.name}")
    out.append("")
    if not hits:
        out.append("CLEAN - no spam-list terms found in email body content.")
        return "\n".join(out)
    # Group by line so multi-hit lines render once.
    by_line = defaultdict(list)
    for hit in hits:
        by_line[hit.line_number].append(hit)
    for line_no in sorted(by_line.keys()):
        line_hits = by_line[line_no]
        terms_summary = ", ".join(f'"{h.term}"x{h.count}' for h in line_hits)
        out.append(f"  Line {line_no}: {terms_summary}")
        # Truncate long spintax lines so the report stays readable.
        snippet = line_hits[0].line_text.strip()
        if len(snippet) > 200:
            snippet = snippet[:200] + " ..."
        out.append(f"    {snippet}")
        out.append("")
    total = sum(h.count for h in hits)
    unique_terms = len({h.term for h in hits})
    out.append(f"TOTAL: {total} hit(s) across {unique_terms} unique term(s) on "
               f"{len(by_line)} line(s).")
    out.append("AUDIT FAILED - fix hits in the file and re-run this script.")
    return "\n".join(out)


def _format_json(path: Path, terms: List[str], hits: List[Hit]) -> str:
    return json.dumps({
        "file": str(path),
        "terms_loaded": len(terms),
        "clean": not hits,
        "total_hits": sum(h.count for h in hits),
        "unique_terms": sorted({h.term for h in hits}),
        "hits": [
            {"line": h.line_number, "term": h.term, "count": h.count,
             "line_text": h.line_text}
            for h in hits
        ],
    }, indent=2)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    p.add_argument("file", type=Path, help="File to audit (final.md, spintaxed.md, etc.)")
    p.add_argument("--json", action="store_true", help="Machine-readable JSON output")
    p.add_argument("--quiet", action="store_true",
                   help="Only print summary line (no per-line details)")
    p.add_argument("--spam-file", type=Path, default=DEFAULT_SPAM_FILE,
                   help="Override the spam-words reference path")
    args = p.parse_args()

    if not args.file.exists():
        sys.stderr.write(f"ERROR: file not found: {args.file}\n")
        return 2

    try:
        terms = load_spam_terms(args.spam_file)
    except (FileNotFoundError, ValueError) as exc:
        sys.stderr.write(f"ERROR: {exc}\n")
        return 2

    hits = audit_file(args.file, terms)

    if args.json:
        print(_format_json(args.file, terms, hits))
    elif args.quiet:
        if hits:
            total = sum(h.count for h in hits)
            unique = len({h.term for h in hits})
            print(f"FAIL: {total} spam-word hit(s), {unique} unique term(s) in {args.file}")
        else:
            print(f"CLEAN: {args.file}")
    else:
        print(_format_report(args.file, terms, hits))

    return 1 if hits else 0


if __name__ == "__main__":
    sys.exit(main())
